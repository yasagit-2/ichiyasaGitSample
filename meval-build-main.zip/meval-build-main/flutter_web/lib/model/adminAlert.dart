import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'adminAlert.freezed.dart';
part 'adminAlert.g.dart';

@freezed
class AdminAlert with _$AdminAlert {
  @firestoreSerializable
  const factory AdminAlert({
    // 行政投稿（注意）ID
    required String? id,
    // 行政投稿（注意）メッセージ
    required String? message,
    // 投稿の座標
    required MapPosition position,
    // 行政投稿（注意）期限
    @TimestampConverter() DateTime? dueDate,
    // 行政投稿（注意）画像のURL
    // 行政投稿（注意）画像が存在しない場合は省略。
    String? imageUrl,
    // 行政投稿（注意）の保存先
    // 行政投稿（注意）画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：adminAlerts/9b823250-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
    String? imagePath,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _AdminAlert;

  factory AdminAlert.fromJson(Map<String, Object?> json) =>
      _$AdminAlertFromJson(json);
}

@Collection<AdminAlert>('adminAlerts')
final adminAlertsRef = AdminAlertCollectionReference();

AdminAlertDocumentReference adminAlertRef({required String id}) =>
    AdminAlertDocumentReference(adminAlertsRef.doc(id).reference);

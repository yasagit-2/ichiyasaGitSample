import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'base.freezed.dart';
part 'base.g.dart';

@freezed
class Base with _$Base {
  @firestoreSerializable
  const factory Base({
    // 拠点ID
    required String id,
    // 拠点名
    required String name,
    // 親拠点のReference（サブ拠点の場合）
    @DocumentReferenceConverter() DocumentReference? parentRef,
    // 拠点の位置情報
    required MapPosition position,
    // 称号のReference
    @DocumentReferenceConverter() DocumentReference? titleRef,
    // サブ拠点数（サブ拠点の場合は0）
    @Default(0) int subBaseCount,
    // 拠点画像のURL
    String? imageUrl,
    // 拠点画像の保存先
    String? imagePath,
    // 有効期間開始
    DateTime? effectivePeriodBegin,
    // 有効期間終了
    DateTime? effectivePeriodEnd,
    // 有効曜日
    List<int>? effectiveDaysOfWeek,
    // 有効時刻開始
    String? effectiveTimeBegin,
    // 有効時刻終了
    String? effectiveTimeEnd,
    // 公開ステータス
    required int publishStatus,
    // 獲得ポイント
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Base;

  factory Base.fromJson(Map<String, Object?> json) => _$BaseFromJson(json);
}

@Collection<Base>('bases')
@Collection<BaseTransaction>('bases/*/baseTransactions',
    name: 'baseTransactions')
final basesRef = BaseCollectionReference();

BaseDocumentReference baseRef({required String id}) =>
    BaseDocumentReference(basesRef.doc(id).reference);

@freezed
class BaseTransaction with _$BaseTransaction {
  @firestoreSerializable
  const factory BaseTransaction({
    // ポイント付与制限人数残り
    required int pointLimitRemain,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _BaseTransaction;

  factory BaseTransaction.fromJson(Map<String, Object?> json) =>
      _$BaseTransactionFromJson(json);
}

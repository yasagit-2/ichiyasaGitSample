import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'setting.freezed.dart';
part 'setting.g.dart';

@freezed
class Setting with _$Setting {
  @firestoreSerializable
  const factory Setting({
    // 拠点アイコンURL
    // マップに表示するアイコンのURL。
    required String? baseIconUrl,
    // チェックイン済み拠点アイコンURL
    // （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、
    required String? baseCheckedInIconUrl,
    // サブ拠点アイコンURL
    // 　アプリケーション側にてデフォルトアイコンが利用される。）
    required String? subBaseIconUrl,
    // 加盟店アイコンURL
    required String? merchantIconUrl,
    // 加盟店つぶやきアイコンURL
    required String? merchantTweetIconUrl,
    // 投稿アイコンURL
    required String? postIconUrl,
    // 行政投稿アラートアイコンURL
    required String? adminAlertIconUrl,
    // 行政投稿アンケートアイコンURL
    required String? adminQuestionnaireIconUrl,
    // チェックイン可能距離（meter）
    // チェックインを可能とする拠点の半径（meter）。小数設定可（例：200.0）。
    required int checkInRadius,
    // 拠点/投稿/加盟店収集半径（km）
    // 取得対象とする拠点/投稿/加盟店のマップ中心位置からの半径（km）。小数設定可（例：10.5）。
    required int collectionRadius,
    // 週間規定歩数
    // ポイント獲得に必要な週間の規定歩数。（例：35000）少数設定不可。
    required int targetStepPerWeek,
    // 週間規定歩数達成ポイント
    // 週間規定歩数を達成することにより獲得できるポイント数。少数設定不可。
    required int stepAchievedPoint,
    // 投稿間隔制限（hour）
    // 投稿間隔の制限時間（hour）。少数設定不可。
    required int postIntervalLimitHour,
    // 行政報告間隔制限（hour）
    // 行政報告間隔の制限時間（hour）。少数設定不可。
    required int reportIntervalLimitHour,
    // コメント間隔制限（minute）
    // コメント間隔の制限時間（minute）。一つの投稿へコメントを行うと、その他の投稿にも間隔制限が経過するまではコメント不可。少数設定不可。
    required int commentIntervalLimitMinute,
    // お知らせ保存日数
    // お知らせ有効期限終了（memberNotificationsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したお知らせは物理削除する。少数設定不可。
    required int notificationRetentionDay,
    // イベント保存日数
    // イベント開催期間終了（eventsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したイベントは物理削除する。少数設定不可。
    required int eventRetentionDay,
    // 会員削除猶予日数
    // 退会申請が行われてから、会員情報を物理削除するまでの猶予日数。少数設定不可。
    required int memberDeletionGraceDay,
    // ヘルプページURL
    // ヘルプページのURL。マイページからこのURLへアクセスする。
    required String? helpPageUrl,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Setting;

  factory Setting.fromJson(Map<String, Object?> json) =>
      _$SettingFromJson(json);
}

@Collection<Setting>('settings')
final settingsRef = SettingCollectionReference();

SettingDocumentReference settingRef({required String id}) =>
    SettingDocumentReference(settingsRef.doc(id).reference);

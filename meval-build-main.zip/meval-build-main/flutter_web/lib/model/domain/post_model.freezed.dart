// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'post_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$PostModel {
// 投稿ID
  String? get id => throw _privateConstructorUsedError; // 投稿メッセージ
  String? get message => throw _privateConstructorUsedError; // 会員のリファレンス
  DocumentReference<Object?>? get memberRef =>
      throw _privateConstructorUsedError; // 投稿の座標
  MapPosition get position => throw _privateConstructorUsedError; // 投稿画像のURL
// 投稿画像が存在しない場合は省略。
  String? get imageUrl => throw _privateConstructorUsedError; // 投稿画像の保存先
// 投稿画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：posts/会員ID/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は投稿ID）
  String? get imagePath => throw _privateConstructorUsedError; // いいね数
  int get likeCount => throw _privateConstructorUsedError; // 投稿の表示/非表示
// 0：表示、1：非表示
  int get visibleStatus => throw _privateConstructorUsedError; // 更新日時
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  DateTime? get createdAt => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PostModelCopyWith<PostModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostModelCopyWith<$Res> {
  factory $PostModelCopyWith(PostModel value, $Res Function(PostModel) then) =
      _$PostModelCopyWithImpl<$Res, PostModel>;
  @useResult
  $Res call(
      {String? id,
      String? message,
      DocumentReference<Object?>? memberRef,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int likeCount,
      int visibleStatus,
      DateTime? updatedAt,
      DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$PostModelCopyWithImpl<$Res, $Val extends PostModel>
    implements $PostModelCopyWith<$Res> {
  _$PostModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? memberRef = freezed,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? likeCount = null,
    Object? visibleStatus = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      memberRef: freezed == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      visibleStatus: null == visibleStatus
          ? _value.visibleStatus
          : visibleStatus // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_PostModelCopyWith<$Res> implements $PostModelCopyWith<$Res> {
  factory _$$_PostModelCopyWith(
          _$_PostModel value, $Res Function(_$_PostModel) then) =
      __$$_PostModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? message,
      DocumentReference<Object?>? memberRef,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int likeCount,
      int visibleStatus,
      DateTime? updatedAt,
      DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_PostModelCopyWithImpl<$Res>
    extends _$PostModelCopyWithImpl<$Res, _$_PostModel>
    implements _$$_PostModelCopyWith<$Res> {
  __$$_PostModelCopyWithImpl(
      _$_PostModel _value, $Res Function(_$_PostModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? memberRef = freezed,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? likeCount = null,
    Object? visibleStatus = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PostModel(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      memberRef: freezed == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      visibleStatus: null == visibleStatus
          ? _value.visibleStatus
          : visibleStatus // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$_PostModel implements _PostModel {
  const _$_PostModel(
      {required this.id,
      required this.message,
      required this.memberRef,
      required this.position,
      this.imageUrl,
      this.imagePath,
      required this.likeCount,
      required this.visibleStatus,
      this.updatedAt,
      this.createdAt});

// 投稿ID
  @override
  final String? id;
// 投稿メッセージ
  @override
  final String? message;
// 会員のリファレンス
  @override
  final DocumentReference<Object?>? memberRef;
// 投稿の座標
  @override
  final MapPosition position;
// 投稿画像のURL
// 投稿画像が存在しない場合は省略。
  @override
  final String? imageUrl;
// 投稿画像の保存先
// 投稿画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：posts/会員ID/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は投稿ID）
  @override
  final String? imagePath;
// いいね数
  @override
  final int likeCount;
// 投稿の表示/非表示
// 0：表示、1：非表示
  @override
  final int visibleStatus;
// 更新日時
  @override
  final DateTime? updatedAt;
// 登録日時
  @override
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PostModel(id: $id, message: $message, memberRef: $memberRef, position: $position, imageUrl: $imageUrl, imagePath: $imagePath, likeCount: $likeCount, visibleStatus: $visibleStatus, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PostModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount) &&
            (identical(other.visibleStatus, visibleStatus) ||
                other.visibleStatus == visibleStatus) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, message, memberRef, position,
      imageUrl, imagePath, likeCount, visibleStatus, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostModelCopyWith<_$_PostModel> get copyWith =>
      __$$_PostModelCopyWithImpl<_$_PostModel>(this, _$identity);
}

abstract class _PostModel implements PostModel {
  const factory _PostModel(
      {required final String? id,
      required final String? message,
      required final DocumentReference<Object?>? memberRef,
      required final MapPosition position,
      final String? imageUrl,
      final String? imagePath,
      required final int likeCount,
      required final int visibleStatus,
      final DateTime? updatedAt,
      final DateTime? createdAt}) = _$_PostModel;

  @override // 投稿ID
  String? get id;
  @override // 投稿メッセージ
  String? get message;
  @override // 会員のリファレンス
  DocumentReference<Object?>? get memberRef;
  @override // 投稿の座標
  MapPosition get position;
  @override // 投稿画像のURL
// 投稿画像が存在しない場合は省略。
  String? get imageUrl;
  @override // 投稿画像の保存先
// 投稿画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：posts/会員ID/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は投稿ID）
  String? get imagePath;
  @override // いいね数
  int get likeCount;
  @override // 投稿の表示/非表示
// 0：表示、1：非表示
  int get visibleStatus;
  @override // 更新日時
  DateTime? get updatedAt;
  @override // 登録日時
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostModelCopyWith<_$_PostModel> get copyWith =>
      throw _privateConstructorUsedError;
}

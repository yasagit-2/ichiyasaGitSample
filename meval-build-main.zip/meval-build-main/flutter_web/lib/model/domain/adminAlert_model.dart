import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../map_position.dart';

part 'adminAlert_model.freezed.dart';

@freezed
class AdminAlertModel with _$AdminAlertModel {
  const factory AdminAlertModel({
    // 行政投稿（注意）ID
    required String? id,
    // 行政投稿（注意）メッセージ
    required String? message,
    // 行政投稿の位置情報
    required MapPosition position,
    // 行政投稿（注意）期限
    required DateTime? dueDate,
    // 行政投稿（注意）画像のURL
    // 行政投稿（注意）画像が存在しない場合は省略。
    String? imageUrl,
    // 行政投稿（注意）の保存先
    // 行政投稿（注意）画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：adminAlerts/9b823250-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
    String? imagePath,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _AdminAlertModel;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../map_position.dart';
part 'merchant_model.freezed.dart';

@freezed
class MerchantModel with _$MerchantModel {
  const factory MerchantModel({
    // 加盟店ID
    required String? id,
    // 加盟店名称
    required String? name,
    // 加盟店画像のURL
    // 加盟店画像が存在しない場合は省略。
    String? imageUrl,
    // 加盟店画像の保存先
    // 加盟店画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：merchants/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は特に規定しない）
    String? imagePath,
    // 加盟店の座標
    required MapPosition position,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _MerchantModel;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'member_model.freezed.dart';

@freezed
class MemberModel with _$MemberModel {
  const factory MemberModel({
    // 会員ID
    // Firebase Authenticationによって採番されるID。
    required String? id,
    // ニックネーム
    required String? nickname,
    // 生年月
    required DateTime? monthOfBirth,
    // 性別
    // 「男性」「女性」「その他」「回答しない」のうちいずれかを設定。
    required String? gender,
    // 居住地
    required String? prefecture,
    // 認証プロバイダ
    // 認証プロバイダを識別するための文字列。「sms」「google」「apple」「facebook」「twitter」のうちいずれかを設定。
    required String? authenticationProvider,
    // 投稿日時
    // 投稿を行った最終日時。初期値はUNIXエポック。
    required DateTime? postedAt,
    // 行政報告日時
    // 行政報告を行った最終日時。初期値はUNIXエポック。
    required DateTime? reportedAt,
    // コメント日時
    // コメントを行った最終日時。初期値はUNIXエポック。
    required DateTime? commentedAt,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _MemberModel;
}

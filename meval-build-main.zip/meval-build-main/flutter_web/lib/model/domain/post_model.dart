import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../map_position.dart';

part 'post_model.freezed.dart';

@freezed
class PostModel with _$PostModel {
  const factory PostModel({
    // 投稿ID
    required String? id,
    // 投稿メッセージ
    required String? message,
    // 会員のリファレンス
    required DocumentReference? memberRef,
    // 投稿の座標
    required MapPosition position,
    // 投稿画像のURL
    // 投稿画像が存在しない場合は省略。
    String? imageUrl,
    // 投稿画像の保存先
    // 投稿画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：posts/会員ID/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は投稿ID）
    String? imagePath,
    // いいね数
    required int likeCount,
    // 投稿の表示/非表示
    // 0：表示、1：非表示
    required int visibleStatus,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _PostModel;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../map_position.dart';

part 'adminQuestionnaire_model.freezed.dart';

@freezed
class AdminQuestionnaireModel with _$AdminQuestionnaireModel {
  const factory AdminQuestionnaireModel({
    // 行政投稿（アンケート）ID
    required String? id,
    // 行政投稿（アンケート）メッセージ
    required String? message,
    // 行政投稿の位置情報
    required MapPosition position,
    // 行政投稿（アンケート）期限
    required DateTime? dueDate,
    // 行政投稿（アンケート）画像のURL
    // 行政投稿（アンケート）画像が存在しない場合は省略。
    String? imageUrl,
    // 行政投稿（アンケート）の保存先
    // imageUrlを設定する場合は必須。例：adminQuestionnaires/c9ba78d0-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
    String? imagePath,
    // アンケート回答獲得ポイント
    // アンケート回答により獲得できるポイント。
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _AdminQuestionnaireModel;
}

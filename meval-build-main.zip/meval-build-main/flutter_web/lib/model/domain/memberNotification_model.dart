import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'memberNotification_model.freezed.dart';

@freezed
class MemberNotificationModel with _$MemberNotificationModel {
  const factory MemberNotificationModel({
    // お知らせID
    required String id,
    // お知らせタイトル
    required String title,
    // お知らせコンテンツURL
    // 管理画面にて登録するお知らせコンテンツのURL。お知らせのコンテンツが存在しない場合を考慮し省略可。
    String? contentUrl,
    // 有効期間開始
    required DateTime? effectivePeriodBegin,
    // 有効期間終了
    required DateTime? effectivePeriodEnd,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _MemberNotificationModel;
}

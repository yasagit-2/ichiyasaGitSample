// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'postIcon_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$PostIconModel {
// いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  String get unitOfLikePostIconUrl =>
      throw _privateConstructorUsedError; // いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  int get likeCount => throw _privateConstructorUsedError; // 更新日時
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  DateTime? get createdAt => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PostIconModelCopyWith<PostIconModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostIconModelCopyWith<$Res> {
  factory $PostIconModelCopyWith(
          PostIconModel value, $Res Function(PostIconModel) then) =
      _$PostIconModelCopyWithImpl<$Res, PostIconModel>;
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class _$PostIconModelCopyWithImpl<$Res, $Val extends PostIconModel>
    implements $PostIconModelCopyWith<$Res> {
  _$PostIconModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PostIconModelCopyWith<$Res>
    implements $PostIconModelCopyWith<$Res> {
  factory _$$_PostIconModelCopyWith(
          _$_PostIconModel value, $Res Function(_$_PostIconModel) then) =
      __$$_PostIconModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class __$$_PostIconModelCopyWithImpl<$Res>
    extends _$PostIconModelCopyWithImpl<$Res, _$_PostIconModel>
    implements _$$_PostIconModelCopyWith<$Res> {
  __$$_PostIconModelCopyWithImpl(
      _$_PostIconModel _value, $Res Function(_$_PostIconModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PostIconModel(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$_PostIconModel implements _PostIconModel {
  const _$_PostIconModel(
      {required this.unitOfLikePostIconUrl,
      required this.likeCount,
      this.updatedAt,
      this.createdAt});

// いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  @override
  final String unitOfLikePostIconUrl;
// いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  @override
  final int likeCount;
// 更新日時
  @override
  final DateTime? updatedAt;
// 登録日時
  @override
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PostIconModel(unitOfLikePostIconUrl: $unitOfLikePostIconUrl, likeCount: $likeCount, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PostIconModel &&
            (identical(other.unitOfLikePostIconUrl, unitOfLikePostIconUrl) ||
                other.unitOfLikePostIconUrl == unitOfLikePostIconUrl) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, unitOfLikePostIconUrl, likeCount, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostIconModelCopyWith<_$_PostIconModel> get copyWith =>
      __$$_PostIconModelCopyWithImpl<_$_PostIconModel>(this, _$identity);
}

abstract class _PostIconModel implements PostIconModel {
  const factory _PostIconModel(
      {required final String unitOfLikePostIconUrl,
      required final int likeCount,
      final DateTime? updatedAt,
      final DateTime? createdAt}) = _$_PostIconModel;

  @override // いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  String get unitOfLikePostIconUrl;
  @override // いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  int get likeCount;
  @override // 更新日時
  DateTime? get updatedAt;
  @override // 登録日時
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostIconModelCopyWith<_$_PostIconModel> get copyWith =>
      throw _privateConstructorUsedError;
}

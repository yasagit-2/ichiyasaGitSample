// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'member_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MemberModel {
// 会員ID
// Firebase Authenticationによって採番されるID。
  String? get id => throw _privateConstructorUsedError; // ニックネーム
  String? get nickname => throw _privateConstructorUsedError; // 生年月
  DateTime? get monthOfBirth => throw _privateConstructorUsedError; // 性別
// 「男性」「女性」「その他」「回答しない」のうちいずれかを設定。
  String? get gender => throw _privateConstructorUsedError; // 居住地
  String? get prefecture => throw _privateConstructorUsedError; // 認証プロバイダ
// 認証プロバイダを識別するための文字列。「sms」「google」「apple」「facebook」「twitter」のうちいずれかを設定。
  String? get authenticationProvider =>
      throw _privateConstructorUsedError; // 投稿日時
// 投稿を行った最終日時。初期値はUNIXエポック。
  DateTime? get postedAt => throw _privateConstructorUsedError; // 行政報告日時
// 行政報告を行った最終日時。初期値はUNIXエポック。
  DateTime? get reportedAt => throw _privateConstructorUsedError; // コメント日時
// コメントを行った最終日時。初期値はUNIXエポック。
  DateTime? get commentedAt => throw _privateConstructorUsedError; // 更新日時
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  DateTime? get createdAt => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MemberModelCopyWith<MemberModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MemberModelCopyWith<$Res> {
  factory $MemberModelCopyWith(
          MemberModel value, $Res Function(MemberModel) then) =
      _$MemberModelCopyWithImpl<$Res, MemberModel>;
  @useResult
  $Res call(
      {String? id,
      String? nickname,
      DateTime? monthOfBirth,
      String? gender,
      String? prefecture,
      String? authenticationProvider,
      DateTime? postedAt,
      DateTime? reportedAt,
      DateTime? commentedAt,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class _$MemberModelCopyWithImpl<$Res, $Val extends MemberModel>
    implements $MemberModelCopyWith<$Res> {
  _$MemberModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? nickname = freezed,
    Object? monthOfBirth = freezed,
    Object? gender = freezed,
    Object? prefecture = freezed,
    Object? authenticationProvider = freezed,
    Object? postedAt = freezed,
    Object? reportedAt = freezed,
    Object? commentedAt = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      nickname: freezed == nickname
          ? _value.nickname
          : nickname // ignore: cast_nullable_to_non_nullable
              as String?,
      monthOfBirth: freezed == monthOfBirth
          ? _value.monthOfBirth
          : monthOfBirth // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      prefecture: freezed == prefecture
          ? _value.prefecture
          : prefecture // ignore: cast_nullable_to_non_nullable
              as String?,
      authenticationProvider: freezed == authenticationProvider
          ? _value.authenticationProvider
          : authenticationProvider // ignore: cast_nullable_to_non_nullable
              as String?,
      postedAt: freezed == postedAt
          ? _value.postedAt
          : postedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      reportedAt: freezed == reportedAt
          ? _value.reportedAt
          : reportedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      commentedAt: freezed == commentedAt
          ? _value.commentedAt
          : commentedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MemberModelCopyWith<$Res>
    implements $MemberModelCopyWith<$Res> {
  factory _$$_MemberModelCopyWith(
          _$_MemberModel value, $Res Function(_$_MemberModel) then) =
      __$$_MemberModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? nickname,
      DateTime? monthOfBirth,
      String? gender,
      String? prefecture,
      String? authenticationProvider,
      DateTime? postedAt,
      DateTime? reportedAt,
      DateTime? commentedAt,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class __$$_MemberModelCopyWithImpl<$Res>
    extends _$MemberModelCopyWithImpl<$Res, _$_MemberModel>
    implements _$$_MemberModelCopyWith<$Res> {
  __$$_MemberModelCopyWithImpl(
      _$_MemberModel _value, $Res Function(_$_MemberModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? nickname = freezed,
    Object? monthOfBirth = freezed,
    Object? gender = freezed,
    Object? prefecture = freezed,
    Object? authenticationProvider = freezed,
    Object? postedAt = freezed,
    Object? reportedAt = freezed,
    Object? commentedAt = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_MemberModel(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      nickname: freezed == nickname
          ? _value.nickname
          : nickname // ignore: cast_nullable_to_non_nullable
              as String?,
      monthOfBirth: freezed == monthOfBirth
          ? _value.monthOfBirth
          : monthOfBirth // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      prefecture: freezed == prefecture
          ? _value.prefecture
          : prefecture // ignore: cast_nullable_to_non_nullable
              as String?,
      authenticationProvider: freezed == authenticationProvider
          ? _value.authenticationProvider
          : authenticationProvider // ignore: cast_nullable_to_non_nullable
              as String?,
      postedAt: freezed == postedAt
          ? _value.postedAt
          : postedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      reportedAt: freezed == reportedAt
          ? _value.reportedAt
          : reportedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      commentedAt: freezed == commentedAt
          ? _value.commentedAt
          : commentedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$_MemberModel implements _MemberModel {
  const _$_MemberModel(
      {required this.id,
      required this.nickname,
      required this.monthOfBirth,
      required this.gender,
      required this.prefecture,
      required this.authenticationProvider,
      required this.postedAt,
      required this.reportedAt,
      required this.commentedAt,
      this.updatedAt,
      this.createdAt});

// 会員ID
// Firebase Authenticationによって採番されるID。
  @override
  final String? id;
// ニックネーム
  @override
  final String? nickname;
// 生年月
  @override
  final DateTime? monthOfBirth;
// 性別
// 「男性」「女性」「その他」「回答しない」のうちいずれかを設定。
  @override
  final String? gender;
// 居住地
  @override
  final String? prefecture;
// 認証プロバイダ
// 認証プロバイダを識別するための文字列。「sms」「google」「apple」「facebook」「twitter」のうちいずれかを設定。
  @override
  final String? authenticationProvider;
// 投稿日時
// 投稿を行った最終日時。初期値はUNIXエポック。
  @override
  final DateTime? postedAt;
// 行政報告日時
// 行政報告を行った最終日時。初期値はUNIXエポック。
  @override
  final DateTime? reportedAt;
// コメント日時
// コメントを行った最終日時。初期値はUNIXエポック。
  @override
  final DateTime? commentedAt;
// 更新日時
  @override
  final DateTime? updatedAt;
// 登録日時
  @override
  final DateTime? createdAt;

  @override
  String toString() {
    return 'MemberModel(id: $id, nickname: $nickname, monthOfBirth: $monthOfBirth, gender: $gender, prefecture: $prefecture, authenticationProvider: $authenticationProvider, postedAt: $postedAt, reportedAt: $reportedAt, commentedAt: $commentedAt, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MemberModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.nickname, nickname) ||
                other.nickname == nickname) &&
            (identical(other.monthOfBirth, monthOfBirth) ||
                other.monthOfBirth == monthOfBirth) &&
            (identical(other.gender, gender) || other.gender == gender) &&
            (identical(other.prefecture, prefecture) ||
                other.prefecture == prefecture) &&
            (identical(other.authenticationProvider, authenticationProvider) ||
                other.authenticationProvider == authenticationProvider) &&
            (identical(other.postedAt, postedAt) ||
                other.postedAt == postedAt) &&
            (identical(other.reportedAt, reportedAt) ||
                other.reportedAt == reportedAt) &&
            (identical(other.commentedAt, commentedAt) ||
                other.commentedAt == commentedAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      nickname,
      monthOfBirth,
      gender,
      prefecture,
      authenticationProvider,
      postedAt,
      reportedAt,
      commentedAt,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MemberModelCopyWith<_$_MemberModel> get copyWith =>
      __$$_MemberModelCopyWithImpl<_$_MemberModel>(this, _$identity);
}

abstract class _MemberModel implements MemberModel {
  const factory _MemberModel(
      {required final String? id,
      required final String? nickname,
      required final DateTime? monthOfBirth,
      required final String? gender,
      required final String? prefecture,
      required final String? authenticationProvider,
      required final DateTime? postedAt,
      required final DateTime? reportedAt,
      required final DateTime? commentedAt,
      final DateTime? updatedAt,
      final DateTime? createdAt}) = _$_MemberModel;

  @override // 会員ID
// Firebase Authenticationによって採番されるID。
  String? get id;
  @override // ニックネーム
  String? get nickname;
  @override // 生年月
  DateTime? get monthOfBirth;
  @override // 性別
// 「男性」「女性」「その他」「回答しない」のうちいずれかを設定。
  String? get gender;
  @override // 居住地
  String? get prefecture;
  @override // 認証プロバイダ
// 認証プロバイダを識別するための文字列。「sms」「google」「apple」「facebook」「twitter」のうちいずれかを設定。
  String? get authenticationProvider;
  @override // 投稿日時
// 投稿を行った最終日時。初期値はUNIXエポック。
  DateTime? get postedAt;
  @override // 行政報告日時
// 行政報告を行った最終日時。初期値はUNIXエポック。
  DateTime? get reportedAt;
  @override // コメント日時
// コメントを行った最終日時。初期値はUNIXエポック。
  DateTime? get commentedAt;
  @override // 更新日時
  DateTime? get updatedAt;
  @override // 登録日時
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MemberModelCopyWith<_$_MemberModel> get copyWith =>
      throw _privateConstructorUsedError;
}

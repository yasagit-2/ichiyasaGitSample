// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'maintenance_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MaintenanceModel {
// アプリケーションバージョン
// アプリケーションのバージョン（例：1.0.0）
  String? get version =>
      throw _privateConstructorUsedError; // Apple App StoreのURL
// ストア登録時に発行されるApple App StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  String? get appStoreUrl =>
      throw _privateConstructorUsedError; // Google Play StoreのURL
// ストア登録時に発行されるGoogle Play StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  String? get playStoreUrl => throw _privateConstructorUsedError; // メンテナンスフラグ
// true：メンテナンス中（メンテナンス中はアプリ利用不可、強制ログアウト）
  bool get isMaintenance => throw _privateConstructorUsedError; // 更新日時
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  DateTime? get createdAt => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MaintenanceModelCopyWith<MaintenanceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MaintenanceModelCopyWith<$Res> {
  factory $MaintenanceModelCopyWith(
          MaintenanceModel value, $Res Function(MaintenanceModel) then) =
      _$MaintenanceModelCopyWithImpl<$Res, MaintenanceModel>;
  @useResult
  $Res call(
      {String? version,
      String? appStoreUrl,
      String? playStoreUrl,
      bool isMaintenance,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class _$MaintenanceModelCopyWithImpl<$Res, $Val extends MaintenanceModel>
    implements $MaintenanceModelCopyWith<$Res> {
  _$MaintenanceModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? version = freezed,
    Object? appStoreUrl = freezed,
    Object? playStoreUrl = freezed,
    Object? isMaintenance = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      version: freezed == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String?,
      appStoreUrl: freezed == appStoreUrl
          ? _value.appStoreUrl
          : appStoreUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      playStoreUrl: freezed == playStoreUrl
          ? _value.playStoreUrl
          : playStoreUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isMaintenance: null == isMaintenance
          ? _value.isMaintenance
          : isMaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MaintenanceModelCopyWith<$Res>
    implements $MaintenanceModelCopyWith<$Res> {
  factory _$$_MaintenanceModelCopyWith(
          _$_MaintenanceModel value, $Res Function(_$_MaintenanceModel) then) =
      __$$_MaintenanceModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? version,
      String? appStoreUrl,
      String? playStoreUrl,
      bool isMaintenance,
      DateTime? updatedAt,
      DateTime? createdAt});
}

/// @nodoc
class __$$_MaintenanceModelCopyWithImpl<$Res>
    extends _$MaintenanceModelCopyWithImpl<$Res, _$_MaintenanceModel>
    implements _$$_MaintenanceModelCopyWith<$Res> {
  __$$_MaintenanceModelCopyWithImpl(
      _$_MaintenanceModel _value, $Res Function(_$_MaintenanceModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? version = freezed,
    Object? appStoreUrl = freezed,
    Object? playStoreUrl = freezed,
    Object? isMaintenance = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_MaintenanceModel(
      version: freezed == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String?,
      appStoreUrl: freezed == appStoreUrl
          ? _value.appStoreUrl
          : appStoreUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      playStoreUrl: freezed == playStoreUrl
          ? _value.playStoreUrl
          : playStoreUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isMaintenance: null == isMaintenance
          ? _value.isMaintenance
          : isMaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$_MaintenanceModel implements _MaintenanceModel {
  const _$_MaintenanceModel(
      {required this.version,
      required this.appStoreUrl,
      required this.playStoreUrl,
      required this.isMaintenance,
      this.updatedAt,
      this.createdAt});

// アプリケーションバージョン
// アプリケーションのバージョン（例：1.0.0）
  @override
  final String? version;
// Apple App StoreのURL
// ストア登録時に発行されるApple App StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  @override
  final String? appStoreUrl;
// Google Play StoreのURL
// ストア登録時に発行されるGoogle Play StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  @override
  final String? playStoreUrl;
// メンテナンスフラグ
// true：メンテナンス中（メンテナンス中はアプリ利用不可、強制ログアウト）
  @override
  final bool isMaintenance;
// 更新日時
  @override
  final DateTime? updatedAt;
// 登録日時
  @override
  final DateTime? createdAt;

  @override
  String toString() {
    return 'MaintenanceModel(version: $version, appStoreUrl: $appStoreUrl, playStoreUrl: $playStoreUrl, isMaintenance: $isMaintenance, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MaintenanceModel &&
            (identical(other.version, version) || other.version == version) &&
            (identical(other.appStoreUrl, appStoreUrl) ||
                other.appStoreUrl == appStoreUrl) &&
            (identical(other.playStoreUrl, playStoreUrl) ||
                other.playStoreUrl == playStoreUrl) &&
            (identical(other.isMaintenance, isMaintenance) ||
                other.isMaintenance == isMaintenance) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @override
  int get hashCode => Object.hash(runtimeType, version, appStoreUrl,
      playStoreUrl, isMaintenance, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MaintenanceModelCopyWith<_$_MaintenanceModel> get copyWith =>
      __$$_MaintenanceModelCopyWithImpl<_$_MaintenanceModel>(this, _$identity);
}

abstract class _MaintenanceModel implements MaintenanceModel {
  const factory _MaintenanceModel(
      {required final String? version,
      required final String? appStoreUrl,
      required final String? playStoreUrl,
      required final bool isMaintenance,
      final DateTime? updatedAt,
      final DateTime? createdAt}) = _$_MaintenanceModel;

  @override // アプリケーションバージョン
// アプリケーションのバージョン（例：1.0.0）
  String? get version;
  @override // Apple App StoreのURL
// ストア登録時に発行されるApple App StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  String? get appStoreUrl;
  @override // Google Play StoreのURL
// ストア登録時に発行されるGoogle Play StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
  String? get playStoreUrl;
  @override // メンテナンスフラグ
// true：メンテナンス中（メンテナンス中はアプリ利用不可、強制ログアウト）
  bool get isMaintenance;
  @override // 更新日時
  DateTime? get updatedAt;
  @override // 登録日時
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MaintenanceModelCopyWith<_$_MaintenanceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../map_position.dart';
part 'base_model.freezed.dart';

@freezed
class BaseModel with _$BaseModel {
  const factory BaseModel({
    // 拠点ID
    required String id,
    // 拠点名
    required String name,
    // 親拠点のReference（サブ拠点の場合）
    DocumentReference? parentRef,
    // 拠点の位置情報
    required MapPosition position,
    // 称号のReference
    DocumentReference? titleRef,
    // サブ拠点数（サブ拠点の場合は0）
    @Default(0) int subBaseCount,
    // 拠点画像のURL
    String? imageUrl,
    // 拠点画像の保存先
    String? imagePath,
    // 有効期間開始
    DateTime? effectivePeriodBegin,
    // 有効期間終了
    DateTime? effectivePeriodEnd,
    // 有効曜日
    List<int>? effectiveDaysOfWeek,
    // 有効時刻開始
    String? effectiveTimeBegin,
    // 有効時刻終了
    String? effectiveTimeEnd,
    // 公開ステータス
    required int publishStatus,
    // 獲得ポイント
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
    // ポイント付与制限人数残り
    required int pointLimitRemain,
  }) = _BaseModel;
}

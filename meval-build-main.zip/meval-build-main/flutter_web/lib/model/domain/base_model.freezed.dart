// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'base_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$BaseModel {
// 拠点ID
  String get id => throw _privateConstructorUsedError; // 拠点名
  String get name =>
      throw _privateConstructorUsedError; // 親拠点のReference（サブ拠点の場合）
  DocumentReference<Object?>? get parentRef =>
      throw _privateConstructorUsedError; // 拠点の位置情報
  MapPosition get position =>
      throw _privateConstructorUsedError; // 称号のReference
  DocumentReference<Object?>? get titleRef =>
      throw _privateConstructorUsedError; // サブ拠点数（サブ拠点の場合は0）
  int get subBaseCount => throw _privateConstructorUsedError; // 拠点画像のURL
  String? get imageUrl => throw _privateConstructorUsedError; // 拠点画像の保存先
  String? get imagePath => throw _privateConstructorUsedError; // 有効期間開始
  DateTime? get effectivePeriodBegin =>
      throw _privateConstructorUsedError; // 有効期間終了
  DateTime? get effectivePeriodEnd =>
      throw _privateConstructorUsedError; // 有効曜日
  List<int>? get effectiveDaysOfWeek =>
      throw _privateConstructorUsedError; // 有効時刻開始
  String? get effectiveTimeBegin =>
      throw _privateConstructorUsedError; // 有効時刻終了
  String? get effectiveTimeEnd => throw _privateConstructorUsedError; // 公開ステータス
  int get publishStatus => throw _privateConstructorUsedError; // 獲得ポイント
  int get point => throw _privateConstructorUsedError; // ポイント付与制限人数
  int get pointLimit => throw _privateConstructorUsedError; // 更新日時
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  DateTime? get createdAt => throw _privateConstructorUsedError; // ポイント付与制限人数残り
  int get pointLimitRemain => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $BaseModelCopyWith<BaseModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BaseModelCopyWith<$Res> {
  factory $BaseModelCopyWith(BaseModel value, $Res Function(BaseModel) then) =
      _$BaseModelCopyWithImpl<$Res, BaseModel>;
  @useResult
  $Res call(
      {String id,
      String name,
      DocumentReference<Object?>? parentRef,
      MapPosition position,
      DocumentReference<Object?>? titleRef,
      int subBaseCount,
      String? imageUrl,
      String? imagePath,
      DateTime? effectivePeriodBegin,
      DateTime? effectivePeriodEnd,
      List<int>? effectiveDaysOfWeek,
      String? effectiveTimeBegin,
      String? effectiveTimeEnd,
      int publishStatus,
      int point,
      int pointLimit,
      DateTime? updatedAt,
      DateTime? createdAt,
      int pointLimitRemain});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$BaseModelCopyWithImpl<$Res, $Val extends BaseModel>
    implements $BaseModelCopyWith<$Res> {
  _$BaseModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? parentRef = freezed,
    Object? position = null,
    Object? titleRef = freezed,
    Object? subBaseCount = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? effectivePeriodBegin = freezed,
    Object? effectivePeriodEnd = freezed,
    Object? effectiveDaysOfWeek = freezed,
    Object? effectiveTimeBegin = freezed,
    Object? effectiveTimeEnd = freezed,
    Object? publishStatus = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
    Object? pointLimitRemain = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      parentRef: freezed == parentRef
          ? _value.parentRef
          : parentRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      titleRef: freezed == titleRef
          ? _value.titleRef
          : titleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: freezed == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectivePeriodEnd: freezed == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectiveDaysOfWeek: freezed == effectiveDaysOfWeek
          ? _value.effectiveDaysOfWeek
          : effectiveDaysOfWeek // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      effectiveTimeBegin: freezed == effectiveTimeBegin
          ? _value.effectiveTimeBegin
          : effectiveTimeBegin // ignore: cast_nullable_to_non_nullable
              as String?,
      effectiveTimeEnd: freezed == effectiveTimeEnd
          ? _value.effectiveTimeEnd
          : effectiveTimeEnd // ignore: cast_nullable_to_non_nullable
              as String?,
      publishStatus: null == publishStatus
          ? _value.publishStatus
          : publishStatus // ignore: cast_nullable_to_non_nullable
              as int,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_BaseModelCopyWith<$Res> implements $BaseModelCopyWith<$Res> {
  factory _$$_BaseModelCopyWith(
          _$_BaseModel value, $Res Function(_$_BaseModel) then) =
      __$$_BaseModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      DocumentReference<Object?>? parentRef,
      MapPosition position,
      DocumentReference<Object?>? titleRef,
      int subBaseCount,
      String? imageUrl,
      String? imagePath,
      DateTime? effectivePeriodBegin,
      DateTime? effectivePeriodEnd,
      List<int>? effectiveDaysOfWeek,
      String? effectiveTimeBegin,
      String? effectiveTimeEnd,
      int publishStatus,
      int point,
      int pointLimit,
      DateTime? updatedAt,
      DateTime? createdAt,
      int pointLimitRemain});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_BaseModelCopyWithImpl<$Res>
    extends _$BaseModelCopyWithImpl<$Res, _$_BaseModel>
    implements _$$_BaseModelCopyWith<$Res> {
  __$$_BaseModelCopyWithImpl(
      _$_BaseModel _value, $Res Function(_$_BaseModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? parentRef = freezed,
    Object? position = null,
    Object? titleRef = freezed,
    Object? subBaseCount = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? effectivePeriodBegin = freezed,
    Object? effectivePeriodEnd = freezed,
    Object? effectiveDaysOfWeek = freezed,
    Object? effectiveTimeBegin = freezed,
    Object? effectiveTimeEnd = freezed,
    Object? publishStatus = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
    Object? pointLimitRemain = null,
  }) {
    return _then(_$_BaseModel(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      parentRef: freezed == parentRef
          ? _value.parentRef
          : parentRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      titleRef: freezed == titleRef
          ? _value.titleRef
          : titleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: freezed == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectivePeriodEnd: freezed == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectiveDaysOfWeek: freezed == effectiveDaysOfWeek
          ? _value._effectiveDaysOfWeek
          : effectiveDaysOfWeek // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      effectiveTimeBegin: freezed == effectiveTimeBegin
          ? _value.effectiveTimeBegin
          : effectiveTimeBegin // ignore: cast_nullable_to_non_nullable
              as String?,
      effectiveTimeEnd: freezed == effectiveTimeEnd
          ? _value.effectiveTimeEnd
          : effectiveTimeEnd // ignore: cast_nullable_to_non_nullable
              as String?,
      publishStatus: null == publishStatus
          ? _value.publishStatus
          : publishStatus // ignore: cast_nullable_to_non_nullable
              as int,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_BaseModel implements _BaseModel {
  const _$_BaseModel(
      {required this.id,
      required this.name,
      this.parentRef,
      required this.position,
      this.titleRef,
      this.subBaseCount = 0,
      this.imageUrl,
      this.imagePath,
      this.effectivePeriodBegin,
      this.effectivePeriodEnd,
      final List<int>? effectiveDaysOfWeek,
      this.effectiveTimeBegin,
      this.effectiveTimeEnd,
      required this.publishStatus,
      required this.point,
      required this.pointLimit,
      this.updatedAt,
      this.createdAt,
      required this.pointLimitRemain})
      : _effectiveDaysOfWeek = effectiveDaysOfWeek;

// 拠点ID
  @override
  final String id;
// 拠点名
  @override
  final String name;
// 親拠点のReference（サブ拠点の場合）
  @override
  final DocumentReference<Object?>? parentRef;
// 拠点の位置情報
  @override
  final MapPosition position;
// 称号のReference
  @override
  final DocumentReference<Object?>? titleRef;
// サブ拠点数（サブ拠点の場合は0）
  @override
  @JsonKey()
  final int subBaseCount;
// 拠点画像のURL
  @override
  final String? imageUrl;
// 拠点画像の保存先
  @override
  final String? imagePath;
// 有効期間開始
  @override
  final DateTime? effectivePeriodBegin;
// 有効期間終了
  @override
  final DateTime? effectivePeriodEnd;
// 有効曜日
  final List<int>? _effectiveDaysOfWeek;
// 有効曜日
  @override
  List<int>? get effectiveDaysOfWeek {
    final value = _effectiveDaysOfWeek;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

// 有効時刻開始
  @override
  final String? effectiveTimeBegin;
// 有効時刻終了
  @override
  final String? effectiveTimeEnd;
// 公開ステータス
  @override
  final int publishStatus;
// 獲得ポイント
  @override
  final int point;
// ポイント付与制限人数
  @override
  final int pointLimit;
// 更新日時
  @override
  final DateTime? updatedAt;
// 登録日時
  @override
  final DateTime? createdAt;
// ポイント付与制限人数残り
  @override
  final int pointLimitRemain;

  @override
  String toString() {
    return 'BaseModel(id: $id, name: $name, parentRef: $parentRef, position: $position, titleRef: $titleRef, subBaseCount: $subBaseCount, imageUrl: $imageUrl, imagePath: $imagePath, effectivePeriodBegin: $effectivePeriodBegin, effectivePeriodEnd: $effectivePeriodEnd, effectiveDaysOfWeek: $effectiveDaysOfWeek, effectiveTimeBegin: $effectiveTimeBegin, effectiveTimeEnd: $effectiveTimeEnd, publishStatus: $publishStatus, point: $point, pointLimit: $pointLimit, updatedAt: $updatedAt, createdAt: $createdAt, pointLimitRemain: $pointLimitRemain)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_BaseModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.parentRef, parentRef) ||
                other.parentRef == parentRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.titleRef, titleRef) ||
                other.titleRef == titleRef) &&
            (identical(other.subBaseCount, subBaseCount) ||
                other.subBaseCount == subBaseCount) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.effectivePeriodBegin, effectivePeriodBegin) ||
                other.effectivePeriodBegin == effectivePeriodBegin) &&
            (identical(other.effectivePeriodEnd, effectivePeriodEnd) ||
                other.effectivePeriodEnd == effectivePeriodEnd) &&
            const DeepCollectionEquality()
                .equals(other._effectiveDaysOfWeek, _effectiveDaysOfWeek) &&
            (identical(other.effectiveTimeBegin, effectiveTimeBegin) ||
                other.effectiveTimeBegin == effectiveTimeBegin) &&
            (identical(other.effectiveTimeEnd, effectiveTimeEnd) ||
                other.effectiveTimeEnd == effectiveTimeEnd) &&
            (identical(other.publishStatus, publishStatus) ||
                other.publishStatus == publishStatus) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointLimit, pointLimit) ||
                other.pointLimit == pointLimit) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.pointLimitRemain, pointLimitRemain) ||
                other.pointLimitRemain == pointLimitRemain));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        name,
        parentRef,
        position,
        titleRef,
        subBaseCount,
        imageUrl,
        imagePath,
        effectivePeriodBegin,
        effectivePeriodEnd,
        const DeepCollectionEquality().hash(_effectiveDaysOfWeek),
        effectiveTimeBegin,
        effectiveTimeEnd,
        publishStatus,
        point,
        pointLimit,
        updatedAt,
        createdAt,
        pointLimitRemain
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_BaseModelCopyWith<_$_BaseModel> get copyWith =>
      __$$_BaseModelCopyWithImpl<_$_BaseModel>(this, _$identity);
}

abstract class _BaseModel implements BaseModel {
  const factory _BaseModel(
      {required final String id,
      required final String name,
      final DocumentReference<Object?>? parentRef,
      required final MapPosition position,
      final DocumentReference<Object?>? titleRef,
      final int subBaseCount,
      final String? imageUrl,
      final String? imagePath,
      final DateTime? effectivePeriodBegin,
      final DateTime? effectivePeriodEnd,
      final List<int>? effectiveDaysOfWeek,
      final String? effectiveTimeBegin,
      final String? effectiveTimeEnd,
      required final int publishStatus,
      required final int point,
      required final int pointLimit,
      final DateTime? updatedAt,
      final DateTime? createdAt,
      required final int pointLimitRemain}) = _$_BaseModel;

  @override // 拠点ID
  String get id;
  @override // 拠点名
  String get name;
  @override // 親拠点のReference（サブ拠点の場合）
  DocumentReference<Object?>? get parentRef;
  @override // 拠点の位置情報
  MapPosition get position;
  @override // 称号のReference
  DocumentReference<Object?>? get titleRef;
  @override // サブ拠点数（サブ拠点の場合は0）
  int get subBaseCount;
  @override // 拠点画像のURL
  String? get imageUrl;
  @override // 拠点画像の保存先
  String? get imagePath;
  @override // 有効期間開始
  DateTime? get effectivePeriodBegin;
  @override // 有効期間終了
  DateTime? get effectivePeriodEnd;
  @override // 有効曜日
  List<int>? get effectiveDaysOfWeek;
  @override // 有効時刻開始
  String? get effectiveTimeBegin;
  @override // 有効時刻終了
  String? get effectiveTimeEnd;
  @override // 公開ステータス
  int get publishStatus;
  @override // 獲得ポイント
  int get point;
  @override // ポイント付与制限人数
  int get pointLimit;
  @override // 更新日時
  DateTime? get updatedAt;
  @override // 登録日時
  DateTime? get createdAt;
  @override // ポイント付与制限人数残り
  int get pointLimitRemain;
  @override
  @JsonKey(ignore: true)
  _$$_BaseModelCopyWith<_$_BaseModel> get copyWith =>
      throw _privateConstructorUsedError;
}

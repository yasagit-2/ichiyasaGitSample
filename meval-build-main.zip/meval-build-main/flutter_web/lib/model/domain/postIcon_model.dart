import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../map_position.dart';

part 'postIcon_model.freezed.dart';

@freezed
class PostIconModel with _$PostIconModel {
  const factory PostIconModel({
    // いいね数単位の投稿アイコンURL
    // マップに表示する投稿アイコンのURL。
    // （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
    // 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
    // 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
    required String unitOfLikePostIconUrl,
    // いいね数
    // 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
    // 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
    required int likeCount,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _PostIconModel;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../map_position.dart';

part 'maintenance_model.freezed.dart';

@freezed
class MaintenanceModel with _$MaintenanceModel {
  const factory MaintenanceModel({
    // アプリケーションバージョン
    // アプリケーションのバージョン（例：1.0.0）
    required String? version,
    // Apple App StoreのURL
    // ストア登録時に発行されるApple App StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
    required String? appStoreUrl,
    // Google Play StoreのURL
    // ストア登録時に発行されるGoogle Play StoreのURL。強制アップロードの際に、このURLを用いてストアへ遷移する。
    required String? playStoreUrl,
    // メンテナンスフラグ
    // true：メンテナンス中（メンテナンス中はアプリ利用不可、強制ログアウト）
    required bool isMaintenance,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _MaintenanceModel;
}

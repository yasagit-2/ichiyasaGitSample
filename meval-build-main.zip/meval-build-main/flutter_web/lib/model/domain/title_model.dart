import 'package:freezed_annotation/freezed_annotation.dart';

part 'title_model.freezed.dart';


@freezed
class TitleModel with _$TitleModel {
  const factory TitleModel({
    // 称号ID
    required String id,
    // 称号名
    required String name,
    // 称号獲得ポイント
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    DateTime? updatedAt,
    // 登録日時
    DateTime? createdAt,
  }) = _TitleModel;
}

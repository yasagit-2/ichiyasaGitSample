// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'base.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Base _$BaseFromJson(Map<String, dynamic> json) {
  return _Base.fromJson(json);
}

/// @nodoc
mixin _$Base {
// 拠点ID
  String get id => throw _privateConstructorUsedError; // 拠点名
  String get name =>
      throw _privateConstructorUsedError; // 親拠点のReference（サブ拠点の場合）
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get parentRef =>
      throw _privateConstructorUsedError; // 拠点の位置情報
  MapPosition get position =>
      throw _privateConstructorUsedError; // 称号のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get titleRef =>
      throw _privateConstructorUsedError; // サブ拠点数（サブ拠点の場合は0）
  int get subBaseCount => throw _privateConstructorUsedError; // 拠点画像のURL
  String? get imageUrl => throw _privateConstructorUsedError; // 拠点画像の保存先
  String? get imagePath => throw _privateConstructorUsedError; // 有効期間開始
  DateTime? get effectivePeriodBegin =>
      throw _privateConstructorUsedError; // 有効期間終了
  DateTime? get effectivePeriodEnd =>
      throw _privateConstructorUsedError; // 有効曜日
  List<int>? get effectiveDaysOfWeek =>
      throw _privateConstructorUsedError; // 有効時刻開始
  String? get effectiveTimeBegin =>
      throw _privateConstructorUsedError; // 有効時刻終了
  String? get effectiveTimeEnd => throw _privateConstructorUsedError; // 公開ステータス
  int get publishStatus => throw _privateConstructorUsedError; // 獲得ポイント
  int get point => throw _privateConstructorUsedError; // ポイント付与制限人数
  int get pointLimit => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BaseCopyWith<Base> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BaseCopyWith<$Res> {
  factory $BaseCopyWith(Base value, $Res Function(Base) then) =
      _$BaseCopyWithImpl<$Res, Base>;
  @useResult
  $Res call(
      {String id,
      String name,
      @DocumentReferenceConverter() DocumentReference<Object?>? parentRef,
      MapPosition position,
      @DocumentReferenceConverter() DocumentReference<Object?>? titleRef,
      int subBaseCount,
      String? imageUrl,
      String? imagePath,
      DateTime? effectivePeriodBegin,
      DateTime? effectivePeriodEnd,
      List<int>? effectiveDaysOfWeek,
      String? effectiveTimeBegin,
      String? effectiveTimeEnd,
      int publishStatus,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$BaseCopyWithImpl<$Res, $Val extends Base>
    implements $BaseCopyWith<$Res> {
  _$BaseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? parentRef = freezed,
    Object? position = null,
    Object? titleRef = freezed,
    Object? subBaseCount = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? effectivePeriodBegin = freezed,
    Object? effectivePeriodEnd = freezed,
    Object? effectiveDaysOfWeek = freezed,
    Object? effectiveTimeBegin = freezed,
    Object? effectiveTimeEnd = freezed,
    Object? publishStatus = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      parentRef: freezed == parentRef
          ? _value.parentRef
          : parentRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      titleRef: freezed == titleRef
          ? _value.titleRef
          : titleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: freezed == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectivePeriodEnd: freezed == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectiveDaysOfWeek: freezed == effectiveDaysOfWeek
          ? _value.effectiveDaysOfWeek
          : effectiveDaysOfWeek // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      effectiveTimeBegin: freezed == effectiveTimeBegin
          ? _value.effectiveTimeBegin
          : effectiveTimeBegin // ignore: cast_nullable_to_non_nullable
              as String?,
      effectiveTimeEnd: freezed == effectiveTimeEnd
          ? _value.effectiveTimeEnd
          : effectiveTimeEnd // ignore: cast_nullable_to_non_nullable
              as String?,
      publishStatus: null == publishStatus
          ? _value.publishStatus
          : publishStatus // ignore: cast_nullable_to_non_nullable
              as int,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_BaseCopyWith<$Res> implements $BaseCopyWith<$Res> {
  factory _$$_BaseCopyWith(_$_Base value, $Res Function(_$_Base) then) =
      __$$_BaseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      @DocumentReferenceConverter() DocumentReference<Object?>? parentRef,
      MapPosition position,
      @DocumentReferenceConverter() DocumentReference<Object?>? titleRef,
      int subBaseCount,
      String? imageUrl,
      String? imagePath,
      DateTime? effectivePeriodBegin,
      DateTime? effectivePeriodEnd,
      List<int>? effectiveDaysOfWeek,
      String? effectiveTimeBegin,
      String? effectiveTimeEnd,
      int publishStatus,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_BaseCopyWithImpl<$Res> extends _$BaseCopyWithImpl<$Res, _$_Base>
    implements _$$_BaseCopyWith<$Res> {
  __$$_BaseCopyWithImpl(_$_Base _value, $Res Function(_$_Base) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? parentRef = freezed,
    Object? position = null,
    Object? titleRef = freezed,
    Object? subBaseCount = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? effectivePeriodBegin = freezed,
    Object? effectivePeriodEnd = freezed,
    Object? effectiveDaysOfWeek = freezed,
    Object? effectiveTimeBegin = freezed,
    Object? effectiveTimeEnd = freezed,
    Object? publishStatus = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Base(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      parentRef: freezed == parentRef
          ? _value.parentRef
          : parentRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      titleRef: freezed == titleRef
          ? _value.titleRef
          : titleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: freezed == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectivePeriodEnd: freezed == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      effectiveDaysOfWeek: freezed == effectiveDaysOfWeek
          ? _value._effectiveDaysOfWeek
          : effectiveDaysOfWeek // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      effectiveTimeBegin: freezed == effectiveTimeBegin
          ? _value.effectiveTimeBegin
          : effectiveTimeBegin // ignore: cast_nullable_to_non_nullable
              as String?,
      effectiveTimeEnd: freezed == effectiveTimeEnd
          ? _value.effectiveTimeEnd
          : effectiveTimeEnd // ignore: cast_nullable_to_non_nullable
              as String?,
      publishStatus: null == publishStatus
          ? _value.publishStatus
          : publishStatus // ignore: cast_nullable_to_non_nullable
              as int,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Base implements _Base {
  const _$_Base(
      {required this.id,
      required this.name,
      @DocumentReferenceConverter() this.parentRef,
      required this.position,
      @DocumentReferenceConverter() this.titleRef,
      this.subBaseCount = 0,
      this.imageUrl,
      this.imagePath,
      this.effectivePeriodBegin,
      this.effectivePeriodEnd,
      final List<int>? effectiveDaysOfWeek,
      this.effectiveTimeBegin,
      this.effectiveTimeEnd,
      required this.publishStatus,
      required this.point,
      required this.pointLimit,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt})
      : _effectiveDaysOfWeek = effectiveDaysOfWeek;

  factory _$_Base.fromJson(Map<String, dynamic> json) => _$$_BaseFromJson(json);

// 拠点ID
  @override
  final String id;
// 拠点名
  @override
  final String name;
// 親拠点のReference（サブ拠点の場合）
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? parentRef;
// 拠点の位置情報
  @override
  final MapPosition position;
// 称号のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? titleRef;
// サブ拠点数（サブ拠点の場合は0）
  @override
  @JsonKey()
  final int subBaseCount;
// 拠点画像のURL
  @override
  final String? imageUrl;
// 拠点画像の保存先
  @override
  final String? imagePath;
// 有効期間開始
  @override
  final DateTime? effectivePeriodBegin;
// 有効期間終了
  @override
  final DateTime? effectivePeriodEnd;
// 有効曜日
  final List<int>? _effectiveDaysOfWeek;
// 有効曜日
  @override
  List<int>? get effectiveDaysOfWeek {
    final value = _effectiveDaysOfWeek;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

// 有効時刻開始
  @override
  final String? effectiveTimeBegin;
// 有効時刻終了
  @override
  final String? effectiveTimeEnd;
// 公開ステータス
  @override
  final int publishStatus;
// 獲得ポイント
  @override
  final int point;
// ポイント付与制限人数
  @override
  final int pointLimit;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Base(id: $id, name: $name, parentRef: $parentRef, position: $position, titleRef: $titleRef, subBaseCount: $subBaseCount, imageUrl: $imageUrl, imagePath: $imagePath, effectivePeriodBegin: $effectivePeriodBegin, effectivePeriodEnd: $effectivePeriodEnd, effectiveDaysOfWeek: $effectiveDaysOfWeek, effectiveTimeBegin: $effectiveTimeBegin, effectiveTimeEnd: $effectiveTimeEnd, publishStatus: $publishStatus, point: $point, pointLimit: $pointLimit, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Base &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.parentRef, parentRef) ||
                other.parentRef == parentRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.titleRef, titleRef) ||
                other.titleRef == titleRef) &&
            (identical(other.subBaseCount, subBaseCount) ||
                other.subBaseCount == subBaseCount) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.effectivePeriodBegin, effectivePeriodBegin) ||
                other.effectivePeriodBegin == effectivePeriodBegin) &&
            (identical(other.effectivePeriodEnd, effectivePeriodEnd) ||
                other.effectivePeriodEnd == effectivePeriodEnd) &&
            const DeepCollectionEquality()
                .equals(other._effectiveDaysOfWeek, _effectiveDaysOfWeek) &&
            (identical(other.effectiveTimeBegin, effectiveTimeBegin) ||
                other.effectiveTimeBegin == effectiveTimeBegin) &&
            (identical(other.effectiveTimeEnd, effectiveTimeEnd) ||
                other.effectiveTimeEnd == effectiveTimeEnd) &&
            (identical(other.publishStatus, publishStatus) ||
                other.publishStatus == publishStatus) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointLimit, pointLimit) ||
                other.pointLimit == pointLimit) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      parentRef,
      position,
      titleRef,
      subBaseCount,
      imageUrl,
      imagePath,
      effectivePeriodBegin,
      effectivePeriodEnd,
      const DeepCollectionEquality().hash(_effectiveDaysOfWeek),
      effectiveTimeBegin,
      effectiveTimeEnd,
      publishStatus,
      point,
      pointLimit,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_BaseCopyWith<_$_Base> get copyWith =>
      __$$_BaseCopyWithImpl<_$_Base>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_BaseToJson(
      this,
    );
  }
}

abstract class _Base implements Base {
  const factory _Base(
      {required final String id,
      required final String name,
      @DocumentReferenceConverter() final DocumentReference<Object?>? parentRef,
      required final MapPosition position,
      @DocumentReferenceConverter() final DocumentReference<Object?>? titleRef,
      final int subBaseCount,
      final String? imageUrl,
      final String? imagePath,
      final DateTime? effectivePeriodBegin,
      final DateTime? effectivePeriodEnd,
      final List<int>? effectiveDaysOfWeek,
      final String? effectiveTimeBegin,
      final String? effectiveTimeEnd,
      required final int publishStatus,
      required final int point,
      required final int pointLimit,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Base;

  factory _Base.fromJson(Map<String, dynamic> json) = _$_Base.fromJson;

  @override // 拠点ID
  String get id;
  @override // 拠点名
  String get name;
  @override // 親拠点のReference（サブ拠点の場合）
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get parentRef;
  @override // 拠点の位置情報
  MapPosition get position;
  @override // 称号のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get titleRef;
  @override // サブ拠点数（サブ拠点の場合は0）
  int get subBaseCount;
  @override // 拠点画像のURL
  String? get imageUrl;
  @override // 拠点画像の保存先
  String? get imagePath;
  @override // 有効期間開始
  DateTime? get effectivePeriodBegin;
  @override // 有効期間終了
  DateTime? get effectivePeriodEnd;
  @override // 有効曜日
  List<int>? get effectiveDaysOfWeek;
  @override // 有効時刻開始
  String? get effectiveTimeBegin;
  @override // 有効時刻終了
  String? get effectiveTimeEnd;
  @override // 公開ステータス
  int get publishStatus;
  @override // 獲得ポイント
  int get point;
  @override // ポイント付与制限人数
  int get pointLimit;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_BaseCopyWith<_$_Base> get copyWith => throw _privateConstructorUsedError;
}

BaseTransaction _$BaseTransactionFromJson(Map<String, dynamic> json) {
  return _BaseTransaction.fromJson(json);
}

/// @nodoc
mixin _$BaseTransaction {
// ポイント付与制限人数残り
  int get pointLimitRemain => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BaseTransactionCopyWith<BaseTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BaseTransactionCopyWith<$Res> {
  factory $BaseTransactionCopyWith(
          BaseTransaction value, $Res Function(BaseTransaction) then) =
      _$BaseTransactionCopyWithImpl<$Res, BaseTransaction>;
  @useResult
  $Res call(
      {int pointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$BaseTransactionCopyWithImpl<$Res, $Val extends BaseTransaction>
    implements $BaseTransactionCopyWith<$Res> {
  _$BaseTransactionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_BaseTransactionCopyWith<$Res>
    implements $BaseTransactionCopyWith<$Res> {
  factory _$$_BaseTransactionCopyWith(
          _$_BaseTransaction value, $Res Function(_$_BaseTransaction) then) =
      __$$_BaseTransactionCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int pointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_BaseTransactionCopyWithImpl<$Res>
    extends _$BaseTransactionCopyWithImpl<$Res, _$_BaseTransaction>
    implements _$$_BaseTransactionCopyWith<$Res> {
  __$$_BaseTransactionCopyWithImpl(
      _$_BaseTransaction _value, $Res Function(_$_BaseTransaction) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_BaseTransaction(
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_BaseTransaction implements _BaseTransaction {
  const _$_BaseTransaction(
      {required this.pointLimitRemain,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_BaseTransaction.fromJson(Map<String, dynamic> json) =>
      _$$_BaseTransactionFromJson(json);

// ポイント付与制限人数残り
  @override
  final int pointLimitRemain;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'BaseTransaction(pointLimitRemain: $pointLimitRemain, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_BaseTransaction &&
            (identical(other.pointLimitRemain, pointLimitRemain) ||
                other.pointLimitRemain == pointLimitRemain) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, pointLimitRemain, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_BaseTransactionCopyWith<_$_BaseTransaction> get copyWith =>
      __$$_BaseTransactionCopyWithImpl<_$_BaseTransaction>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_BaseTransactionToJson(
      this,
    );
  }
}

abstract class _BaseTransaction implements BaseTransaction {
  const factory _BaseTransaction(
      {required final int pointLimitRemain,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_BaseTransaction;

  factory _BaseTransaction.fromJson(Map<String, dynamic> json) =
      _$_BaseTransaction.fromJson;

  @override // ポイント付与制限人数残り
  int get pointLimitRemain;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_BaseTransactionCopyWith<_$_BaseTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'merchant.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Merchant _$MerchantFromJson(Map<String, dynamic> json) {
  return _Merchant.fromJson(json);
}

/// @nodoc
mixin _$Merchant {
// 加盟店ID
  String? get id => throw _privateConstructorUsedError; // 加盟店名称
  String? get name => throw _privateConstructorUsedError; // 加盟店画像のURL
// 加盟店画像が存在しない場合は省略。
  String? get imageUrl => throw _privateConstructorUsedError; // 加盟店画像の保存先
// 加盟店画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：merchants/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は特に規定しない）
  String? get imagePath => throw _privateConstructorUsedError; // 加盟店の座標
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantCopyWith<Merchant> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantCopyWith<$Res> {
  factory $MerchantCopyWith(Merchant value, $Res Function(Merchant) then) =
      _$MerchantCopyWithImpl<$Res, Merchant>;
  @useResult
  $Res call(
      {String? id,
      String? name,
      String? imageUrl,
      String? imagePath,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$MerchantCopyWithImpl<$Res, $Val extends Merchant>
    implements $MerchantCopyWith<$Res> {
  _$MerchantCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_MerchantCopyWith<$Res> implements $MerchantCopyWith<$Res> {
  factory _$$_MerchantCopyWith(
          _$_Merchant value, $Res Function(_$_Merchant) then) =
      __$$_MerchantCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? name,
      String? imageUrl,
      String? imagePath,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_MerchantCopyWithImpl<$Res>
    extends _$MerchantCopyWithImpl<$Res, _$_Merchant>
    implements _$$_MerchantCopyWith<$Res> {
  __$$_MerchantCopyWithImpl(
      _$_Merchant _value, $Res Function(_$_Merchant) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Merchant(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Merchant implements _Merchant {
  const _$_Merchant(
      {required this.id,
      required this.name,
      this.imageUrl,
      this.imagePath,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Merchant.fromJson(Map<String, dynamic> json) =>
      _$$_MerchantFromJson(json);

// 加盟店ID
  @override
  final String? id;
// 加盟店名称
  @override
  final String? name;
// 加盟店画像のURL
// 加盟店画像が存在しない場合は省略。
  @override
  final String? imageUrl;
// 加盟店画像の保存先
// 加盟店画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：merchants/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は特に規定しない）
  @override
  final String? imagePath;
// 加盟店の座標
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Merchant(id: $id, name: $name, imageUrl: $imageUrl, imagePath: $imagePath, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Merchant &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, imageUrl, imagePath,
      position, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantCopyWith<_$_Merchant> get copyWith =>
      __$$_MerchantCopyWithImpl<_$_Merchant>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MerchantToJson(
      this,
    );
  }
}

abstract class _Merchant implements Merchant {
  const factory _Merchant(
      {required final String? id,
      required final String? name,
      final String? imageUrl,
      final String? imagePath,
      required final MapPosition position,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Merchant;

  factory _Merchant.fromJson(Map<String, dynamic> json) = _$_Merchant.fromJson;

  @override // 加盟店ID
  String? get id;
  @override // 加盟店名称
  String? get name;
  @override // 加盟店画像のURL
// 加盟店画像が存在しない場合は省略。
  String? get imageUrl;
  @override // 加盟店画像の保存先
// 加盟店画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：merchants/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は特に規定しない）
  String? get imagePath;
  @override // 加盟店の座標
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MerchantCopyWith<_$_Merchant> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'title_data.freezed.dart';
part 'title_data.g.dart';

/// 称号
@freezed
class TitleData with _$TitleData {
  @firestoreSerializable
  const factory TitleData({
    // 称号ID
    required String id,
    // 称号名称
    required String name,
    // 称号獲得ポイント
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _TitleData;

  factory TitleData.fromJson(Map<String, Object?> json) =>
      _$TitleDataFromJson(json);
}

@Collection<TitleData>('titles')
final titlesRef = TitleDataCollectionReference();

TitleDataDocumentReference titleRef({required String id}) =>
    TitleDataDocumentReference(titlesRef.doc(id).reference);

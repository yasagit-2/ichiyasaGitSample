import 'map_position.dart';

mixin MapPositionMixin {
  // 位置情報
  MapPosition get position;

  // 画像URL
  String? get imageUrl;
}

// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'map_position.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MapPosition _$$_MapPositionFromJson(Map<String, dynamic> json) =>
    _$_MapPosition(
      geohash: json['geohash'] as String,
      geopoint:
          const GeoPointConverter().fromJson(json['geopoint'] as GeoPoint),
    );

const _$$_MapPositionFieldMap = <String, String>{
  'geohash': 'geohash',
  'geopoint': 'geopoint',
};

Map<String, dynamic> _$$_MapPositionToJson(_$_MapPosition instance) =>
    <String, dynamic>{
      'geohash': instance.geohash,
      'geopoint': const GeoPointConverter().toJson(instance.geopoint),
    };

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'title_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

TitleData _$TitleDataFromJson(Map<String, dynamic> json) {
  return _TitleData.fromJson(json);
}

/// @nodoc
mixin _$TitleData {
// 称号ID
  String get id => throw _privateConstructorUsedError; // 称号名称
  String get name => throw _privateConstructorUsedError; // 称号獲得ポイント
  int get point => throw _privateConstructorUsedError; // ポイント付与制限人数
  int get pointLimit => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TitleDataCopyWith<TitleData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TitleDataCopyWith<$Res> {
  factory $TitleDataCopyWith(TitleData value, $Res Function(TitleData) then) =
      _$TitleDataCopyWithImpl<$Res, TitleData>;
  @useResult
  $Res call(
      {String id,
      String name,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$TitleDataCopyWithImpl<$Res, $Val extends TitleData>
    implements $TitleDataCopyWith<$Res> {
  _$TitleDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_TitleDataCopyWith<$Res> implements $TitleDataCopyWith<$Res> {
  factory _$$_TitleDataCopyWith(
          _$_TitleData value, $Res Function(_$_TitleData) then) =
      __$$_TitleDataCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_TitleDataCopyWithImpl<$Res>
    extends _$TitleDataCopyWithImpl<$Res, _$_TitleData>
    implements _$$_TitleDataCopyWith<$Res> {
  __$$_TitleDataCopyWithImpl(
      _$_TitleData _value, $Res Function(_$_TitleData) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_TitleData(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_TitleData implements _TitleData {
  const _$_TitleData(
      {required this.id,
      required this.name,
      required this.point,
      required this.pointLimit,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_TitleData.fromJson(Map<String, dynamic> json) =>
      _$$_TitleDataFromJson(json);

// 称号ID
  @override
  final String id;
// 称号名称
  @override
  final String name;
// 称号獲得ポイント
  @override
  final int point;
// ポイント付与制限人数
  @override
  final int pointLimit;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'TitleData(id: $id, name: $name, point: $point, pointLimit: $pointLimit, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TitleData &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointLimit, pointLimit) ||
                other.pointLimit == pointLimit) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, point, pointLimit, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_TitleDataCopyWith<_$_TitleData> get copyWith =>
      __$$_TitleDataCopyWithImpl<_$_TitleData>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_TitleDataToJson(
      this,
    );
  }
}

abstract class _TitleData implements TitleData {
  const factory _TitleData(
      {required final String id,
      required final String name,
      required final int point,
      required final int pointLimit,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_TitleData;

  factory _TitleData.fromJson(Map<String, dynamic> json) =
      _$_TitleData.fromJson;

  @override // 称号ID
  String get id;
  @override // 称号名称
  String get name;
  @override // 称号獲得ポイント
  int get point;
  @override // ポイント付与制限人数
  int get pointLimit;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_TitleDataCopyWith<_$_TitleData> get copyWith =>
      throw _privateConstructorUsedError;
}

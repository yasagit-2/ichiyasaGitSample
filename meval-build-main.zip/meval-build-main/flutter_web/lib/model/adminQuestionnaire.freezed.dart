// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'adminQuestionnaire.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

AdminQuestionnaire _$AdminQuestionnaireFromJson(Map<String, dynamic> json) {
  return _AdminQuestionnaire.fromJson(json);
}

/// @nodoc
mixin _$AdminQuestionnaire {
// 行政投稿（アンケート）ID
  String? get id => throw _privateConstructorUsedError; // 行政投稿（アンケート）メッセージ
  String? get message => throw _privateConstructorUsedError; // 投稿の座標
  MapPosition get position =>
      throw _privateConstructorUsedError; // 行政投稿（アンケート）期限
  @TimestampConverter()
  DateTime? get dueDate =>
      throw _privateConstructorUsedError; // 行政投稿（アンケート）画像のURL
// 行政投稿（アンケート）画像が存在しない場合は省略。
  String? get imageUrl => throw _privateConstructorUsedError; // 行政投稿（アンケート）の保存先
// imageUrlを設定する場合は必須。例：adminQuestionnaires/c9ba78d0-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  String? get imagePath => throw _privateConstructorUsedError; // アンケート回答獲得ポイント
// アンケート回答により獲得できるポイント。
  int get point => throw _privateConstructorUsedError; // ポイント付与制限人数
  int get pointLimit => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AdminQuestionnaireCopyWith<AdminQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdminQuestionnaireCopyWith<$Res> {
  factory $AdminQuestionnaireCopyWith(
          AdminQuestionnaire value, $Res Function(AdminQuestionnaire) then) =
      _$AdminQuestionnaireCopyWithImpl<$Res, AdminQuestionnaire>;
  @useResult
  $Res call(
      {String? id,
      String? message,
      MapPosition position,
      @TimestampConverter() DateTime? dueDate,
      String? imageUrl,
      String? imagePath,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$AdminQuestionnaireCopyWithImpl<$Res, $Val extends AdminQuestionnaire>
    implements $AdminQuestionnaireCopyWith<$Res> {
  _$AdminQuestionnaireCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? position = null,
    Object? dueDate = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      dueDate: freezed == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_AdminQuestionnaireCopyWith<$Res>
    implements $AdminQuestionnaireCopyWith<$Res> {
  factory _$$_AdminQuestionnaireCopyWith(_$_AdminQuestionnaire value,
          $Res Function(_$_AdminQuestionnaire) then) =
      __$$_AdminQuestionnaireCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? message,
      MapPosition position,
      @TimestampConverter() DateTime? dueDate,
      String? imageUrl,
      String? imagePath,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_AdminQuestionnaireCopyWithImpl<$Res>
    extends _$AdminQuestionnaireCopyWithImpl<$Res, _$_AdminQuestionnaire>
    implements _$$_AdminQuestionnaireCopyWith<$Res> {
  __$$_AdminQuestionnaireCopyWithImpl(
      _$_AdminQuestionnaire _value, $Res Function(_$_AdminQuestionnaire) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? position = null,
    Object? dueDate = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_AdminQuestionnaire(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      dueDate: freezed == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_AdminQuestionnaire implements _AdminQuestionnaire {
  const _$_AdminQuestionnaire(
      {required this.id,
      required this.message,
      required this.position,
      @TimestampConverter() this.dueDate,
      this.imageUrl,
      this.imagePath,
      required this.point,
      required this.pointLimit,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_AdminQuestionnaire.fromJson(Map<String, dynamic> json) =>
      _$$_AdminQuestionnaireFromJson(json);

// 行政投稿（アンケート）ID
  @override
  final String? id;
// 行政投稿（アンケート）メッセージ
  @override
  final String? message;
// 投稿の座標
  @override
  final MapPosition position;
// 行政投稿（アンケート）期限
  @override
  @TimestampConverter()
  final DateTime? dueDate;
// 行政投稿（アンケート）画像のURL
// 行政投稿（アンケート）画像が存在しない場合は省略。
  @override
  final String? imageUrl;
// 行政投稿（アンケート）の保存先
// imageUrlを設定する場合は必須。例：adminQuestionnaires/c9ba78d0-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  @override
  final String? imagePath;
// アンケート回答獲得ポイント
// アンケート回答により獲得できるポイント。
  @override
  final int point;
// ポイント付与制限人数
  @override
  final int pointLimit;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'AdminQuestionnaire(id: $id, message: $message, position: $position, dueDate: $dueDate, imageUrl: $imageUrl, imagePath: $imagePath, point: $point, pointLimit: $pointLimit, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AdminQuestionnaire &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.dueDate, dueDate) || other.dueDate == dueDate) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointLimit, pointLimit) ||
                other.pointLimit == pointLimit) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, message, position, dueDate,
      imageUrl, imagePath, point, pointLimit, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AdminQuestionnaireCopyWith<_$_AdminQuestionnaire> get copyWith =>
      __$$_AdminQuestionnaireCopyWithImpl<_$_AdminQuestionnaire>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AdminQuestionnaireToJson(
      this,
    );
  }
}

abstract class _AdminQuestionnaire implements AdminQuestionnaire {
  const factory _AdminQuestionnaire(
      {required final String? id,
      required final String? message,
      required final MapPosition position,
      @TimestampConverter() final DateTime? dueDate,
      final String? imageUrl,
      final String? imagePath,
      required final int point,
      required final int pointLimit,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_AdminQuestionnaire;

  factory _AdminQuestionnaire.fromJson(Map<String, dynamic> json) =
      _$_AdminQuestionnaire.fromJson;

  @override // 行政投稿（アンケート）ID
  String? get id;
  @override // 行政投稿（アンケート）メッセージ
  String? get message;
  @override // 投稿の座標
  MapPosition get position;
  @override // 行政投稿（アンケート）期限
  @TimestampConverter()
  DateTime? get dueDate;
  @override // 行政投稿（アンケート）画像のURL
// 行政投稿（アンケート）画像が存在しない場合は省略。
  String? get imageUrl;
  @override // 行政投稿（アンケート）の保存先
// imageUrlを設定する場合は必須。例：adminQuestionnaires/c9ba78d0-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  String? get imagePath;
  @override // アンケート回答獲得ポイント
// アンケート回答により獲得できるポイント。
  int get point;
  @override // ポイント付与制限人数
  int get pointLimit;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_AdminQuestionnaireCopyWith<_$_AdminQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

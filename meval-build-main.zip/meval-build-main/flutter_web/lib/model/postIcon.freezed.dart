// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'postIcon.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

PostIcon _$PostIconFromJson(Map<String, dynamic> json) {
  return _PostIcon.fromJson(json);
}

/// @nodoc
mixin _$PostIcon {
// いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  String get unitOfLikePostIconUrl =>
      throw _privateConstructorUsedError; // いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  int get likeCount => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PostIconCopyWith<PostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostIconCopyWith<$Res> {
  factory $PostIconCopyWith(PostIcon value, $Res Function(PostIcon) then) =
      _$PostIconCopyWithImpl<$Res, PostIcon>;
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$PostIconCopyWithImpl<$Res, $Val extends PostIcon>
    implements $PostIconCopyWith<$Res> {
  _$PostIconCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PostIconCopyWith<$Res> implements $PostIconCopyWith<$Res> {
  factory _$$_PostIconCopyWith(
          _$_PostIcon value, $Res Function(_$_PostIcon) then) =
      __$$_PostIconCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_PostIconCopyWithImpl<$Res>
    extends _$PostIconCopyWithImpl<$Res, _$_PostIcon>
    implements _$$_PostIconCopyWith<$Res> {
  __$$_PostIconCopyWithImpl(
      _$_PostIcon _value, $Res Function(_$_PostIcon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PostIcon(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_PostIcon implements _PostIcon {
  const _$_PostIcon(
      {required this.unitOfLikePostIconUrl,
      required this.likeCount,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_PostIcon.fromJson(Map<String, dynamic> json) =>
      _$$_PostIconFromJson(json);

// いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  @override
  final String unitOfLikePostIconUrl;
// いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  @override
  final int likeCount;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PostIcon(unitOfLikePostIconUrl: $unitOfLikePostIconUrl, likeCount: $likeCount, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PostIcon &&
            (identical(other.unitOfLikePostIconUrl, unitOfLikePostIconUrl) ||
                other.unitOfLikePostIconUrl == unitOfLikePostIconUrl) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, unitOfLikePostIconUrl, likeCount, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostIconCopyWith<_$_PostIcon> get copyWith =>
      __$$_PostIconCopyWithImpl<_$_PostIcon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PostIconToJson(
      this,
    );
  }
}

abstract class _PostIcon implements PostIcon {
  const factory _PostIcon(
      {required final String unitOfLikePostIconUrl,
      required final int likeCount,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_PostIcon;

  factory _PostIcon.fromJson(Map<String, dynamic> json) = _$_PostIcon.fromJson;

  @override // いいね数単位の投稿アイコンURL
// マップに表示する投稿アイコンのURL。
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
// 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
// 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
  String get unitOfLikePostIconUrl;
  @override // いいね数
// 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
// 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
  int get likeCount;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostIconCopyWith<_$_PostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'merchant.freezed.dart';
part 'merchant.g.dart';

@freezed
class Merchant with _$Merchant {
  @firestoreSerializable
  const factory Merchant({
    // 加盟店ID
    required String? id,
    // 加盟店名称
    required String? name,
    // 加盟店画像のURL
    // 加盟店画像が存在しない場合は省略。
    String? imageUrl,
    // 加盟店画像の保存先
    // 加盟店画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：merchants/2b752bd6-b85e-431e-bb8d-204241e9dd56（ファイル名は特に規定しない）
    String? imagePath,
    // 加盟店の座標
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Merchant;

  factory Merchant.fromJson(Map<String, Object?> json) =>
      _$MerchantFromJson(json);
}

@Collection<Merchant>('merchants')
final merchantsRef = MerchantCollectionReference();

MerchantDocumentReference merchantRef({required String id}) =>
    MerchantDocumentReference(merchantsRef.doc(id).reference);

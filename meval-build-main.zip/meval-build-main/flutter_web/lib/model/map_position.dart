import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'map_position.freezed.dart';
part 'map_position.g.dart';

@freezed
class MapPosition with _$MapPosition {
  @firestoreSerializable
  const factory MapPosition({
    // Geohash
    required String geohash,
    // GeoPoint
    @GeoPointConverter() required GeoPoint geopoint,
  }) = _MapPosition;

  factory MapPosition.fromJson(Map<String, Object?> json) =>
      _$MapPositionFromJson(json);
}

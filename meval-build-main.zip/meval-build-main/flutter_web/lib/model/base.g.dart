// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'base.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class BaseCollectionReference
    implements
        BaseQuery,
        FirestoreCollectionReference<Base, BaseQuerySnapshot> {
  factory BaseCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$BaseCollectionReference;

  static Base fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return Base.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    Base value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<Base> get reference;

  @override
  BaseDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<BaseDocumentReference> add(Base value);
}

class _$BaseCollectionReference extends _$BaseQuery
    implements BaseCollectionReference {
  factory _$BaseCollectionReference([FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$BaseCollectionReference._(
      firestore.collection('bases').withConverter(
            fromFirestore: BaseCollectionReference.fromFirestore,
            toFirestore: BaseCollectionReference.toFirestore,
          ),
    );
  }

  _$BaseCollectionReference._(
    CollectionReference<Base> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<Base> get reference =>
      super.reference as CollectionReference<Base>;

  @override
  BaseDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return BaseDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<BaseDocumentReference> add(Base value) {
    return reference.add(value).then((ref) => BaseDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$BaseCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class BaseDocumentReference
    extends FirestoreDocumentReference<Base, BaseDocumentSnapshot> {
  factory BaseDocumentReference(DocumentReference<Base> reference) =
      _$BaseDocumentReference;

  DocumentReference<Base> get reference;

  /// A reference to the [BaseCollectionReference] containing this document.
  BaseCollectionReference get parent {
    return _$BaseCollectionReference(reference.firestore);
  }

  late final BaseTransactionCollectionReference baseTransactions =
      _$BaseTransactionCollectionReference(
    reference,
  );

  @override
  Stream<BaseDocumentSnapshot> snapshots();

  @override
  Future<BaseDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String id,
    FieldValue idFieldValue,
    String name,
    FieldValue nameFieldValue,
    int subBaseCount,
    FieldValue subBaseCountFieldValue,
    String? imageUrl,
    FieldValue imageUrlFieldValue,
    String? imagePath,
    FieldValue imagePathFieldValue,
    DateTime? effectivePeriodBegin,
    FieldValue effectivePeriodBeginFieldValue,
    DateTime? effectivePeriodEnd,
    FieldValue effectivePeriodEndFieldValue,
    String? effectiveTimeBegin,
    FieldValue effectiveTimeBeginFieldValue,
    String? effectiveTimeEnd,
    FieldValue effectiveTimeEndFieldValue,
    int publishStatus,
    FieldValue publishStatusFieldValue,
    int point,
    FieldValue pointFieldValue,
    int pointLimit,
    FieldValue pointLimitFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String id,
    FieldValue idFieldValue,
    String name,
    FieldValue nameFieldValue,
    int subBaseCount,
    FieldValue subBaseCountFieldValue,
    String? imageUrl,
    FieldValue imageUrlFieldValue,
    String? imagePath,
    FieldValue imagePathFieldValue,
    DateTime? effectivePeriodBegin,
    FieldValue effectivePeriodBeginFieldValue,
    DateTime? effectivePeriodEnd,
    FieldValue effectivePeriodEndFieldValue,
    String? effectiveTimeBegin,
    FieldValue effectiveTimeBeginFieldValue,
    String? effectiveTimeEnd,
    FieldValue effectiveTimeEndFieldValue,
    int publishStatus,
    FieldValue publishStatusFieldValue,
    int point,
    FieldValue pointFieldValue,
    int pointLimit,
    FieldValue pointLimitFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$BaseDocumentReference
    extends FirestoreDocumentReference<Base, BaseDocumentSnapshot>
    implements BaseDocumentReference {
  _$BaseDocumentReference(this.reference);

  @override
  final DocumentReference<Base> reference;

  /// A reference to the [BaseCollectionReference] containing this document.
  BaseCollectionReference get parent {
    return _$BaseCollectionReference(reference.firestore);
  }

  late final BaseTransactionCollectionReference baseTransactions =
      _$BaseTransactionCollectionReference(
    reference,
  );

  @override
  Stream<BaseDocumentSnapshot> snapshots() {
    return reference.snapshots().map(BaseDocumentSnapshot._);
  }

  @override
  Future<BaseDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(BaseDocumentSnapshot._);
  }

  @override
  Future<BaseDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(BaseDocumentSnapshot._);
  }

  Future<void> update({
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? name = _sentinel,
    FieldValue? nameFieldValue,
    Object? subBaseCount = _sentinel,
    FieldValue? subBaseCountFieldValue,
    Object? imageUrl = _sentinel,
    FieldValue? imageUrlFieldValue,
    Object? imagePath = _sentinel,
    FieldValue? imagePathFieldValue,
    Object? effectivePeriodBegin = _sentinel,
    FieldValue? effectivePeriodBeginFieldValue,
    Object? effectivePeriodEnd = _sentinel,
    FieldValue? effectivePeriodEndFieldValue,
    Object? effectiveTimeBegin = _sentinel,
    FieldValue? effectiveTimeBeginFieldValue,
    Object? effectiveTimeEnd = _sentinel,
    FieldValue? effectiveTimeEndFieldValue,
    Object? publishStatus = _sentinel,
    FieldValue? publishStatusFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? pointLimit = _sentinel,
    FieldValue? pointLimitFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      name == _sentinel || nameFieldValue == null,
      "Cannot specify both name and nameFieldValue",
    );
    assert(
      subBaseCount == _sentinel || subBaseCountFieldValue == null,
      "Cannot specify both subBaseCount and subBaseCountFieldValue",
    );
    assert(
      imageUrl == _sentinel || imageUrlFieldValue == null,
      "Cannot specify both imageUrl and imageUrlFieldValue",
    );
    assert(
      imagePath == _sentinel || imagePathFieldValue == null,
      "Cannot specify both imagePath and imagePathFieldValue",
    );
    assert(
      effectivePeriodBegin == _sentinel ||
          effectivePeriodBeginFieldValue == null,
      "Cannot specify both effectivePeriodBegin and effectivePeriodBeginFieldValue",
    );
    assert(
      effectivePeriodEnd == _sentinel || effectivePeriodEndFieldValue == null,
      "Cannot specify both effectivePeriodEnd and effectivePeriodEndFieldValue",
    );
    assert(
      effectiveTimeBegin == _sentinel || effectiveTimeBeginFieldValue == null,
      "Cannot specify both effectiveTimeBegin and effectiveTimeBeginFieldValue",
    );
    assert(
      effectiveTimeEnd == _sentinel || effectiveTimeEndFieldValue == null,
      "Cannot specify both effectiveTimeEnd and effectiveTimeEndFieldValue",
    );
    assert(
      publishStatus == _sentinel || publishStatusFieldValue == null,
      "Cannot specify both publishStatus and publishStatusFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      pointLimit == _sentinel || pointLimitFieldValue == null,
      "Cannot specify both pointLimit and pointLimitFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (name != _sentinel) 'name': name as String,
      if (nameFieldValue != null) 'name': nameFieldValue,
      if (subBaseCount != _sentinel) 'subBaseCount': subBaseCount as int,
      if (subBaseCountFieldValue != null)
        'subBaseCount': subBaseCountFieldValue,
      if (imageUrl != _sentinel) 'imageUrl': imageUrl as String?,
      if (imageUrlFieldValue != null) 'imageUrl': imageUrlFieldValue,
      if (imagePath != _sentinel) 'imagePath': imagePath as String?,
      if (imagePathFieldValue != null) 'imagePath': imagePathFieldValue,
      if (effectivePeriodBegin != _sentinel)
        'effectivePeriodBegin': effectivePeriodBegin as DateTime?,
      if (effectivePeriodBeginFieldValue != null)
        'effectivePeriodBegin': effectivePeriodBeginFieldValue,
      if (effectivePeriodEnd != _sentinel)
        'effectivePeriodEnd': effectivePeriodEnd as DateTime?,
      if (effectivePeriodEndFieldValue != null)
        'effectivePeriodEnd': effectivePeriodEndFieldValue,
      if (effectiveTimeBegin != _sentinel)
        'effectiveTimeBegin': effectiveTimeBegin as String?,
      if (effectiveTimeBeginFieldValue != null)
        'effectiveTimeBegin': effectiveTimeBeginFieldValue,
      if (effectiveTimeEnd != _sentinel)
        'effectiveTimeEnd': effectiveTimeEnd as String?,
      if (effectiveTimeEndFieldValue != null)
        'effectiveTimeEnd': effectiveTimeEndFieldValue,
      if (publishStatus != _sentinel) 'publishStatus': publishStatus as int,
      if (publishStatusFieldValue != null)
        'publishStatus': publishStatusFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (pointLimit != _sentinel) 'pointLimit': pointLimit as int,
      if (pointLimitFieldValue != null) 'pointLimit': pointLimitFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? name = _sentinel,
    FieldValue? nameFieldValue,
    Object? subBaseCount = _sentinel,
    FieldValue? subBaseCountFieldValue,
    Object? imageUrl = _sentinel,
    FieldValue? imageUrlFieldValue,
    Object? imagePath = _sentinel,
    FieldValue? imagePathFieldValue,
    Object? effectivePeriodBegin = _sentinel,
    FieldValue? effectivePeriodBeginFieldValue,
    Object? effectivePeriodEnd = _sentinel,
    FieldValue? effectivePeriodEndFieldValue,
    Object? effectiveTimeBegin = _sentinel,
    FieldValue? effectiveTimeBeginFieldValue,
    Object? effectiveTimeEnd = _sentinel,
    FieldValue? effectiveTimeEndFieldValue,
    Object? publishStatus = _sentinel,
    FieldValue? publishStatusFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? pointLimit = _sentinel,
    FieldValue? pointLimitFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      name == _sentinel || nameFieldValue == null,
      "Cannot specify both name and nameFieldValue",
    );
    assert(
      subBaseCount == _sentinel || subBaseCountFieldValue == null,
      "Cannot specify both subBaseCount and subBaseCountFieldValue",
    );
    assert(
      imageUrl == _sentinel || imageUrlFieldValue == null,
      "Cannot specify both imageUrl and imageUrlFieldValue",
    );
    assert(
      imagePath == _sentinel || imagePathFieldValue == null,
      "Cannot specify both imagePath and imagePathFieldValue",
    );
    assert(
      effectivePeriodBegin == _sentinel ||
          effectivePeriodBeginFieldValue == null,
      "Cannot specify both effectivePeriodBegin and effectivePeriodBeginFieldValue",
    );
    assert(
      effectivePeriodEnd == _sentinel || effectivePeriodEndFieldValue == null,
      "Cannot specify both effectivePeriodEnd and effectivePeriodEndFieldValue",
    );
    assert(
      effectiveTimeBegin == _sentinel || effectiveTimeBeginFieldValue == null,
      "Cannot specify both effectiveTimeBegin and effectiveTimeBeginFieldValue",
    );
    assert(
      effectiveTimeEnd == _sentinel || effectiveTimeEndFieldValue == null,
      "Cannot specify both effectiveTimeEnd and effectiveTimeEndFieldValue",
    );
    assert(
      publishStatus == _sentinel || publishStatusFieldValue == null,
      "Cannot specify both publishStatus and publishStatusFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      pointLimit == _sentinel || pointLimitFieldValue == null,
      "Cannot specify both pointLimit and pointLimitFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (name != _sentinel) 'name': name as String,
      if (nameFieldValue != null) 'name': nameFieldValue,
      if (subBaseCount != _sentinel) 'subBaseCount': subBaseCount as int,
      if (subBaseCountFieldValue != null)
        'subBaseCount': subBaseCountFieldValue,
      if (imageUrl != _sentinel) 'imageUrl': imageUrl as String?,
      if (imageUrlFieldValue != null) 'imageUrl': imageUrlFieldValue,
      if (imagePath != _sentinel) 'imagePath': imagePath as String?,
      if (imagePathFieldValue != null) 'imagePath': imagePathFieldValue,
      if (effectivePeriodBegin != _sentinel)
        'effectivePeriodBegin': effectivePeriodBegin as DateTime?,
      if (effectivePeriodBeginFieldValue != null)
        'effectivePeriodBegin': effectivePeriodBeginFieldValue,
      if (effectivePeriodEnd != _sentinel)
        'effectivePeriodEnd': effectivePeriodEnd as DateTime?,
      if (effectivePeriodEndFieldValue != null)
        'effectivePeriodEnd': effectivePeriodEndFieldValue,
      if (effectiveTimeBegin != _sentinel)
        'effectiveTimeBegin': effectiveTimeBegin as String?,
      if (effectiveTimeBeginFieldValue != null)
        'effectiveTimeBegin': effectiveTimeBeginFieldValue,
      if (effectiveTimeEnd != _sentinel)
        'effectiveTimeEnd': effectiveTimeEnd as String?,
      if (effectiveTimeEndFieldValue != null)
        'effectiveTimeEnd': effectiveTimeEndFieldValue,
      if (publishStatus != _sentinel) 'publishStatus': publishStatus as int,
      if (publishStatusFieldValue != null)
        'publishStatus': publishStatusFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (pointLimit != _sentinel) 'pointLimit': pointLimit as int,
      if (pointLimitFieldValue != null) 'pointLimit': pointLimitFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is BaseDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class BaseQuery implements QueryReference<Base, BaseQuerySnapshot> {
  @override
  BaseQuery limit(int limit);

  @override
  BaseQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  BaseQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  BaseQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  BaseQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  BaseQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  BaseQuery whereName({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  BaseQuery whereSubBaseCount({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  BaseQuery whereImageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  BaseQuery whereImagePath({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  BaseQuery whereEffectivePeriodBegin({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  BaseQuery whereEffectivePeriodEnd({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  BaseQuery whereEffectiveTimeBegin({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  BaseQuery whereEffectiveTimeEnd({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  BaseQuery wherePublishStatus({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  BaseQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  BaseQuery wherePointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  BaseQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  BaseQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  BaseQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderById({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByName({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderBySubBaseCount({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByImageUrl({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByImagePath({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByEffectivePeriodBegin({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByEffectivePeriodEnd({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByEffectiveTimeBegin({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByEffectiveTimeEnd({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByPublishStatus({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByPoint({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByPointLimit({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });

  BaseQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  });
}

class _$BaseQuery extends QueryReference<Base, BaseQuerySnapshot>
    implements BaseQuery {
  _$BaseQuery(
    this._collection, {
    required Query<Base> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<BaseQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference.snapshots().map(BaseQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<BaseQuerySnapshot> get([GetOptions? options]) {
    return reference.get(options).then(BaseQuerySnapshot._fromQuerySnapshot);
  }

  @override
  BaseQuery limit(int limit) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  BaseQuery limitToLast(int limit) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['id']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereName({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['name']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereSubBaseCount({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['subBaseCount']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereImageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['imageUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereImagePath({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['imagePath']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereEffectivePeriodBegin({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['effectivePeriodBegin']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereEffectivePeriodEnd({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['effectivePeriodEnd']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereEffectiveTimeBegin({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['effectiveTimeBegin']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereEffectiveTimeEnd({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['effectiveTimeEnd']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery wherePublishStatus({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['publishStatus']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['point']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery wherePointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['pointLimit']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderById({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_BaseFieldMap['id']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByName({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_BaseFieldMap['name']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderBySubBaseCount({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['subBaseCount']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByImageUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_BaseFieldMap['imageUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByImagePath({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['imagePath']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByEffectivePeriodBegin({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseFieldMap['effectivePeriodBegin']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByEffectivePeriodEnd({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseFieldMap['effectivePeriodEnd']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByEffectiveTimeBegin({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseFieldMap['effectiveTimeBegin']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByEffectiveTimeEnd({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['effectiveTimeEnd']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByPublishStatus({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['publishStatus']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByPoint({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_BaseFieldMap['point']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByPointLimit({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['pointLimit']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseDocumentSnapshot? startAtDocument,
    BaseDocumentSnapshot? endAtDocument,
    BaseDocumentSnapshot? endBeforeDocument,
    BaseDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_BaseFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$BaseQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class BaseDocumentSnapshot extends FirestoreDocumentSnapshot<Base> {
  BaseDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<Base> snapshot;

  @override
  BaseDocumentReference get reference {
    return BaseDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final Base? data;
}

class BaseQuerySnapshot
    extends FirestoreQuerySnapshot<Base, BaseQueryDocumentSnapshot> {
  BaseQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory BaseQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<Base> snapshot,
  ) {
    final docs = snapshot.docs.map(BaseQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        BaseDocumentSnapshot._,
      );
    }).toList();

    return BaseQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<BaseDocumentSnapshot> _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    BaseDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<BaseDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<Base> snapshot;

  @override
  final List<BaseQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<BaseDocumentSnapshot>> docChanges;
}

class BaseQueryDocumentSnapshot extends FirestoreQueryDocumentSnapshot<Base>
    implements BaseDocumentSnapshot {
  BaseQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<Base> snapshot;

  @override
  final Base data;

  @override
  BaseDocumentReference get reference {
    return BaseDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class BaseTransactionCollectionReference
    implements
        BaseTransactionQuery,
        FirestoreCollectionReference<BaseTransaction,
            BaseTransactionQuerySnapshot> {
  factory BaseTransactionCollectionReference(
    DocumentReference<Base> parent,
  ) = _$BaseTransactionCollectionReference;

  static BaseTransaction fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return BaseTransaction.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    BaseTransaction value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<BaseTransaction> get reference;

  /// A reference to the containing [BaseDocumentReference] if this is a subcollection.
  BaseDocumentReference get parent;

  @override
  BaseTransactionDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<BaseTransactionDocumentReference> add(BaseTransaction value);
}

class _$BaseTransactionCollectionReference extends _$BaseTransactionQuery
    implements BaseTransactionCollectionReference {
  factory _$BaseTransactionCollectionReference(
    DocumentReference<Base> parent,
  ) {
    return _$BaseTransactionCollectionReference._(
      BaseDocumentReference(parent),
      parent.collection('baseTransactions').withConverter(
            fromFirestore: BaseTransactionCollectionReference.fromFirestore,
            toFirestore: BaseTransactionCollectionReference.toFirestore,
          ),
    );
  }

  _$BaseTransactionCollectionReference._(
    this.parent,
    CollectionReference<BaseTransaction> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final BaseDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<BaseTransaction> get reference =>
      super.reference as CollectionReference<BaseTransaction>;

  @override
  BaseTransactionDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return BaseTransactionDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<BaseTransactionDocumentReference> add(BaseTransaction value) {
    return reference
        .add(value)
        .then((ref) => BaseTransactionDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$BaseTransactionCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class BaseTransactionDocumentReference
    extends FirestoreDocumentReference<BaseTransaction,
        BaseTransactionDocumentSnapshot> {
  factory BaseTransactionDocumentReference(
          DocumentReference<BaseTransaction> reference) =
      _$BaseTransactionDocumentReference;

  DocumentReference<BaseTransaction> get reference;

  /// A reference to the [BaseTransactionCollectionReference] containing this document.
  BaseTransactionCollectionReference get parent {
    return _$BaseTransactionCollectionReference(
      reference.parent.parent!.withConverter<Base>(
        fromFirestore: BaseCollectionReference.fromFirestore,
        toFirestore: BaseCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<BaseTransactionDocumentSnapshot> snapshots();

  @override
  Future<BaseTransactionDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    int pointLimitRemain,
    FieldValue pointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    int pointLimitRemain,
    FieldValue pointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$BaseTransactionDocumentReference extends FirestoreDocumentReference<
        BaseTransaction, BaseTransactionDocumentSnapshot>
    implements BaseTransactionDocumentReference {
  _$BaseTransactionDocumentReference(this.reference);

  @override
  final DocumentReference<BaseTransaction> reference;

  /// A reference to the [BaseTransactionCollectionReference] containing this document.
  BaseTransactionCollectionReference get parent {
    return _$BaseTransactionCollectionReference(
      reference.parent.parent!.withConverter<Base>(
        fromFirestore: BaseCollectionReference.fromFirestore,
        toFirestore: BaseCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<BaseTransactionDocumentSnapshot> snapshots() {
    return reference.snapshots().map(BaseTransactionDocumentSnapshot._);
  }

  @override
  Future<BaseTransactionDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(BaseTransactionDocumentSnapshot._);
  }

  @override
  Future<BaseTransactionDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction.get(reference).then(BaseTransactionDocumentSnapshot._);
  }

  Future<void> update({
    Object? pointLimitRemain = _sentinel,
    FieldValue? pointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      pointLimitRemain == _sentinel || pointLimitRemainFieldValue == null,
      "Cannot specify both pointLimitRemain and pointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (pointLimitRemain != _sentinel)
        'pointLimitRemain': pointLimitRemain as int,
      if (pointLimitRemainFieldValue != null)
        'pointLimitRemain': pointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? pointLimitRemain = _sentinel,
    FieldValue? pointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      pointLimitRemain == _sentinel || pointLimitRemainFieldValue == null,
      "Cannot specify both pointLimitRemain and pointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (pointLimitRemain != _sentinel)
        'pointLimitRemain': pointLimitRemain as int,
      if (pointLimitRemainFieldValue != null)
        'pointLimitRemain': pointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is BaseTransactionDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class BaseTransactionQuery
    implements QueryReference<BaseTransaction, BaseTransactionQuerySnapshot> {
  @override
  BaseTransactionQuery limit(int limit);

  @override
  BaseTransactionQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  BaseTransactionQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  BaseTransactionQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  BaseTransactionQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  BaseTransactionQuery wherePointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  BaseTransactionQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  BaseTransactionQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  BaseTransactionQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  });

  BaseTransactionQuery orderByPointLimitRemain({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  });

  BaseTransactionQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  });

  BaseTransactionQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  });
}

class _$BaseTransactionQuery
    extends QueryReference<BaseTransaction, BaseTransactionQuerySnapshot>
    implements BaseTransactionQuery {
  _$BaseTransactionQuery(
    this._collection, {
    required Query<BaseTransaction> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<BaseTransactionQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(BaseTransactionQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<BaseTransactionQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(BaseTransactionQuerySnapshot._fromQuerySnapshot);
  }

  @override
  BaseTransactionQuery limit(int limit) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  BaseTransactionQuery limitToLast(int limit) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseTransactionQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery wherePointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseTransactionFieldMap['pointLimitRemain']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseTransactionFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_BaseTransactionFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  BaseTransactionQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseTransactionQuery orderByPointLimitRemain({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseTransactionFieldMap['pointLimitRemain']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseTransactionQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseTransactionFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  BaseTransactionQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    BaseTransactionDocumentSnapshot? startAtDocument,
    BaseTransactionDocumentSnapshot? endAtDocument,
    BaseTransactionDocumentSnapshot? endBeforeDocument,
    BaseTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_BaseTransactionFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$BaseTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$BaseTransactionQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class BaseTransactionDocumentSnapshot
    extends FirestoreDocumentSnapshot<BaseTransaction> {
  BaseTransactionDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<BaseTransaction> snapshot;

  @override
  BaseTransactionDocumentReference get reference {
    return BaseTransactionDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final BaseTransaction? data;
}

class BaseTransactionQuerySnapshot extends FirestoreQuerySnapshot<
    BaseTransaction, BaseTransactionQueryDocumentSnapshot> {
  BaseTransactionQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory BaseTransactionQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<BaseTransaction> snapshot,
  ) {
    final docs =
        snapshot.docs.map(BaseTransactionQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        BaseTransactionDocumentSnapshot._,
      );
    }).toList();

    return BaseTransactionQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<BaseTransactionDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    BaseTransactionDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<BaseTransactionDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<BaseTransaction> snapshot;

  @override
  final List<BaseTransactionQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<BaseTransactionDocumentSnapshot>>
      docChanges;
}

class BaseTransactionQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<BaseTransaction>
    implements BaseTransactionDocumentSnapshot {
  BaseTransactionQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<BaseTransaction> snapshot;

  @override
  final BaseTransaction data;

  @override
  BaseTransactionDocumentReference get reference {
    return BaseTransactionDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Base _$$_BaseFromJson(Map<String, dynamic> json) => _$_Base(
      id: json['id'] as String,
      name: json['name'] as String,
      parentRef: _$JsonConverterFromJson<DocumentReference<Object?>,
              DocumentReference<Object?>>(
          json['parentRef'], const DocumentReferenceConverter().fromJson),
      position: MapPosition.fromJson(json['position'] as Map<String, dynamic>),
      titleRef: _$JsonConverterFromJson<DocumentReference<Object?>,
              DocumentReference<Object?>>(
          json['titleRef'], const DocumentReferenceConverter().fromJson),
      subBaseCount: json['subBaseCount'] as int? ?? 0,
      imageUrl: json['imageUrl'] as String?,
      imagePath: json['imagePath'] as String?,
      effectivePeriodBegin: _$JsonConverterFromJson<Timestamp, DateTime>(
          json['effectivePeriodBegin'],
          const FirestoreDateTimeConverter().fromJson),
      effectivePeriodEnd: _$JsonConverterFromJson<Timestamp, DateTime>(
          json['effectivePeriodEnd'],
          const FirestoreDateTimeConverter().fromJson),
      effectiveDaysOfWeek: (json['effectiveDaysOfWeek'] as List<dynamic>?)
          ?.map((e) => e as int)
          .toList(),
      effectiveTimeBegin: json['effectiveTimeBegin'] as String?,
      effectiveTimeEnd: json['effectiveTimeEnd'] as String?,
      publishStatus: json['publishStatus'] as int,
      point: json['point'] as int,
      pointLimit: json['pointLimit'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_BaseFieldMap = <String, String>{
  'id': 'id',
  'name': 'name',
  'parentRef': 'parentRef',
  'position': 'position',
  'titleRef': 'titleRef',
  'subBaseCount': 'subBaseCount',
  'imageUrl': 'imageUrl',
  'imagePath': 'imagePath',
  'effectivePeriodBegin': 'effectivePeriodBegin',
  'effectivePeriodEnd': 'effectivePeriodEnd',
  'effectiveDaysOfWeek': 'effectiveDaysOfWeek',
  'effectiveTimeBegin': 'effectiveTimeBegin',
  'effectiveTimeEnd': 'effectiveTimeEnd',
  'publishStatus': 'publishStatus',
  'point': 'point',
  'pointLimit': 'pointLimit',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_BaseToJson(_$_Base instance) {
  final val = <String, dynamic>{
    'id': instance.id,
    'name': instance.name,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'parentRef',
      _$JsonConverterToJson<DocumentReference<Object?>,
              DocumentReference<Object?>>(
          instance.parentRef, const DocumentReferenceConverter().toJson));
  val['position'] = instance.position.toJson();
  writeNotNull(
      'titleRef',
      _$JsonConverterToJson<DocumentReference<Object?>,
              DocumentReference<Object?>>(
          instance.titleRef, const DocumentReferenceConverter().toJson));
  val['subBaseCount'] = instance.subBaseCount;
  writeNotNull('imageUrl', instance.imageUrl);
  writeNotNull('imagePath', instance.imagePath);
  writeNotNull(
      'effectivePeriodBegin',
      _$JsonConverterToJson<Timestamp, DateTime>(instance.effectivePeriodBegin,
          const FirestoreDateTimeConverter().toJson));
  writeNotNull(
      'effectivePeriodEnd',
      _$JsonConverterToJson<Timestamp, DateTime>(instance.effectivePeriodEnd,
          const FirestoreDateTimeConverter().toJson));
  writeNotNull('effectiveDaysOfWeek', instance.effectiveDaysOfWeek);
  writeNotNull('effectiveTimeBegin', instance.effectiveTimeBegin);
  writeNotNull('effectiveTimeEnd', instance.effectiveTimeEnd);
  val['publishStatus'] = instance.publishStatus;
  val['point'] = instance.point;
  val['pointLimit'] = instance.pointLimit;
  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

Value? _$JsonConverterFromJson<Json, Value>(
  Object? json,
  Value? Function(Json json) fromJson,
) =>
    json == null ? null : fromJson(json as Json);

Json? _$JsonConverterToJson<Json, Value>(
  Value? value,
  Json? Function(Value value) toJson,
) =>
    value == null ? null : toJson(value);

_$_BaseTransaction _$$_BaseTransactionFromJson(Map<String, dynamic> json) =>
    _$_BaseTransaction(
      pointLimitRemain: json['pointLimitRemain'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_BaseTransactionFieldMap = <String, String>{
  'pointLimitRemain': 'pointLimitRemain',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_BaseTransactionToJson(_$_BaseTransaction instance) {
  final val = <String, dynamic>{
    'pointLimitRemain': instance.pointLimitRemain,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

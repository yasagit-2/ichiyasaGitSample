import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'postIcon.freezed.dart';
part 'postIcon.g.dart';

@freezed
class PostIcon with _$PostIcon {
  @firestoreSerializable
  const factory PostIcon({
    // いいね数単位の投稿アイコンURL
    // マップに表示する投稿アイコンのURL。
    // （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、settingsコレクションのpostIconUrlが利用される。
    // 　settingsコレクションのpostIconUrlも利用できない場合、アプリケーション側にてデフォルトアイコンが利用される。
    // 　postIconsコレクション自体が存在しない場合、同様にsettingsコレクションのpostIconUrlが利用される。）
    required String unitOfLikePostIconUrl,
    // いいね数
    // 当該アイコンが有効化される投稿のいいね数。投稿のいいね数がこの数値以下の場合に有効化。
    // 他ドキュメントのlikeCountと同一の値は設定不可（必ず異なる数値を設定）。
    required int likeCount,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _PostIcon;

  factory PostIcon.fromJson(Map<String, Object?> json) =>
      _$PostIconFromJson(json);
}

@Collection<PostIcon>('settings/mevalAppSettings/postIcons', name: 'postIcons')
final postIconsRef = PostIconCollectionReference();

PostIconDocumentReference postIconRef({required String id}) =>
    PostIconDocumentReference(postIconsRef.doc(id).reference);

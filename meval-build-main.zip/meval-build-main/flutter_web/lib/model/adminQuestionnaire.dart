import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'adminQuestionnaire.freezed.dart';
part 'adminQuestionnaire.g.dart';

@freezed
class AdminQuestionnaire with _$AdminQuestionnaire {
  @firestoreSerializable
  const factory AdminQuestionnaire({
    // 行政投稿（アンケート）ID
    required String? id,
    // 行政投稿（アンケート）メッセージ
    required String? message,
    // 投稿の座標
    required MapPosition position,
    // 行政投稿（アンケート）期限
    @TimestampConverter() DateTime? dueDate,
    // 行政投稿（アンケート）画像のURL
    // 行政投稿（アンケート）画像が存在しない場合は省略。
    String? imageUrl,
    // 行政投稿（アンケート）の保存先
    // imageUrlを設定する場合は必須。例：adminQuestionnaires/c9ba78d0-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
    String? imagePath,
    // アンケート回答獲得ポイント
    // アンケート回答により獲得できるポイント。
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _AdminQuestionnaire;

  factory AdminQuestionnaire.fromJson(Map<String, Object?> json) =>
      _$AdminQuestionnaireFromJson(json);
}

@Collection<AdminQuestionnaire>('adminQuestionnaires')
final adminQuestionnairesRef = AdminQuestionnaireCollectionReference();

AdminQuestionnaireDocumentReference adminQuestionnaireRef(
        {required String id}) =>
    AdminQuestionnaireDocumentReference(
        adminQuestionnairesRef.doc(id).reference);

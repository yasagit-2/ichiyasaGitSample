import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'event_data.freezed.dart';
part 'event_data.g.dart';
/// イベント
@freezed
class Event with MapPositionMixin, _$Event {
  @firestoreSerializable
  const factory Event({
    // イベントID
    required String id,
    // イベントタイトル
    required String title,
    // イベント画像のURL
    String? imageUrl,
    // イベント期間開始
    required DateTime effectivePeriodBegin,
    // イベント期間終了
    required DateTime effectivePeriodEnd,
    // イベントアイコンURL
    required String eventIconUrl,
    // スタンプ獲得済アイコンURL
    required String completeSpotIconUrl,
    // イベント達成地点数
    required int completeSpotCount,
    // 位置情報の利用
    required bool isUseLocation,
    // QRコード読み取り可能距離（meter）
    required double qrCodeRadius,
    // イベント達成獲得ポイント
    required int point,
    // 交換制限人数
    required int exchangeLimit,
    // 交換対象種別
    required int exchangeType,
    // イベントスポット数
    required int eventSpotCount,
    // イベントの開催位置情報
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Event;

  factory Event.fromJson(Map<String, Object?> json) => _$EventFromJson(json);
}

@Collection<Event>('events')
@Collection<EventSpot>('events/*/eventSpots', name: 'eventSpots')
@Collection<EventTransaction>('events/*/eventTransactions',
    name: 'eventTransactions')
final eventsRef = EventCollectionReference();

EventDocumentReference eventRef({required String id}) =>
    EventDocumentReference(eventsRef.doc(id).reference);
/// イベントスポット
@freezed
class EventSpot with MapPositionMixin, _$EventSpot {
  @firestoreSerializable
  const factory EventSpot({
    // イベントスポットID
    required String id,
    // イベントスポット名称
    required String name,
    // イベントスポットのURL
    String? imageUrl,
    // イベントスポットの位置情報
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _EventSpot;

  factory EventSpot.fromJson(Map<String, Object?> json) =>
      _$EventSpotFromJson(json);
}

/// イベントトランザクション
@freezed
class EventTransaction with _$EventTransaction {
  @firestoreSerializable
  const factory EventTransaction({
    // 交換制限人数残り
    required int exchangeLimitRemain,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _EventTransaction;

  factory EventTransaction.fromJson(Map<String, Object?> json) =>
      _$EventTransactionFromJson(json);
}


// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'setting.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Setting _$SettingFromJson(Map<String, dynamic> json) {
  return _Setting.fromJson(json);
}

/// @nodoc
mixin _$Setting {
// 拠点アイコンURL
// マップに表示するアイコンのURL。
  String? get baseIconUrl =>
      throw _privateConstructorUsedError; // チェックイン済み拠点アイコンURL
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、
  String? get baseCheckedInIconUrl =>
      throw _privateConstructorUsedError; // サブ拠点アイコンURL
// 　アプリケーション側にてデフォルトアイコンが利用される。）
  String? get subBaseIconUrl =>
      throw _privateConstructorUsedError; // 加盟店アイコンURL
  String? get merchantIconUrl =>
      throw _privateConstructorUsedError; // 加盟店つぶやきアイコンURL
  String? get merchantTweetIconUrl =>
      throw _privateConstructorUsedError; // 投稿アイコンURL
  String? get postIconUrl =>
      throw _privateConstructorUsedError; // 行政投稿アラートアイコンURL
  String? get adminAlertIconUrl =>
      throw _privateConstructorUsedError; // 行政投稿アンケートアイコンURL
  String? get adminQuestionnaireIconUrl =>
      throw _privateConstructorUsedError; // チェックイン可能距離（meter）
// チェックインを可能とする拠点の半径（meter）。小数設定可（例：200.0）。
  int get checkInRadius =>
      throw _privateConstructorUsedError; // 拠点/投稿/加盟店収集半径（km）
// 取得対象とする拠点/投稿/加盟店のマップ中心位置からの半径（km）。小数設定可（例：10.5）。
  int get collectionRadius => throw _privateConstructorUsedError; // 週間規定歩数
// ポイント獲得に必要な週間の規定歩数。（例：35000）少数設定不可。
  int get targetStepPerWeek =>
      throw _privateConstructorUsedError; // 週間規定歩数達成ポイント
// 週間規定歩数を達成することにより獲得できるポイント数。少数設定不可。
  int get stepAchievedPoint =>
      throw _privateConstructorUsedError; // 投稿間隔制限（hour）
// 投稿間隔の制限時間（hour）。少数設定不可。
  int get postIntervalLimitHour =>
      throw _privateConstructorUsedError; // 行政報告間隔制限（hour）
// 行政報告間隔の制限時間（hour）。少数設定不可。
  int get reportIntervalLimitHour =>
      throw _privateConstructorUsedError; // コメント間隔制限（minute）
// コメント間隔の制限時間（minute）。一つの投稿へコメントを行うと、その他の投稿にも間隔制限が経過するまではコメント不可。少数設定不可。
  int get commentIntervalLimitMinute =>
      throw _privateConstructorUsedError; // お知らせ保存日数
// お知らせ有効期限終了（memberNotificationsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したお知らせは物理削除する。少数設定不可。
  int get notificationRetentionDay =>
      throw _privateConstructorUsedError; // イベント保存日数
// イベント開催期間終了（eventsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したイベントは物理削除する。少数設定不可。
  int get eventRetentionDay => throw _privateConstructorUsedError; // 会員削除猶予日数
// 退会申請が行われてから、会員情報を物理削除するまでの猶予日数。少数設定不可。
  int get memberDeletionGraceDay =>
      throw _privateConstructorUsedError; // ヘルプページURL
// ヘルプページのURL。マイページからこのURLへアクセスする。
  String? get helpPageUrl => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SettingCopyWith<Setting> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SettingCopyWith<$Res> {
  factory $SettingCopyWith(Setting value, $Res Function(Setting) then) =
      _$SettingCopyWithImpl<$Res, Setting>;
  @useResult
  $Res call(
      {String? baseIconUrl,
      String? baseCheckedInIconUrl,
      String? subBaseIconUrl,
      String? merchantIconUrl,
      String? merchantTweetIconUrl,
      String? postIconUrl,
      String? adminAlertIconUrl,
      String? adminQuestionnaireIconUrl,
      int checkInRadius,
      int collectionRadius,
      int targetStepPerWeek,
      int stepAchievedPoint,
      int postIntervalLimitHour,
      int reportIntervalLimitHour,
      int commentIntervalLimitMinute,
      int notificationRetentionDay,
      int eventRetentionDay,
      int memberDeletionGraceDay,
      String? helpPageUrl,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$SettingCopyWithImpl<$Res, $Val extends Setting>
    implements $SettingCopyWith<$Res> {
  _$SettingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIconUrl = freezed,
    Object? baseCheckedInIconUrl = freezed,
    Object? subBaseIconUrl = freezed,
    Object? merchantIconUrl = freezed,
    Object? merchantTweetIconUrl = freezed,
    Object? postIconUrl = freezed,
    Object? adminAlertIconUrl = freezed,
    Object? adminQuestionnaireIconUrl = freezed,
    Object? checkInRadius = null,
    Object? collectionRadius = null,
    Object? targetStepPerWeek = null,
    Object? stepAchievedPoint = null,
    Object? postIntervalLimitHour = null,
    Object? reportIntervalLimitHour = null,
    Object? commentIntervalLimitMinute = null,
    Object? notificationRetentionDay = null,
    Object? eventRetentionDay = null,
    Object? memberDeletionGraceDay = null,
    Object? helpPageUrl = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      baseIconUrl: freezed == baseIconUrl
          ? _value.baseIconUrl
          : baseIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      baseCheckedInIconUrl: freezed == baseCheckedInIconUrl
          ? _value.baseCheckedInIconUrl
          : baseCheckedInIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      subBaseIconUrl: freezed == subBaseIconUrl
          ? _value.subBaseIconUrl
          : subBaseIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      merchantIconUrl: freezed == merchantIconUrl
          ? _value.merchantIconUrl
          : merchantIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      merchantTweetIconUrl: freezed == merchantTweetIconUrl
          ? _value.merchantTweetIconUrl
          : merchantTweetIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      postIconUrl: freezed == postIconUrl
          ? _value.postIconUrl
          : postIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      adminAlertIconUrl: freezed == adminAlertIconUrl
          ? _value.adminAlertIconUrl
          : adminAlertIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      adminQuestionnaireIconUrl: freezed == adminQuestionnaireIconUrl
          ? _value.adminQuestionnaireIconUrl
          : adminQuestionnaireIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      checkInRadius: null == checkInRadius
          ? _value.checkInRadius
          : checkInRadius // ignore: cast_nullable_to_non_nullable
              as int,
      collectionRadius: null == collectionRadius
          ? _value.collectionRadius
          : collectionRadius // ignore: cast_nullable_to_non_nullable
              as int,
      targetStepPerWeek: null == targetStepPerWeek
          ? _value.targetStepPerWeek
          : targetStepPerWeek // ignore: cast_nullable_to_non_nullable
              as int,
      stepAchievedPoint: null == stepAchievedPoint
          ? _value.stepAchievedPoint
          : stepAchievedPoint // ignore: cast_nullable_to_non_nullable
              as int,
      postIntervalLimitHour: null == postIntervalLimitHour
          ? _value.postIntervalLimitHour
          : postIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      reportIntervalLimitHour: null == reportIntervalLimitHour
          ? _value.reportIntervalLimitHour
          : reportIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      commentIntervalLimitMinute: null == commentIntervalLimitMinute
          ? _value.commentIntervalLimitMinute
          : commentIntervalLimitMinute // ignore: cast_nullable_to_non_nullable
              as int,
      notificationRetentionDay: null == notificationRetentionDay
          ? _value.notificationRetentionDay
          : notificationRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      eventRetentionDay: null == eventRetentionDay
          ? _value.eventRetentionDay
          : eventRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      memberDeletionGraceDay: null == memberDeletionGraceDay
          ? _value.memberDeletionGraceDay
          : memberDeletionGraceDay // ignore: cast_nullable_to_non_nullable
              as int,
      helpPageUrl: freezed == helpPageUrl
          ? _value.helpPageUrl
          : helpPageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_SettingCopyWith<$Res> implements $SettingCopyWith<$Res> {
  factory _$$_SettingCopyWith(
          _$_Setting value, $Res Function(_$_Setting) then) =
      __$$_SettingCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? baseIconUrl,
      String? baseCheckedInIconUrl,
      String? subBaseIconUrl,
      String? merchantIconUrl,
      String? merchantTweetIconUrl,
      String? postIconUrl,
      String? adminAlertIconUrl,
      String? adminQuestionnaireIconUrl,
      int checkInRadius,
      int collectionRadius,
      int targetStepPerWeek,
      int stepAchievedPoint,
      int postIntervalLimitHour,
      int reportIntervalLimitHour,
      int commentIntervalLimitMinute,
      int notificationRetentionDay,
      int eventRetentionDay,
      int memberDeletionGraceDay,
      String? helpPageUrl,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_SettingCopyWithImpl<$Res>
    extends _$SettingCopyWithImpl<$Res, _$_Setting>
    implements _$$_SettingCopyWith<$Res> {
  __$$_SettingCopyWithImpl(_$_Setting _value, $Res Function(_$_Setting) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIconUrl = freezed,
    Object? baseCheckedInIconUrl = freezed,
    Object? subBaseIconUrl = freezed,
    Object? merchantIconUrl = freezed,
    Object? merchantTweetIconUrl = freezed,
    Object? postIconUrl = freezed,
    Object? adminAlertIconUrl = freezed,
    Object? adminQuestionnaireIconUrl = freezed,
    Object? checkInRadius = null,
    Object? collectionRadius = null,
    Object? targetStepPerWeek = null,
    Object? stepAchievedPoint = null,
    Object? postIntervalLimitHour = null,
    Object? reportIntervalLimitHour = null,
    Object? commentIntervalLimitMinute = null,
    Object? notificationRetentionDay = null,
    Object? eventRetentionDay = null,
    Object? memberDeletionGraceDay = null,
    Object? helpPageUrl = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Setting(
      baseIconUrl: freezed == baseIconUrl
          ? _value.baseIconUrl
          : baseIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      baseCheckedInIconUrl: freezed == baseCheckedInIconUrl
          ? _value.baseCheckedInIconUrl
          : baseCheckedInIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      subBaseIconUrl: freezed == subBaseIconUrl
          ? _value.subBaseIconUrl
          : subBaseIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      merchantIconUrl: freezed == merchantIconUrl
          ? _value.merchantIconUrl
          : merchantIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      merchantTweetIconUrl: freezed == merchantTweetIconUrl
          ? _value.merchantTweetIconUrl
          : merchantTweetIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      postIconUrl: freezed == postIconUrl
          ? _value.postIconUrl
          : postIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      adminAlertIconUrl: freezed == adminAlertIconUrl
          ? _value.adminAlertIconUrl
          : adminAlertIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      adminQuestionnaireIconUrl: freezed == adminQuestionnaireIconUrl
          ? _value.adminQuestionnaireIconUrl
          : adminQuestionnaireIconUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      checkInRadius: null == checkInRadius
          ? _value.checkInRadius
          : checkInRadius // ignore: cast_nullable_to_non_nullable
              as int,
      collectionRadius: null == collectionRadius
          ? _value.collectionRadius
          : collectionRadius // ignore: cast_nullable_to_non_nullable
              as int,
      targetStepPerWeek: null == targetStepPerWeek
          ? _value.targetStepPerWeek
          : targetStepPerWeek // ignore: cast_nullable_to_non_nullable
              as int,
      stepAchievedPoint: null == stepAchievedPoint
          ? _value.stepAchievedPoint
          : stepAchievedPoint // ignore: cast_nullable_to_non_nullable
              as int,
      postIntervalLimitHour: null == postIntervalLimitHour
          ? _value.postIntervalLimitHour
          : postIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      reportIntervalLimitHour: null == reportIntervalLimitHour
          ? _value.reportIntervalLimitHour
          : reportIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      commentIntervalLimitMinute: null == commentIntervalLimitMinute
          ? _value.commentIntervalLimitMinute
          : commentIntervalLimitMinute // ignore: cast_nullable_to_non_nullable
              as int,
      notificationRetentionDay: null == notificationRetentionDay
          ? _value.notificationRetentionDay
          : notificationRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      eventRetentionDay: null == eventRetentionDay
          ? _value.eventRetentionDay
          : eventRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      memberDeletionGraceDay: null == memberDeletionGraceDay
          ? _value.memberDeletionGraceDay
          : memberDeletionGraceDay // ignore: cast_nullable_to_non_nullable
              as int,
      helpPageUrl: freezed == helpPageUrl
          ? _value.helpPageUrl
          : helpPageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Setting implements _Setting {
  const _$_Setting(
      {required this.baseIconUrl,
      required this.baseCheckedInIconUrl,
      required this.subBaseIconUrl,
      required this.merchantIconUrl,
      required this.merchantTweetIconUrl,
      required this.postIconUrl,
      required this.adminAlertIconUrl,
      required this.adminQuestionnaireIconUrl,
      required this.checkInRadius,
      required this.collectionRadius,
      required this.targetStepPerWeek,
      required this.stepAchievedPoint,
      required this.postIntervalLimitHour,
      required this.reportIntervalLimitHour,
      required this.commentIntervalLimitMinute,
      required this.notificationRetentionDay,
      required this.eventRetentionDay,
      required this.memberDeletionGraceDay,
      required this.helpPageUrl,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Setting.fromJson(Map<String, dynamic> json) =>
      _$$_SettingFromJson(json);

// 拠点アイコンURL
// マップに表示するアイコンのURL。
  @override
  final String? baseIconUrl;
// チェックイン済み拠点アイコンURL
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、
  @override
  final String? baseCheckedInIconUrl;
// サブ拠点アイコンURL
// 　アプリケーション側にてデフォルトアイコンが利用される。）
  @override
  final String? subBaseIconUrl;
// 加盟店アイコンURL
  @override
  final String? merchantIconUrl;
// 加盟店つぶやきアイコンURL
  @override
  final String? merchantTweetIconUrl;
// 投稿アイコンURL
  @override
  final String? postIconUrl;
// 行政投稿アラートアイコンURL
  @override
  final String? adminAlertIconUrl;
// 行政投稿アンケートアイコンURL
  @override
  final String? adminQuestionnaireIconUrl;
// チェックイン可能距離（meter）
// チェックインを可能とする拠点の半径（meter）。小数設定可（例：200.0）。
  @override
  final int checkInRadius;
// 拠点/投稿/加盟店収集半径（km）
// 取得対象とする拠点/投稿/加盟店のマップ中心位置からの半径（km）。小数設定可（例：10.5）。
  @override
  final int collectionRadius;
// 週間規定歩数
// ポイント獲得に必要な週間の規定歩数。（例：35000）少数設定不可。
  @override
  final int targetStepPerWeek;
// 週間規定歩数達成ポイント
// 週間規定歩数を達成することにより獲得できるポイント数。少数設定不可。
  @override
  final int stepAchievedPoint;
// 投稿間隔制限（hour）
// 投稿間隔の制限時間（hour）。少数設定不可。
  @override
  final int postIntervalLimitHour;
// 行政報告間隔制限（hour）
// 行政報告間隔の制限時間（hour）。少数設定不可。
  @override
  final int reportIntervalLimitHour;
// コメント間隔制限（minute）
// コメント間隔の制限時間（minute）。一つの投稿へコメントを行うと、その他の投稿にも間隔制限が経過するまではコメント不可。少数設定不可。
  @override
  final int commentIntervalLimitMinute;
// お知らせ保存日数
// お知らせ有効期限終了（memberNotificationsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したお知らせは物理削除する。少数設定不可。
  @override
  final int notificationRetentionDay;
// イベント保存日数
// イベント開催期間終了（eventsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したイベントは物理削除する。少数設定不可。
  @override
  final int eventRetentionDay;
// 会員削除猶予日数
// 退会申請が行われてから、会員情報を物理削除するまでの猶予日数。少数設定不可。
  @override
  final int memberDeletionGraceDay;
// ヘルプページURL
// ヘルプページのURL。マイページからこのURLへアクセスする。
  @override
  final String? helpPageUrl;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Setting(baseIconUrl: $baseIconUrl, baseCheckedInIconUrl: $baseCheckedInIconUrl, subBaseIconUrl: $subBaseIconUrl, merchantIconUrl: $merchantIconUrl, merchantTweetIconUrl: $merchantTweetIconUrl, postIconUrl: $postIconUrl, adminAlertIconUrl: $adminAlertIconUrl, adminQuestionnaireIconUrl: $adminQuestionnaireIconUrl, checkInRadius: $checkInRadius, collectionRadius: $collectionRadius, targetStepPerWeek: $targetStepPerWeek, stepAchievedPoint: $stepAchievedPoint, postIntervalLimitHour: $postIntervalLimitHour, reportIntervalLimitHour: $reportIntervalLimitHour, commentIntervalLimitMinute: $commentIntervalLimitMinute, notificationRetentionDay: $notificationRetentionDay, eventRetentionDay: $eventRetentionDay, memberDeletionGraceDay: $memberDeletionGraceDay, helpPageUrl: $helpPageUrl, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Setting &&
            (identical(other.baseIconUrl, baseIconUrl) ||
                other.baseIconUrl == baseIconUrl) &&
            (identical(other.baseCheckedInIconUrl, baseCheckedInIconUrl) ||
                other.baseCheckedInIconUrl == baseCheckedInIconUrl) &&
            (identical(other.subBaseIconUrl, subBaseIconUrl) ||
                other.subBaseIconUrl == subBaseIconUrl) &&
            (identical(other.merchantIconUrl, merchantIconUrl) ||
                other.merchantIconUrl == merchantIconUrl) &&
            (identical(other.merchantTweetIconUrl, merchantTweetIconUrl) ||
                other.merchantTweetIconUrl == merchantTweetIconUrl) &&
            (identical(other.postIconUrl, postIconUrl) ||
                other.postIconUrl == postIconUrl) &&
            (identical(other.adminAlertIconUrl, adminAlertIconUrl) ||
                other.adminAlertIconUrl == adminAlertIconUrl) &&
            (identical(other.adminQuestionnaireIconUrl,
                    adminQuestionnaireIconUrl) ||
                other.adminQuestionnaireIconUrl == adminQuestionnaireIconUrl) &&
            (identical(other.checkInRadius, checkInRadius) ||
                other.checkInRadius == checkInRadius) &&
            (identical(other.collectionRadius, collectionRadius) ||
                other.collectionRadius == collectionRadius) &&
            (identical(other.targetStepPerWeek, targetStepPerWeek) ||
                other.targetStepPerWeek == targetStepPerWeek) &&
            (identical(other.stepAchievedPoint, stepAchievedPoint) ||
                other.stepAchievedPoint == stepAchievedPoint) &&
            (identical(other.postIntervalLimitHour, postIntervalLimitHour) ||
                other.postIntervalLimitHour == postIntervalLimitHour) &&
            (identical(other.reportIntervalLimitHour, reportIntervalLimitHour) ||
                other.reportIntervalLimitHour == reportIntervalLimitHour) &&
            (identical(other.commentIntervalLimitMinute,
                    commentIntervalLimitMinute) ||
                other.commentIntervalLimitMinute ==
                    commentIntervalLimitMinute) &&
            (identical(
                    other.notificationRetentionDay, notificationRetentionDay) ||
                other.notificationRetentionDay == notificationRetentionDay) &&
            (identical(other.eventRetentionDay, eventRetentionDay) ||
                other.eventRetentionDay == eventRetentionDay) &&
            (identical(other.memberDeletionGraceDay, memberDeletionGraceDay) ||
                other.memberDeletionGraceDay == memberDeletionGraceDay) &&
            (identical(other.helpPageUrl, helpPageUrl) ||
                other.helpPageUrl == helpPageUrl) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        baseIconUrl,
        baseCheckedInIconUrl,
        subBaseIconUrl,
        merchantIconUrl,
        merchantTweetIconUrl,
        postIconUrl,
        adminAlertIconUrl,
        adminQuestionnaireIconUrl,
        checkInRadius,
        collectionRadius,
        targetStepPerWeek,
        stepAchievedPoint,
        postIntervalLimitHour,
        reportIntervalLimitHour,
        commentIntervalLimitMinute,
        notificationRetentionDay,
        eventRetentionDay,
        memberDeletionGraceDay,
        helpPageUrl,
        updatedAt,
        createdAt
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SettingCopyWith<_$_Setting> get copyWith =>
      __$$_SettingCopyWithImpl<_$_Setting>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SettingToJson(
      this,
    );
  }
}

abstract class _Setting implements Setting {
  const factory _Setting(
      {required final String? baseIconUrl,
      required final String? baseCheckedInIconUrl,
      required final String? subBaseIconUrl,
      required final String? merchantIconUrl,
      required final String? merchantTweetIconUrl,
      required final String? postIconUrl,
      required final String? adminAlertIconUrl,
      required final String? adminQuestionnaireIconUrl,
      required final int checkInRadius,
      required final int collectionRadius,
      required final int targetStepPerWeek,
      required final int stepAchievedPoint,
      required final int postIntervalLimitHour,
      required final int reportIntervalLimitHour,
      required final int commentIntervalLimitMinute,
      required final int notificationRetentionDay,
      required final int eventRetentionDay,
      required final int memberDeletionGraceDay,
      required final String? helpPageUrl,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Setting;

  factory _Setting.fromJson(Map<String, dynamic> json) = _$_Setting.fromJson;

  @override // 拠点アイコンURL
// マップに表示するアイコンのURL。
  String? get baseIconUrl;
  @override // チェックイン済み拠点アイコンURL
// （省略不可。ただし、存在しないURLやブランク等の文字列を設定した場合、
  String? get baseCheckedInIconUrl;
  @override // サブ拠点アイコンURL
// 　アプリケーション側にてデフォルトアイコンが利用される。）
  String? get subBaseIconUrl;
  @override // 加盟店アイコンURL
  String? get merchantIconUrl;
  @override // 加盟店つぶやきアイコンURL
  String? get merchantTweetIconUrl;
  @override // 投稿アイコンURL
  String? get postIconUrl;
  @override // 行政投稿アラートアイコンURL
  String? get adminAlertIconUrl;
  @override // 行政投稿アンケートアイコンURL
  String? get adminQuestionnaireIconUrl;
  @override // チェックイン可能距離（meter）
// チェックインを可能とする拠点の半径（meter）。小数設定可（例：200.0）。
  int get checkInRadius;
  @override // 拠点/投稿/加盟店収集半径（km）
// 取得対象とする拠点/投稿/加盟店のマップ中心位置からの半径（km）。小数設定可（例：10.5）。
  int get collectionRadius;
  @override // 週間規定歩数
// ポイント獲得に必要な週間の規定歩数。（例：35000）少数設定不可。
  int get targetStepPerWeek;
  @override // 週間規定歩数達成ポイント
// 週間規定歩数を達成することにより獲得できるポイント数。少数設定不可。
  int get stepAchievedPoint;
  @override // 投稿間隔制限（hour）
// 投稿間隔の制限時間（hour）。少数設定不可。
  int get postIntervalLimitHour;
  @override // 行政報告間隔制限（hour）
// 行政報告間隔の制限時間（hour）。少数設定不可。
  int get reportIntervalLimitHour;
  @override // コメント間隔制限（minute）
// コメント間隔の制限時間（minute）。一つの投稿へコメントを行うと、その他の投稿にも間隔制限が経過するまではコメント不可。少数設定不可。
  int get commentIntervalLimitMinute;
  @override // お知らせ保存日数
// お知らせ有効期限終了（memberNotificationsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したお知らせは物理削除する。少数設定不可。
  int get notificationRetentionDay;
  @override // イベント保存日数
// イベント開催期間終了（eventsのeffectivePeriodEnd）からの保存日数。この保存日数を超過したイベントは物理削除する。少数設定不可。
  int get eventRetentionDay;
  @override // 会員削除猶予日数
// 退会申請が行われてから、会員情報を物理削除するまでの猶予日数。少数設定不可。
  int get memberDeletionGraceDay;
  @override // ヘルプページURL
// ヘルプページのURL。マイページからこのURLへアクセスする。
  String? get helpPageUrl;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_SettingCopyWith<_$_Setting> get copyWith =>
      throw _privateConstructorUsedError;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'adminAlert.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

AdminAlert _$AdminAlertFromJson(Map<String, dynamic> json) {
  return _AdminAlert.fromJson(json);
}

/// @nodoc
mixin _$AdminAlert {
// 行政投稿（注意）ID
  String? get id => throw _privateConstructorUsedError; // 行政投稿（注意）メッセージ
  String? get message => throw _privateConstructorUsedError; // 投稿の座標
  MapPosition get position => throw _privateConstructorUsedError; // 行政投稿（注意）期限
  @TimestampConverter()
  DateTime? get dueDate => throw _privateConstructorUsedError; // 行政投稿（注意）画像のURL
// 行政投稿（注意）画像が存在しない場合は省略。
  String? get imageUrl => throw _privateConstructorUsedError; // 行政投稿（注意）の保存先
// 行政投稿（注意）画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：adminAlerts/9b823250-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  String? get imagePath => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AdminAlertCopyWith<AdminAlert> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdminAlertCopyWith<$Res> {
  factory $AdminAlertCopyWith(
          AdminAlert value, $Res Function(AdminAlert) then) =
      _$AdminAlertCopyWithImpl<$Res, AdminAlert>;
  @useResult
  $Res call(
      {String? id,
      String? message,
      MapPosition position,
      @TimestampConverter() DateTime? dueDate,
      String? imageUrl,
      String? imagePath,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$AdminAlertCopyWithImpl<$Res, $Val extends AdminAlert>
    implements $AdminAlertCopyWith<$Res> {
  _$AdminAlertCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? position = null,
    Object? dueDate = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      dueDate: freezed == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_AdminAlertCopyWith<$Res>
    implements $AdminAlertCopyWith<$Res> {
  factory _$$_AdminAlertCopyWith(
          _$_AdminAlert value, $Res Function(_$_AdminAlert) then) =
      __$$_AdminAlertCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? message,
      MapPosition position,
      @TimestampConverter() DateTime? dueDate,
      String? imageUrl,
      String? imagePath,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_AdminAlertCopyWithImpl<$Res>
    extends _$AdminAlertCopyWithImpl<$Res, _$_AdminAlert>
    implements _$$_AdminAlertCopyWith<$Res> {
  __$$_AdminAlertCopyWithImpl(
      _$_AdminAlert _value, $Res Function(_$_AdminAlert) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? message = freezed,
    Object? position = null,
    Object? dueDate = freezed,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_AdminAlert(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      dueDate: freezed == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_AdminAlert implements _AdminAlert {
  const _$_AdminAlert(
      {required this.id,
      required this.message,
      required this.position,
      @TimestampConverter() this.dueDate,
      this.imageUrl,
      this.imagePath,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_AdminAlert.fromJson(Map<String, dynamic> json) =>
      _$$_AdminAlertFromJson(json);

// 行政投稿（注意）ID
  @override
  final String? id;
// 行政投稿（注意）メッセージ
  @override
  final String? message;
// 投稿の座標
  @override
  final MapPosition position;
// 行政投稿（注意）期限
  @override
  @TimestampConverter()
  final DateTime? dueDate;
// 行政投稿（注意）画像のURL
// 行政投稿（注意）画像が存在しない場合は省略。
  @override
  final String? imageUrl;
// 行政投稿（注意）の保存先
// 行政投稿（注意）画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：adminAlerts/9b823250-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  @override
  final String? imagePath;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'AdminAlert(id: $id, message: $message, position: $position, dueDate: $dueDate, imageUrl: $imageUrl, imagePath: $imagePath, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AdminAlert &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.dueDate, dueDate) || other.dueDate == dueDate) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, message, position, dueDate,
      imageUrl, imagePath, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AdminAlertCopyWith<_$_AdminAlert> get copyWith =>
      __$$_AdminAlertCopyWithImpl<_$_AdminAlert>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AdminAlertToJson(
      this,
    );
  }
}

abstract class _AdminAlert implements AdminAlert {
  const factory _AdminAlert(
      {required final String? id,
      required final String? message,
      required final MapPosition position,
      @TimestampConverter() final DateTime? dueDate,
      final String? imageUrl,
      final String? imagePath,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_AdminAlert;

  factory _AdminAlert.fromJson(Map<String, dynamic> json) =
      _$_AdminAlert.fromJson;

  @override // 行政投稿（注意）ID
  String? get id;
  @override // 行政投稿（注意）メッセージ
  String? get message;
  @override // 投稿の座標
  MapPosition get position;
  @override // 行政投稿（注意）期限
  @TimestampConverter()
  DateTime? get dueDate;
  @override // 行政投稿（注意）画像のURL
// 行政投稿（注意）画像が存在しない場合は省略。
  String? get imageUrl;
  @override // 行政投稿（注意）の保存先
// 行政投稿（注意）画像が存在しない場合は省略。imageUrlを設定する場合は必須。例：adminAlerts/9b823250-1f4c-11ed-a58e-2d93bf301945（ファイル名は特に規定しない）
  String? get imagePath;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_AdminAlertCopyWith<_$_AdminAlert> get copyWith =>
      throw _privateConstructorUsedError;
}

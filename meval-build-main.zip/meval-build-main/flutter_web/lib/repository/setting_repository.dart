import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/setting.dart';

final settingRepositoryProvider = Provider((ref) => SettingRepository());

class SettingRepository {
  Stream<List<Setting>> getSettings() {
    return settingsRef.snapshots().map((settingQuerySnapshot) =>
        settingQuerySnapshot.docs
            .map((settingQueryDocSnap) => settingQueryDocSnap.data)
            .toList());
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/member.dart';

final memberRepositoryProvider = Provider((ref) => MemberRepository());

class MemberRepository {
  Stream<List<Member>> getMembers() {
    return membersRef.snapshots().map((memberQuerySnapshot) =>
        memberQuerySnapshot.docs
            .map((memberQueryDocSnap) => memberQueryDocSnap.data)
            .toList());
  }

  Stream<Member?> getMemberById(String memberid) {
    return memberRef(id: memberid)
        .snapshots()
        .map((memberQuerySnapshot) => memberQuerySnapshot.data);
  }
}

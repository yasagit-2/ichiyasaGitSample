import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/adminAlert.dart';

final adminAlertRepositoryProvider = Provider((ref) => AdminAlertRepository());

class AdminAlertRepository {
  Stream<List<AdminAlert>> getAdminAlerts() {
    return adminAlertsRef.snapshots().map((adminAlertQuerySnapshot) =>
        adminAlertQuerySnapshot.docs
            .map((adminAlertQueryDocSnap) => adminAlertQueryDocSnap.data)
            .toList());
  }

  Stream<AdminAlert?> getAdminAlertById(String adminAlertid) {
    return adminAlertRef(id: adminAlertid)
        .snapshots()
        .map((adminAlertQuerySnapshot) => adminAlertQuerySnapshot.data);
  }
}

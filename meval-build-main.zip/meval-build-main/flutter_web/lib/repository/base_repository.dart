import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../model/base.dart';

final baseRepositoryProvider = Provider((ref) => BaseRepository());

class BaseRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Base>> getParentBases() {
    return basesRef.snapshots().map(
          (baseQuerySnapshot) => baseQuerySnapshot.docs
              .map(
                (baseQueryDocSnap) {
                  final base = baseQueryDocSnap.data;
                  if (base.parentRef != null) {
                    return null;
                  }
                  return baseQueryDocSnap.data;
                },
              )
              .whereType<Base>()
              .toList(),
        );
  }

  Future<int> getPointLimitRemain(String baseId) async {
    final baseTransactionDocSnap =
        await baseRef(id: baseId).baseTransactions.doc('baseTransaction').get();

    final baseTransaction = baseTransactionDocSnap.data;
    if (baseTransaction == null) {
      return 0;
    }

    return baseTransaction.pointLimitRemain;
  }

  Stream<List<Base>> getSubBasesByParentBaseId(String parentBaseId) {
    final parentBaseDocRef = baseRef(id: parentBaseId).reference;
    return basesRef.reference
        .where('parentRef', isEqualTo: parentBaseDocRef)
        .snapshots()
        .map((querySnapshot) => querySnapshot.docs
            .map((queryDocSnap) => queryDocSnap.data())
            .toList());
  }

  Future<void> createParentBase(Base parentBase, File? imageFile) async {
    if (imageFile != null) {
      // 投稿画像の保存

      final storageRef =
          FirebaseStorage.instance.ref().child('bases/${parentBase.id}');

      final metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {'picked-file-path': imageFile.path},
      );

      final xFile = XFile(imageFile.path);

      // 投稿画像をStorageへ保存
      final taskSnapshot =
          await storageRef.putData(await xFile.readAsBytes(), metadata);
      final imageUrl = await taskSnapshot.ref.getDownloadURL();
      final imagePath = taskSnapshot.ref.fullPath;

      parentBase =
          parentBase.copyWith(imageUrl: imageUrl, imagePath: imagePath);
    }

    return await _db.runTransaction((transaction) async {
      transaction.set(baseRef(id: parentBase.id).reference, parentBase);
      transaction.set(
          baseRef(id: parentBase.id)
              .baseTransactions
              .doc('baseTransaction')
              .reference,
          BaseTransaction(pointLimitRemain: parentBase.pointLimit));
    });
  }
}

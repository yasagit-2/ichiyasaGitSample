import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/title_data.dart';

final titleRepositoryProvider = Provider((ref) => TitleRepository());

class TitleRepository {
  Stream<List<TitleData>> getTitles() {
    return titlesRef.snapshots().map((titleQuerySnapshot) => titleQuerySnapshot
        .docs
        .map((titleQueryDocSnap) => titleQueryDocSnap.data)
        .toList());
  }

  Stream<TitleData?> getTitleById(String titleId) {
    return titleRef(id: titleId)
        .snapshots()
        .map((titleDocumentSnapshot) =>
            titleDocumentSnapshot.data);
  }

  /// 称号情報を更新します。
  Future<void> updateTitle({
    required String titleId,
    required String name,
    required int point,
    required int pointLimit,
  }) async {

    return await titleRef(id:titleId).reference.update(
      {
        'name': name,
        'point': point,
        'pointLimit': pointLimit,
        'updatedAt': FieldValue.serverTimestamp(),
      },
    );
  }
    /// 投稿[post]を削除します。
  Future<void> deleteTitle(String titleId) async {
    // 投稿削除
    return await titleRef(id: titleId)
        .delete()
        .timeout(Duration(seconds: 300));
  }
}


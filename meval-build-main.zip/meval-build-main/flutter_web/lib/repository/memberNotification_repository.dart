import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/memberNotification.dart';

final memberNotificationRepositoryProvider =
    Provider((ref) => MemberNotificationRepository());

class MemberNotificationRepository {
  Stream<List<MemberNotification>> getMemberNotifications() {
    return memberNotificationsRef.snapshots().map(
        (memberNotificationQuerySnapshot) => memberNotificationQuerySnapshot
            .docs
            .map((memberNotificationQueryDocSnap) =>
                memberNotificationQueryDocSnap.data)
            .toList());
  }

  Stream<MemberNotification?> getMemberNotificationById(
      String memberNotificationid) {
    return memberNotificationRef(id: memberNotificationid).snapshots().map(
        (memberNotificationQuerySnapshot) =>
            memberNotificationQuerySnapshot.data);
  }
}

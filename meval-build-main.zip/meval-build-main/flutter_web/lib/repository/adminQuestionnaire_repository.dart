import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/adminQuestionnaire.dart';

final adminQuestionnaireRepositoryProvider =
    Provider((ref) => AdminQuestionnaireRepository());

class AdminQuestionnaireRepository {
  Stream<List<AdminQuestionnaire>> getAdminQuestionnaires() {
    return adminQuestionnairesRef.snapshots().map(
        (adminQuestionnaireQuerySnapshot) => adminQuestionnaireQuerySnapshot
            .docs
            .map((adminQuestionnaireQueryDocSnap) =>
                adminQuestionnaireQueryDocSnap.data)
            .toList());
  }

  Stream<AdminQuestionnaire?> getAdminQuestionnaireById(
      String adminQuestionnaireid) {
    return adminQuestionnaireRef(id: adminQuestionnaireid).snapshots().map(
        (adminQuestionnaireQuerySnapshot) =>
            adminQuestionnaireQuerySnapshot.data);
  }
}

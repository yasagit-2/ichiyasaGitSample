import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/maintenance.dart';

final maintenanceRepositoryProvider =
    Provider((ref) => MaintenanceRepository());

class MaintenanceRepository {
  Stream<List<Maintenance>> getMaintenances() {
    return maintenancesRef.snapshots().map((maintenanceQuerySnapshot) =>
        maintenanceQuerySnapshot.docs
            .map((maintenanceQueryDocSnap) => maintenanceQueryDocSnap.data)
            .toList());
  }
}

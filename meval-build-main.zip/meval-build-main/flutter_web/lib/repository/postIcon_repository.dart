import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/postIcon.dart';

final postIconRepositoryProvider = Provider((ref) => PostIconRepository());

class PostIconRepository {
  Stream<List<PostIcon>> getPostIcons() {
    return postIconsRef.snapshots().map((postIconQuerySnapshot) =>
        postIconQuerySnapshot.docs
            .map((postIconQueryDocSnap) => postIconQueryDocSnap.data)
            .toList());
  }

  Stream<PostIcon?> getPostIconById(String postIconid) {
    return postIconRef(id: postIconid)
        .snapshots()
        .map((postIconQuerySnapshot) => postIconQuerySnapshot.data);
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/merchant.dart';

final merchantRepositoryProvider = Provider((ref) => MerchantRepository());

class MerchantRepository {
  Stream<List<Merchant>> getMerchants() {
    return merchantsRef.snapshots().map((merchantQuerySnapshot) =>
        merchantQuerySnapshot.docs
            .map((merchantQueryDocSnap) => merchantQueryDocSnap.data)
            .toList());
  }

  Stream<Merchant?> getMerchantById(String merchantid) {
    return merchantRef(id: merchantid)
        .snapshots()
        .map((merchantQuerySnapshot) => merchantQuerySnapshot.data);
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/post.dart';

final postRepositoryProvider = Provider((ref) => PostRepository());

class PostRepository {
  Stream<List<Post>> getPosts() {
    return postsRef.snapshots().map((postQuerySnapshot) => postQuerySnapshot
        .docs
        .map((postQueryDocSnap) => postQueryDocSnap.data)
        .toList());
  }

  Stream<Post?> getPostById(String postid) {
    return postRef(id: postid)
        .snapshots()
        .map((postQuerySnapshot) => postQuerySnapshot.data);
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/event_data.dart';

final eventRepositoryProvider = Provider((ref) => EventRepository());

class EventRepository {
  Stream<List<Event>> getEvents() {
    return eventsRef.snapshots().map((eventQuerySnapshot) => eventQuerySnapshot
        .docs
        .map((eventQueryDocSnap) => eventQueryDocSnap.data)
        .toList());
  }
  /// [eventId]のイベントスポット(Stream)を取得します。
  Stream<List<EventSpot>> getEventSpotById(String eventId) {
  return eventRef(id: eventId).eventSpots.snapshots().map(
        (eventSpotQuerySnapshot) => eventSpotQuerySnapshot.docs
            .map((eventSpotQueryDocSnapshot) => eventSpotQueryDocSnapshot.data)
            .toList());
  }
}
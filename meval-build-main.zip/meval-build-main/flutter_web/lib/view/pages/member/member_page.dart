import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/member.dart';
import '../../../provider/member_provider.dart';
import '../../../util/logger.dart';

// import 'add_member_page.dart';
// import 'edit_member_page.dart';
import 'show_member_page.dart';

class MemberPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '会員ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'ニックネーム',
      field: 'nickname',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '生年月',
      field: 'monthOfBirth',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '性別',
      field: 'gender',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '居住地',
      field: 'prefecture',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '認証プロバイダ',
      field: 'authenticationProvider',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿日時',
      field: 'postedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政報告日時',
      field: 'reportedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'コメント日時',
      field: 'commentedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const MemberPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final membersAsyncValue = ref.watch(membersStreamProvider);

    if (membersAsyncValue is! AsyncData || membersAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = membersAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ユーザー管理'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('ユーザー一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openAddItemDialog(context);
                                //   },
                                //   child: const Text('追加'),
                                // ),
                                // const SizedBox(width: 24.0),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openEditItemDialog(context);
                                //   },
                                //   child: const Text('更新'),
                                // ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openShowItemDialog(context);
                                  },
                                  child: const Text('詳細'),
                                ),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(memberIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(memberIdProvider.notifier)
                              .update((_) => selectedId);

                          openShowItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<Member> members) {
    List<PlutoRow> rows = [];
    members.asMap().forEach(
      (index, member) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: member.id),
            'nickname': PlutoCell(value: member.nickname),
            'monthOfBirth': PlutoCell(value: member.monthOfBirth),
            'gender': PlutoCell(value: member.gender),
            'prefecture': PlutoCell(value: member.prefecture),
            'authenticationProvider':
                PlutoCell(value: member.authenticationProvider),
            'postedAt': PlutoCell(value: member.postedAt),
            'reportedAt': PlutoCell(value: member.reportedAt),
            'commentedAt': PlutoCell(value: member.commentedAt),
            'updatedAt': PlutoCell(value: member.updatedAt),
            'createdAt': PlutoCell(value: member.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  // void openAddItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 800.0,
  //           width: 800.0,
  //           child: AddMemberPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  // void openEditItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 1000.0,
  //           width: 800.0,
  //           child: EditMemberPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  void openShowItemDialog(BuildContext context) {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => const ShowMemberPage()));
  }
}

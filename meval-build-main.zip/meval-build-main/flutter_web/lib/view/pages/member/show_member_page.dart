import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../provider/member_provider.dart';

final memberIdProvider = StateProvider<String>((ref) => '');

const titleColumnColoer = Colors.grey;
const titleColumnWidth = 150.0;
const cellMarginWidth = EdgeInsets.all(10.0);

class ShowMemberPage extends ConsumerWidget {
  const ShowMemberPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 指定されたアイテムのIDを取得
    final selectId = ref.watch(memberIdProvider);

    // 指定されたアイテムのデータを取得(非同期待ち)
    final selectItemAsyncValue = ref.watch(memberIdSelectProvider(selectId));
    if (selectId.isNotEmpty) {
      if (selectItemAsyncValue is! AsyncData ||
          selectItemAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    final selectItem = selectItemAsyncValue.value!;

    return Scaffold(
        appBar: AppBar(
          title: const Text('ユーザー詳細'),
        ),
        body: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          return Container(
              margin: EdgeInsets.all(30.0),
              child: Table(
                border: TableBorder.all(color: Color.fromARGB(255, 0, 0, 0)),
                columnWidths: const <int, TableColumnWidth>{
                  0: IntrinsicColumnWidth(),
                  1: FlexColumnWidth(1.0),
                },
                defaultVerticalAlignment: TableCellVerticalAlignment.top,
                children: [
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('会員ID'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.id.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('会員ステータス'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child:
                          const Text("【ここにトグルスイッチを表示】データはFireBaseのAuthから取ってくる"),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('ニックネーム'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.nickname.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('生年月'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.monthOfBirth.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('性別'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.gender.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('居住地'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.prefecture.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('認証プロバイダ'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.authenticationProvider.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('投稿日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.postedAt.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政報告日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.reportedAt.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('コメント日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.commentedAt.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('更新日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.updatedAt.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('登録日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.createdAt.toString()),
                    ),
                  ]),
                ],
              ));
        }));
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/post.dart';
import '../../../provider/post_provider.dart';
import '../../../util/logger.dart';

// import 'add_post_page.dart';
// import 'edit_post_page.dart';
import 'show_post_page.dart';

class PostPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿メッセージ',
      field: 'message',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '会員のリファレンス',
      field: 'memberRef',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿画像のURL',
      field: 'imageUrl',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿画像の保存先',
      field: 'imagePath',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'いいね数',
      field: 'likeCount',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '投稿の表示/非表示',
      field: 'visibleStatus',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const PostPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final postsAsyncValue = ref.watch(postsStreamProvider);

    if (postsAsyncValue is! AsyncData || postsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = postsAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ユーザー投稿管理'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('ユーザー投稿一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openAddItemDialog(context);
                                //   },
                                //   child: const Text('追加'),
                                // ),
                                // const SizedBox(width: 24.0),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openEditItemDialog(context);
                                //   },
                                //   child: const Text('更新'),
                                // ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openShowItemDialog(context);
                                  },
                                  child: const Text('詳細'),
                                ),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(postIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(postIdProvider.notifier)
                              .update((_) => selectedId);

                          openShowItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<Post> posts) {
    List<PlutoRow> rows = [];
    posts.asMap().forEach(
      (index, post) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: post.id),
            'message': PlutoCell(value: post.message),
            'memberRef': PlutoCell(value: post.memberRef),
            'latitude': PlutoCell(value: post.position.geopoint.latitude),
            'longitude': PlutoCell(value: post.position.geopoint.longitude),
            'imageUrl': PlutoCell(value: post.imageUrl),
            'imagePath': PlutoCell(value: post.imagePath),
            'likeCount': PlutoCell(value: post.likeCount),
            'visibleStatus': PlutoCell(value: post.visibleStatus),
            'updatedAt': PlutoCell(value: post.updatedAt),
            'createdAt': PlutoCell(value: post.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  // void openAddItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 800.0,
  //           width: 800.0,
  //           child: AddPostPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  // void openEditItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 1000.0,
  //           width: 800.0,
  //           child: EditPostPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  void openShowItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: ShowPostPage(),
          ),
        );
      },
    );
  }
}

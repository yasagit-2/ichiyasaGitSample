import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../../provider/map_controller_provider.dart';
import '../../../util/logger.dart';

final locationProvider = StateProvider.autoDispose<LatLng?>((ref) => null);

final selectedBaseNameProvider =
    StateProvider.autoDispose<String?>((ref) => null);

final markersProvider = Provider.autoDispose<Set<Marker>>((ref) {
  final location = ref.watch(locationProvider);
  if (location == null) {
    return {};
  }

  final selectedBaseName = ref.watch(selectedBaseNameProvider);

  return {
    Marker(
      markerId: MarkerId(const Uuid().v4()),
      position: location,
      infoWindow: InfoWindow(title: selectedBaseName ?? ''),
    )
  };
});

class MapPage extends ConsumerWidget {
  const MapPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final markers = ref.watch(markersProvider);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: GoogleMap(
        initialCameraPosition: CameraPosition(
            target: ref.watch(locationProvider) ??
                const LatLng(35.68142790469979, 139.76712479782196),
            zoom: 14.4746),
        onMapCreated: (GoogleMapController controller) async {
          logger.info('onMapCreated');
          ref
              .read(googleMapControllerProvider.notifier)
              .update((_) => controller);
        },
        onCameraIdle: () async {
          logger.info('onCameraIdle');
          final googleMapController = ref.watch(googleMapControllerProvider);
          if (markers.isNotEmpty && googleMapController != null) {
            final marker = markers.first;
            await googleMapController.showMarkerInfoWindow(marker.markerId);
          }
        },
        markers: markers,
      ),
    );
  }
}

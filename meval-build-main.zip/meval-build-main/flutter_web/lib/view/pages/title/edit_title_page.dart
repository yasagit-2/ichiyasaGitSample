import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:flutter_web/view/pages/title/title_page.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/title_data.dart';
import '../../../provider/title_provider.dart';
import '../../../util/logger.dart';
import '../../../view_model/title_view_model.dart';
import '../../component/loading_service.dart';

final titleIdProvider = StateProvider<String>((ref) => '');

class EditTitlePage extends HookConsumerWidget {
  const EditTitlePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final titleId = ref.watch(titleIdProvider);
    final selectTitleAsyncValue = ref.watch(titleIdSelectProvider(titleId));
    if (titleId.isNotEmpty || titleId == "") {
      if (selectTitleAsyncValue is! AsyncData ||
          selectTitleAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    final titleNameController = useTextEditingController(text: selectTitleAsyncValue.value?.name);
    final pointController = useTextEditingController(text: selectTitleAsyncValue.value?.point.toString());
    final pointLimitController = useTextEditingController(text: selectTitleAsyncValue.value?.pointLimit.toString());

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('称号編集'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '称号を更新しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                final editTitle = TitleData(
                  id: titleId,
                  name: titleNameController.text,
                  point: int.parse(pointController.text),
                  pointLimit: int.parse(pointLimitController.text),
                );

                // ignore: use_build_context_synchronously
                await _updateTitle(ref,context,editTitle);

                showCreateToast('称号 ${editTitle.name} を更新しました');
                // ignore: use_build_context_synchronously
                Navigator.pop(context,const TitlePage());
              } on Exception {
                showErrorToast('称号の更新に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
        
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('称号名称', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: titleNameController,
                      style: const TextStyle(fontSize: 24.0,),
                      
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('称号獲得ポイント', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: pointController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('ポイント付与制限人数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: pointLimitController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  /// 称号を更新します。
  Future<void> _updateTitle(WidgetRef ref, BuildContext context,TitleData editTitle) async {
    await ref.read(loadingServiceProvider.notifier).wrap(ref
        .read(titleViewModelProvider.notifier)
        .updateTitle(
            id: editTitle.id,
            name: editTitle.name,
            point: editTitle.point,
            pointLimit: editTitle.pointLimit));

    await showOkAlertDialog(
      context: context,
      title: '称号を更新しました',
    );
  }
}


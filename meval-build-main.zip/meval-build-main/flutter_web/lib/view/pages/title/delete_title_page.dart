import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:flutter_web/view/pages/title/title_page.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/title_data.dart';
import '../../../provider/title_provider.dart';
import '../../../view_model/title_view_model.dart';
import '../../component/loading_service.dart';
import 'edit_title_page.dart';

class DeleteTitlePage extends HookConsumerWidget {
  const DeleteTitlePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final titleId = ref.watch(titleIdProvider);
    final selectTitleAsyncValue = ref.watch(titleIdSelectProvider(titleId));
    if (titleId.isNotEmpty || titleId == "") {
      if (selectTitleAsyncValue is! AsyncData ||
          selectTitleAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('称号削除'),   
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              onPressed: () async {
                try {
                  final result = await showOkCancelAlertDialog(
                    context: context,
                    title: '称号を削除しますか？',
                    isDestructiveAction: true,
                  );

                  if (result == OkCancelResult.cancel) {
                    return;
                  }

                  await _deletePost(ref,context,titleId);

                  showCreateToast('称号を削除しました');
                  // ignore: use_build_context_synchronously
                  Navigator.pop(context);
                } on Exception catch (e) {
                  showErrorToast('称号の削除に失敗しました');
                }
              },
              icon: const Icon(
                Icons.done,
              ),
            ),
          ],
        ),
      ),
    );
  }
    /// 投稿を削除します。
  Future<void> _deletePost(WidgetRef ref,BuildContext context, String titleId) async {
    await ref
        .watch(loadingServiceProvider.notifier)
        .wrap(ref.read(titleViewModelProvider.notifier).deleteTitle(titleId));

    await showOkAlertDialog(
      context: context,
      title: '称号を削除しました',
    );
  }
}


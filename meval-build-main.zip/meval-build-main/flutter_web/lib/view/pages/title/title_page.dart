import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/title_data.dart';
import '../../../provider/title_provider.dart';
import 'add_title_page.dart';
import 'delete_title_page.dart';
import 'edit_title_page.dart';

/// 画面上に表示するリストのクラスを作成
class TitlePage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 300.0,
      title: '称号ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 300.0,
      title: '称号名称',
      field: 'name',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '称号獲得ポイント',
      field: 'point',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 100.0,
      title: 'ポイント付与制限人数',
      field: 'pointLimit',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const TitlePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final titlesAsyncValue = ref.watch(titlesProvider);

    /// ロード画面のくるくるを呼出す
    if (titlesAsyncValue is! AsyncData || titlesAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final titles = titlesAsyncValue.value!;
    final rows = createRows(titles);

    return Scaffold(
      appBar: AppBar(
        title: const Text('称号'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('称号',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: false,
                                      builder: (builder) {
                                        return const Dialog(
                                          child: SizedBox(
                                            height: 300.0,
                                            width: 500.0,
                                            child: AddTitlePage(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: const Text('称号追加'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: false,
                                      builder: (builder) {
                                        return const Dialog(
                                          child: SizedBox(
                                            height: 300.0,
                                            width: 500.0,
                                            child: EditTitlePage(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: const Text('称号編集'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: false,
                                      builder: (builder) {
                                        return const Dialog(
                                          child: SizedBox(
                                            height: 300.0,
                                            width: 500.0,
                                            child: DeleteTitlePage(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: const Text('称号削除'),
                                ),
                                const SizedBox(width: 12.0),
                              ],
                            ),
                          );
                        },
                        ///ToDo 編集画面の際の初期値をIDに格納
                        onLoaded: (event) async{
                          final titleId = titles.first.id;
                          ref
                              .read(titleIdProvider.notifier)
                              .update((_) => titleId);
                        },
                        onSelected: (event) async {
                          final titleId = event.row!.cells['id']!.value;
                          ref
                              .read(titleIdProvider.notifier)
                              .update((_) => titleId);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<TitleData> titles) {
    List<PlutoRow> rows = [];
    titles.asMap().forEach(
      (index, title) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: title.id),
            'name': PlutoCell(value: title.name),
            'point': PlutoCell(value: title.point),
            'pointLimit': PlutoCell(value: title.pointLimit),
            'updatedAt': PlutoCell(value: title.updatedAt),
            'createdAt': PlutoCell(value: title.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }
}

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/domain/base_model.dart';
import '../../../provider/base_provider.dart';
import '../../../provider/map_controller_provider.dart';
import '../../../util/logger.dart';
import '../map/map_page.dart';
import 'add_parent_base_page.dart';
import 'sub_base_grid.dart';

class BasePage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 300.0,
      title: '拠点ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 300.0,
      title: '拠点名称',
      field: 'name',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 150.0,
      title: '公開ステータス',
      field: 'publishStatus',
      type: PlutoColumnType.select([0, 1, 9]),
    ),
    PlutoColumn(
      width: 150.0,
      title: '獲得ポイント',
      field: 'point',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 200.0,
      title: 'ポイント付与制限人数',
      field: 'pointLimit',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 200.0,
      title: 'ポイント付与制限人数残り',
      field: 'pointLimitRemain',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const BasePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final parentBasesAsyncValue = ref.watch(parentBasesFutureProvider);

    if (parentBasesAsyncValue is! AsyncData ||
        parentBasesAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = parentBasesAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('拠点'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth / 2,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('親拠点',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: false,
                                      builder: (builder) {
                                        return const Dialog(
                                          child: SizedBox(
                                            height: 1000.0,
                                            width: 1500.0,
                                            child: AddParentBasePage(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: const Text('親拠点追加'),
                                ),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final parentBaseId = event.row!.cells['id']!.value;
                          final parentBaseName =
                              event.row!.cells['name']!.value;
                          ref
                              .read(selectedBaseNameProvider.notifier)
                              .update((_) => parentBaseName);

                          ref
                              .read(parentBaseIdProvider.notifier)
                              .update((_) => parentBaseId);

                          final latitude = event.row!.cells['latitude']!.value;
                          final longitude =
                              event.row!.cells['longitude']!.value;

                          await moveCamera(ref, LatLng(latitude, longitude));
                        },
                        onRowDoubleTap: (event) {
                          logger.info(event.row.cells['id']!.value);
                          logger.info(event.row.cells['name']!.value);
                        },
                      ),
                    ),
                    SizedBox(
                      width: constraints.maxWidth / 2,
                      child: const SubBaseGrid(),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: constraints.maxHeight / 3,
                child: const MapPage(),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<BaseModel> bases) {
    List<PlutoRow> rows = [];
    bases.asMap().forEach(
      (index, base) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: base.id),
            'name': PlutoCell(value: base.name),
            'latitude': PlutoCell(value: base.position.geopoint.latitude),
            'longitude': PlutoCell(value: base.position.geopoint.longitude),
            'publishStatus': PlutoCell(value: base.publishStatus),
            'point': PlutoCell(value: base.point),
            'pointLimit': PlutoCell(value: base.pointLimit),
            'pointLimitRemain': PlutoCell(value: base.pointLimitRemain),
            'updatedAt': PlutoCell(value: base.updatedAt),
            'createdAt': PlutoCell(value: base.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }
}

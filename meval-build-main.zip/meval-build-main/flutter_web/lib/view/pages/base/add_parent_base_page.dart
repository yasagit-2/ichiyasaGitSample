import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dart_geohash/dart_geohash.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/model/base.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../../model/map_position.dart';
import '../../../model/title_data.dart';
import '../../../provider/title_provider.dart';
import '../../../repository/base_repository.dart';
import '../../../util/logger.dart';
import 'base_image.dart';

class AddParentBasePage extends HookConsumerWidget {
  const AddParentBasePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final titlesAsyncValue = ref.watch(titlesProvider);
    if (titlesAsyncValue is! AsyncData || titlesAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final titles = titlesAsyncValue.value!;

    final selectedTitle = useState<TitleData?>(null);
    final selectedPublishStatus = useState<int>(0);

    if (titles.isNotEmpty) {
      useEffect(() {
        selectedTitle.value = titles.first;
        return null;
      }, [titles]);
    }

    final baseNameController = useTextEditingController();
    final latitudeController = useTextEditingController();
    final longitudeController = useTextEditingController();
    final pointController = useTextEditingController();
    final pointLimitController = useTextEditingController();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('親拠点追加'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '親拠点を登録しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('value=${selectedTitle.value}');
                logger.info('baseName=${baseNameController.text}');
                logger.info('latitude=${latitudeController.text}');
                logger.info('longitude=${longitudeController.text}');
                logger.info('publishStatus=${selectedPublishStatus.value}');
                logger.info('point=${pointController.text}');
                logger.info('pointLimit=${pointLimitController.text}');

                final geohash = GeoHasher().encode(
                    double.parse(longitudeController.text),
                    double.parse(latitudeController.text),
                    precision: 9);
                logger.info('geohash=$geohash');

                final parentBase = Base(
                  id: const Uuid().v4(),
                  name: baseNameController.text,
                  titleRef: titleRef(id: selectedTitle.value!.id).reference,
                  position: MapPosition(
                      geohash: geohash,
                      geopoint: GeoPoint(double.parse(latitudeController.text),
                          double.parse(longitudeController.text))),
                  publishStatus: selectedPublishStatus.value,
                  point: int.parse(pointController.text),
                  pointLimit: int.parse(pointLimitController.text),
                );

                final imageFile = ref.read(baseImageProvider);

                await ref
                    .watch(baseRepositoryProvider)
                    .createParentBase(parentBase, imageFile);

                showCreateToast('親拠点 ${parentBase.name} を登録しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('親拠点の登録に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('称号', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    titles.isEmpty
                        ? const SizedBox()
                        : DropdownButton2(
                            buttonWidth: 500.0,
                            items: titles.map(
                              (title) {
                                return DropdownMenuItem<TitleData>(
                                  value: title,
                                  child: Text(title.name,
                                      style: const TextStyle(fontSize: 24.0)),
                                );
                              },
                            ).toList(),
                            value: selectedTitle.value,
                            onChanged: (value) {
                              if (value != null) {
                                selectedTitle.value = value;
                              }
                            },
                          ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('拠点名称', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: baseNameController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('緯度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: latitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('経度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: longitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('公開ステータス', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    DropdownButton2(
                      items: [0, 1, 9].map((publishStatus) {
                        return DropdownMenuItem(
                          value: publishStatus,
                          child: Text(publishStatus.toString(),
                              style: const TextStyle(fontSize: 24.0)),
                        );
                      }).toList(),
                      value: selectedPublishStatus.value,
                      onChanged: (value) {
                        if (value != null) {
                          selectedPublishStatus.value = value;
                        }
                      },
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('獲得ポイント', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: pointController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('ポイント付与制限人数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: pointLimitController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 100.0),
            const SizedBox(
              width: 600.0,
              height: 400.0,
              child: BaseImage(),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:image_picker/image_picker.dart';

final baseImageProvider = StateProvider.autoDispose<File?>((ref) => null);

class BaseImage extends ConsumerWidget {
  const BaseImage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final postImage = ref.watch(baseImageProvider);

    if (postImage != null) {
      // final image = Image.file(postImage);
      final image = Image.network(postImage.path);

      return Column(
        children: [
          DottedBorder(
            color: Colors.grey,
            borderType: BorderType.RRect,
            radius: const Radius.circular(5),
            padding: const EdgeInsets.all(6),
            strokeWidth: 3,
            dashPattern: const [15.0, 6.0],
            child: Ink.image(
              height: 350,
              image: image.image,
              child: InkWell(
                onTap: () async => await _pickImage(ref),
                // },
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () => ref.refresh(baseImageProvider),
            child: const Text('画像をクリア'),
          ),
        ],
      );
    }

    return DottedBorder(
      color: Colors.grey,
      borderType: BorderType.RRect,
      radius: const Radius.circular(5),
      padding: const EdgeInsets.all(6),
      strokeWidth: 3,
      dashPattern: const [15.0, 6.0],
      child: InkWell(
        onTap: () async => await _pickImage(ref),
        child: SizedBox(
          width: double.infinity,
          // height: 50.0,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text('画像なし', style: TextStyle(fontSize: 24.0)),
                Text('※クリックで画像選択', style: TextStyle(fontSize: 24.0)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// ギャラリーから画像を読み込みます。
  Future<void> _pickImage(WidgetRef ref) async {
    final picker = ImagePicker();
    final image =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 20);
    if (image != null) {
      ref.read(baseImageProvider.notifier).update((_) => File(image.path));
    }
  }
}

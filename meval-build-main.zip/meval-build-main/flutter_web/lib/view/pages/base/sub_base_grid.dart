import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/domain/base_model.dart';
import '../../../provider/base_provider.dart';
import '../../../provider/map_controller_provider.dart';
import '../../../util/logger.dart';
import '../map/map_page.dart';

final parentBaseIdProvider = StateProvider.autoDispose<String>((ref) => '');

class SubBaseGrid extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 300.0,
      title: 'サブ拠点ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 300.0,
      title: '拠点名称',
      field: 'name',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const SubBaseGrid({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final parentBaseId = ref.watch(parentBaseIdProvider);

    List<PlutoRow> rows = [];
    if (parentBaseId.isNotEmpty) {
      final subBasesAsyncValue =
          ref.watch(subBasesByParentBaseIdFutureProvider(parentBaseId));
      if (subBasesAsyncValue is! AsyncData ||
          subBasesAsyncValue.value == null) {
        return const SizedBox();
      }

      final subBases = subBasesAsyncValue.value!;
      rows = createRows(subBases);
    }

    return Container(
      padding: const EdgeInsets.only(
          top: 16.0, bottom: 16.0, right: 16.0, left: 8.0),
      child: PlutoGrid(
        mode: PlutoGridMode.selectWithOneTap,
        columns: columns,
        rows: rows,
        createHeader: (stateManager) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                const Expanded(
                    child: Text('サブ拠点', style: TextStyle(fontSize: 24.0))),
                ElevatedButton(
                  onPressed: () {},
                  child: const Text('サブ拠点追加'),
                ),
              ],
            ),
          );
        },
        onChanged: (event) {
          logger.info(event);
        },
        onLoaded: (event) {
          logger.info(event);
        },
        onSelected: (event) async {
          final subBaseName = event.row!.cells['name']!.value;
          ref
              .read(selectedBaseNameProvider.notifier)
              .update((_) => subBaseName);

          final latitude = event.row!.cells['latitude']!.value;
          final longitude = event.row!.cells['longitude']!.value;

          await moveCamera(ref, LatLng(latitude, longitude));
        },
        onRowDoubleTap: (event) {
          logger.info(event.row.cells['id']!.value);
          logger.info(event.row.cells['name']!.value);
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<BaseModel> bases) {
    List<PlutoRow> rows = [];
    bases.asMap().forEach(
      (index, base) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: base.id),
            'name': PlutoCell(value: base.name),
            'latitude': PlutoCell(value: base.position.geopoint.latitude),
            'longitude': PlutoCell(value: base.position.geopoint.longitude),
            'updatedAt': PlutoCell(value: base.updatedAt),
            'createdAt': PlutoCell(value: base.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }
}

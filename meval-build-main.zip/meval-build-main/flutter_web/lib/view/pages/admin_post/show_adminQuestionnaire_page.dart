import 'package:adaptive_dialog/adaptive_dialog.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:dart_geohash/dart_geohash.dart';
//import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
//import 'package:uuid/uuid.dart';

import '../../../model/domain/adminQuestionnaire_model.dart';
import '../../../repository/adminQuestionnaire_repository.dart';
import '../../../provider/adminQuestionnaire_provider.dart';
import '../../../util/logger.dart';
//import '../base/base_image.dart';

const titleColumnColoer = Colors.grey;
const titleColumnWidth = 150.0;
const cellMarginWidth = EdgeInsets.all(10.0);

class ShowAdminQuestionnairePage extends ConsumerWidget {
  const ShowAdminQuestionnairePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 指定されたアイテムのIDを取得
    final selectId = ref.watch(adminQuestionnaireIdProvider);

    // 指定されたアイテムのデータを取得(非同期待ち)
    final selectItemAsyncValue =
        ref.watch(adminQuestionnaireIdSelectProvider(selectId));
    if (selectId.isNotEmpty) {
      if (selectItemAsyncValue is! AsyncData ||
          selectItemAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    final selectItem = selectItemAsyncValue.value!;

    return Scaffold(
        appBar: AppBar(
          title: const Text('詳細'),
        ),
        body: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          return Container(
              margin: EdgeInsets.all(30.0),
              child: Table(
                border: TableBorder.all(color: Color.fromARGB(255, 0, 0, 0)),
                columnWidths: const <int, TableColumnWidth>{
                  0: IntrinsicColumnWidth(),
                  1: FlexColumnWidth(1.0),
                },
                defaultVerticalAlignment: TableCellVerticalAlignment.top,
                children: [
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政投稿（アンケート）ID'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.id.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政投稿（アンケート）メッセージ'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.message.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('緯度'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(
                          selectItem.position.geopoint.latitude.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('経度'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(
                          selectItem.position.geopoint.longitude.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政投稿（アンケート）期限'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.dueDate.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政投稿（アンケート）画像のURL'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.imageUrl.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('行政投稿（アンケート）の保存先'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.imagePath.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('アンケート回答獲得ポイント'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.point.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('ポイント付与制限人数'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.pointLimit.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('更新日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.updatedAt.toString()),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                      color: titleColumnColoer,
                      child: Container(
                        margin: cellMarginWidth,
                        width: titleColumnWidth,
                        child: const Text('登録日時'),
                      ),
                    ),
                    Container(
                      margin: cellMarginWidth,
                      child: Text(selectItem.createdAt.toString()),
                    ),
                  ]),
                ],
              ));
        }));
  }
}

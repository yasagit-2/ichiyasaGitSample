import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/adminAlert.dart';
import '../../../provider/adminAlert_provider.dart';
import '../../../util/logger.dart';

import 'add_adminAlert_page.dart';
import 'edit_adminAlert_page.dart';
import 'show_adminAlert_page.dart';

class AdminAlertPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政投稿（注意）ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政投稿（注意）メッセージ',
      field: 'message',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政投稿（注意）期限',
      field: 'dueDate',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政投稿（注意）画像のURL',
      field: 'imageUrl',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '行政投稿（注意）の保存先',
      field: 'imagePath',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const AdminAlertPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adminAlertsAsyncValue = ref.watch(adminAlertsStreamProvider);

    if (adminAlertsAsyncValue is! AsyncData ||
        adminAlertsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = adminAlertsAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('行政投稿（注意）一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    openAddItemDialog(context);
                                  },
                                  child: const Text('追加'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openEditItemDialog(context);
                                  },
                                  child: const Text('更新'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openShowItemDialog(context);
                                  },
                                  child: const Text('詳細'),
                                ),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(adminAlertIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(adminAlertIdProvider.notifier)
                              .update((_) => selectedId);

                          openShowItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<AdminAlert> adminAlerts) {
    List<PlutoRow> rows = [];
    adminAlerts.asMap().forEach(
      (index, adminAlert) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: adminAlert.id),
            'message': PlutoCell(value: adminAlert.message),
            'latitude': PlutoCell(value: adminAlert.position.geopoint.latitude),
            'longitude':
                PlutoCell(value: adminAlert.position.geopoint.longitude),
            'dueDate': PlutoCell(value: adminAlert.dueDate),
            'imageUrl': PlutoCell(value: adminAlert.imageUrl),
            'imagePath': PlutoCell(value: adminAlert.imagePath),
            'updatedAt': PlutoCell(value: adminAlert.updatedAt),
            'createdAt': PlutoCell(value: adminAlert.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  void openAddItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 800.0,
            width: 800.0,
            child: AddAdminAlertPage(),
          ),
        );
      },
    );
  }

  void openEditItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: EditAdminAlertPage(),
          ),
        );
      },
    );
  }

  void openShowItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: ShowAdminAlertPage(),
          ),
        );
      },
    );
  }
}

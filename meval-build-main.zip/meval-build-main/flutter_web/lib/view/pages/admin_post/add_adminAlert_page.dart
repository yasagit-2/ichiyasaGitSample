import 'package:adaptive_dialog/adaptive_dialog.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:dart_geohash/dart_geohash.dart';
//import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
//import 'package:uuid/uuid.dart';

import '../../../model/domain/adminAlert_model.dart';
import '../../../repository/adminAlert_repository.dart';
import '../../../util/logger.dart';
//import '../base/base_image.dart';

class AddAdminAlertPage extends HookConsumerWidget {
  const AddAdminAlertPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ToDo:コンボボックスの選択肢やリストデータなど画面に読み込むデータを取得

    // 項目のコントローラーを作成
    final idController = useTextEditingController();
    final messageController = useTextEditingController();
    final latitudeController = useTextEditingController();
    final longitudeController = useTextEditingController();
    final dueDateController = useTextEditingController();
    final imageUrlController = useTextEditingController();
    final imagePathController = useTextEditingController();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('行政投稿（注意）追加'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '行政投稿（注意）を登録しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('');

                // ToDo:登録データ作成
                //final createData = AdminAlert();

                // ToDo:データ登録
                //await ref
                //     .watch(adminAlertRepositoryProvider)
                //     .createAdminAlert(createData);

                showCreateToast('行政投稿（注意）を登録しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('行政投稿（注意）の登録に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('行政投稿（注意）ID', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: idController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（注意）メッセージ',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: messageController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('緯度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: latitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('経度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: longitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（注意）期限', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: dueDateController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（注意）画像のURL',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imageUrlController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（注意）の保存先',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imagePathController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

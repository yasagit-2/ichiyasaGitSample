import 'package:adaptive_dialog/adaptive_dialog.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:dart_geohash/dart_geohash.dart';
//import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
//import 'package:uuid/uuid.dart';

import '../../../model/domain/adminQuestionnaire_model.dart';
import '../../../repository/adminQuestionnaire_repository.dart';
import '../../../provider/adminQuestionnaire_provider.dart';
import '../../../util/logger.dart';
//import '../base/base_image.dart';

class EditAdminQuestionnairePage extends HookConsumerWidget {
  const EditAdminQuestionnairePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ToDo:コンボボックスの選択肢やリストデータなど画面に読み込むデータを取得

    // 指定されたアイテムのIDを取得
    final selectId = ref.watch(adminQuestionnaireIdProvider);

    // 指定されたアイテムのデータを取得(非同期待ち)
    final selectItemAsyncValue =
        ref.watch(adminQuestionnaireIdSelectProvider(selectId));
    if (selectId.isNotEmpty) {
      if (selectItemAsyncValue is! AsyncData ||
          selectItemAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    final selectItem = selectItemAsyncValue.value!;

    // 項目のコントローラーを作成
    final idController = useTextEditingController(text: selectItem.id);
    final messageController =
        useTextEditingController(text: selectItem.message);
    final latitudeController = useTextEditingController(
        text: selectItem.position.geopoint.latitude.toString());
    final longitudeController = useTextEditingController(
        text: selectItem.position.geopoint.longitude.toString());
    final dueDateController =
        useTextEditingController(text: selectItem.dueDate.toString());
    final imageUrlController =
        useTextEditingController(text: selectItem.imageUrl);
    final imagePathController =
        useTextEditingController(text: selectItem.imagePath);
    final pointController =
        useTextEditingController(text: selectItem.point.toString());
    final pointLimitController =
        useTextEditingController(text: selectItem.pointLimit.toString());

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('行政投稿（アンケート）更新'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '行政投稿（アンケート）を更新しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('');

                // ToDo:更新データ作成
                //final updateData = AdminQuestionnaire();

                // ToDo:データ更新
                //await ref
                //     .watch(adminQuestionnaireRepositoryProvider)
                //     .updateAdminQuestionnaire(updateData);

                // ToDo：サブコレクションも登録

                showCreateToast('行政投稿（アンケート）を更新しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('行政投稿（アンケート）の更新に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('行政投稿（アンケート）ID',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: idController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（アンケート）メッセージ',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: messageController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('緯度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: latitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('経度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: longitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（アンケート）期限',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: dueDateController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（アンケート）画像のURL',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imageUrlController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('行政投稿（アンケート）の保存先',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imagePathController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('アンケート回答獲得ポイント',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: pointController,
                        style: const TextStyle(fontSize: 24.0),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^(?!0)[0-9]*$'))
                        ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('ポイント付与制限人数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: pointLimitController,
                        style: const TextStyle(fontSize: 24.0),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^(?!0)[0-9]*$'))
                        ],
                      ),
                    ),
                  ],
                ),
                // ToDo：サブコレクションも登録
              ],
            ),
          ],
        ),
      ),
    );
  }
}

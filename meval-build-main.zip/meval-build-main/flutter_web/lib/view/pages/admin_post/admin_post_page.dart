import 'package:flutter/material.dart';
import 'adminAlert_page.dart';
import 'adminQuestionnaire_page.dart';

class AdminPostPage extends StatelessWidget {
  const AdminPostPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('行政投稿'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              SizedBox(
                width: constraints.maxHeight,
                height: constraints.maxHeight / 2,
                child: const AdminAlertPage(),
              ),
              SizedBox(
                width: constraints.maxHeight,
                height: constraints.maxHeight / 2,
                child: const AdminQuestionnairePage(),
              ),
            ],
          );
        },
      ),
    );
  }
}

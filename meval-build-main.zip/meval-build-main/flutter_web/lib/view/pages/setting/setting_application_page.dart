import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../util/logger.dart';

import '../../../provider/setting_provider.dart';
import 'setting_postIcon_page.dart';

const titleColumnColoer = Color.fromARGB(255, 255, 255, 255);
const titleColumnWidth = 200.0;
const cellMarginWidth = EdgeInsets.all(10.0);

class SettingApplicationPage extends HookConsumerWidget {
  const SettingApplicationPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingAsyncValue = ref.watch(settingStreamProvider);
    if (settingAsyncValue is! AsyncData || settingAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final setting = settingAsyncValue.value!;

    final baseIconUrlController =
        useTextEditingController(text: setting.baseIconUrl);
    final baseCheckedInIconUrlController =
        useTextEditingController(text: setting.baseCheckedInIconUrl);
    final subBaseIconUrlController =
        useTextEditingController(text: setting.subBaseIconUrl);
    final merchantIconUrlController =
        useTextEditingController(text: setting.merchantIconUrl);
    final merchantTweetIconUrlController =
        useTextEditingController(text: setting.merchantTweetIconUrl);
    final postIconUrlController =
        useTextEditingController(text: setting.postIconUrl);
    final adminAlertIconUrlController =
        useTextEditingController(text: setting.adminAlertIconUrl);
    final adminQuestionnaireIconUrlController =
        useTextEditingController(text: setting.adminQuestionnaireIconUrl);
    final checkInRadiusController =
        useTextEditingController(text: setting.checkInRadius.toString());
    final collectionRadiusController =
        useTextEditingController(text: setting.collectionRadius.toString());
    final targetStepPerWeekController =
        useTextEditingController(text: setting.targetStepPerWeek.toString());
    final stepAchievedPointController =
        useTextEditingController(text: setting.stepAchievedPoint.toString());
    final postIntervalLimitHourController = useTextEditingController(
        text: setting.postIntervalLimitHour.toString());
    final reportIntervalLimitHourController = useTextEditingController(
        text: setting.reportIntervalLimitHour.toString());
    final commentIntervalLimitMinuteController = useTextEditingController(
        text: setting.commentIntervalLimitMinute.toString());
    final notificationRetentionDayController = useTextEditingController(
        text: setting.notificationRetentionDay.toString());
    final eventRetentionDayController =
        useTextEditingController(text: setting.eventRetentionDay.toString());
    final memberDeletionGraceDayController = useTextEditingController(
        text: setting.memberDeletionGraceDay.toString());
    final helpPageUrlController =
        useTextEditingController(text: setting.helpPageUrl);

    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return Container(
        margin: EdgeInsets.all(30.0),
        // ToDo ヘッダと更新ボタンをつける
        child: Table(
          border: TableBorder.all(color: Color.fromARGB(255, 0, 0, 0)),
          columnWidths: const <int, TableColumnWidth>{
            0: IntrinsicColumnWidth(),
            1: FlexColumnWidth(1.0),
          },
          defaultVerticalAlignment: TableCellVerticalAlignment.top,
          children: [
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('拠点アイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: baseIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('チェックイン済み拠点アイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: baseCheckedInIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('サブ拠点アイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: subBaseIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('加盟店アイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: merchantIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('加盟店つぶやきアイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: merchantTweetIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('投稿アイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: postIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('投稿アイコン設定'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: ElevatedButton(
                  onPressed: () {
                    openPostIconPage(context);
                  },
                  child: const Text('設定'),
                ),
              ),
            ]),
            //   Container(
            //       margin: cellMarginWidth,
            //       child: Table(
            //           border:
            //               TableBorder.all(color: Color.fromARGB(255, 0, 0, 0)),
            //           columnWidths: const <int, TableColumnWidth>{
            //             0: IntrinsicColumnWidth(),
            //             1: FlexColumnWidth(1.0),
            //           },
            //           defaultVerticalAlignment: TableCellVerticalAlignment.top,
            //           children: [
            //             TableRow(children: [
            //               Container(
            //                 margin: cellMarginWidth,
            //                 child: TextField(
            //                   controller: postIconUrlController,
            //                   style: const TextStyle(fontSize: 24.0),
            //                 ),
            //               ),
            //               ElevatedButton(
            //                 onPressed: () {
            //                   //  openShowItemDialog(context);
            //                 },
            //                 child: const Text('詳細'),
            //               ),
            //             ]),
            //           ])),
            // ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('行政投稿アラートアイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: adminAlertIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('行政投稿アンケートアイコンURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: adminQuestionnaireIconUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('チェックイン可能距離（meter）'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: checkInRadiusController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('拠点/投稿/加盟店収集半径（km）'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: collectionRadiusController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('週間規定歩数'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: targetStepPerWeekController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('週間規定歩数達成ポイント'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: stepAchievedPointController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('投稿間隔制限（hour）'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: postIntervalLimitHourController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('行政報告間隔制限（hour）'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: reportIntervalLimitHourController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('コメント間隔制限（minute）'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: commentIntervalLimitMinuteController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('お知らせ保存日数'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: notificationRetentionDayController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('イベント保存日数'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: eventRetentionDayController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('会員削除猶予日数'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: memberDeletionGraceDayController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('ヘルプページURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: helpPageUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('更新日時'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: Text(setting.updatedAt.toString()),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('登録日時'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: Text(setting.createdAt.toString()),
              ),
            ]),
          ],
        ),
      );
    });
  }

  void openPostIconPage(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: PostIconPage(),
          ),
        );
      },
    );
  }
}

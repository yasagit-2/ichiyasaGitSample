import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../util/logger.dart';

import '../../../provider/maintenance_provider.dart';

const titleColumnColoer = Color.fromARGB(255, 255, 255, 255);
const titleColumnWidth = 150.0;
const cellMarginWidth = EdgeInsets.all(10.0);

class SettingMaintenancePage extends HookConsumerWidget {
  const SettingMaintenancePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final maintenanceAsyncValue = ref.watch(maintenanceStreamProvider);
    if (maintenanceAsyncValue is! AsyncData ||
        maintenanceAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final maintenance = maintenanceAsyncValue.value!;

    final versionController =
        useTextEditingController(text: maintenance.version);
    final appStoreUrlController =
        useTextEditingController(text: maintenance.appStoreUrl);
    final playStoreUrlController =
        useTextEditingController(text: maintenance.playStoreUrl);
    final isMaintenanceController = useTextEditingController(
        text: maintenance.isMaintenance.toString()); // ToDo

    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return Container(
        margin: EdgeInsets.all(30.0),
        // ToDo ヘッダと更新ボタンをつける
        child: Table(
          border: TableBorder.all(color: Color.fromARGB(255, 0, 0, 0)),
          columnWidths: const <int, TableColumnWidth>{
            0: IntrinsicColumnWidth(),
            1: FlexColumnWidth(1.0),
          },
          defaultVerticalAlignment: TableCellVerticalAlignment.top,
          children: [
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('アプリケーションバージョン'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'^(?!0)[0-9]*$'))
                  ],
                  controller: versionController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('Apple App StoreのURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: appStoreUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('Google Play StoreのURL'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: playStoreUrlController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('メンテナンスフラグ'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: TextField(
                  controller: isMaintenanceController,
                  style: const TextStyle(fontSize: 24.0),
                ),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('更新日時'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: Text(maintenance.updatedAt.toString()),
              ),
            ]),
            TableRow(children: [
              Container(
                color: titleColumnColoer,
                child: Container(
                  margin: cellMarginWidth,
                  width: titleColumnWidth,
                  child: const Text('登録日時'),
                ),
              ),
              Container(
                margin: cellMarginWidth,
                child: Text(maintenance.createdAt.toString()),
              ),
            ]),
          ],
        ),
      );
    });
  }
}

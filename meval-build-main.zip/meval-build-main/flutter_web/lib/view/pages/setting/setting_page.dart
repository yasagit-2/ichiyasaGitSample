import 'package:flutter/material.dart';

import 'setting_maintenance_page.dart';
import 'setting_application_page.dart';

class SettingPage extends StatelessWidget {
  const SettingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('システム設定'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return SingleChildScrollView(
              child: Column(
            children: [
              SizedBox(
                width: constraints.maxHeight,
                child: const SettingMaintenancePage(),
              ),
              SizedBox(
                width: constraints.maxHeight,
                child: const SettingApplicationPage(),
              ),
            ],
          ));
        },
      ),
    );
  }
}

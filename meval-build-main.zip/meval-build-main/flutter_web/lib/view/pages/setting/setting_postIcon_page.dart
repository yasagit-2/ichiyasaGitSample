import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/postIcon.dart';
import '../../../provider/postIcon_provider.dart';
import '../../../provider/setting_provider.dart';
import 'setting_postIcon_page.dart';
import '../../../util/logger.dart';
// import 'add_postIcon_page.dart';
// import 'edit_postIcon_page.dart';
//import 'show_postIcon_page.dart';

class PostIconPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'いいね数単位の投稿アイコンURL',
      field: 'unitOfLikePostIconUrl',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'いいね数',
      field: 'likeCount',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const PostIconPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final postIconsAsyncValue = ref.watch(postIconsStreamProvider);

    if (postIconsAsyncValue is! AsyncData ||
        postIconsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = postIconsAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('いいね数別アイコン設定'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('アイコン一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openAddItemDialog(context);
                                //   },
                                //   child: const Text('追加'),
                                // ),
                                // const SizedBox(width: 24.0),
                                // ElevatedButton(
                                //   onPressed: () {
                                //     openEditItemDialog(context);
                                //   },
                                //   child: const Text('更新'),
                                // ),
                                //const SizedBox(width: 24.0),
                                //ElevatedButton(
                                //  onPressed: () {
                                //    openShowItemDialog(context);
                                //  },
                                //  child: const Text('詳細'),
                                //),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(postIconIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(postIconIdProvider.notifier)
                              .update((_) => selectedId);

                          //openEditItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<PostIcon> postIcons) {
    List<PlutoRow> rows = [];
    postIcons.asMap().forEach(
      (index, postIcon) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'unitOfLikePostIconUrl':
                PlutoCell(value: postIcon.unitOfLikePostIconUrl),
            'likeCount': PlutoCell(value: postIcon.likeCount),
            'updatedAt': PlutoCell(value: postIcon.updatedAt),
            'createdAt': PlutoCell(value: postIcon.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  // void openAddItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 800.0,
  //           width: 800.0,
  //           child: AddPostIconPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  // void openEditItemDialog(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (builder) {
  //       return const Dialog(
  //         child: SizedBox(
  //           height: 1000.0,
  //           width: 800.0,
  //           child: EditPostIconPage(),
  //         ),
  //       );
  //     },
  //   );
  // }

  //void openShowItemDialog(BuildContext context) {
  //  showDialog(
  //    context: context,
  //    barrierDismissible: false,
  //    builder: (builder) {
  //      return const Dialog(
  //        child: SizedBox(
  //          height: 1000.0,
  //          width: 800.0,
  //          child: ShowPostIconPage(),
  //        ),
  //      );
  //    },
  //  );
  //}

}

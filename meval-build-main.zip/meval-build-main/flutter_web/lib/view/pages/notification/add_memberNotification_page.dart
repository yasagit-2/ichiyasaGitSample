import 'package:adaptive_dialog/adaptive_dialog.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:dart_geohash/dart_geohash.dart';
//import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
//import 'package:flutter_web/model/base.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
//import 'package:uuid/uuid.dart';

import '../../../model/domain/memberNotification_model.dart';
import '../../../repository/memberNotification_repository.dart';
import '../../../util/logger.dart';
//import '../base/base_image.dart';

class AddMemberNotificationPage extends HookConsumerWidget {
  const AddMemberNotificationPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ToDo:コンボボックスの選択肢やリストデータなど画面に読み込むデータを取得

    // 項目のコントローラーを作成
    final titleController = useTextEditingController();
    final contentUrlController = useTextEditingController();
    final effectivePeriodBeginController = useTextEditingController();
    final effectivePeriodEndController = useTextEditingController();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('お知らせ追加'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: 'お知らせを登録しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('');

                // ToDo:登録データ作成
                //final createData = MemberNotification();

                // ToDo:データ登録
                //await ref
                //     .watch(memberNotificationRepositoryProvider)
                //     .createMemberNotification(createData);

                showCreateToast('お知らせを登録しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('お知らせの登録に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('お知らせタイトル', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: titleController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('お知らせコンテンツURL',
                        style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: contentUrlController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('有効期間開始', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: effectivePeriodBeginController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('有効期間終了', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: effectivePeriodEndController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

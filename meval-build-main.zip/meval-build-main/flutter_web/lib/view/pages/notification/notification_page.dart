import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/memberNotification.dart';
import '../../../provider/memberNotification_provider.dart';
import '../../../util/logger.dart';

import 'add_memberNotification_page.dart'; // 追加
import 'edit_memberNotification_page.dart'; // 更新
//import 'show_memberNotification_page.dart';// 詳細

class MemberNotificationPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'お知らせID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'お知らせタイトル',
      field: 'title',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'お知らせコンテンツURL',
      field: 'contentUrl',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '有効期間開始',
      field: 'effectivePeriodBegin',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '有効期間終了',
      field: 'effectivePeriodEnd',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const MemberNotificationPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final memberNotificationsAsyncValue =
        ref.watch(memberNotificationsStreamProvider);

    if (memberNotificationsAsyncValue is! AsyncData ||
        memberNotificationsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = memberNotificationsAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('お知らせ管理'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('お知らせ一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    openAddItemDialog(context);
                                  },
                                  child: const Text('お知らせ追加'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openEditItemDialog(context);
                                  },
                                  child: const Text('お知らせ更新'),
                                ),
                                //const SizedBox(width: 24.0),
                                //ElevatedButton(
                                //  onPressed: () {
                                //    openShowItemDialog(context);
                                //  },
                                //  child: const Text('詳細'),
                                //),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(memberNotificationIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(memberNotificationIdProvider.notifier)
                              .update((_) => selectedId);

                          openEditItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<MemberNotification> memberNotifications) {
    List<PlutoRow> rows = [];
    memberNotifications.asMap().forEach(
      (index, memberNotification) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: memberNotification.id),
            'title': PlutoCell(value: memberNotification.title),
            'contentUrl': PlutoCell(value: memberNotification.contentUrl),
            'effectivePeriodBegin':
                PlutoCell(value: memberNotification.effectivePeriodBegin),
            'effectivePeriodEnd':
                PlutoCell(value: memberNotification.effectivePeriodEnd),
            'updatedAt': PlutoCell(value: memberNotification.updatedAt),
            'createdAt': PlutoCell(value: memberNotification.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  // 追加画面表示
  void openAddItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 800.0,
            width: 800.0,
            child: AddMemberNotificationPage(),
          ),
        );
      },
    );
  }

  // 更新画面表示
  void openEditItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: EditMemberNotificationPage(),
          ),
        );
      },
    );
  }

  // 詳細画面表示
  //void openShowItemDialog(BuildContext context) {
  //  showDialog(
  //    context: context,
  //    barrierDismissible: false,
  //    builder: (builder) {
  //      return const Dialog(
  //        child: SizedBox(
  //          height: 1000.0,
  //          width: 800.0,
  //          child: ShowMemberNotificationPage(),
  //        ),
  //      );
  //    },
  //  );
  //}
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

DateTime? _selectedDate;
TextEditingController _textEditingController = TextEditingController();

class AddEventPage extends HookConsumerWidget {
  const AddEventPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final eventTitleController = useTextEditingController();
    final eventSpotCountController = useTextEditingController();
    final longitudeController = useTextEditingController();
    final latitudeController = useTextEditingController();
    final completeSpotCountController = useTextEditingController();
    final isUseLocationController = useTextEditingController();
    final qrCodeRadiusController = useTextEditingController();
    final pointController = useTextEditingController();
    final exchangeLimitController = useTextEditingController();
    final exchangeTypeController = useTextEditingController();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('イベント追加'),
        actions: [
          IconButton(
            onPressed: () async {
              /*try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '親拠点を登録しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('value=${selectedTitle.value}');
                logger.info('baseName=${baseNameController.text}');
                logger.info('latitude=${latitudeController.text}');
                logger.info('longitude=${longitudeController.text}');
                logger.info('publishStatus=${selectedPublishStatus.value}');
                logger.info('point=${pointController.text}');
                logger.info('pointLimit=${pointLimitController.text}');

                final geohash = GeoHasher().encode(
                    double.parse(longitudeController.text),
                    double.parse(latitudeController.text),
                    precision: 9);
                logger.info('geohash=$geohash');

                final parentBase = Base(
                  id: const Uuid().v4(),
                  name: baseNameController.text,
                  titleRef: titleRef(id: selectedTitle.value!.id).reference,
                  position: MapPosition(
                      geohash: geohash,
                      geopoint: GeoPoint(double.parse(latitudeController.text),
                          double.parse(longitudeController.text))),
                  publishStatus: selectedPublishStatus.value,
                  point: int.parse(pointController.text),
                  pointLimit: int.parse(pointLimitController.text),
                );

                final imageFile = ref.read(baseImageProvider);

                await ref
                    .watch(baseRepositoryProvider)
                    .createParentBase(parentBase, imageFile);

                showCreateToast('親拠点 ${parentBase.name} を登録しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('親拠点の登録に失敗しました');
              }*/
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('イベントタイトル', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: eventTitleController,
                      style: const TextStyle(
                        fontSize: 24.0,
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('イベントスポット数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: eventSpotCountController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('緯度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: latitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('経度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: longitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('イベント開始日', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: _textEditingController,
                      decoration: InputDecoration(
                        suffixIcon: IconButton(
                          onPressed: () => _selectDate(context),
                          icon: Icon(Icons.calendar_month),
                        ),
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('イベント終了日', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: _textEditingController,
                      decoration: InputDecoration(
                        suffixIcon: IconButton(
                          onPressed: () => _selectDate(context),
                          icon: Icon(Icons.calendar_month),
                        ),
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('イベント達成地点数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: completeSpotCountController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),

                /// ToDo bool型なのでプルダウンから選択にする
                TableRow(
                  children: [
                    const Text('位置情報の利用', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      controller: isUseLocationController,
                      style: const TextStyle(
                        fontSize: 24.0,
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('読み取り可能距離', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: qrCodeRadiusController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('達成獲得ポイント', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: pointController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('交換制限人数', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: exchangeLimitController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('交換対象種別', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^(?!0)[0-9]*$'))
                      ],
                      controller: exchangeTypeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ignore: unused_element
_selectDate(BuildContext context) async {
  final newSelectedDate = await showDatePicker(
    context: context,
    initialDate: _selectedDate ?? DateTime.now(),
    firstDate: DateTime(2000),
    lastDate: DateTime(2040),
  );

  if (newSelectedDate != null) {
    _selectedDate = newSelectedDate;
    _textEditingController.text = _selectedDate.toString();
  }
}

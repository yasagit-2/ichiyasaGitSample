import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';
import '../../../model/event_data.dart';
import '../../../provider/event_provider.dart';
import 'add_event_page.dart';
import 'event_grid.dart';

/// 画面上に表示するリストのクラスを作成
class EventPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 300.0,
      title: 'イベントID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 300.0,
      title: 'イベントタイトル',
      field: 'title',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 100.0,
      title: 'イベント画像URL',
      field: 'imageURL',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 100.0,
      title: 'イベントスポット数',
      field: 'eventSpotCount',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'イベント開始日',
      field: 'effectivePeriodBegin',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: 'イベント終了日',
      field: 'effectivePeriodEnd',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 100.0,
      title: 'イベント達成地点数',
      field: 'completeSpotCount',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '位置情報の利用',
      field: 'isUseLocation',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '読み取り可能距離',
      field: 'qrCodeRadius',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '達成獲得ポイント',
      field: 'point',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '交換制限人数',
      field: 'exchangeLimit',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 100.0,
      title: '交換対象種別',
      field: 'exchangeType',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const EventPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final eventsAsyncValue = ref.watch(eventsProvider);

    /// ロード画面のくるくるを呼出す
    if (eventsAsyncValue is! AsyncData || eventsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final event = eventsAsyncValue.value!;
    final rows = createRows(event);

    return Scaffold(
      appBar: AppBar(
        title: const Text('イベント'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth / 2,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('イベント',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: false,
                                      builder: (builder) {
                                        return const Dialog(
                                          child: SizedBox(
                                            height: 1000.0,
                                            width: 1200.0,
                                            child: AddEventPage(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: const Text('イベント追加'),
                                ),
                              ],
                            ),
                          );
                        },
                        onSelected: (event) async {
                          final eventId = event.row!.cells['id']!.value;
                          ref
                              .read(eventIdProvider.notifier)
                              .update((_) => eventId);
                        },
                      ),
                    ),
                    SizedBox(
                      width: constraints.maxWidth / 2,
                      child: const EventGrid(),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<Event> event) {
    List<PlutoRow> rows = [];
    event.asMap().forEach(
      (index, event) {
        final plutoRow = PlutoRow(cells: {
          'index': PlutoCell(value: index + 1),
          'id': PlutoCell(value: event.id),
          'title': PlutoCell(value: event.title),
          'imageURL': PlutoCell(value: event.imageUrl),
          'eventSpotCount': PlutoCell(value: event.eventSpotCount),
          'longitude': PlutoCell(value: event.position.geopoint.longitude),
          'latitude': PlutoCell(value: event.position.geopoint.latitude),
          'effectivePeriodBegin': PlutoCell(value: event.effectivePeriodBegin),
          'effectivePeriodEnd': PlutoCell(value: event.effectivePeriodEnd),
          'completeSpotCount': PlutoCell(value: event.completeSpotCount),
          'isUseLocation': PlutoCell(value: event.isUseLocation),
          'qrCodeRadius': PlutoCell(value: event.qrCodeRadius),
          'point': PlutoCell(value: event.point),
          'exchangeLimit': PlutoCell(value: event.exchangeLimit),
          'exchangeType': PlutoCell(value: event.exchangeType),
          'updatedAt': PlutoCell(value: event.updatedAt),
          'createdAt': PlutoCell(value: event.createdAt),
        });

        rows.add(plutoRow);
      },
    );

    return rows;
  }
}

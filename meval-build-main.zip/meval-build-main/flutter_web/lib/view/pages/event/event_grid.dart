import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/event_data.dart';
import '../../../provider/base_provider.dart';
import '../../../provider/event_provider.dart';
import '../../../provider/map_controller_provider.dart';
import '../../../util/logger.dart';
import '../map/map_page.dart';

final eventIdProvider = StateProvider.autoDispose<String>((ref) => '');

class EventGrid extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 300.0,
      title: 'スポット名称',
      field: 'name',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 300.0,
      title: 'スポット画像',
      field: 'imageURL',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
  ];

  const EventGrid({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final eventId = ref.watch(eventIdProvider);

    List<PlutoRow> rows = [];
    if (eventId.isNotEmpty) {
      final eventAsyncValue =
          ref.watch(eventsSpotProvider(eventId));
      if (eventAsyncValue is! AsyncData ||
          eventAsyncValue.value == null) {
        return const SizedBox();
      }

      final eventSpot = eventAsyncValue.value!;
      rows = createRows(eventSpot);
    }

    return Container(
      padding: const EdgeInsets.only(
          top: 16.0, bottom: 16.0, right: 16.0, left: 8.0),
      child: PlutoGrid(
        mode: PlutoGridMode.selectWithOneTap,
        columns: columns,
        rows: rows,
        createHeader: (stateManager) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                const Expanded(
                    child: Text('イベントスポット', style: TextStyle(fontSize: 24.0))),
                ElevatedButton(
                  onPressed: () {},
                  child: const Text('イベントスポット追加'),
                ),
              ],
            ),
          );
        },
        onChanged: (event) {
          logger.info(event);
        },
        onLoaded: (event) {
          logger.info(event);
        },
        onSelected: (event) async {
          final subBaseName = event.row!.cells['name']!.value;
          ref
              .read(selectedBaseNameProvider.notifier)
              .update((_) => subBaseName);

          final latitude = event.row!.cells['latitude']!.value;
          final longitude = event.row!.cells['longitude']!.value;

          await moveCamera(ref, LatLng(latitude, longitude));
        },
        onRowDoubleTap: (event) {
          logger.info(event.row.cells['id']!.value);
          logger.info(event.row.cells['name']!.value);
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<EventSpot> bases) {
    List<PlutoRow> rows = [];
    bases.asMap().forEach(
      (index, event) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'name': PlutoCell(value: event.name),
            'imageURL': PlutoCell(value: event.imageUrl),
            'latitude': PlutoCell(value: event.position.geopoint.latitude),
            'longitude': PlutoCell(value: event.position.geopoint.longitude),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }
}

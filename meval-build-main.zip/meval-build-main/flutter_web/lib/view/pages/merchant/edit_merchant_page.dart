import 'package:adaptive_dialog/adaptive_dialog.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:dart_geohash/dart_geohash.dart';
//import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_web/util/show_toast.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
//import 'package:uuid/uuid.dart';

import '../../../model/domain/merchant_model.dart';
import '../../../repository/merchant_repository.dart';
import '../../../provider/merchant_provider.dart';
import '../../../util/logger.dart';
//import '../base/base_image.dart';

class EditMerchantPage extends HookConsumerWidget {
  const EditMerchantPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ToDo:コンボボックスの選択肢やリストデータなど画面に読み込むデータを取得

    // 指定されたアイテムのIDを取得
    final selectId = ref.watch(merchantIdProvider);

    // 指定されたアイテムのデータを取得(非同期待ち)
    final selectItemAsyncValue = ref.watch(merchantIdSelectProvider(selectId));
    if (selectId.isNotEmpty) {
      if (selectItemAsyncValue is! AsyncData ||
          selectItemAsyncValue.value == null) {
        return const Center(child: CircularProgressIndicator());
      }
    }

    final selectItem = selectItemAsyncValue.value!;

    // 項目のコントローラーを作成
    final idController = useTextEditingController(text: selectItem.id);
    final nameController = useTextEditingController(text: selectItem.name);
    final imageUrlController =
        useTextEditingController(text: selectItem.imageUrl);
    final imagePathController =
        useTextEditingController(text: selectItem.imagePath);
    final latitudeController = useTextEditingController(
        text: selectItem.position.geopoint.latitude.toString());
    final longitudeController = useTextEditingController(
        text: selectItem.position.geopoint.longitude.toString());

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text('加盟店更新'),
        actions: [
          IconButton(
            onPressed: () async {
              try {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '加盟店を更新しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                logger.info('');

                // ToDo:更新データ作成
                //final updateData = Merchant();

                // ToDo:データ更新
                //await ref
                //     .watch(merchantRepositoryProvider)
                //     .updateMerchant(updateData);

                showCreateToast('加盟店を更新しました');
                Navigator.pop(context);
              } on Exception catch (e) {
                logger.severe(e);
                showErrorToast('加盟店の更新に失敗しました');
              }
            },
            icon: const Icon(
              Icons.done,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Table(
              defaultColumnWidth: const IntrinsicColumnWidth(),
              children: [
                TableRow(
                  children: [
                    const Text('加盟店ID', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: idController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('加盟店名称', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: nameController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('加盟店画像のURL', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imageUrlController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('加盟店画像の保存先', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    SizedBox(
                      width: 200.0,
                      child: TextField(
                        controller: imagePathController,
                        style: const TextStyle(fontSize: 24.0),
                        // ToDo? inputFormatters: [ FilteringTextInputFormatter.allow() ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('緯度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: latitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    const Text('経度', style: TextStyle(fontSize: 24.0)),
                    const SizedBox(width: 48.0),
                    TextField(
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,15}'))
                      ],
                      controller: longitudeController,
                      style: const TextStyle(fontSize: 24.0),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

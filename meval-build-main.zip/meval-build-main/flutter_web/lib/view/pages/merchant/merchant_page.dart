import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../../../model/merchant.dart';
import '../../../provider/merchant_provider.dart';
import '../../../util/logger.dart';

import 'add_merchant_page.dart';
import 'edit_merchant_page.dart';
import 'show_merchant_page.dart';

class MerchantPage extends ConsumerWidget {
  static List<PlutoColumn> columns = [
    PlutoColumn(
      width: 70.0,
      title: 'No.',
      field: 'index',
      type: PlutoColumnType.number(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '加盟店ID',
      field: 'id',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '加盟店名称',
      field: 'name',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '加盟店画像のURL',
      field: 'imageUrl',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 170.0,
      title: '加盟店画像の保存先',
      field: 'imagePath',
      type: PlutoColumnType.text(),
    ),
    PlutoColumn(
      width: 200.0,
      title: '緯度',
      field: 'latitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 200.0,
      title: '経度',
      field: 'longitude',
      type: PlutoColumnType.number(format: '#,###.###############'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '更新日時',
      field: 'updatedAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
    PlutoColumn(
      width: 170.0,
      title: '登録日時',
      field: 'createdAt',
      type: PlutoColumnType.date(format: 'yyyy/MM/dd HH:mm:ss'),
    ),
  ];

  const MerchantPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final merchantsAsyncValue = ref.watch(merchantsStreamProvider);

    if (merchantsAsyncValue is! AsyncData ||
        merchantsAsyncValue.value == null) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            height: 100.0,
            width: 100.0,
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    final parentBases = merchantsAsyncValue.value!;
    final rows = createRows(parentBases);

    return Scaffold(
      appBar: AppBar(
        title: const Text('加盟店管理'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      padding: const EdgeInsets.only(
                          top: 16.0, bottom: 16.0, right: 8.0, left: 16.0),
                      child: PlutoGrid(
                        mode: PlutoGridMode.selectWithOneTap,
                        columns: columns,
                        rows: rows,
                        createHeader: (stateManager) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const Expanded(
                                    child: Text('加盟店一覧',
                                        style: TextStyle(fontSize: 24.0))),
                                ElevatedButton(
                                  onPressed: () {
                                    openAddItemDialog(context);
                                  },
                                  child: const Text('加盟店追加'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openEditItemDialog(context);
                                  },
                                  child: const Text('加盟店更新'),
                                ),
                                const SizedBox(width: 24.0),
                                ElevatedButton(
                                  onPressed: () {
                                    openShowItemDialog(context);
                                  },
                                  child: const Text('加盟店詳細'),
                                ),
                              ],
                            ),
                          );
                        },
                        onChanged: (event) {
                          logger.info(event);
                        },
                        onLoaded: (event) {
                          logger.info(event);
                        },
                        onSelected: (event) async {
                          final selectedId = event.row!.cells['id']!.value;
                          ref
                              .read(merchantIdProvider.notifier)
                              .update((_) => selectedId);
                        },
                        onRowDoubleTap: (event) {
                          final selectedId = event.row.cells['id']!.value;
                          ref
                              .read(merchantIdProvider.notifier)
                              .update((_) => selectedId);

                          openShowItemDialog(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PlutoRow> createRows(List<Merchant> merchants) {
    List<PlutoRow> rows = [];
    merchants.asMap().forEach(
      (index, merchant) {
        final plutoRow = PlutoRow(
          cells: {
            'index': PlutoCell(value: index + 1),
            'id': PlutoCell(value: merchant.id),
            'name': PlutoCell(value: merchant.name),
            'imageUrl': PlutoCell(value: merchant.imageUrl),
            'imagePath': PlutoCell(value: merchant.imagePath),
            'latitude': PlutoCell(value: merchant.position.geopoint.latitude),
            'longitude': PlutoCell(value: merchant.position.geopoint.latitude),
            'updatedAt': PlutoCell(value: merchant.updatedAt),
            'createdAt': PlutoCell(value: merchant.createdAt),
          },
        );

        rows.add(plutoRow);
      },
    );

    return rows;
  }

  void openAddItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 800.0,
            width: 800.0,
            child: AddMerchantPage(),
          ),
        );
      },
    );
  }

  void openEditItemDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (builder) {
        return const Dialog(
          child: SizedBox(
            height: 1000.0,
            width: 800.0,
            child: EditMerchantPage(),
          ),
        );
      },
    );
  }

  void openShowItemDialog(BuildContext context) {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => const ShowMerchantPage()));
  }
}

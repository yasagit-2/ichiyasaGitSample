import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../provider/authentication.dart';
import 'content_root.dart';
import 'style.dart';

class SideMenuPage extends ConsumerWidget {
  const SideMenuPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            child: Column(
              children: [
                Image.asset(
                  'assets/images/logo.png',
                  width: 100.0,
                  height: 100.0,
                ),
                const Text('MeValシステム管理', style: TextStyle(fontSize: 18.0)),
              ],
            ),
          ),
          ListTile(
            title: const Text('拠点', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.base);
            },
          ),
          ListTile(
            title: const Text('称号', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.title);
            },
          ),
          ListTile(
            title: const Text('加盟店', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.merchant);
            },
          ),
          ListTile(
            title: const Text('ユーザ投稿', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.userPost);
            },
          ),
          ListTile(
            title: const Text('行政投稿', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.adminPost);
            },
          ),
          ListTile(
            title: const Text('イベント', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.event);
            },
          ),
          ListTile(
            title: const Text('お知らせ', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.notification);
            },
          ),
          ListTile(
            title: const Text('ユーザー管理', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.member);
            },
          ),
          ListTile(
            title: const Text('システム設定', style: TextStyle(fontSize: 24.0)),
            onTap: () {
              ref
                  .read(contentTypeProvider.notifier)
                  .update((_) => ContentType.setting);
            },
          ),
          VerticalSpacer.standard,
          ListTile(
            title: const Text('サインアウト', style: TextStyle(fontSize: 24.0)),
            onTap: () async {
              final result = await showOkCancelAlertDialog(
                context: context,
                title: 'サインアウトしますか？',
                isDestructiveAction: true,
              );

              if (result == OkCancelResult.cancel) {
                return;
              }

              // サインアウト
              await ref.read(authenticatorProvider.notifier).signOut();
            },
          ),
        ],
      ),
    );
  }
}

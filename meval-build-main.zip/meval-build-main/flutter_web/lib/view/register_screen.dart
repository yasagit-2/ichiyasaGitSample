import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../provider/authentication.dart';
import '../util/show_toast.dart';
import 'style.dart';

class RegisterScreen extends HookConsumerWidget {
  static String path = 'register';
  static String name = 'register';

  const RegisterScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final emailController = useTextEditingController();
    final isValidEmail = useState(false);

    final passwordController = useTextEditingController();
    final isValidPassword = useState(false);

    final isVisiblePassword = useState(true);

    return Scaffold(
      appBar: AppBar(
        title: const Text('アカウント新規登録'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 500,
              child: TextFormField(
                controller: emailController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [
                  AutofillHints.email,
                  AutofillHints.username
                ],
                validator: (value) {
                  if ((value == null) || !EmailValidator.validate(value)) {
                    WidgetsBinding.instance.addPostFrameCallback(
                        (_) => isValidEmail.value = false);
                    return '正しいメールアドレスを入力してください';
                  }

                  WidgetsBinding.instance
                      .addPostFrameCallback((_) => isValidEmail.value = true);
                  return null;
                },
                onChanged: (value) {
                  emailController.text = value;
                  emailController.selection = TextSelection.fromPosition(
                      TextPosition(offset: value.length));
                },
                decoration: InputDecoration(
                  label: const Text('メールアドレス'),
                  prefixIcon: const Icon(Icons.mail),
                  // クリアボタン
                  suffixIcon: IconButton(
                    onPressed: () {
                      emailController.clear();
                    },
                    icon: const Icon(
                      Icons.clear,
                      size: 20.0,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 500,
              child: TextFormField(
                obscureText: isVisiblePassword.value,
                controller: passwordController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                autofillHints: const [AutofillHints.password],
                validator: (value) {
                  if ((value == null) || value.isEmpty || value.length < 8) {
                    WidgetsBinding.instance.addPostFrameCallback(
                        (_) => isValidPassword.value = false);
                    return 'パスワードを8文字以上で入力してください';
                  }

                  WidgetsBinding.instance.addPostFrameCallback(
                      (_) => isValidPassword.value = true);
                  return null;
                },
                onChanged: (value) {
                  passwordController.text = value;
                  passwordController.selection = TextSelection.fromPosition(
                      TextPosition(offset: value.length));
                },
                decoration: InputDecoration(
                  label: const Text('パスワード'),
                  prefixIcon: const Icon(Icons.password),
                  suffixIcon: IconButton(
                    onPressed: () {
                      isVisiblePassword.value = !isVisiblePassword.value;
                    },
                    icon: isVisiblePassword.value
                        ? const Icon(Icons.visibility_off, size: 20.0)
                        : const Icon(Icons.visibility, size: 20.0),
                  ),
                ),
              ),
            ),
            VerticalSpacer.standard,
            ElevatedButton(
              onPressed: () async {
                try {
                  await ref
                      .read(authenticatorProvider.notifier)
                      .createUserWithEmailAndPassword(
                          emailController.text, passwordController.text);

                  showCreateToast(
                      '登録したメールアドレスへ確認メールを送信しました\nメールアドレスの確認を行ってください');

                  context.pop();
                } on FirebaseAuthException {
                  showErrorToast('アカウントの登録に失敗しました');
                }
              },
              child: const Text('登録'),
            ),
          ],
        ),
      ),
    );
  }
}

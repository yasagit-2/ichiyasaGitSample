import 'package:flutter/material.dart';

const titleFont = 'Roboto_Italic';
const regularFont = 'NotoSansJP_Medium';
const boldFont = 'NotoSansJP_Bold';

final lightTheme = ThemeData(
  brightness: Brightness.light,
  appBarTheme: const AppBarTheme(
    // backgroundColor: Colors.blue[400],
    backgroundColor: Colors.white,
    iconTheme: IconThemeData(
      color: Colors.black,
    ),
    titleTextStyle: TextStyle(
      color: Colors.black,
      fontSize: 20.0,
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      foregroundColor: Colors.white,
      backgroundColor: Colors.black54,
      textStyle: TextStyles.buttonTextStyle,
    ),
  ),
  primaryIconTheme: const IconThemeData(
    color: Colors.black,
  ),
  iconTheme: const IconThemeData(
    color: Colors.black,
  ),
  fontFamily: regularFont,
);

class CustomColors {
  static const sideMenuBgColor = Color(0xFF1b1b1b);
  static const taskListBgColor = Color(0xFF212121);
  static const detailBgColor = Color(0xFF424242);

  static const periodOverTaskColor = Colors.red;

  static Color taskCardBgColor(BuildContext context) =>
      Theme.of(context).cardColor;
}

class WidgetColors {
  static const timeOverChipBgColor = Colors.red;
}

class BreakPointWidth {
  static const double smallToMid = 600;
  static const double midToLarge = 1240;
}

enum ScreenSize {
  small,
  mid,
  large,
}

class WidgetSize {
  static const double addTaskDialogWidth = 500.0;
  static const double addTaskDialogHeight = 500.0;
}

class TextStyles {
  static const newTaskTitleTextStyle = TextStyle(fontSize: 18.0);
  static const newTaskItemTextStyle = TextStyle(fontSize: 16.0);
  static const newTaskDetailTextStyle = TextStyle(fontSize: 14.0);
  static const listTileChipTextStyle = TextStyle(fontSize: 12.0);

  // ボタンのスタイル
  static const buttonTextStyle = TextStyle(fontSize: 18.0);
}

class VerticalSpacer {
  // Widget間の標準スペース
  static const standard = SizedBox(height: 24.0);

  // Widget間のスペース(小さめ)
  static const smallish = SizedBox(height: 12.0);

  // Widget間のスペース(セパレート)
  static const separator = SizedBox(height: 5.0);
}

class HorizontalSpacer {
  // Widget間の標準スペース
  static const standard = SizedBox(width: 24.0);

  // Widget間のスペース(小さめ)
  static const smallish = SizedBox(width: 12.0);

  // 「※必須」のスペース
  static const requiredEntry = SizedBox(width: 18.0);
}

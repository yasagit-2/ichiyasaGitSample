import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'pages/admin_post/admin_post_page.dart';
import 'pages/title/title_page.dart';
import 'pages/base/base_page.dart';
import 'pages/event/event_page.dart';
import 'pages/merchant/merchant_page.dart';
import 'pages/notification/notification_page.dart';
import 'pages/setting/setting_page.dart';
import 'pages/user_post/user_post_page.dart';
import 'pages/member/member_page.dart';
import 'side_menu_page.dart';

 

enum ContentType {
  base,
  title,
  merchant,
  userPost,
  adminPost,
  event,
  notification,
  member,
  setting,
}

final contentTypeProvider =
    StateProvider.autoDispose<ContentType>((_) => ContentType.base);

final contentSelectProvider = Provider.autoDispose<Widget>((ref) {
  final contentType = ref.watch(contentTypeProvider);

  switch (contentType) {
    case ContentType.base:
      return const BasePage();
    case ContentType.title:
      return const TitlePage();
    case ContentType.merchant:
      return const MerchantPage();
    case ContentType.userPost:
      return const PostPage();
    case ContentType.adminPost:
      return const AdminPostPage();
    case ContentType.event:
      return const EventPage();
    case ContentType.notification:
      return const MemberNotificationPage();
    case ContentType.member:
      return const MemberPage();
    case ContentType.setting:
      return const SettingPage();
    default:
      return const BasePage();
  }
});

class ContentRoot extends ConsumerWidget {
  static String path = '/contentRoot';
  static String name = 'contentRoot';

  const ContentRoot({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        if (constraints.maxWidth >= 1240) {
          return Row(
            children: [
              const Expanded(
                flex: 1,
                child: SideMenuPage(),
              ),
              Expanded(
                flex: 5,
                child: ref.watch(contentSelectProvider),
              ),
            ],
          );
        } else {
          return ref.watch(contentSelectProvider);
        }
      },
    );
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

final loadingServiceProvider = StateNotifierProvider<LoadingService, bool>(
  (ref) {
    return LoadingService();
  },
);

class LoadingService extends StateNotifier<bool> {
  LoadingService() : super(false);

  Future<T> wrap<T>(Future<T> future) async {
    present();
    try {
      return await future;
    } finally {
      dismiss();
    }
  }

  void present() {
    state = true;
  }

  void dismiss() {
    state = false;
  }
}

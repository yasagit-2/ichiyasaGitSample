import 'package:flutter/cupertino.dart';
import 'package:flutter_web/repository/title_repository.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../util/logger.dart';

// MemberViewModelプロバイダ
final titleViewModelProvider = StateNotifierProvider<TitleViewModel, Title?>(
  (ref) {
    ref.onDispose(() {
      logger.fine('memberViewModelProvider dispose.');
    });
    return TitleViewModel(
      ref,
      ref.read(titleRepositoryProvider),
    );
  },
);

class TitleViewModel extends StateNotifier<Title?> {
  final Ref _ref;
  final TitleRepository _titleRepository;

  TitleViewModel(this._ref, this._titleRepository) : super(null);

  /// 会員登録を行います。
  // Future<void> register({
  //   required String nickname,
  //   required String gender,
  //   required DateTime monthOfBirth,
  //   required String prefecture,
  // }) async {
  //   // デバイス情報
  //   await _titleRepository.register(
  //     nickname: nickname,
  //     gender: gender,
  //     monthOfBirth: monthOfBirth,
  //     prefecture: prefecture,
  //   );
  // }

  /// 会員情報を削除します。
  Future<void> deleteTitle(titleId) async {
    if (titleId == null || titleId == "") return;
    return await _titleRepository.deleteTitle(titleId);
  }
  

  /// 会員情報を更新します。
  Future<void> updateTitle({
    required String id,
    required String name,
    required int point,
    required int pointLimit,
  }) async {
    if (id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    await _titleRepository.updateTitle(
      titleId: id,
      name: name,
      point: point,
      pointLimit: pointLimit,
    );
  }
}

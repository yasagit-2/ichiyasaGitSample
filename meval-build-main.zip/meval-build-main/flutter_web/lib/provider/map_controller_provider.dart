import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../view/pages/map/map_page.dart';

/// GoogleMapControllerプロバイダ
final googleMapControllerProvider =
    StateProvider<GoogleMapController?>((ref) => null);

/// マップの中心位置を[position]へ移動します。
Future<void> moveCamera(WidgetRef ref, LatLng location) async {
  final googleMapController = ref.read(googleMapControllerProvider);
  if (googleMapController == null) {
    return;
  }

  ref.read(locationProvider.notifier).update((_) => location);

  await googleMapController.moveCamera(
    CameraUpdate.newCameraPosition(
      CameraPosition(
        target: LatLng(location.latitude, location.longitude),
        zoom: await googleMapController.getZoomLevel(),
      ),
    ),
  );
}

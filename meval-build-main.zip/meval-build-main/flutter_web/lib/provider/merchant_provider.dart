import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/merchant.dart';
import '../repository/merchant_repository.dart';

final merchantsStreamProvider =
    StreamProvider.autoDispose<List<Merchant>>((ref) {
  return ref.watch(merchantRepositoryProvider).getMerchants();
});

final merchantIdSelectProvider =
    StreamProvider.family.autoDispose<Merchant?, String>((ref, String id) {
  return ref.watch(merchantRepositoryProvider).getMerchantById(id);
});

final merchantIdProvider = StateProvider<String>((ref) => '');

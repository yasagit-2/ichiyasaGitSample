import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/title_data.dart';
import '../repository/title_repository.dart';

final titlesProvider = StreamProvider.autoDispose<List<TitleData>>((ref) {
  return ref.watch(titleRepositoryProvider).getTitles();
});

final titleIdSelectProvider = StreamProvider.family.autoDispose<TitleData?,String>((ref,String titleId) {
  return ref.watch(titleRepositoryProvider).getTitleById(titleId);
});
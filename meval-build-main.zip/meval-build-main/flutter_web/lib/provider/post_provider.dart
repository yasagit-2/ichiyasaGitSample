import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/post.dart';
import '../repository/post_repository.dart';

final postsStreamProvider = StreamProvider.autoDispose<List<Post>>((ref) {
  return ref.watch(postRepositoryProvider).getPosts();
});

final postIdSelectProvider =
    StreamProvider.family.autoDispose<Post?, String>((ref, String id) {
  return ref.watch(postRepositoryProvider).getPostById(id);
});

final postIdProvider = StateProvider<String>((ref) => '');

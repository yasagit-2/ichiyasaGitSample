import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/member.dart';
import '../repository/member_repository.dart';

final membersStreamProvider = StreamProvider.autoDispose<List<Member>>((ref) {
  return ref.watch(memberRepositoryProvider).getMembers();
});

final memberIdSelectProvider =
    StreamProvider.family.autoDispose<Member?, String>((ref, String id) {
  return ref.watch(memberRepositoryProvider).getMemberById(id);
});

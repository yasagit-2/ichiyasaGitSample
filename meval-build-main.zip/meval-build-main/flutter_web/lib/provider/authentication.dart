import 'package:firebase_auth/firebase_auth.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../util/logger.dart';

final authenticatorProvider =
    StateNotifierProvider<AuthenticationController, User?>(
  (ref) =>
      AuthenticationController(initialUser: FirebaseAuth.instance.currentUser),
);

class AuthenticationController extends StateNotifier<User?> {
  final _auth = FirebaseAuth.instance;

  AuthenticationController({User? initialUser}) : super(initialUser) {
    // Userの変更を検知して状態を更新
    _auth.userChanges().listen((user) {
      state = user;
    });
  }

  Future<User?> signInWithEmail(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);

      final user = userCredential.user;
      if (user != null && !user.emailVerified) {
        // メールアドレスの確認
        await user.sendEmailVerification();
      }

      return user;
    } on FirebaseAuthException catch (e) {
      logger.severe(e);
      rethrow;
    }
  }

  Future<User?> createUserWithEmailAndPassword(
      String email, String password) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);

      final user = userCredential.user;
      if (user != null) {
        // メールアドレスの確認
        await user.sendEmailVerification();
      }

      return user;
    } on FirebaseAuthException catch (e) {
      logger.severe(e);
      rethrow;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }
}

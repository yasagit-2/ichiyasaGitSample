import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/base.dart';
import '../model/domain/base_model.dart';
import '../repository/base_repository.dart';

final parentBasesStreamProvider = StreamProvider.autoDispose<List<Base>>((ref) {
  return ref.watch(baseRepositoryProvider).getParentBases();
});

final subBasesStreamProvider = StreamProvider.family
    .autoDispose<List<Base>, String>((ref, String parentBaseId) {
  return ref
      .watch(baseRepositoryProvider)
      .getSubBasesByParentBaseId(parentBaseId);
});

final parentBasesFutureProvider =
    FutureProvider.autoDispose<List<BaseModel>>((ref) async {
  final parentBases = await ref.watch(parentBasesStreamProvider.future);

  List<BaseModel> baseModels = [];
  for (final base in parentBases) {
    int pointLimitRemain =
        await ref.watch(baseRepositoryProvider).getPointLimitRemain(base.id);

    final baseModel = BaseModel(
      id: base.id,
      name: base.name,
      subBaseCount: base.subBaseCount,
      // parentRef: base.parentRef,
      imageUrl: base.imageUrl,
      imagePath: base.imagePath,
      titleRef: base.titleRef,
      position: base.position,
      effectivePeriodBegin: base.effectivePeriodBegin,
      effectivePeriodEnd: base.effectivePeriodEnd,
      effectiveDaysOfWeek: base.effectiveDaysOfWeek,
      effectiveTimeBegin: base.effectiveTimeBegin,
      effectiveTimeEnd: base.effectiveTimeEnd,
      publishStatus: base.publishStatus,
      point: base.point,
      pointLimit: base.pointLimit,
      updatedAt: base.updatedAt,
      createdAt: base.createdAt,
      pointLimitRemain: pointLimitRemain,
    );

    baseModels.add(baseModel);
  }

  return baseModels;
});

final subBasesByParentBaseIdFutureProvider = FutureProvider.family
    .autoDispose<List<BaseModel>, String>((ref, String parentBaseId) async {
  final subBases = await ref.watch(subBasesStreamProvider(parentBaseId).future);

  List<BaseModel> baseModels = [];
  for (final base in subBases) {
    final baseModel = BaseModel(
      id: base.id,
      name: base.name,
      subBaseCount: base.subBaseCount,
      parentRef: base.parentRef,
      imageUrl: base.imageUrl,
      imagePath: base.imagePath,
      titleRef: base.titleRef,
      position: base.position,
      effectivePeriodBegin: base.effectivePeriodBegin,
      effectivePeriodEnd: base.effectivePeriodEnd,
      effectiveDaysOfWeek: base.effectiveDaysOfWeek,
      effectiveTimeBegin: base.effectiveTimeBegin,
      effectiveTimeEnd: base.effectiveTimeEnd,
      publishStatus: base.publishStatus,
      point: base.point,
      pointLimit: base.pointLimit,
      updatedAt: base.updatedAt,
      createdAt: base.createdAt,
      pointLimitRemain: 0,
    );

    baseModels.add(baseModel);
  }

  return baseModels;
});

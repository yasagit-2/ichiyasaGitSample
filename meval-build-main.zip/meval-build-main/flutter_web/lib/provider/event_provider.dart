import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/event_data.dart';
import '../repository/event_repository.dart';

final eventsProvider = StreamProvider.autoDispose<List<Event>>((ref) {
  return ref.watch(eventRepositoryProvider).getEvents();
});

final eventsSpotProvider = StreamProvider.family.autoDispose<List<EventSpot>,String>((ref,String eventId) {
  return ref.watch(eventRepositoryProvider).getEventSpotById(eventId);
});



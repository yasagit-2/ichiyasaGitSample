import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/postIcon.dart';
import '../repository/postIcon_repository.dart';

final postIconsStreamProvider =
    StreamProvider.autoDispose<List<PostIcon>>((ref) {
  return ref.watch(postIconRepositoryProvider).getPostIcons();
});

final postIconIdSelectProvider =
    StreamProvider.family.autoDispose<PostIcon?, String>((ref, String id) {
  return ref.watch(postIconRepositoryProvider).getPostIconById(id);
});

final postIconIdProvider = StateProvider<String>((ref) => '');

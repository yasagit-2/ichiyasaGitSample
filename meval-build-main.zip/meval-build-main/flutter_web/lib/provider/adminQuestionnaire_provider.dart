import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/adminQuestionnaire.dart';
import '../repository/adminQuestionnaire_repository.dart';

final adminQuestionnairesStreamProvider =
    StreamProvider.autoDispose<List<AdminQuestionnaire>>((ref) {
  return ref
      .watch(adminQuestionnaireRepositoryProvider)
      .getAdminQuestionnaires();
});

final adminQuestionnaireIdSelectProvider = StreamProvider.family
    .autoDispose<AdminQuestionnaire?, String>((ref, String id) {
  return ref
      .watch(adminQuestionnaireRepositoryProvider)
      .getAdminQuestionnaireById(id);
});

final adminQuestionnaireIdProvider = StateProvider<String>((ref) => '');

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/adminAlert.dart';
import '../repository/adminAlert_repository.dart';

final adminAlertsStreamProvider =
    StreamProvider.autoDispose<List<AdminAlert>>((ref) {
  return ref.watch(adminAlertRepositoryProvider).getAdminAlerts();
});

final adminAlertIdSelectProvider =
    StreamProvider.family.autoDispose<AdminAlert?, String>((ref, String id) {
  return ref.watch(adminAlertRepositoryProvider).getAdminAlertById(id);
});

final adminAlertIdProvider = StateProvider<String>((ref) => '');

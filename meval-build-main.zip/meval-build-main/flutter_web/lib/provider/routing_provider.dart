import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../view/content_root.dart';
import '../view/home_screen.dart';
import '../view/register_screen.dart';
import 'authentication.dart';

final routingProvider = Provider(
  (ref) => GoRouter(
    debugLogDiagnostics: true,
    initialLocation: HomeScreen.path,
    routes: [
      GoRoute(
        path: HomeScreen.path,
        name: HomeScreen.name,
        builder: (context, state) => const HomeScreen(),
        routes: [
          GoRoute(
            path: RegisterScreen.path,
            name: RegisterScreen.name,
            builder: (context, state) => const RegisterScreen(),
          ),
        ],
      ),
      GoRoute(
        path: ContentRoot.path,
        name: ContentRoot.name,
        builder: (context, state) => const ContentRoot(),
      ),
    ],
    redirect: (context, state) {
      final user = ref.watch(authenticatorProvider);
      if (user != null) {
        return ContentRoot.path;
      }

      // TODO user.emailVerified == false の場合、ログインOKと判定しない

      return null;
    },
  ),
);

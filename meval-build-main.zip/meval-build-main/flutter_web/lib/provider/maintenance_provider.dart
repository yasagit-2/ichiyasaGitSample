import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/maintenance.dart';
import '../repository/maintenance_repository.dart';
import '../util/logger.dart';

final maintenanceStreamProvider =
    StreamProvider.autoDispose<Maintenance?>((ref) {
  ref.onDispose(() {
    logger.fine('maintenanceStreamProvider dispose.');
  });

  return maintenanceRef(id: 'maintenance')
      .snapshots()
      .map((maintenanceDocSnap) => maintenanceDocSnap.data);
});

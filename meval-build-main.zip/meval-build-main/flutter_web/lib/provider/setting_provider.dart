import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/setting.dart';
import '../repository/setting_repository.dart';
import '../util/logger.dart';

final settingStreamProvider = StreamProvider.autoDispose<Setting?>((ref) {
  ref.onDispose(() {
    logger.fine('settingsStreamProvider dispose.');
  });

  return settingRef(id: 'mevalAppSettings')
      .snapshots()
      .map((settingDocSnap) => settingDocSnap.data);
});

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/memberNotification.dart';
import '../repository/memberNotification_repository.dart';

final memberNotificationsStreamProvider =
    StreamProvider.autoDispose<List<MemberNotification>>((ref) {
  return ref
      .watch(memberNotificationRepositoryProvider)
      .getMemberNotifications();
});

final memberNotificationIdSelectProvider = StreamProvider.family
    .autoDispose<MemberNotification?, String>((ref, String id) {
  return ref
      .watch(memberNotificationRepositoryProvider)
      .getMemberNotificationById(id);
});

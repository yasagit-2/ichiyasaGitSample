import 'package:flutter/foundation.dart';
import 'package:simple_logger/simple_logger.dart';

final logger = SimpleLogger()
  ..setLevel(
    Level.FINEST,
    // リリースビルドの場合は無効 (スタックトレースを扱うことからパフォーマンスを考慮)
    includeCallerInfo: !kReleaseMode,
  );

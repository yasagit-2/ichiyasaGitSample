import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'posting_alert.freezed.dart';
part 'posting_alert.g.dart';

/// 通報
@freezed
class PostingAlert with _$PostingAlert {
  @firestoreSerializable
  const factory PostingAlert({
    // 通報ID
    required String id,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 投稿のReference
    @DocumentReferenceConverter() required DocumentReference postRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _PostingAlert;

  factory PostingAlert.fromJson(Map<String, Object?> json) =>
      _$PostingAlertFromJson(json);
}

@Collection<PostingAlert>('postingAlerts')
final postingAlertsRef = PostingAlertCollectionReference();

PostingAlertDocumentReference postingAlertRef({required String id}) =>
    PostingAlertDocumentReference(postingAlertsRef.doc(id).reference);

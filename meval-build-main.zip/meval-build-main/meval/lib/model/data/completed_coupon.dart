import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'completed_coupon.freezed.dart';
part 'completed_coupon.g.dart';

/// クーポン獲得情報
@freezed
class CompletedCoupon with _$CompletedCoupon {
  @firestoreSerializable
  const factory CompletedCoupon({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedCoupon;

  factory CompletedCoupon.fromJson(Map<String, Object?> json) =>
      _$CompletedCouponFromJson(json);
}

@Collection<CompletedCoupon>('completedCoupons')
@Collection<CouponHistory>('completedCoupons/*/couponHistories',
    name: 'couponHistories')
final completedCouponsRef = CompletedCouponCollectionReference();

CompletedCouponDocumentReference completedCouponRef({required String id}) =>
    CompletedCouponDocumentReference(completedCouponsRef.doc(id).reference);

/// クーポン獲得/使用履歴
@freezed
class CouponHistory with _$CouponHistory {
  @firestoreSerializable
  const factory CouponHistory({
    // クーポンID
    required String id,
    // 加盟店ID
    required String merchantId,
    // クーポン名称
    required String name,
    // 交換ポイント
    required int exchangePoint,
    // クーポン有効期限
    required DateTime dueDate,
    // ポイント交換済み
    required bool isPointUsed,
    // クーポン使用済み
    required bool isCouponUsed,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CouponHistory;

  factory CouponHistory.fromJson(Map<String, Object?> json) =>
      _$CouponHistoryFromJson(json);
}

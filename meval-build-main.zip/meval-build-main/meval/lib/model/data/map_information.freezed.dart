// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'map_information.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MapInformation _$MapInformationFromJson(Map<String, dynamic> json) {
  return _MapInformation.fromJson(json);
}

/// @nodoc
mixin _$MapInformation {
// 拠点ドキュメントリスト
  dynamic get bases => throw _privateConstructorUsedError; // 投稿ドキュメントリスト
  dynamic get posts => throw _privateConstructorUsedError; // 行政投稿アラートドキュメントリスト
  dynamic get adminAlert =>
      throw _privateConstructorUsedError; // 行政投稿アンケートドキュメントリスト
  dynamic get adminQuestionnaire =>
      throw _privateConstructorUsedError; // 加盟店ドキュメントリスト
  dynamic get merchants => throw _privateConstructorUsedError; // 拠点マーカー
  dynamic get baseMarkers => throw _privateConstructorUsedError; // 投稿マーカー
  dynamic get postMarkers => throw _privateConstructorUsedError; // 行政投稿アラートマーカー
  dynamic get adminAlertMarkers =>
      throw _privateConstructorUsedError; // 行政投稿アンケートマーカー
  dynamic get adminQuestionnaireMarkers =>
      throw _privateConstructorUsedError; // 加盟店マーカー
  dynamic get merchantMarkers => throw _privateConstructorUsedError; // 拠点サークル
  dynamic get baseCircles => throw _privateConstructorUsedError; // 投稿準備マーカー
  dynamic get postingPreparationMarker => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MapInformationCopyWith<MapInformation> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MapInformationCopyWith<$Res> {
  factory $MapInformationCopyWith(
          MapInformation value, $Res Function(MapInformation) then) =
      _$MapInformationCopyWithImpl<$Res, MapInformation>;
  @useResult
  $Res call(
      {dynamic bases,
      dynamic posts,
      dynamic adminAlert,
      dynamic adminQuestionnaire,
      dynamic merchants,
      dynamic baseMarkers,
      dynamic postMarkers,
      dynamic adminAlertMarkers,
      dynamic adminQuestionnaireMarkers,
      dynamic merchantMarkers,
      dynamic baseCircles,
      dynamic postingPreparationMarker});
}

/// @nodoc
class _$MapInformationCopyWithImpl<$Res, $Val extends MapInformation>
    implements $MapInformationCopyWith<$Res> {
  _$MapInformationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bases = null,
    Object? posts = null,
    Object? adminAlert = null,
    Object? adminQuestionnaire = null,
    Object? merchants = null,
    Object? baseMarkers = null,
    Object? postMarkers = null,
    Object? adminAlertMarkers = null,
    Object? adminQuestionnaireMarkers = null,
    Object? merchantMarkers = null,
    Object? baseCircles = null,
    Object? postingPreparationMarker = null,
  }) {
    return _then(_value.copyWith(
      bases: null == bases
          ? _value.bases
          : bases // ignore: cast_nullable_to_non_nullable
              as dynamic,
      posts: null == posts
          ? _value.posts
          : posts // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminAlert: null == adminAlert
          ? _value.adminAlert
          : adminAlert // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminQuestionnaire: null == adminQuestionnaire
          ? _value.adminQuestionnaire
          : adminQuestionnaire // ignore: cast_nullable_to_non_nullable
              as dynamic,
      merchants: null == merchants
          ? _value.merchants
          : merchants // ignore: cast_nullable_to_non_nullable
              as dynamic,
      baseMarkers: null == baseMarkers
          ? _value.baseMarkers
          : baseMarkers // ignore: cast_nullable_to_non_nullable
              as dynamic,
      postMarkers: null == postMarkers
          ? _value.postMarkers
          : postMarkers // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminAlertMarkers: null == adminAlertMarkers
          ? _value.adminAlertMarkers
          : adminAlertMarkers // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminQuestionnaireMarkers: null == adminQuestionnaireMarkers
          ? _value.adminQuestionnaireMarkers
          : adminQuestionnaireMarkers // ignore: cast_nullable_to_non_nullable
              as dynamic,
      merchantMarkers: null == merchantMarkers
          ? _value.merchantMarkers
          : merchantMarkers // ignore: cast_nullable_to_non_nullable
              as dynamic,
      baseCircles: null == baseCircles
          ? _value.baseCircles
          : baseCircles // ignore: cast_nullable_to_non_nullable
              as dynamic,
      postingPreparationMarker: null == postingPreparationMarker
          ? _value.postingPreparationMarker
          : postingPreparationMarker // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MapInformationCopyWith<$Res>
    implements $MapInformationCopyWith<$Res> {
  factory _$$_MapInformationCopyWith(
          _$_MapInformation value, $Res Function(_$_MapInformation) then) =
      __$$_MapInformationCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {dynamic bases,
      dynamic posts,
      dynamic adminAlert,
      dynamic adminQuestionnaire,
      dynamic merchants,
      dynamic baseMarkers,
      dynamic postMarkers,
      dynamic adminAlertMarkers,
      dynamic adminQuestionnaireMarkers,
      dynamic merchantMarkers,
      dynamic baseCircles,
      dynamic postingPreparationMarker});
}

/// @nodoc
class __$$_MapInformationCopyWithImpl<$Res>
    extends _$MapInformationCopyWithImpl<$Res, _$_MapInformation>
    implements _$$_MapInformationCopyWith<$Res> {
  __$$_MapInformationCopyWithImpl(
      _$_MapInformation _value, $Res Function(_$_MapInformation) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bases = null,
    Object? posts = null,
    Object? adminAlert = null,
    Object? adminQuestionnaire = null,
    Object? merchants = null,
    Object? baseMarkers = null,
    Object? postMarkers = null,
    Object? adminAlertMarkers = null,
    Object? adminQuestionnaireMarkers = null,
    Object? merchantMarkers = null,
    Object? baseCircles = null,
    Object? postingPreparationMarker = null,
  }) {
    return _then(_$_MapInformation(
      bases: null == bases ? _value.bases : bases,
      posts: null == posts ? _value.posts : posts,
      adminAlert: null == adminAlert ? _value.adminAlert : adminAlert,
      adminQuestionnaire: null == adminQuestionnaire
          ? _value.adminQuestionnaire
          : adminQuestionnaire,
      merchants: null == merchants ? _value.merchants : merchants,
      baseMarkers: null == baseMarkers ? _value.baseMarkers : baseMarkers,
      postMarkers: null == postMarkers ? _value.postMarkers : postMarkers,
      adminAlertMarkers: null == adminAlertMarkers
          ? _value.adminAlertMarkers
          : adminAlertMarkers,
      adminQuestionnaireMarkers: null == adminQuestionnaireMarkers
          ? _value.adminQuestionnaireMarkers
          : adminQuestionnaireMarkers,
      merchantMarkers:
          null == merchantMarkers ? _value.merchantMarkers : merchantMarkers,
      baseCircles: null == baseCircles ? _value.baseCircles : baseCircles,
      postingPreparationMarker: null == postingPreparationMarker
          ? _value.postingPreparationMarker
          : postingPreparationMarker,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MapInformation implements _MapInformation {
  const _$_MapInformation(
      {this.bases = const <DocumentSnapshot>[],
      this.posts = const <DocumentSnapshot>[],
      this.adminAlert = const <DocumentSnapshot>[],
      this.adminQuestionnaire = const <DocumentSnapshot>[],
      this.merchants = const <DocumentSnapshot>[],
      this.baseMarkers = const <Marker>{},
      this.postMarkers = const <Marker>{},
      this.adminAlertMarkers = const <Marker>{},
      this.adminQuestionnaireMarkers = const <Marker>{},
      this.merchantMarkers = const <Marker>{},
      this.baseCircles = const <Circle>{},
      this.postingPreparationMarker = const <Marker>{}});

  factory _$_MapInformation.fromJson(Map<String, dynamic> json) =>
      _$$_MapInformationFromJson(json);

// 拠点ドキュメントリスト
  @override
  @JsonKey()
  final dynamic bases;
// 投稿ドキュメントリスト
  @override
  @JsonKey()
  final dynamic posts;
// 行政投稿アラートドキュメントリスト
  @override
  @JsonKey()
  final dynamic adminAlert;
// 行政投稿アンケートドキュメントリスト
  @override
  @JsonKey()
  final dynamic adminQuestionnaire;
// 加盟店ドキュメントリスト
  @override
  @JsonKey()
  final dynamic merchants;
// 拠点マーカー
  @override
  @JsonKey()
  final dynamic baseMarkers;
// 投稿マーカー
  @override
  @JsonKey()
  final dynamic postMarkers;
// 行政投稿アラートマーカー
  @override
  @JsonKey()
  final dynamic adminAlertMarkers;
// 行政投稿アンケートマーカー
  @override
  @JsonKey()
  final dynamic adminQuestionnaireMarkers;
// 加盟店マーカー
  @override
  @JsonKey()
  final dynamic merchantMarkers;
// 拠点サークル
  @override
  @JsonKey()
  final dynamic baseCircles;
// 投稿準備マーカー
  @override
  @JsonKey()
  final dynamic postingPreparationMarker;

  @override
  String toString() {
    return 'MapInformation(bases: $bases, posts: $posts, adminAlert: $adminAlert, adminQuestionnaire: $adminQuestionnaire, merchants: $merchants, baseMarkers: $baseMarkers, postMarkers: $postMarkers, adminAlertMarkers: $adminAlertMarkers, adminQuestionnaireMarkers: $adminQuestionnaireMarkers, merchantMarkers: $merchantMarkers, baseCircles: $baseCircles, postingPreparationMarker: $postingPreparationMarker)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MapInformation &&
            const DeepCollectionEquality().equals(other.bases, bases) &&
            const DeepCollectionEquality().equals(other.posts, posts) &&
            const DeepCollectionEquality()
                .equals(other.adminAlert, adminAlert) &&
            const DeepCollectionEquality()
                .equals(other.adminQuestionnaire, adminQuestionnaire) &&
            const DeepCollectionEquality().equals(other.merchants, merchants) &&
            const DeepCollectionEquality()
                .equals(other.baseMarkers, baseMarkers) &&
            const DeepCollectionEquality()
                .equals(other.postMarkers, postMarkers) &&
            const DeepCollectionEquality()
                .equals(other.adminAlertMarkers, adminAlertMarkers) &&
            const DeepCollectionEquality().equals(
                other.adminQuestionnaireMarkers, adminQuestionnaireMarkers) &&
            const DeepCollectionEquality()
                .equals(other.merchantMarkers, merchantMarkers) &&
            const DeepCollectionEquality()
                .equals(other.baseCircles, baseCircles) &&
            const DeepCollectionEquality().equals(
                other.postingPreparationMarker, postingPreparationMarker));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(bases),
      const DeepCollectionEquality().hash(posts),
      const DeepCollectionEquality().hash(adminAlert),
      const DeepCollectionEquality().hash(adminQuestionnaire),
      const DeepCollectionEquality().hash(merchants),
      const DeepCollectionEquality().hash(baseMarkers),
      const DeepCollectionEquality().hash(postMarkers),
      const DeepCollectionEquality().hash(adminAlertMarkers),
      const DeepCollectionEquality().hash(adminQuestionnaireMarkers),
      const DeepCollectionEquality().hash(merchantMarkers),
      const DeepCollectionEquality().hash(baseCircles),
      const DeepCollectionEquality().hash(postingPreparationMarker));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MapInformationCopyWith<_$_MapInformation> get copyWith =>
      __$$_MapInformationCopyWithImpl<_$_MapInformation>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MapInformationToJson(
      this,
    );
  }
}

abstract class _MapInformation implements MapInformation {
  const factory _MapInformation(
      {final dynamic bases,
      final dynamic posts,
      final dynamic adminAlert,
      final dynamic adminQuestionnaire,
      final dynamic merchants,
      final dynamic baseMarkers,
      final dynamic postMarkers,
      final dynamic adminAlertMarkers,
      final dynamic adminQuestionnaireMarkers,
      final dynamic merchantMarkers,
      final dynamic baseCircles,
      final dynamic postingPreparationMarker}) = _$_MapInformation;

  factory _MapInformation.fromJson(Map<String, dynamic> json) =
      _$_MapInformation.fromJson;

  @override // 拠点ドキュメントリスト
  dynamic get bases;
  @override // 投稿ドキュメントリスト
  dynamic get posts;
  @override // 行政投稿アラートドキュメントリスト
  dynamic get adminAlert;
  @override // 行政投稿アンケートドキュメントリスト
  dynamic get adminQuestionnaire;
  @override // 加盟店ドキュメントリスト
  dynamic get merchants;
  @override // 拠点マーカー
  dynamic get baseMarkers;
  @override // 投稿マーカー
  dynamic get postMarkers;
  @override // 行政投稿アラートマーカー
  dynamic get adminAlertMarkers;
  @override // 行政投稿アンケートマーカー
  dynamic get adminQuestionnaireMarkers;
  @override // 加盟店マーカー
  dynamic get merchantMarkers;
  @override // 拠点サークル
  dynamic get baseCircles;
  @override // 投稿準備マーカー
  dynamic get postingPreparationMarker;
  @override
  @JsonKey(ignore: true)
  _$$_MapInformationCopyWith<_$_MapInformation> get copyWith =>
      throw _privateConstructorUsedError;
}

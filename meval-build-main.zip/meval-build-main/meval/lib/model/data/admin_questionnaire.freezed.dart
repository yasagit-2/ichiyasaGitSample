// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'admin_questionnaire.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

AdminQuestionnaire _$AdminQuestionnaireFromJson(Map<String, dynamic> json) {
  return _AdminQuestionnaire.fromJson(json);
}

/// @nodoc
mixin _$AdminQuestionnaire {
// アンケートID
  String get id => throw _privateConstructorUsedError; // アンケート本文
  String get message => throw _privateConstructorUsedError; // アンケート期限
  DateTime get dueDate => throw _privateConstructorUsedError; // アンケートの位置情報
  MapPosition get position => throw _privateConstructorUsedError; // アンケート画像のURL
  String? get imageUrl => throw _privateConstructorUsedError; // アンケート画像の保存先
  String? get imagePath => throw _privateConstructorUsedError; // アンケート回答獲得ポイント
  int get point => throw _privateConstructorUsedError; // ポイント付与制限人数
  int get pointLimit => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AdminQuestionnaireCopyWith<AdminQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdminQuestionnaireCopyWith<$Res> {
  factory $AdminQuestionnaireCopyWith(
          AdminQuestionnaire value, $Res Function(AdminQuestionnaire) then) =
      _$AdminQuestionnaireCopyWithImpl<$Res, AdminQuestionnaire>;
  @useResult
  $Res call(
      {String id,
      String message,
      DateTime dueDate,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$AdminQuestionnaireCopyWithImpl<$Res, $Val extends AdminQuestionnaire>
    implements $AdminQuestionnaireCopyWith<$Res> {
  _$AdminQuestionnaireCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? dueDate = null,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_AdminQuestionnaireCopyWith<$Res>
    implements $AdminQuestionnaireCopyWith<$Res> {
  factory _$$_AdminQuestionnaireCopyWith(_$_AdminQuestionnaire value,
          $Res Function(_$_AdminQuestionnaire) then) =
      __$$_AdminQuestionnaireCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String message,
      DateTime dueDate,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int point,
      int pointLimit,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_AdminQuestionnaireCopyWithImpl<$Res>
    extends _$AdminQuestionnaireCopyWithImpl<$Res, _$_AdminQuestionnaire>
    implements _$$_AdminQuestionnaireCopyWith<$Res> {
  __$$_AdminQuestionnaireCopyWithImpl(
      _$_AdminQuestionnaire _value, $Res Function(_$_AdminQuestionnaire) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? dueDate = null,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? point = null,
    Object? pointLimit = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_AdminQuestionnaire(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointLimit: null == pointLimit
          ? _value.pointLimit
          : pointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_AdminQuestionnaire implements _AdminQuestionnaire {
  const _$_AdminQuestionnaire(
      {required this.id,
      required this.message,
      required this.dueDate,
      required this.position,
      this.imageUrl,
      this.imagePath,
      required this.point,
      required this.pointLimit,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_AdminQuestionnaire.fromJson(Map<String, dynamic> json) =>
      _$$_AdminQuestionnaireFromJson(json);

// アンケートID
  @override
  final String id;
// アンケート本文
  @override
  final String message;
// アンケート期限
  @override
  final DateTime dueDate;
// アンケートの位置情報
  @override
  final MapPosition position;
// アンケート画像のURL
  @override
  final String? imageUrl;
// アンケート画像の保存先
  @override
  final String? imagePath;
// アンケート回答獲得ポイント
  @override
  final int point;
// ポイント付与制限人数
  @override
  final int pointLimit;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'AdminQuestionnaire(id: $id, message: $message, dueDate: $dueDate, position: $position, imageUrl: $imageUrl, imagePath: $imagePath, point: $point, pointLimit: $pointLimit, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AdminQuestionnaire &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.dueDate, dueDate) || other.dueDate == dueDate) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointLimit, pointLimit) ||
                other.pointLimit == pointLimit) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, message, dueDate, position,
      imageUrl, imagePath, point, pointLimit, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AdminQuestionnaireCopyWith<_$_AdminQuestionnaire> get copyWith =>
      __$$_AdminQuestionnaireCopyWithImpl<_$_AdminQuestionnaire>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AdminQuestionnaireToJson(
      this,
    );
  }
}

abstract class _AdminQuestionnaire implements AdminQuestionnaire {
  const factory _AdminQuestionnaire(
      {required final String id,
      required final String message,
      required final DateTime dueDate,
      required final MapPosition position,
      final String? imageUrl,
      final String? imagePath,
      required final int point,
      required final int pointLimit,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_AdminQuestionnaire;

  factory _AdminQuestionnaire.fromJson(Map<String, dynamic> json) =
      _$_AdminQuestionnaire.fromJson;

  @override // アンケートID
  String get id;
  @override // アンケート本文
  String get message;
  @override // アンケート期限
  DateTime get dueDate;
  @override // アンケートの位置情報
  MapPosition get position;
  @override // アンケート画像のURL
  String? get imageUrl;
  @override // アンケート画像の保存先
  String? get imagePath;
  @override // アンケート回答獲得ポイント
  int get point;
  @override // ポイント付与制限人数
  int get pointLimit;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_AdminQuestionnaireCopyWith<_$_AdminQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

Choice _$ChoiceFromJson(Map<String, dynamic> json) {
  return _Choice.fromJson(json);
}

/// @nodoc
mixin _$Choice {
// 選択肢ID
  String get id => throw _privateConstructorUsedError; // 選択肢の文言
  String get choice => throw _privateConstructorUsedError; // 選択肢の表示順序
  int get displayOrder => throw _privateConstructorUsedError; // アンケートの回答数
  int get answer => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ChoiceCopyWith<Choice> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChoiceCopyWith<$Res> {
  factory $ChoiceCopyWith(Choice value, $Res Function(Choice) then) =
      _$ChoiceCopyWithImpl<$Res, Choice>;
  @useResult
  $Res call(
      {String id,
      String choice,
      int displayOrder,
      int answer,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$ChoiceCopyWithImpl<$Res, $Val extends Choice>
    implements $ChoiceCopyWith<$Res> {
  _$ChoiceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? choice = null,
    Object? displayOrder = null,
    Object? answer = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      choice: null == choice
          ? _value.choice
          : choice // ignore: cast_nullable_to_non_nullable
              as String,
      displayOrder: null == displayOrder
          ? _value.displayOrder
          : displayOrder // ignore: cast_nullable_to_non_nullable
              as int,
      answer: null == answer
          ? _value.answer
          : answer // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ChoiceCopyWith<$Res> implements $ChoiceCopyWith<$Res> {
  factory _$$_ChoiceCopyWith(_$_Choice value, $Res Function(_$_Choice) then) =
      __$$_ChoiceCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String choice,
      int displayOrder,
      int answer,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_ChoiceCopyWithImpl<$Res>
    extends _$ChoiceCopyWithImpl<$Res, _$_Choice>
    implements _$$_ChoiceCopyWith<$Res> {
  __$$_ChoiceCopyWithImpl(_$_Choice _value, $Res Function(_$_Choice) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? choice = null,
    Object? displayOrder = null,
    Object? answer = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Choice(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      choice: null == choice
          ? _value.choice
          : choice // ignore: cast_nullable_to_non_nullable
              as String,
      displayOrder: null == displayOrder
          ? _value.displayOrder
          : displayOrder // ignore: cast_nullable_to_non_nullable
              as int,
      answer: null == answer
          ? _value.answer
          : answer // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Choice implements _Choice {
  const _$_Choice(
      {required this.id,
      required this.choice,
      required this.displayOrder,
      required this.answer,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Choice.fromJson(Map<String, dynamic> json) =>
      _$$_ChoiceFromJson(json);

// 選択肢ID
  @override
  final String id;
// 選択肢の文言
  @override
  final String choice;
// 選択肢の表示順序
  @override
  final int displayOrder;
// アンケートの回答数
  @override
  final int answer;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Choice(id: $id, choice: $choice, displayOrder: $displayOrder, answer: $answer, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Choice &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.choice, choice) || other.choice == choice) &&
            (identical(other.displayOrder, displayOrder) ||
                other.displayOrder == displayOrder) &&
            (identical(other.answer, answer) || other.answer == answer) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, choice, displayOrder, answer, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ChoiceCopyWith<_$_Choice> get copyWith =>
      __$$_ChoiceCopyWithImpl<_$_Choice>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ChoiceToJson(
      this,
    );
  }
}

abstract class _Choice implements Choice {
  const factory _Choice(
      {required final String id,
      required final String choice,
      required final int displayOrder,
      required final int answer,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Choice;

  factory _Choice.fromJson(Map<String, dynamic> json) = _$_Choice.fromJson;

  @override // 選択肢ID
  String get id;
  @override // 選択肢の文言
  String get choice;
  @override // 選択肢の表示順序
  int get displayOrder;
  @override // アンケートの回答数
  int get answer;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_ChoiceCopyWith<_$_Choice> get copyWith =>
      throw _privateConstructorUsedError;
}

QuestionnaireTransaction _$QuestionnaireTransactionFromJson(
    Map<String, dynamic> json) {
  return _QuestionnaireTransaction.fromJson(json);
}

/// @nodoc
mixin _$QuestionnaireTransaction {
// ポイント付与制限人数残り
  int get pointLimitRemain => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $QuestionnaireTransactionCopyWith<QuestionnaireTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QuestionnaireTransactionCopyWith<$Res> {
  factory $QuestionnaireTransactionCopyWith(QuestionnaireTransaction value,
          $Res Function(QuestionnaireTransaction) then) =
      _$QuestionnaireTransactionCopyWithImpl<$Res, QuestionnaireTransaction>;
  @useResult
  $Res call(
      {int pointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$QuestionnaireTransactionCopyWithImpl<$Res,
        $Val extends QuestionnaireTransaction>
    implements $QuestionnaireTransactionCopyWith<$Res> {
  _$QuestionnaireTransactionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_QuestionnaireTransactionCopyWith<$Res>
    implements $QuestionnaireTransactionCopyWith<$Res> {
  factory _$$_QuestionnaireTransactionCopyWith(
          _$_QuestionnaireTransaction value,
          $Res Function(_$_QuestionnaireTransaction) then) =
      __$$_QuestionnaireTransactionCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int pointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_QuestionnaireTransactionCopyWithImpl<$Res>
    extends _$QuestionnaireTransactionCopyWithImpl<$Res,
        _$_QuestionnaireTransaction>
    implements _$$_QuestionnaireTransactionCopyWith<$Res> {
  __$$_QuestionnaireTransactionCopyWithImpl(_$_QuestionnaireTransaction _value,
      $Res Function(_$_QuestionnaireTransaction) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_QuestionnaireTransaction(
      pointLimitRemain: null == pointLimitRemain
          ? _value.pointLimitRemain
          : pointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_QuestionnaireTransaction implements _QuestionnaireTransaction {
  const _$_QuestionnaireTransaction(
      {required this.pointLimitRemain,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_QuestionnaireTransaction.fromJson(Map<String, dynamic> json) =>
      _$$_QuestionnaireTransactionFromJson(json);

// ポイント付与制限人数残り
  @override
  final int pointLimitRemain;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'QuestionnaireTransaction(pointLimitRemain: $pointLimitRemain, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_QuestionnaireTransaction &&
            (identical(other.pointLimitRemain, pointLimitRemain) ||
                other.pointLimitRemain == pointLimitRemain) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, pointLimitRemain, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_QuestionnaireTransactionCopyWith<_$_QuestionnaireTransaction>
      get copyWith => __$$_QuestionnaireTransactionCopyWithImpl<
          _$_QuestionnaireTransaction>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_QuestionnaireTransactionToJson(
      this,
    );
  }
}

abstract class _QuestionnaireTransaction implements QuestionnaireTransaction {
  const factory _QuestionnaireTransaction(
          {required final int pointLimitRemain,
          @TimestampConverter() final DateTime? updatedAt,
          @TimestampConverter() final DateTime? createdAt}) =
      _$_QuestionnaireTransaction;

  factory _QuestionnaireTransaction.fromJson(Map<String, dynamic> json) =
      _$_QuestionnaireTransaction.fromJson;

  @override // ポイント付与制限人数残り
  int get pointLimitRemain;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_QuestionnaireTransactionCopyWith<_$_QuestionnaireTransaction>
      get copyWith => throw _privateConstructorUsedError;
}

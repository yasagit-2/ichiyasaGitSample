// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'answered_questionnaire.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

AnsweredQuestionnaire _$AnsweredQuestionnaireFromJson(
    Map<String, dynamic> json) {
  return _AnsweredQuestionnaire.fromJson(json);
}

/// @nodoc
mixin _$AnsweredQuestionnaire {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AnsweredQuestionnaireCopyWith<AnsweredQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AnsweredQuestionnaireCopyWith<$Res> {
  factory $AnsweredQuestionnaireCopyWith(AnsweredQuestionnaire value,
          $Res Function(AnsweredQuestionnaire) then) =
      _$AnsweredQuestionnaireCopyWithImpl<$Res, AnsweredQuestionnaire>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$AnsweredQuestionnaireCopyWithImpl<$Res,
        $Val extends AnsweredQuestionnaire>
    implements $AnsweredQuestionnaireCopyWith<$Res> {
  _$AnsweredQuestionnaireCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_AnsweredQuestionnaireCopyWith<$Res>
    implements $AnsweredQuestionnaireCopyWith<$Res> {
  factory _$$_AnsweredQuestionnaireCopyWith(_$_AnsweredQuestionnaire value,
          $Res Function(_$_AnsweredQuestionnaire) then) =
      __$$_AnsweredQuestionnaireCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_AnsweredQuestionnaireCopyWithImpl<$Res>
    extends _$AnsweredQuestionnaireCopyWithImpl<$Res, _$_AnsweredQuestionnaire>
    implements _$$_AnsweredQuestionnaireCopyWith<$Res> {
  __$$_AnsweredQuestionnaireCopyWithImpl(_$_AnsweredQuestionnaire _value,
      $Res Function(_$_AnsweredQuestionnaire) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_AnsweredQuestionnaire(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_AnsweredQuestionnaire implements _AnsweredQuestionnaire {
  const _$_AnsweredQuestionnaire(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_AnsweredQuestionnaire.fromJson(Map<String, dynamic> json) =>
      _$$_AnsweredQuestionnaireFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'AnsweredQuestionnaire(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AnsweredQuestionnaire &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AnsweredQuestionnaireCopyWith<_$_AnsweredQuestionnaire> get copyWith =>
      __$$_AnsweredQuestionnaireCopyWithImpl<_$_AnsweredQuestionnaire>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AnsweredQuestionnaireToJson(
      this,
    );
  }
}

abstract class _AnsweredQuestionnaire implements AnsweredQuestionnaire {
  const factory _AnsweredQuestionnaire(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_AnsweredQuestionnaire;

  factory _AnsweredQuestionnaire.fromJson(Map<String, dynamic> json) =
      _$_AnsweredQuestionnaire.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_AnsweredQuestionnaireCopyWith<_$_AnsweredQuestionnaire> get copyWith =>
      throw _privateConstructorUsedError;
}

QuestionnaireHistory _$QuestionnaireHistoryFromJson(Map<String, dynamic> json) {
  return _QuestionnaireHistory.fromJson(json);
}

/// @nodoc
mixin _$QuestionnaireHistory {
// アンケートID
  String get id => throw _privateConstructorUsedError; // アンケートのメッセージ
  String get message => throw _privateConstructorUsedError; // 選択肢ID
  String get choiceId => throw _privateConstructorUsedError; // 選択肢の文言
  String get choiceMessage =>
      throw _privateConstructorUsedError; // アンケート回答獲得ポイント
  int get point => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $QuestionnaireHistoryCopyWith<QuestionnaireHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QuestionnaireHistoryCopyWith<$Res> {
  factory $QuestionnaireHistoryCopyWith(QuestionnaireHistory value,
          $Res Function(QuestionnaireHistory) then) =
      _$QuestionnaireHistoryCopyWithImpl<$Res, QuestionnaireHistory>;
  @useResult
  $Res call(
      {String id,
      String message,
      String choiceId,
      String choiceMessage,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$QuestionnaireHistoryCopyWithImpl<$Res,
        $Val extends QuestionnaireHistory>
    implements $QuestionnaireHistoryCopyWith<$Res> {
  _$QuestionnaireHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? choiceId = null,
    Object? choiceMessage = null,
    Object? point = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      choiceId: null == choiceId
          ? _value.choiceId
          : choiceId // ignore: cast_nullable_to_non_nullable
              as String,
      choiceMessage: null == choiceMessage
          ? _value.choiceMessage
          : choiceMessage // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_QuestionnaireHistoryCopyWith<$Res>
    implements $QuestionnaireHistoryCopyWith<$Res> {
  factory _$$_QuestionnaireHistoryCopyWith(_$_QuestionnaireHistory value,
          $Res Function(_$_QuestionnaireHistory) then) =
      __$$_QuestionnaireHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String message,
      String choiceId,
      String choiceMessage,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_QuestionnaireHistoryCopyWithImpl<$Res>
    extends _$QuestionnaireHistoryCopyWithImpl<$Res, _$_QuestionnaireHistory>
    implements _$$_QuestionnaireHistoryCopyWith<$Res> {
  __$$_QuestionnaireHistoryCopyWithImpl(_$_QuestionnaireHistory _value,
      $Res Function(_$_QuestionnaireHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? choiceId = null,
    Object? choiceMessage = null,
    Object? point = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_QuestionnaireHistory(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      choiceId: null == choiceId
          ? _value.choiceId
          : choiceId // ignore: cast_nullable_to_non_nullable
              as String,
      choiceMessage: null == choiceMessage
          ? _value.choiceMessage
          : choiceMessage // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_QuestionnaireHistory implements _QuestionnaireHistory {
  const _$_QuestionnaireHistory(
      {required this.id,
      required this.message,
      required this.choiceId,
      required this.choiceMessage,
      required this.point,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_QuestionnaireHistory.fromJson(Map<String, dynamic> json) =>
      _$$_QuestionnaireHistoryFromJson(json);

// アンケートID
  @override
  final String id;
// アンケートのメッセージ
  @override
  final String message;
// 選択肢ID
  @override
  final String choiceId;
// 選択肢の文言
  @override
  final String choiceMessage;
// アンケート回答獲得ポイント
  @override
  final int point;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'QuestionnaireHistory(id: $id, message: $message, choiceId: $choiceId, choiceMessage: $choiceMessage, point: $point, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_QuestionnaireHistory &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.choiceId, choiceId) ||
                other.choiceId == choiceId) &&
            (identical(other.choiceMessage, choiceMessage) ||
                other.choiceMessage == choiceMessage) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, message, choiceId,
      choiceMessage, point, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_QuestionnaireHistoryCopyWith<_$_QuestionnaireHistory> get copyWith =>
      __$$_QuestionnaireHistoryCopyWithImpl<_$_QuestionnaireHistory>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_QuestionnaireHistoryToJson(
      this,
    );
  }
}

abstract class _QuestionnaireHistory implements QuestionnaireHistory {
  const factory _QuestionnaireHistory(
      {required final String id,
      required final String message,
      required final String choiceId,
      required final String choiceMessage,
      required final int point,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_QuestionnaireHistory;

  factory _QuestionnaireHistory.fromJson(Map<String, dynamic> json) =
      _$_QuestionnaireHistory.fromJson;

  @override // アンケートID
  String get id;
  @override // アンケートのメッセージ
  String get message;
  @override // 選択肢ID
  String get choiceId;
  @override // 選択肢の文言
  String get choiceMessage;
  @override // アンケート回答獲得ポイント
  int get point;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_QuestionnaireHistoryCopyWith<_$_QuestionnaireHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

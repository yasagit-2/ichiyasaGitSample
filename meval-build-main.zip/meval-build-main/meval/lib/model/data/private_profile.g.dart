// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'private_profile.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class PrivateProfileCollectionReference
    implements
        PrivateProfileQuery,
        FirestoreCollectionReference<PrivateProfile,
            PrivateProfileQuerySnapshot> {
  factory PrivateProfileCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$PrivateProfileCollectionReference;

  static PrivateProfile fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return PrivateProfile.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    PrivateProfile value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<PrivateProfile> get reference;

  @override
  PrivateProfileDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<PrivateProfileDocumentReference> add(PrivateProfile value);
}

class _$PrivateProfileCollectionReference extends _$PrivateProfileQuery
    implements PrivateProfileCollectionReference {
  factory _$PrivateProfileCollectionReference([FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$PrivateProfileCollectionReference._(
      firestore.collection('privateProfiles').withConverter(
            fromFirestore: PrivateProfileCollectionReference.fromFirestore,
            toFirestore: PrivateProfileCollectionReference.toFirestore,
          ),
    );
  }

  _$PrivateProfileCollectionReference._(
    CollectionReference<PrivateProfile> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<PrivateProfile> get reference =>
      super.reference as CollectionReference<PrivateProfile>;

  @override
  PrivateProfileDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return PrivateProfileDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<PrivateProfileDocumentReference> add(PrivateProfile value) {
    return reference
        .add(value)
        .then((ref) => PrivateProfileDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$PrivateProfileCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class PrivateProfileDocumentReference
    extends FirestoreDocumentReference<PrivateProfile,
        PrivateProfileDocumentSnapshot> {
  factory PrivateProfileDocumentReference(
          DocumentReference<PrivateProfile> reference) =
      _$PrivateProfileDocumentReference;

  DocumentReference<PrivateProfile> get reference;

  /// A reference to the [PrivateProfileCollectionReference] containing this document.
  PrivateProfileCollectionReference get parent {
    return _$PrivateProfileCollectionReference(reference.firestore);
  }

  @override
  Stream<PrivateProfileDocumentSnapshot> snapshots();

  @override
  Future<PrivateProfileDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$PrivateProfileDocumentReference extends FirestoreDocumentReference<
    PrivateProfile,
    PrivateProfileDocumentSnapshot> implements PrivateProfileDocumentReference {
  _$PrivateProfileDocumentReference(this.reference);

  @override
  final DocumentReference<PrivateProfile> reference;

  /// A reference to the [PrivateProfileCollectionReference] containing this document.
  PrivateProfileCollectionReference get parent {
    return _$PrivateProfileCollectionReference(reference.firestore);
  }

  @override
  Stream<PrivateProfileDocumentSnapshot> snapshots() {
    return reference.snapshots().map(PrivateProfileDocumentSnapshot._);
  }

  @override
  Future<PrivateProfileDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(PrivateProfileDocumentSnapshot._);
  }

  @override
  Future<PrivateProfileDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction.get(reference).then(PrivateProfileDocumentSnapshot._);
  }

  Future<void> update({
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is PrivateProfileDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class PrivateProfileQuery
    implements QueryReference<PrivateProfile, PrivateProfileQuerySnapshot> {
  @override
  PrivateProfileQuery limit(int limit);

  @override
  PrivateProfileQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  PrivateProfileQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  PrivateProfileQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  PrivateProfileQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  PrivateProfileQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  PrivateProfileQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  PrivateProfileQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  });

  PrivateProfileQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  });

  PrivateProfileQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  });
}

class _$PrivateProfileQuery
    extends QueryReference<PrivateProfile, PrivateProfileQuerySnapshot>
    implements PrivateProfileQuery {
  _$PrivateProfileQuery(
    this._collection, {
    required Query<PrivateProfile> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<PrivateProfileQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(PrivateProfileQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<PrivateProfileQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(PrivateProfileQuerySnapshot._fromQuerySnapshot);
  }

  @override
  PrivateProfileQuery limit(int limit) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  PrivateProfileQuery limitToLast(int limit) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  PrivateProfileQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PrivateProfileQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PrivateProfileQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PrivateProfileQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PrivateProfileFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PrivateProfileQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PrivateProfileFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PrivateProfileQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PrivateProfileQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_PrivateProfileFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PrivateProfileQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PrivateProfileDocumentSnapshot? startAtDocument,
    PrivateProfileDocumentSnapshot? endAtDocument,
    PrivateProfileDocumentSnapshot? endBeforeDocument,
    PrivateProfileDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_PrivateProfileFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PrivateProfileQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$PrivateProfileQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class PrivateProfileDocumentSnapshot
    extends FirestoreDocumentSnapshot<PrivateProfile> {
  PrivateProfileDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<PrivateProfile> snapshot;

  @override
  PrivateProfileDocumentReference get reference {
    return PrivateProfileDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final PrivateProfile? data;
}

class PrivateProfileQuerySnapshot extends FirestoreQuerySnapshot<PrivateProfile,
    PrivateProfileQueryDocumentSnapshot> {
  PrivateProfileQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory PrivateProfileQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<PrivateProfile> snapshot,
  ) {
    final docs =
        snapshot.docs.map(PrivateProfileQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        PrivateProfileDocumentSnapshot._,
      );
    }).toList();

    return PrivateProfileQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<PrivateProfileDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    PrivateProfileDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<PrivateProfileDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<PrivateProfile> snapshot;

  @override
  final List<PrivateProfileQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<PrivateProfileDocumentSnapshot>>
      docChanges;
}

class PrivateProfileQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<PrivateProfile>
    implements PrivateProfileDocumentSnapshot {
  PrivateProfileQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<PrivateProfile> snapshot;

  @override
  final PrivateProfile data;

  @override
  PrivateProfileDocumentReference get reference {
    return PrivateProfileDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_PrivateProfile _$$_PrivateProfileFromJson(Map<String, dynamic> json) =>
    _$_PrivateProfile(
      memberRef: const DocumentReferenceConverter()
          .fromJson(json['memberRef'] as DocumentReference<Object?>),
      deviceInfo:
          DeviceInfo.fromJson(json['deviceInfo'] as Map<String, dynamic>),
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_PrivateProfileFieldMap = <String, String>{
  'memberRef': 'memberRef',
  'deviceInfo': 'deviceInfo',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_PrivateProfileToJson(_$_PrivateProfile instance) {
  final val = <String, dynamic>{
    'memberRef': const DocumentReferenceConverter().toJson(instance.memberRef),
    'deviceInfo': instance.deviceInfo.toJson(),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

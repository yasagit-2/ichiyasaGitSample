mixin AdminPostMixin {
  String get id;

  String get message;

  DateTime get dueDate;

  String? get imageUrl;

  String? get imagePath;

  DateTime? get updatedAt;

  DateTime? get createdAt;
}

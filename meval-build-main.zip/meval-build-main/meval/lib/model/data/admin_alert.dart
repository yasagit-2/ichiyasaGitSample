import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'admin_post_mixin.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'admin_alert.freezed.dart';
part 'admin_alert.g.dart';

/// 行政投稿（注意）
@freezed
class AdminAlert with MapPositionMixin, AdminPostMixin, _$AdminAlert {
  @firestoreSerializable
  const factory AdminAlert({
    // 行政投稿（注意）ID
    required String id,
    // 行政投稿（注意）本文
    required String message,
    // 行政投稿（注意）期限
    required DateTime dueDate,
    // 行政投稿（注意）の位置情報
    required MapPosition position,
    // 行政投稿（注意）画像のURL
    String? imageUrl,
    // 行政投稿（注意）の保存先
    String? imagePath,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _AdminAlert;

  factory AdminAlert.fromJson(Map<String, Object?> json) =>
      _$AdminAlertFromJson(json);
}

@Collection<AdminAlert>('adminAlerts')
final adminAlertsRef = AdminAlertCollectionReference();

AdminAlertDocumentReference adminAlertRef({required String id}) =>
    AdminAlertDocumentReference(adminAlertsRef.doc(id).reference);

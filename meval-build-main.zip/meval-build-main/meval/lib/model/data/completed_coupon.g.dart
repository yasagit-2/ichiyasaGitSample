// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'completed_coupon.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class CompletedCouponCollectionReference
    implements
        CompletedCouponQuery,
        FirestoreCollectionReference<CompletedCoupon,
            CompletedCouponQuerySnapshot> {
  factory CompletedCouponCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$CompletedCouponCollectionReference;

  static CompletedCoupon fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return CompletedCoupon.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    CompletedCoupon value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<CompletedCoupon> get reference;

  @override
  CompletedCouponDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<CompletedCouponDocumentReference> add(CompletedCoupon value);
}

class _$CompletedCouponCollectionReference extends _$CompletedCouponQuery
    implements CompletedCouponCollectionReference {
  factory _$CompletedCouponCollectionReference([FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$CompletedCouponCollectionReference._(
      firestore.collection('completedCoupons').withConverter(
            fromFirestore: CompletedCouponCollectionReference.fromFirestore,
            toFirestore: CompletedCouponCollectionReference.toFirestore,
          ),
    );
  }

  _$CompletedCouponCollectionReference._(
    CollectionReference<CompletedCoupon> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<CompletedCoupon> get reference =>
      super.reference as CollectionReference<CompletedCoupon>;

  @override
  CompletedCouponDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return CompletedCouponDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<CompletedCouponDocumentReference> add(CompletedCoupon value) {
    return reference
        .add(value)
        .then((ref) => CompletedCouponDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$CompletedCouponCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class CompletedCouponDocumentReference
    extends FirestoreDocumentReference<CompletedCoupon,
        CompletedCouponDocumentSnapshot> {
  factory CompletedCouponDocumentReference(
          DocumentReference<CompletedCoupon> reference) =
      _$CompletedCouponDocumentReference;

  DocumentReference<CompletedCoupon> get reference;

  /// A reference to the [CompletedCouponCollectionReference] containing this document.
  CompletedCouponCollectionReference get parent {
    return _$CompletedCouponCollectionReference(reference.firestore);
  }

  late final CouponHistoryCollectionReference couponHistories =
      _$CouponHistoryCollectionReference(
    reference,
  );

  @override
  Stream<CompletedCouponDocumentSnapshot> snapshots();

  @override
  Future<CompletedCouponDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$CompletedCouponDocumentReference extends FirestoreDocumentReference<
        CompletedCoupon, CompletedCouponDocumentSnapshot>
    implements CompletedCouponDocumentReference {
  _$CompletedCouponDocumentReference(this.reference);

  @override
  final DocumentReference<CompletedCoupon> reference;

  /// A reference to the [CompletedCouponCollectionReference] containing this document.
  CompletedCouponCollectionReference get parent {
    return _$CompletedCouponCollectionReference(reference.firestore);
  }

  late final CouponHistoryCollectionReference couponHistories =
      _$CouponHistoryCollectionReference(
    reference,
  );

  @override
  Stream<CompletedCouponDocumentSnapshot> snapshots() {
    return reference.snapshots().map(CompletedCouponDocumentSnapshot._);
  }

  @override
  Future<CompletedCouponDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(CompletedCouponDocumentSnapshot._);
  }

  @override
  Future<CompletedCouponDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction.get(reference).then(CompletedCouponDocumentSnapshot._);
  }

  Future<void> update({
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is CompletedCouponDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class CompletedCouponQuery
    implements QueryReference<CompletedCoupon, CompletedCouponQuerySnapshot> {
  @override
  CompletedCouponQuery limit(int limit);

  @override
  CompletedCouponQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  CompletedCouponQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  CompletedCouponQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  CompletedCouponQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  CompletedCouponQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  CompletedCouponQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  CompletedCouponQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  });

  CompletedCouponQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  });

  CompletedCouponQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  });
}

class _$CompletedCouponQuery
    extends QueryReference<CompletedCoupon, CompletedCouponQuerySnapshot>
    implements CompletedCouponQuery {
  _$CompletedCouponQuery(
    this._collection, {
    required Query<CompletedCoupon> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<CompletedCouponQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(CompletedCouponQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<CompletedCouponQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(CompletedCouponQuerySnapshot._fromQuerySnapshot);
  }

  @override
  CompletedCouponQuery limit(int limit) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  CompletedCouponQuery limitToLast(int limit) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  CompletedCouponQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CompletedCouponQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CompletedCouponQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CompletedCouponQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CompletedCouponFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CompletedCouponQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CompletedCouponFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CompletedCouponQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CompletedCouponQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CompletedCouponFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CompletedCouponQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CompletedCouponDocumentSnapshot? startAtDocument,
    CompletedCouponDocumentSnapshot? endAtDocument,
    CompletedCouponDocumentSnapshot? endBeforeDocument,
    CompletedCouponDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CompletedCouponFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CompletedCouponQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$CompletedCouponQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class CompletedCouponDocumentSnapshot
    extends FirestoreDocumentSnapshot<CompletedCoupon> {
  CompletedCouponDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<CompletedCoupon> snapshot;

  @override
  CompletedCouponDocumentReference get reference {
    return CompletedCouponDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final CompletedCoupon? data;
}

class CompletedCouponQuerySnapshot extends FirestoreQuerySnapshot<
    CompletedCoupon, CompletedCouponQueryDocumentSnapshot> {
  CompletedCouponQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory CompletedCouponQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<CompletedCoupon> snapshot,
  ) {
    final docs =
        snapshot.docs.map(CompletedCouponQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        CompletedCouponDocumentSnapshot._,
      );
    }).toList();

    return CompletedCouponQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<CompletedCouponDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    CompletedCouponDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<CompletedCouponDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<CompletedCoupon> snapshot;

  @override
  final List<CompletedCouponQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<CompletedCouponDocumentSnapshot>>
      docChanges;
}

class CompletedCouponQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<CompletedCoupon>
    implements CompletedCouponDocumentSnapshot {
  CompletedCouponQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<CompletedCoupon> snapshot;

  @override
  final CompletedCoupon data;

  @override
  CompletedCouponDocumentReference get reference {
    return CompletedCouponDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class CouponHistoryCollectionReference
    implements
        CouponHistoryQuery,
        FirestoreCollectionReference<CouponHistory,
            CouponHistoryQuerySnapshot> {
  factory CouponHistoryCollectionReference(
    DocumentReference<CompletedCoupon> parent,
  ) = _$CouponHistoryCollectionReference;

  static CouponHistory fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return CouponHistory.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    CouponHistory value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<CouponHistory> get reference;

  /// A reference to the containing [CompletedCouponDocumentReference] if this is a subcollection.
  CompletedCouponDocumentReference get parent;

  @override
  CouponHistoryDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<CouponHistoryDocumentReference> add(CouponHistory value);
}

class _$CouponHistoryCollectionReference extends _$CouponHistoryQuery
    implements CouponHistoryCollectionReference {
  factory _$CouponHistoryCollectionReference(
    DocumentReference<CompletedCoupon> parent,
  ) {
    return _$CouponHistoryCollectionReference._(
      CompletedCouponDocumentReference(parent),
      parent.collection('couponHistories').withConverter(
            fromFirestore: CouponHistoryCollectionReference.fromFirestore,
            toFirestore: CouponHistoryCollectionReference.toFirestore,
          ),
    );
  }

  _$CouponHistoryCollectionReference._(
    this.parent,
    CollectionReference<CouponHistory> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final CompletedCouponDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<CouponHistory> get reference =>
      super.reference as CollectionReference<CouponHistory>;

  @override
  CouponHistoryDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return CouponHistoryDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<CouponHistoryDocumentReference> add(CouponHistory value) {
    return reference
        .add(value)
        .then((ref) => CouponHistoryDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$CouponHistoryCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class CouponHistoryDocumentReference
    extends FirestoreDocumentReference<CouponHistory,
        CouponHistoryDocumentSnapshot> {
  factory CouponHistoryDocumentReference(
          DocumentReference<CouponHistory> reference) =
      _$CouponHistoryDocumentReference;

  DocumentReference<CouponHistory> get reference;

  /// A reference to the [CouponHistoryCollectionReference] containing this document.
  CouponHistoryCollectionReference get parent {
    return _$CouponHistoryCollectionReference(
      reference.parent.parent!.withConverter<CompletedCoupon>(
        fromFirestore: CompletedCouponCollectionReference.fromFirestore,
        toFirestore: CompletedCouponCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<CouponHistoryDocumentSnapshot> snapshots();

  @override
  Future<CouponHistoryDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String id,
    FieldValue idFieldValue,
    String merchantId,
    FieldValue merchantIdFieldValue,
    String name,
    FieldValue nameFieldValue,
    int exchangePoint,
    FieldValue exchangePointFieldValue,
    DateTime dueDate,
    FieldValue dueDateFieldValue,
    bool isPointUsed,
    FieldValue isPointUsedFieldValue,
    bool isCouponUsed,
    FieldValue isCouponUsedFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String id,
    FieldValue idFieldValue,
    String merchantId,
    FieldValue merchantIdFieldValue,
    String name,
    FieldValue nameFieldValue,
    int exchangePoint,
    FieldValue exchangePointFieldValue,
    DateTime dueDate,
    FieldValue dueDateFieldValue,
    bool isPointUsed,
    FieldValue isPointUsedFieldValue,
    bool isCouponUsed,
    FieldValue isCouponUsedFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$CouponHistoryDocumentReference extends FirestoreDocumentReference<
    CouponHistory,
    CouponHistoryDocumentSnapshot> implements CouponHistoryDocumentReference {
  _$CouponHistoryDocumentReference(this.reference);

  @override
  final DocumentReference<CouponHistory> reference;

  /// A reference to the [CouponHistoryCollectionReference] containing this document.
  CouponHistoryCollectionReference get parent {
    return _$CouponHistoryCollectionReference(
      reference.parent.parent!.withConverter<CompletedCoupon>(
        fromFirestore: CompletedCouponCollectionReference.fromFirestore,
        toFirestore: CompletedCouponCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<CouponHistoryDocumentSnapshot> snapshots() {
    return reference.snapshots().map(CouponHistoryDocumentSnapshot._);
  }

  @override
  Future<CouponHistoryDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(CouponHistoryDocumentSnapshot._);
  }

  @override
  Future<CouponHistoryDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction.get(reference).then(CouponHistoryDocumentSnapshot._);
  }

  Future<void> update({
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? merchantId = _sentinel,
    FieldValue? merchantIdFieldValue,
    Object? name = _sentinel,
    FieldValue? nameFieldValue,
    Object? exchangePoint = _sentinel,
    FieldValue? exchangePointFieldValue,
    Object? dueDate = _sentinel,
    FieldValue? dueDateFieldValue,
    Object? isPointUsed = _sentinel,
    FieldValue? isPointUsedFieldValue,
    Object? isCouponUsed = _sentinel,
    FieldValue? isCouponUsedFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      merchantId == _sentinel || merchantIdFieldValue == null,
      "Cannot specify both merchantId and merchantIdFieldValue",
    );
    assert(
      name == _sentinel || nameFieldValue == null,
      "Cannot specify both name and nameFieldValue",
    );
    assert(
      exchangePoint == _sentinel || exchangePointFieldValue == null,
      "Cannot specify both exchangePoint and exchangePointFieldValue",
    );
    assert(
      dueDate == _sentinel || dueDateFieldValue == null,
      "Cannot specify both dueDate and dueDateFieldValue",
    );
    assert(
      isPointUsed == _sentinel || isPointUsedFieldValue == null,
      "Cannot specify both isPointUsed and isPointUsedFieldValue",
    );
    assert(
      isCouponUsed == _sentinel || isCouponUsedFieldValue == null,
      "Cannot specify both isCouponUsed and isCouponUsedFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (merchantId != _sentinel) 'merchantId': merchantId as String,
      if (merchantIdFieldValue != null) 'merchantId': merchantIdFieldValue,
      if (name != _sentinel) 'name': name as String,
      if (nameFieldValue != null) 'name': nameFieldValue,
      if (exchangePoint != _sentinel) 'exchangePoint': exchangePoint as int,
      if (exchangePointFieldValue != null)
        'exchangePoint': exchangePointFieldValue,
      if (dueDate != _sentinel) 'dueDate': dueDate as DateTime,
      if (dueDateFieldValue != null) 'dueDate': dueDateFieldValue,
      if (isPointUsed != _sentinel) 'isPointUsed': isPointUsed as bool,
      if (isPointUsedFieldValue != null) 'isPointUsed': isPointUsedFieldValue,
      if (isCouponUsed != _sentinel) 'isCouponUsed': isCouponUsed as bool,
      if (isCouponUsedFieldValue != null)
        'isCouponUsed': isCouponUsedFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? merchantId = _sentinel,
    FieldValue? merchantIdFieldValue,
    Object? name = _sentinel,
    FieldValue? nameFieldValue,
    Object? exchangePoint = _sentinel,
    FieldValue? exchangePointFieldValue,
    Object? dueDate = _sentinel,
    FieldValue? dueDateFieldValue,
    Object? isPointUsed = _sentinel,
    FieldValue? isPointUsedFieldValue,
    Object? isCouponUsed = _sentinel,
    FieldValue? isCouponUsedFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      merchantId == _sentinel || merchantIdFieldValue == null,
      "Cannot specify both merchantId and merchantIdFieldValue",
    );
    assert(
      name == _sentinel || nameFieldValue == null,
      "Cannot specify both name and nameFieldValue",
    );
    assert(
      exchangePoint == _sentinel || exchangePointFieldValue == null,
      "Cannot specify both exchangePoint and exchangePointFieldValue",
    );
    assert(
      dueDate == _sentinel || dueDateFieldValue == null,
      "Cannot specify both dueDate and dueDateFieldValue",
    );
    assert(
      isPointUsed == _sentinel || isPointUsedFieldValue == null,
      "Cannot specify both isPointUsed and isPointUsedFieldValue",
    );
    assert(
      isCouponUsed == _sentinel || isCouponUsedFieldValue == null,
      "Cannot specify both isCouponUsed and isCouponUsedFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (merchantId != _sentinel) 'merchantId': merchantId as String,
      if (merchantIdFieldValue != null) 'merchantId': merchantIdFieldValue,
      if (name != _sentinel) 'name': name as String,
      if (nameFieldValue != null) 'name': nameFieldValue,
      if (exchangePoint != _sentinel) 'exchangePoint': exchangePoint as int,
      if (exchangePointFieldValue != null)
        'exchangePoint': exchangePointFieldValue,
      if (dueDate != _sentinel) 'dueDate': dueDate as DateTime,
      if (dueDateFieldValue != null) 'dueDate': dueDateFieldValue,
      if (isPointUsed != _sentinel) 'isPointUsed': isPointUsed as bool,
      if (isPointUsedFieldValue != null) 'isPointUsed': isPointUsedFieldValue,
      if (isCouponUsed != _sentinel) 'isCouponUsed': isCouponUsed as bool,
      if (isCouponUsedFieldValue != null)
        'isCouponUsed': isCouponUsedFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is CouponHistoryDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class CouponHistoryQuery
    implements QueryReference<CouponHistory, CouponHistoryQuerySnapshot> {
  @override
  CouponHistoryQuery limit(int limit);

  @override
  CouponHistoryQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  CouponHistoryQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  CouponHistoryQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  CouponHistoryQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  CouponHistoryQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  CouponHistoryQuery whereMerchantId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  CouponHistoryQuery whereName({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  CouponHistoryQuery whereExchangePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  CouponHistoryQuery whereDueDate({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime>? whereIn,
    List<DateTime>? whereNotIn,
  });
  CouponHistoryQuery whereIsPointUsed({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  });
  CouponHistoryQuery whereIsCouponUsed({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  });
  CouponHistoryQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  CouponHistoryQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  CouponHistoryQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderById({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByMerchantId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByName({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByExchangePoint({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByDueDate({
    bool descending = false,
    DateTime startAt,
    DateTime startAfter,
    DateTime endAt,
    DateTime endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByIsPointUsed({
    bool descending = false,
    bool startAt,
    bool startAfter,
    bool endAt,
    bool endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByIsCouponUsed({
    bool descending = false,
    bool startAt,
    bool startAfter,
    bool endAt,
    bool endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });

  CouponHistoryQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  });
}

class _$CouponHistoryQuery
    extends QueryReference<CouponHistory, CouponHistoryQuerySnapshot>
    implements CouponHistoryQuery {
  _$CouponHistoryQuery(
    this._collection, {
    required Query<CouponHistory> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<CouponHistoryQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(CouponHistoryQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<CouponHistoryQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(CouponHistoryQuerySnapshot._fromQuerySnapshot);
  }

  @override
  CouponHistoryQuery limit(int limit) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  CouponHistoryQuery limitToLast(int limit) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['id']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereMerchantId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['merchantId']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereName({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['name']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereExchangePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['exchangePoint']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereDueDate({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime>? whereIn,
    List<DateTime>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['dueDate']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereIsPointUsed({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['isPointUsed']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereIsCouponUsed({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['isCouponUsed']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_CouponHistoryFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  CouponHistoryQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderById({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_CouponHistoryFieldMap['id']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByMerchantId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['merchantId']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByName({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_CouponHistoryFieldMap['name']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByExchangePoint({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['exchangePoint']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByDueDate({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_CouponHistoryFieldMap['dueDate']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByIsPointUsed({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['isPointUsed']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByIsCouponUsed({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['isCouponUsed']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  CouponHistoryQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    CouponHistoryDocumentSnapshot? startAtDocument,
    CouponHistoryDocumentSnapshot? endAtDocument,
    CouponHistoryDocumentSnapshot? endBeforeDocument,
    CouponHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_CouponHistoryFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$CouponHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$CouponHistoryQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class CouponHistoryDocumentSnapshot
    extends FirestoreDocumentSnapshot<CouponHistory> {
  CouponHistoryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<CouponHistory> snapshot;

  @override
  CouponHistoryDocumentReference get reference {
    return CouponHistoryDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final CouponHistory? data;
}

class CouponHistoryQuerySnapshot extends FirestoreQuerySnapshot<CouponHistory,
    CouponHistoryQueryDocumentSnapshot> {
  CouponHistoryQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory CouponHistoryQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<CouponHistory> snapshot,
  ) {
    final docs =
        snapshot.docs.map(CouponHistoryQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        CouponHistoryDocumentSnapshot._,
      );
    }).toList();

    return CouponHistoryQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<CouponHistoryDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    CouponHistoryDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<CouponHistoryDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<CouponHistory> snapshot;

  @override
  final List<CouponHistoryQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<CouponHistoryDocumentSnapshot>> docChanges;
}

class CouponHistoryQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<CouponHistory>
    implements CouponHistoryDocumentSnapshot {
  CouponHistoryQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<CouponHistory> snapshot;

  @override
  final CouponHistory data;

  @override
  CouponHistoryDocumentReference get reference {
    return CouponHistoryDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CompletedCoupon _$$_CompletedCouponFromJson(Map<String, dynamic> json) =>
    _$_CompletedCoupon(
      memberRef: const DocumentReferenceConverter()
          .fromJson(json['memberRef'] as DocumentReference<Object?>),
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_CompletedCouponFieldMap = <String, String>{
  'memberRef': 'memberRef',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_CompletedCouponToJson(_$_CompletedCoupon instance) {
  final val = <String, dynamic>{
    'memberRef': const DocumentReferenceConverter().toJson(instance.memberRef),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_CouponHistory _$$_CouponHistoryFromJson(Map<String, dynamic> json) =>
    _$_CouponHistory(
      id: json['id'] as String,
      merchantId: json['merchantId'] as String,
      name: json['name'] as String,
      exchangePoint: json['exchangePoint'] as int,
      dueDate: const FirestoreDateTimeConverter()
          .fromJson(json['dueDate'] as Timestamp),
      isPointUsed: json['isPointUsed'] as bool,
      isCouponUsed: json['isCouponUsed'] as bool,
      memberRef: const DocumentReferenceConverter()
          .fromJson(json['memberRef'] as DocumentReference<Object?>),
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_CouponHistoryFieldMap = <String, String>{
  'id': 'id',
  'merchantId': 'merchantId',
  'name': 'name',
  'exchangePoint': 'exchangePoint',
  'dueDate': 'dueDate',
  'isPointUsed': 'isPointUsed',
  'isCouponUsed': 'isCouponUsed',
  'memberRef': 'memberRef',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_CouponHistoryToJson(_$_CouponHistory instance) {
  final val = <String, dynamic>{
    'id': instance.id,
    'merchantId': instance.merchantId,
    'name': instance.name,
    'exchangePoint': instance.exchangePoint,
    'dueDate': const FirestoreDateTimeConverter().toJson(instance.dueDate),
    'isPointUsed': instance.isPointUsed,
    'isCouponUsed': instance.isCouponUsed,
    'memberRef': const DocumentReferenceConverter().toJson(instance.memberRef),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

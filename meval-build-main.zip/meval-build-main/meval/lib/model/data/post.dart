import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'post.freezed.dart';
part 'post.g.dart';

@freezed
class Post with MapPositionMixin, _$Post {
  @firestoreSerializable
  const factory Post({
    // 投稿ID
    required String id,
    // メッセージ
    required String message,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 投稿地点の位置情報
    required MapPosition position,
    // 投稿画像
    String? imageUrl,
    // 投稿画像の保存先
    String? imagePath,
    // いいいね数
    @Default(0) int likeCount,
    // 投稿の表示/非表示（0：表示、1：非表示）
    @Default(0) int visibleStatus,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Post;

  factory Post.fromJson(Map<String, Object?> json) => _$PostFromJson(json);
}

@Collection<Post>('posts')
final postsRef = PostCollectionReference();

PostDocumentReference postRef({required String id}) =>
    PostDocumentReference(postsRef.doc(id).reference);

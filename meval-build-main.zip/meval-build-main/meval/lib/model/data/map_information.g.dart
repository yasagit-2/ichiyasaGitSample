// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'map_information.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MapInformation _$$_MapInformationFromJson(Map<String, dynamic> json) =>
    _$_MapInformation(
      bases: json['bases'] ?? const <DocumentSnapshot>[],
      posts: json['posts'] ?? const <DocumentSnapshot>[],
      adminAlert: json['adminAlert'] ?? const <DocumentSnapshot>[],
      adminQuestionnaire:
          json['adminQuestionnaire'] ?? const <DocumentSnapshot>[],
      merchants: json['merchants'] ?? const <DocumentSnapshot>[],
      baseMarkers: json['baseMarkers'] ?? const <Marker>{},
      postMarkers: json['postMarkers'] ?? const <Marker>{},
      adminAlertMarkers: json['adminAlertMarkers'] ?? const <Marker>{},
      adminQuestionnaireMarkers:
          json['adminQuestionnaireMarkers'] ?? const <Marker>{},
      merchantMarkers: json['merchantMarkers'] ?? const <Marker>{},
      baseCircles: json['baseCircles'] ?? const <Circle>{},
      postingPreparationMarker:
          json['postingPreparationMarker'] ?? const <Marker>{},
    );

const _$$_MapInformationFieldMap = <String, String>{
  'bases': 'bases',
  'posts': 'posts',
  'adminAlert': 'adminAlert',
  'adminQuestionnaire': 'adminQuestionnaire',
  'merchants': 'merchants',
  'baseMarkers': 'baseMarkers',
  'postMarkers': 'postMarkers',
  'adminAlertMarkers': 'adminAlertMarkers',
  'adminQuestionnaireMarkers': 'adminQuestionnaireMarkers',
  'merchantMarkers': 'merchantMarkers',
  'baseCircles': 'baseCircles',
  'postingPreparationMarker': 'postingPreparationMarker',
};

Map<String, dynamic> _$$_MapInformationToJson(_$_MapInformation instance) =>
    <String, dynamic>{
      'bases': instance.bases,
      'posts': instance.posts,
      'adminAlert': instance.adminAlert,
      'adminQuestionnaire': instance.adminQuestionnaire,
      'merchants': instance.merchants,
      'baseMarkers': instance.baseMarkers,
      'postMarkers': instance.postMarkers,
      'adminAlertMarkers': instance.adminAlertMarkers,
      'adminQuestionnaireMarkers': instance.adminQuestionnaireMarkers,
      'merchantMarkers': instance.merchantMarkers,
      'baseCircles': instance.baseCircles,
      'postingPreparationMarker': instance.postingPreparationMarker,
    };

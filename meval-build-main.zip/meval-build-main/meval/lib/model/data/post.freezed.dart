// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'post.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Post _$PostFromJson(Map<String, dynamic> json) {
  return _Post.fromJson(json);
}

/// @nodoc
mixin _$Post {
// 投稿ID
  String get id => throw _privateConstructorUsedError; // メッセージ
  String get message => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 投稿地点の位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 投稿画像
  String? get imageUrl => throw _privateConstructorUsedError; // 投稿画像の保存先
  String? get imagePath => throw _privateConstructorUsedError; // いいいね数
  int get likeCount =>
      throw _privateConstructorUsedError; // 投稿の表示/非表示（0：表示、1：非表示）
  int get visibleStatus => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PostCopyWith<Post> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostCopyWith<$Res> {
  factory $PostCopyWith(Post value, $Res Function(Post) then) =
      _$PostCopyWithImpl<$Res, Post>;
  @useResult
  $Res call(
      {String id,
      String message,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int likeCount,
      int visibleStatus,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$PostCopyWithImpl<$Res, $Val extends Post>
    implements $PostCopyWith<$Res> {
  _$PostCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? memberRef = null,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? likeCount = null,
    Object? visibleStatus = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      visibleStatus: null == visibleStatus
          ? _value.visibleStatus
          : visibleStatus // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_PostCopyWith<$Res> implements $PostCopyWith<$Res> {
  factory _$$_PostCopyWith(_$_Post value, $Res Function(_$_Post) then) =
      __$$_PostCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String message,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      String? imageUrl,
      String? imagePath,
      int likeCount,
      int visibleStatus,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_PostCopyWithImpl<$Res> extends _$PostCopyWithImpl<$Res, _$_Post>
    implements _$$_PostCopyWith<$Res> {
  __$$_PostCopyWithImpl(_$_Post _value, $Res Function(_$_Post) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? message = null,
    Object? memberRef = null,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? likeCount = null,
    Object? visibleStatus = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Post(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      visibleStatus: null == visibleStatus
          ? _value.visibleStatus
          : visibleStatus // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Post implements _Post {
  const _$_Post(
      {required this.id,
      required this.message,
      @DocumentReferenceConverter() required this.memberRef,
      required this.position,
      this.imageUrl,
      this.imagePath,
      this.likeCount = 0,
      this.visibleStatus = 0,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Post.fromJson(Map<String, dynamic> json) => _$$_PostFromJson(json);

// 投稿ID
  @override
  final String id;
// メッセージ
  @override
  final String message;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 投稿地点の位置情報
  @override
  final MapPosition position;
// 投稿画像
  @override
  final String? imageUrl;
// 投稿画像の保存先
  @override
  final String? imagePath;
// いいいね数
  @override
  @JsonKey()
  final int likeCount;
// 投稿の表示/非表示（0：表示、1：非表示）
  @override
  @JsonKey()
  final int visibleStatus;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Post(id: $id, message: $message, memberRef: $memberRef, position: $position, imageUrl: $imageUrl, imagePath: $imagePath, likeCount: $likeCount, visibleStatus: $visibleStatus, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Post &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount) &&
            (identical(other.visibleStatus, visibleStatus) ||
                other.visibleStatus == visibleStatus) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, message, memberRef, position,
      imageUrl, imagePath, likeCount, visibleStatus, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostCopyWith<_$_Post> get copyWith =>
      __$$_PostCopyWithImpl<_$_Post>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PostToJson(
      this,
    );
  }
}

abstract class _Post implements Post {
  const factory _Post(
      {required final String id,
      required final String message,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      required final MapPosition position,
      final String? imageUrl,
      final String? imagePath,
      final int likeCount,
      final int visibleStatus,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_Post;

  factory _Post.fromJson(Map<String, dynamic> json) = _$_Post.fromJson;

  @override // 投稿ID
  String get id;
  @override // メッセージ
  String get message;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 投稿地点の位置情報
  MapPosition get position;
  @override // 投稿画像
  String? get imageUrl;
  @override // 投稿画像の保存先
  String? get imagePath;
  @override // いいいね数
  int get likeCount;
  @override // 投稿の表示/非表示（0：表示、1：非表示）
  int get visibleStatus;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostCopyWith<_$_Post> get copyWith => throw _privateConstructorUsedError;
}

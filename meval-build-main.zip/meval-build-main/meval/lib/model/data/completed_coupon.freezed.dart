// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'completed_coupon.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CompletedCoupon _$CompletedCouponFromJson(Map<String, dynamic> json) {
  return _CompletedCoupon.fromJson(json);
}

/// @nodoc
mixin _$CompletedCoupon {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedCouponCopyWith<CompletedCoupon> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedCouponCopyWith<$Res> {
  factory $CompletedCouponCopyWith(
          CompletedCoupon value, $Res Function(CompletedCoupon) then) =
      _$CompletedCouponCopyWithImpl<$Res, CompletedCoupon>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CompletedCouponCopyWithImpl<$Res, $Val extends CompletedCoupon>
    implements $CompletedCouponCopyWith<$Res> {
  _$CompletedCouponCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CompletedCouponCopyWith<$Res>
    implements $CompletedCouponCopyWith<$Res> {
  factory _$$_CompletedCouponCopyWith(
          _$_CompletedCoupon value, $Res Function(_$_CompletedCoupon) then) =
      __$$_CompletedCouponCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CompletedCouponCopyWithImpl<$Res>
    extends _$CompletedCouponCopyWithImpl<$Res, _$_CompletedCoupon>
    implements _$$_CompletedCouponCopyWith<$Res> {
  __$$_CompletedCouponCopyWithImpl(
      _$_CompletedCoupon _value, $Res Function(_$_CompletedCoupon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedCoupon(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedCoupon implements _CompletedCoupon {
  const _$_CompletedCoupon(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedCoupon.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedCouponFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedCoupon(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedCoupon &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedCouponCopyWith<_$_CompletedCoupon> get copyWith =>
      __$$_CompletedCouponCopyWithImpl<_$_CompletedCoupon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedCouponToJson(
      this,
    );
  }
}

abstract class _CompletedCoupon implements CompletedCoupon {
  const factory _CompletedCoupon(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedCoupon;

  factory _CompletedCoupon.fromJson(Map<String, dynamic> json) =
      _$_CompletedCoupon.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedCouponCopyWith<_$_CompletedCoupon> get copyWith =>
      throw _privateConstructorUsedError;
}

CouponHistory _$CouponHistoryFromJson(Map<String, dynamic> json) {
  return _CouponHistory.fromJson(json);
}

/// @nodoc
mixin _$CouponHistory {
// クーポンID
  String get id => throw _privateConstructorUsedError; // 加盟店ID
  String get merchantId => throw _privateConstructorUsedError; // クーポン名称
  String get name => throw _privateConstructorUsedError; // 交換ポイント
  int get exchangePoint => throw _privateConstructorUsedError; // クーポン有効期限
  DateTime get dueDate => throw _privateConstructorUsedError; // ポイント交換済み
  bool get isPointUsed => throw _privateConstructorUsedError; // クーポン使用済み
  bool get isCouponUsed => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CouponHistoryCopyWith<CouponHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CouponHistoryCopyWith<$Res> {
  factory $CouponHistoryCopyWith(
          CouponHistory value, $Res Function(CouponHistory) then) =
      _$CouponHistoryCopyWithImpl<$Res, CouponHistory>;
  @useResult
  $Res call(
      {String id,
      String merchantId,
      String name,
      int exchangePoint,
      DateTime dueDate,
      bool isPointUsed,
      bool isCouponUsed,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CouponHistoryCopyWithImpl<$Res, $Val extends CouponHistory>
    implements $CouponHistoryCopyWith<$Res> {
  _$CouponHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? merchantId = null,
    Object? name = null,
    Object? exchangePoint = null,
    Object? dueDate = null,
    Object? isPointUsed = null,
    Object? isCouponUsed = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      exchangePoint: null == exchangePoint
          ? _value.exchangePoint
          : exchangePoint // ignore: cast_nullable_to_non_nullable
              as int,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isPointUsed: null == isPointUsed
          ? _value.isPointUsed
          : isPointUsed // ignore: cast_nullable_to_non_nullable
              as bool,
      isCouponUsed: null == isCouponUsed
          ? _value.isCouponUsed
          : isCouponUsed // ignore: cast_nullable_to_non_nullable
              as bool,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CouponHistoryCopyWith<$Res>
    implements $CouponHistoryCopyWith<$Res> {
  factory _$$_CouponHistoryCopyWith(
          _$_CouponHistory value, $Res Function(_$_CouponHistory) then) =
      __$$_CouponHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String merchantId,
      String name,
      int exchangePoint,
      DateTime dueDate,
      bool isPointUsed,
      bool isCouponUsed,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CouponHistoryCopyWithImpl<$Res>
    extends _$CouponHistoryCopyWithImpl<$Res, _$_CouponHistory>
    implements _$$_CouponHistoryCopyWith<$Res> {
  __$$_CouponHistoryCopyWithImpl(
      _$_CouponHistory _value, $Res Function(_$_CouponHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? merchantId = null,
    Object? name = null,
    Object? exchangePoint = null,
    Object? dueDate = null,
    Object? isPointUsed = null,
    Object? isCouponUsed = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CouponHistory(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      exchangePoint: null == exchangePoint
          ? _value.exchangePoint
          : exchangePoint // ignore: cast_nullable_to_non_nullable
              as int,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isPointUsed: null == isPointUsed
          ? _value.isPointUsed
          : isPointUsed // ignore: cast_nullable_to_non_nullable
              as bool,
      isCouponUsed: null == isCouponUsed
          ? _value.isCouponUsed
          : isCouponUsed // ignore: cast_nullable_to_non_nullable
              as bool,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CouponHistory implements _CouponHistory {
  const _$_CouponHistory(
      {required this.id,
      required this.merchantId,
      required this.name,
      required this.exchangePoint,
      required this.dueDate,
      required this.isPointUsed,
      required this.isCouponUsed,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CouponHistory.fromJson(Map<String, dynamic> json) =>
      _$$_CouponHistoryFromJson(json);

// クーポンID
  @override
  final String id;
// 加盟店ID
  @override
  final String merchantId;
// クーポン名称
  @override
  final String name;
// 交換ポイント
  @override
  final int exchangePoint;
// クーポン有効期限
  @override
  final DateTime dueDate;
// ポイント交換済み
  @override
  final bool isPointUsed;
// クーポン使用済み
  @override
  final bool isCouponUsed;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CouponHistory(id: $id, merchantId: $merchantId, name: $name, exchangePoint: $exchangePoint, dueDate: $dueDate, isPointUsed: $isPointUsed, isCouponUsed: $isCouponUsed, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CouponHistory &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.merchantId, merchantId) ||
                other.merchantId == merchantId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.exchangePoint, exchangePoint) ||
                other.exchangePoint == exchangePoint) &&
            (identical(other.dueDate, dueDate) || other.dueDate == dueDate) &&
            (identical(other.isPointUsed, isPointUsed) ||
                other.isPointUsed == isPointUsed) &&
            (identical(other.isCouponUsed, isCouponUsed) ||
                other.isCouponUsed == isCouponUsed) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      merchantId,
      name,
      exchangePoint,
      dueDate,
      isPointUsed,
      isCouponUsed,
      memberRef,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CouponHistoryCopyWith<_$_CouponHistory> get copyWith =>
      __$$_CouponHistoryCopyWithImpl<_$_CouponHistory>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CouponHistoryToJson(
      this,
    );
  }
}

abstract class _CouponHistory implements CouponHistory {
  const factory _CouponHistory(
      {required final String id,
      required final String merchantId,
      required final String name,
      required final int exchangePoint,
      required final DateTime dueDate,
      required final bool isPointUsed,
      required final bool isCouponUsed,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CouponHistory;

  factory _CouponHistory.fromJson(Map<String, dynamic> json) =
      _$_CouponHistory.fromJson;

  @override // クーポンID
  String get id;
  @override // 加盟店ID
  String get merchantId;
  @override // クーポン名称
  String get name;
  @override // 交換ポイント
  int get exchangePoint;
  @override // クーポン有効期限
  DateTime get dueDate;
  @override // ポイント交換済み
  bool get isPointUsed;
  @override // クーポン使用済み
  bool get isCouponUsed;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CouponHistoryCopyWith<_$_CouponHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

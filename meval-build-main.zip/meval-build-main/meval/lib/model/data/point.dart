import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'point.freezed.dart';
part 'point.g.dart';

/// ポイント
@freezed
class Point with _$Point {
  @firestoreSerializable
  const factory Point({
    // ポイント
    required int point,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Point;

  factory Point.fromJson(Map<String, Object?> json) => _$PointFromJson(json);
}

@Collection<Point>('points')
@Collection<PointHistory>('points/*/pointHistories', name: 'pointHistories')
final pointsRef = PointCollectionReference();

PointDocumentReference pointRef({required String id}) =>
    PointDocumentReference(pointsRef.doc(id).reference);

/// ポイント履歴
@freezed
class PointHistory with _$PointHistory {
  @firestoreSerializable
  const factory PointHistory({
    // 獲得ポイント
    required int point,
    // 獲得前のポイント
    required int pointBeforeEarning,
    // 拠点制覇情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? completedParentBaseRef,
    // 称号獲得情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? completedTitleRef,
    // アンケート回答情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? answeredQuestionnaireRef,
    // ウォーク達成情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? completedWalkRef,
    // イベント達成情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? completedEventRef,
    // クーポン獲得情報のリファレンス
    @DocumentReferenceConverter() DocumentReference? completedCouponRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _PointHistory;

  factory PointHistory.fromJson(Map<String, Object?> json) =>
      _$PointHistoryFromJson(json);
}

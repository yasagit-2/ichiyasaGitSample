import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'event_participation_history.freezed.dart';
part 'event_participation_history.g.dart';

/// イベント参加履歴
@freezed
class EventParticipationHistory with _$EventParticipationHistory {
  @firestoreSerializable
  const factory EventParticipationHistory({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _EventParticipationHistory;

  factory EventParticipationHistory.fromJson(Map<String, Object?> json) =>
      _$EventParticipationHistoryFromJson(json);
}

@Collection<EventParticipationHistory>('eventParticipationHistories')
@Collection<ParticipatedEvent>(
    'eventParticipationHistories/*/participatedEvents',
    name: 'participatedEvents')
@Collection<CompletedSpot>(
    'eventParticipationHistories/*/participatedEvents/*/completedSpots',
    name: 'completedSpots')
final eventParticipationHistoriesRef =
    EventParticipationHistoryCollectionReference();

EventParticipationHistoryDocumentReference eventParticipationHistoryRef(
        {required String id}) =>
    EventParticipationHistoryDocumentReference(
        eventParticipationHistoriesRef.doc(id).reference);

/// 参加イベント
@freezed
class ParticipatedEvent with _$ParticipatedEvent {
  @firestoreSerializable
  const factory ParticipatedEvent({
    // イベントID
    required String id,
    // イベントタイトル
    required String title,
    // イベント達成獲得ポイント
    required int point,
    // 交換対象種別
    required int exchangeType,
    // イベント達成地点数
    required int completeSpotCount,
    // イベント達成フラグ
    @Default(false) bool isComplete,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _ParticipatedEvent;

  factory ParticipatedEvent.fromJson(Map<String, Object?> json) =>
      _$ParticipatedEventFromJson(json);
}

/// 達成地点
@freezed
class CompletedSpot with _$CompletedSpot {
  @firestoreSerializable
  const factory CompletedSpot({
    // QRコード識別子
    required String id,
    // イベントスポットID
    required String eventSpotId,
    // イベントスポット名称
    required String eventSpotName,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // イベントスポットの位置情報
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedSpot;

  factory CompletedSpot.fromJson(Map<String, Object?> json) =>
      _$CompletedSpotFromJson(json);
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'merchant.freezed.dart';
part 'merchant.g.dart';

const couponTransactionDocumentId = 'couponTransaction';

@freezed
class Merchant with MapPositionMixin, _$Merchant {
  @firestoreSerializable
  const factory Merchant({
    // 加盟店ID
    required String id,
    // 加盟店名
    required String name,
    // 加盟店のURL
    String? merchantsUrl,
    // 加盟店の内容
    String? content,
    // 加盟店の位置情報
    required MapPosition position,
    // 加盟店画像のURL
    String? imageUrl,
    // 加盟店画像の保存先
    @override String? imagePath,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Merchant;

  factory Merchant.fromJson(Map<String, Object?> json) =>
      _$MerchantFromJson(json);
}

@Collection<Merchant>('merchants')
@Collection<Coupon>('merchants/*/coupons', name: 'coupons')
@Collection<CouponTransaction>('merchants/*/coupons/*/couponTransactions',
    name: 'couponTransactions')
final merchantsRef = MerchantCollectionReference();

MerchantDocumentReference merchantRef({required String id}) =>
    MerchantDocumentReference(merchantsRef.doc(id).reference);

@freezed
class Coupon with _$Coupon {
  @firestoreSerializable
  const factory Coupon({
    // クーポンID
    required String id,
    // 加盟店ID
    required String merchantId,
    // クーポン名称
    required String name,
    // 交換ポイント
    required int exchangePoint,
    // クーポン獲得制限人数
    required int exchangeLimit,
    // クーポン有効期限
    required DateTime dueDate,
    // 掲載期間開始
    required DateTime publicationPeriodBegin,
    // 掲載期間終了
    required DateTime publicationPeriodEnd,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Coupon;

  factory Coupon.fromJson(Map<String, Object?> json) => _$CouponFromJson(json);
}

@freezed
class CouponTransaction with _$CouponTransaction {
  @firestoreSerializable
  const factory CouponTransaction({
    // クーポン獲得制限人数残り
    required int exchangeLimitRemain,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CouponTransaction;

  factory CouponTransaction.fromJson(Map<String, Object?> json) =>
      _$CouponTransactionFromJson(json);
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'completed_walk.freezed.dart';
part 'completed_walk.g.dart';

/// ウォーク達成情報
@freezed
class CompletedWalk with _$CompletedWalk {
  @firestoreSerializable
  const factory CompletedWalk({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedWalk;

  factory CompletedWalk.fromJson(Map<String, Object?> json) =>
      _$CompletedWalkFromJson(json);
}

@Collection<CompletedWalk>('completedWalks')
@Collection<WalkHistory>('completedWalks/*/walkHistories',
    name: 'walkHistories')
final completedWalksRef = CompletedWalkCollectionReference();

CompletedWalkDocumentReference completedWalkRef({required String id}) =>
    CompletedWalkDocumentReference(completedWalksRef.doc(id).reference);

/// ウォーク達成履歴
@freezed
class WalkHistory with _$WalkHistory {
  @firestoreSerializable
  const factory WalkHistory({
    // 週番号（YYYYWww）
    required String id,
    // 獲得ポイント
    required int point,
    // 歩数（履歴作成時点の歩数）
    required int step,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _WalkHistory;

  factory WalkHistory.fromJson(Map<String, Object?> json) =>
      _$WalkHistoryFromJson(json);
}

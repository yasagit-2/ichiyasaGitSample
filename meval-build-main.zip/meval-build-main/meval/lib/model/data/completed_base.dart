import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';

part 'completed_base.freezed.dart';
part 'completed_base.g.dart';

/// 拠点制覇情報
@freezed
class CompletedBase with _$CompletedBase {
  @firestoreSerializable
  const factory CompletedBase({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedBase;

  factory CompletedBase.fromJson(Map<String, Object?> json) =>
      _$CompletedBaseFromJson(json);
}

@Collection<CompletedBase>('completedBases')
@Collection<CompletedParentBase>('completedBases/*/completedParentBases',
    name: 'completedParentBases')
@Collection<CompletedSubBase>(
    'completedBases/*/completedParentBases/*/completedSubBases',
    name: 'completedSubBases')
final completedBasesRef = CompletedBaseCollectionReference();

CompletedBaseDocumentReference completedBaseRef({required String id}) =>
    CompletedBaseDocumentReference(completedBasesRef.doc(id).reference);

/// 拠点制覇情報（親拠点）
@freezed
class CompletedParentBase with _$CompletedParentBase {
  @firestoreSerializable
  const factory CompletedParentBase({
    // 親拠点ID
    required String id,
    // 親拠点名称
    required String name,
    // 配下のサブ拠点数
    required int subBaseCount,
    // 称号ID
    required String titleId,
    // 称号名称
    required String titleName,
    // 獲得ポイント
    required int point,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 親拠点の位置情報
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedParentBase;

  factory CompletedParentBase.fromJson(Map<String, Object?> json) =>
      _$CompletedParentBaseFromJson(json);
}

/// 拠点制覇情報（サブ拠点）
@freezed
class CompletedSubBase with _$CompletedSubBase {
  @firestoreSerializable
  const factory CompletedSubBase({
    // サブ拠点ID
    required String id,
    // サブ拠点名称
    required String name,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // サブ拠点の位置情報
    required MapPosition position,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedSubBase;

  factory CompletedSubBase.fromJson(Map<String, Object?> json) =>
      _$CompletedSubBaseFromJson(json);
}

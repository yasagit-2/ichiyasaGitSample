// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'map_icon.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MapIcon _$MapIconFromJson(Map<String, dynamic> json) {
  return _MapIcon.fromJson(json);
}

/// @nodoc
mixin _$MapIcon {
// 拠点アイコン
  BitmapDescriptor get baseIcon =>
      throw _privateConstructorUsedError; // チェックイン済みアイコン
  BitmapDescriptor get baseCheckedInIcon =>
      throw _privateConstructorUsedError; // サブ拠点アイコン
  BitmapDescriptor get subBaseIcon =>
      throw _privateConstructorUsedError; // 加盟店アイコン
  BitmapDescriptor get merchantIcon =>
      throw _privateConstructorUsedError; // 加盟店つぶやきアイコン
  BitmapDescriptor get merchantTweetIcon =>
      throw _privateConstructorUsedError; // 投稿アイコン
  BitmapDescriptor get postIcon =>
      throw _privateConstructorUsedError; // 行政投稿アラートアイコン
  BitmapDescriptor get adminAlertIcon =>
      throw _privateConstructorUsedError; // 行政投稿アンケートアイコン
  BitmapDescriptor get adminQuestionnaireIcon =>
      throw _privateConstructorUsedError; // いいね数単位の投稿アイコン
  List<MapPostIcon>? get mapPostIcons => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MapIconCopyWith<MapIcon> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MapIconCopyWith<$Res> {
  factory $MapIconCopyWith(MapIcon value, $Res Function(MapIcon) then) =
      _$MapIconCopyWithImpl<$Res, MapIcon>;
  @useResult
  $Res call(
      {BitmapDescriptor baseIcon,
      BitmapDescriptor baseCheckedInIcon,
      BitmapDescriptor subBaseIcon,
      BitmapDescriptor merchantIcon,
      BitmapDescriptor merchantTweetIcon,
      BitmapDescriptor postIcon,
      BitmapDescriptor adminAlertIcon,
      BitmapDescriptor adminQuestionnaireIcon,
      List<MapPostIcon>? mapPostIcons});
}

/// @nodoc
class _$MapIconCopyWithImpl<$Res, $Val extends MapIcon>
    implements $MapIconCopyWith<$Res> {
  _$MapIconCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIcon = null,
    Object? baseCheckedInIcon = null,
    Object? subBaseIcon = null,
    Object? merchantIcon = null,
    Object? merchantTweetIcon = null,
    Object? postIcon = null,
    Object? adminAlertIcon = null,
    Object? adminQuestionnaireIcon = null,
    Object? mapPostIcons = freezed,
  }) {
    return _then(_value.copyWith(
      baseIcon: null == baseIcon
          ? _value.baseIcon
          : baseIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      baseCheckedInIcon: null == baseCheckedInIcon
          ? _value.baseCheckedInIcon
          : baseCheckedInIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      subBaseIcon: null == subBaseIcon
          ? _value.subBaseIcon
          : subBaseIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      merchantIcon: null == merchantIcon
          ? _value.merchantIcon
          : merchantIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      merchantTweetIcon: null == merchantTweetIcon
          ? _value.merchantTweetIcon
          : merchantTweetIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      postIcon: null == postIcon
          ? _value.postIcon
          : postIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      adminAlertIcon: null == adminAlertIcon
          ? _value.adminAlertIcon
          : adminAlertIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      adminQuestionnaireIcon: null == adminQuestionnaireIcon
          ? _value.adminQuestionnaireIcon
          : adminQuestionnaireIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      mapPostIcons: freezed == mapPostIcons
          ? _value.mapPostIcons
          : mapPostIcons // ignore: cast_nullable_to_non_nullable
              as List<MapPostIcon>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MapIconCopyWith<$Res> implements $MapIconCopyWith<$Res> {
  factory _$$_MapIconCopyWith(
          _$_MapIcon value, $Res Function(_$_MapIcon) then) =
      __$$_MapIconCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {BitmapDescriptor baseIcon,
      BitmapDescriptor baseCheckedInIcon,
      BitmapDescriptor subBaseIcon,
      BitmapDescriptor merchantIcon,
      BitmapDescriptor merchantTweetIcon,
      BitmapDescriptor postIcon,
      BitmapDescriptor adminAlertIcon,
      BitmapDescriptor adminQuestionnaireIcon,
      List<MapPostIcon>? mapPostIcons});
}

/// @nodoc
class __$$_MapIconCopyWithImpl<$Res>
    extends _$MapIconCopyWithImpl<$Res, _$_MapIcon>
    implements _$$_MapIconCopyWith<$Res> {
  __$$_MapIconCopyWithImpl(_$_MapIcon _value, $Res Function(_$_MapIcon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIcon = null,
    Object? baseCheckedInIcon = null,
    Object? subBaseIcon = null,
    Object? merchantIcon = null,
    Object? merchantTweetIcon = null,
    Object? postIcon = null,
    Object? adminAlertIcon = null,
    Object? adminQuestionnaireIcon = null,
    Object? mapPostIcons = freezed,
  }) {
    return _then(_$_MapIcon(
      baseIcon: null == baseIcon
          ? _value.baseIcon
          : baseIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      baseCheckedInIcon: null == baseCheckedInIcon
          ? _value.baseCheckedInIcon
          : baseCheckedInIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      subBaseIcon: null == subBaseIcon
          ? _value.subBaseIcon
          : subBaseIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      merchantIcon: null == merchantIcon
          ? _value.merchantIcon
          : merchantIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      merchantTweetIcon: null == merchantTweetIcon
          ? _value.merchantTweetIcon
          : merchantTweetIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      postIcon: null == postIcon
          ? _value.postIcon
          : postIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      adminAlertIcon: null == adminAlertIcon
          ? _value.adminAlertIcon
          : adminAlertIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      adminQuestionnaireIcon: null == adminQuestionnaireIcon
          ? _value.adminQuestionnaireIcon
          : adminQuestionnaireIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      mapPostIcons: freezed == mapPostIcons
          ? _value._mapPostIcons
          : mapPostIcons // ignore: cast_nullable_to_non_nullable
              as List<MapPostIcon>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MapIcon implements _MapIcon {
  const _$_MapIcon(
      {required this.baseIcon,
      required this.baseCheckedInIcon,
      required this.subBaseIcon,
      required this.merchantIcon,
      required this.merchantTweetIcon,
      required this.postIcon,
      required this.adminAlertIcon,
      required this.adminQuestionnaireIcon,
      final List<MapPostIcon>? mapPostIcons})
      : _mapPostIcons = mapPostIcons;

  factory _$_MapIcon.fromJson(Map<String, dynamic> json) =>
      _$$_MapIconFromJson(json);

// 拠点アイコン
  @override
  final BitmapDescriptor baseIcon;
// チェックイン済みアイコン
  @override
  final BitmapDescriptor baseCheckedInIcon;
// サブ拠点アイコン
  @override
  final BitmapDescriptor subBaseIcon;
// 加盟店アイコン
  @override
  final BitmapDescriptor merchantIcon;
// 加盟店つぶやきアイコン
  @override
  final BitmapDescriptor merchantTweetIcon;
// 投稿アイコン
  @override
  final BitmapDescriptor postIcon;
// 行政投稿アラートアイコン
  @override
  final BitmapDescriptor adminAlertIcon;
// 行政投稿アンケートアイコン
  @override
  final BitmapDescriptor adminQuestionnaireIcon;
// いいね数単位の投稿アイコン
  final List<MapPostIcon>? _mapPostIcons;
// いいね数単位の投稿アイコン
  @override
  List<MapPostIcon>? get mapPostIcons {
    final value = _mapPostIcons;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'MapIcon(baseIcon: $baseIcon, baseCheckedInIcon: $baseCheckedInIcon, subBaseIcon: $subBaseIcon, merchantIcon: $merchantIcon, merchantTweetIcon: $merchantTweetIcon, postIcon: $postIcon, adminAlertIcon: $adminAlertIcon, adminQuestionnaireIcon: $adminQuestionnaireIcon, mapPostIcons: $mapPostIcons)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MapIcon &&
            (identical(other.baseIcon, baseIcon) ||
                other.baseIcon == baseIcon) &&
            (identical(other.baseCheckedInIcon, baseCheckedInIcon) ||
                other.baseCheckedInIcon == baseCheckedInIcon) &&
            (identical(other.subBaseIcon, subBaseIcon) ||
                other.subBaseIcon == subBaseIcon) &&
            (identical(other.merchantIcon, merchantIcon) ||
                other.merchantIcon == merchantIcon) &&
            (identical(other.merchantTweetIcon, merchantTweetIcon) ||
                other.merchantTweetIcon == merchantTweetIcon) &&
            (identical(other.postIcon, postIcon) ||
                other.postIcon == postIcon) &&
            (identical(other.adminAlertIcon, adminAlertIcon) ||
                other.adminAlertIcon == adminAlertIcon) &&
            (identical(other.adminQuestionnaireIcon, adminQuestionnaireIcon) ||
                other.adminQuestionnaireIcon == adminQuestionnaireIcon) &&
            const DeepCollectionEquality()
                .equals(other._mapPostIcons, _mapPostIcons));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      baseIcon,
      baseCheckedInIcon,
      subBaseIcon,
      merchantIcon,
      merchantTweetIcon,
      postIcon,
      adminAlertIcon,
      adminQuestionnaireIcon,
      const DeepCollectionEquality().hash(_mapPostIcons));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MapIconCopyWith<_$_MapIcon> get copyWith =>
      __$$_MapIconCopyWithImpl<_$_MapIcon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MapIconToJson(
      this,
    );
  }
}

abstract class _MapIcon implements MapIcon {
  const factory _MapIcon(
      {required final BitmapDescriptor baseIcon,
      required final BitmapDescriptor baseCheckedInIcon,
      required final BitmapDescriptor subBaseIcon,
      required final BitmapDescriptor merchantIcon,
      required final BitmapDescriptor merchantTweetIcon,
      required final BitmapDescriptor postIcon,
      required final BitmapDescriptor adminAlertIcon,
      required final BitmapDescriptor adminQuestionnaireIcon,
      final List<MapPostIcon>? mapPostIcons}) = _$_MapIcon;

  factory _MapIcon.fromJson(Map<String, dynamic> json) = _$_MapIcon.fromJson;

  @override // 拠点アイコン
  BitmapDescriptor get baseIcon;
  @override // チェックイン済みアイコン
  BitmapDescriptor get baseCheckedInIcon;
  @override // サブ拠点アイコン
  BitmapDescriptor get subBaseIcon;
  @override // 加盟店アイコン
  BitmapDescriptor get merchantIcon;
  @override // 加盟店つぶやきアイコン
  BitmapDescriptor get merchantTweetIcon;
  @override // 投稿アイコン
  BitmapDescriptor get postIcon;
  @override // 行政投稿アラートアイコン
  BitmapDescriptor get adminAlertIcon;
  @override // 行政投稿アンケートアイコン
  BitmapDescriptor get adminQuestionnaireIcon;
  @override // いいね数単位の投稿アイコン
  List<MapPostIcon>? get mapPostIcons;
  @override
  @JsonKey(ignore: true)
  _$$_MapIconCopyWith<_$_MapIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

MapPostIcon _$MapPostIconFromJson(Map<String, dynamic> json) {
  return _MapPostIcon.fromJson(json);
}

/// @nodoc
mixin _$MapPostIcon {
// いいね数単位の投稿アイコン
  BitmapDescriptor get unitOfLikePostIcon =>
      throw _privateConstructorUsedError; // いいね数
  int get likeCount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MapPostIconCopyWith<MapPostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MapPostIconCopyWith<$Res> {
  factory $MapPostIconCopyWith(
          MapPostIcon value, $Res Function(MapPostIcon) then) =
      _$MapPostIconCopyWithImpl<$Res, MapPostIcon>;
  @useResult
  $Res call({BitmapDescriptor unitOfLikePostIcon, int likeCount});
}

/// @nodoc
class _$MapPostIconCopyWithImpl<$Res, $Val extends MapPostIcon>
    implements $MapPostIconCopyWith<$Res> {
  _$MapPostIconCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIcon = null,
    Object? likeCount = null,
  }) {
    return _then(_value.copyWith(
      unitOfLikePostIcon: null == unitOfLikePostIcon
          ? _value.unitOfLikePostIcon
          : unitOfLikePostIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MapPostIconCopyWith<$Res>
    implements $MapPostIconCopyWith<$Res> {
  factory _$$_MapPostIconCopyWith(
          _$_MapPostIcon value, $Res Function(_$_MapPostIcon) then) =
      __$$_MapPostIconCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BitmapDescriptor unitOfLikePostIcon, int likeCount});
}

/// @nodoc
class __$$_MapPostIconCopyWithImpl<$Res>
    extends _$MapPostIconCopyWithImpl<$Res, _$_MapPostIcon>
    implements _$$_MapPostIconCopyWith<$Res> {
  __$$_MapPostIconCopyWithImpl(
      _$_MapPostIcon _value, $Res Function(_$_MapPostIcon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIcon = null,
    Object? likeCount = null,
  }) {
    return _then(_$_MapPostIcon(
      unitOfLikePostIcon: null == unitOfLikePostIcon
          ? _value.unitOfLikePostIcon
          : unitOfLikePostIcon // ignore: cast_nullable_to_non_nullable
              as BitmapDescriptor,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MapPostIcon implements _MapPostIcon {
  const _$_MapPostIcon(
      {required this.unitOfLikePostIcon, required this.likeCount});

  factory _$_MapPostIcon.fromJson(Map<String, dynamic> json) =>
      _$$_MapPostIconFromJson(json);

// いいね数単位の投稿アイコン
  @override
  final BitmapDescriptor unitOfLikePostIcon;
// いいね数
  @override
  final int likeCount;

  @override
  String toString() {
    return 'MapPostIcon(unitOfLikePostIcon: $unitOfLikePostIcon, likeCount: $likeCount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MapPostIcon &&
            (identical(other.unitOfLikePostIcon, unitOfLikePostIcon) ||
                other.unitOfLikePostIcon == unitOfLikePostIcon) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, unitOfLikePostIcon, likeCount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MapPostIconCopyWith<_$_MapPostIcon> get copyWith =>
      __$$_MapPostIconCopyWithImpl<_$_MapPostIcon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MapPostIconToJson(
      this,
    );
  }
}

abstract class _MapPostIcon implements MapPostIcon {
  const factory _MapPostIcon(
      {required final BitmapDescriptor unitOfLikePostIcon,
      required final int likeCount}) = _$_MapPostIcon;

  factory _MapPostIcon.fromJson(Map<String, dynamic> json) =
      _$_MapPostIcon.fromJson;

  @override // いいね数単位の投稿アイコン
  BitmapDescriptor get unitOfLikePostIcon;
  @override // いいね数
  int get likeCount;
  @override
  @JsonKey(ignore: true)
  _$$_MapPostIconCopyWith<_$_MapPostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

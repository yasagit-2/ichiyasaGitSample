// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'completed_walk.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CompletedWalk _$CompletedWalkFromJson(Map<String, dynamic> json) {
  return _CompletedWalk.fromJson(json);
}

/// @nodoc
mixin _$CompletedWalk {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedWalkCopyWith<CompletedWalk> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedWalkCopyWith<$Res> {
  factory $CompletedWalkCopyWith(
          CompletedWalk value, $Res Function(CompletedWalk) then) =
      _$CompletedWalkCopyWithImpl<$Res, CompletedWalk>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CompletedWalkCopyWithImpl<$Res, $Val extends CompletedWalk>
    implements $CompletedWalkCopyWith<$Res> {
  _$CompletedWalkCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CompletedWalkCopyWith<$Res>
    implements $CompletedWalkCopyWith<$Res> {
  factory _$$_CompletedWalkCopyWith(
          _$_CompletedWalk value, $Res Function(_$_CompletedWalk) then) =
      __$$_CompletedWalkCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CompletedWalkCopyWithImpl<$Res>
    extends _$CompletedWalkCopyWithImpl<$Res, _$_CompletedWalk>
    implements _$$_CompletedWalkCopyWith<$Res> {
  __$$_CompletedWalkCopyWithImpl(
      _$_CompletedWalk _value, $Res Function(_$_CompletedWalk) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedWalk(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedWalk implements _CompletedWalk {
  const _$_CompletedWalk(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedWalk.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedWalkFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedWalk(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedWalk &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedWalkCopyWith<_$_CompletedWalk> get copyWith =>
      __$$_CompletedWalkCopyWithImpl<_$_CompletedWalk>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedWalkToJson(
      this,
    );
  }
}

abstract class _CompletedWalk implements CompletedWalk {
  const factory _CompletedWalk(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedWalk;

  factory _CompletedWalk.fromJson(Map<String, dynamic> json) =
      _$_CompletedWalk.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedWalkCopyWith<_$_CompletedWalk> get copyWith =>
      throw _privateConstructorUsedError;
}

WalkHistory _$WalkHistoryFromJson(Map<String, dynamic> json) {
  return _WalkHistory.fromJson(json);
}

/// @nodoc
mixin _$WalkHistory {
// 週番号（YYYYWww）
  String get id => throw _privateConstructorUsedError; // 獲得ポイント
  int get point => throw _privateConstructorUsedError; // 歩数（履歴作成時点の歩数）
  int get step => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalkHistoryCopyWith<WalkHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalkHistoryCopyWith<$Res> {
  factory $WalkHistoryCopyWith(
          WalkHistory value, $Res Function(WalkHistory) then) =
      _$WalkHistoryCopyWithImpl<$Res, WalkHistory>;
  @useResult
  $Res call(
      {String id,
      int point,
      int step,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$WalkHistoryCopyWithImpl<$Res, $Val extends WalkHistory>
    implements $WalkHistoryCopyWith<$Res> {
  _$WalkHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? point = null,
    Object? step = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      step: null == step
          ? _value.step
          : step // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_WalkHistoryCopyWith<$Res>
    implements $WalkHistoryCopyWith<$Res> {
  factory _$$_WalkHistoryCopyWith(
          _$_WalkHistory value, $Res Function(_$_WalkHistory) then) =
      __$$_WalkHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      int point,
      int step,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_WalkHistoryCopyWithImpl<$Res>
    extends _$WalkHistoryCopyWithImpl<$Res, _$_WalkHistory>
    implements _$$_WalkHistoryCopyWith<$Res> {
  __$$_WalkHistoryCopyWithImpl(
      _$_WalkHistory _value, $Res Function(_$_WalkHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? point = null,
    Object? step = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_WalkHistory(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      step: null == step
          ? _value.step
          : step // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_WalkHistory implements _WalkHistory {
  const _$_WalkHistory(
      {required this.id,
      required this.point,
      required this.step,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_WalkHistory.fromJson(Map<String, dynamic> json) =>
      _$$_WalkHistoryFromJson(json);

// 週番号（YYYYWww）
  @override
  final String id;
// 獲得ポイント
  @override
  final int point;
// 歩数（履歴作成時点の歩数）
  @override
  final int step;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'WalkHistory(id: $id, point: $point, step: $step, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalkHistory &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.step, step) || other.step == step) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, point, step, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalkHistoryCopyWith<_$_WalkHistory> get copyWith =>
      __$$_WalkHistoryCopyWithImpl<_$_WalkHistory>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WalkHistoryToJson(
      this,
    );
  }
}

abstract class _WalkHistory implements WalkHistory {
  const factory _WalkHistory(
      {required final String id,
      required final int point,
      required final int step,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_WalkHistory;

  factory _WalkHistory.fromJson(Map<String, dynamic> json) =
      _$_WalkHistory.fromJson;

  @override // 週番号（YYYYWww）
  String get id;
  @override // 獲得ポイント
  int get point;
  @override // 歩数（履歴作成時点の歩数）
  int get step;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_WalkHistoryCopyWith<_$_WalkHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

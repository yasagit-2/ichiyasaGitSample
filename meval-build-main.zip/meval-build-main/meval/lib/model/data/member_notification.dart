import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'member_notification.freezed.dart';
part 'member_notification.g.dart';

/// お知らせ
@freezed
class MemberNotification with _$MemberNotification {
  @firestoreSerializable
  const factory MemberNotification({
    // お知らせID
    required String id,
    // タイトル
    required String title,
    // お知らせURL
    String? contentUrl,
    // 有効期間開始
    @TimestampConverter() required DateTime effectivePeriodBegin,
    // 有効期間終了
    @TimestampConverter() required DateTime effectivePeriodEnd,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _MemberNotification;

  factory MemberNotification.fromJson(Map<String, Object?> json) =>
      _$MemberNotificationFromJson(json);
}

@Collection<MemberNotification>('memberNotifications')
final memberNotificationsRef = MemberNotificationCollectionReference();

MemberNotificationDocumentReference memberNotificationRef(
        {required String id}) =>
    MemberNotificationDocumentReference(
        memberNotificationsRef.doc(id).reference);

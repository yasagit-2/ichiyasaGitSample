// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'point.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Point _$PointFromJson(Map<String, dynamic> json) {
  return _Point.fromJson(json);
}

/// @nodoc
mixin _$Point {
// ポイント
  int get point => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PointCopyWith<Point> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PointCopyWith<$Res> {
  factory $PointCopyWith(Point value, $Res Function(Point) then) =
      _$PointCopyWithImpl<$Res, Point>;
  @useResult
  $Res call(
      {int point,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$PointCopyWithImpl<$Res, $Val extends Point>
    implements $PointCopyWith<$Res> {
  _$PointCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? point = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PointCopyWith<$Res> implements $PointCopyWith<$Res> {
  factory _$$_PointCopyWith(_$_Point value, $Res Function(_$_Point) then) =
      __$$_PointCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int point,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_PointCopyWithImpl<$Res> extends _$PointCopyWithImpl<$Res, _$_Point>
    implements _$$_PointCopyWith<$Res> {
  __$$_PointCopyWithImpl(_$_Point _value, $Res Function(_$_Point) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? point = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Point(
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Point implements _Point {
  const _$_Point(
      {required this.point,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Point.fromJson(Map<String, dynamic> json) =>
      _$$_PointFromJson(json);

// ポイント
  @override
  final int point;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Point(point: $point, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Point &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, point, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PointCopyWith<_$_Point> get copyWith =>
      __$$_PointCopyWithImpl<_$_Point>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PointToJson(
      this,
    );
  }
}

abstract class _Point implements Point {
  const factory _Point(
      {required final int point,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Point;

  factory _Point.fromJson(Map<String, dynamic> json) = _$_Point.fromJson;

  @override // ポイント
  int get point;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PointCopyWith<_$_Point> get copyWith =>
      throw _privateConstructorUsedError;
}

PointHistory _$PointHistoryFromJson(Map<String, dynamic> json) {
  return _PointHistory.fromJson(json);
}

/// @nodoc
mixin _$PointHistory {
// 獲得ポイント
  int get point => throw _privateConstructorUsedError; // 獲得前のポイント
  int get pointBeforeEarning =>
      throw _privateConstructorUsedError; // 拠点制覇情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedParentBaseRef =>
      throw _privateConstructorUsedError; // 称号獲得情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedTitleRef =>
      throw _privateConstructorUsedError; // アンケート回答情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get answeredQuestionnaireRef =>
      throw _privateConstructorUsedError; // ウォーク達成情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedWalkRef =>
      throw _privateConstructorUsedError; // イベント達成情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedEventRef =>
      throw _privateConstructorUsedError; // クーポン獲得情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedCouponRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PointHistoryCopyWith<PointHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PointHistoryCopyWith<$Res> {
  factory $PointHistoryCopyWith(
          PointHistory value, $Res Function(PointHistory) then) =
      _$PointHistoryCopyWithImpl<$Res, PointHistory>;
  @useResult
  $Res call(
      {int point,
      int pointBeforeEarning,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedParentBaseRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedTitleRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? answeredQuestionnaireRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedWalkRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedEventRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedCouponRef,
      @TimestampConverter()
          DateTime? updatedAt,
      @TimestampConverter()
          DateTime? createdAt});
}

/// @nodoc
class _$PointHistoryCopyWithImpl<$Res, $Val extends PointHistory>
    implements $PointHistoryCopyWith<$Res> {
  _$PointHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? point = null,
    Object? pointBeforeEarning = null,
    Object? completedParentBaseRef = freezed,
    Object? completedTitleRef = freezed,
    Object? answeredQuestionnaireRef = freezed,
    Object? completedWalkRef = freezed,
    Object? completedEventRef = freezed,
    Object? completedCouponRef = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointBeforeEarning: null == pointBeforeEarning
          ? _value.pointBeforeEarning
          : pointBeforeEarning // ignore: cast_nullable_to_non_nullable
              as int,
      completedParentBaseRef: freezed == completedParentBaseRef
          ? _value.completedParentBaseRef
          : completedParentBaseRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedTitleRef: freezed == completedTitleRef
          ? _value.completedTitleRef
          : completedTitleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      answeredQuestionnaireRef: freezed == answeredQuestionnaireRef
          ? _value.answeredQuestionnaireRef
          : answeredQuestionnaireRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedWalkRef: freezed == completedWalkRef
          ? _value.completedWalkRef
          : completedWalkRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedEventRef: freezed == completedEventRef
          ? _value.completedEventRef
          : completedEventRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedCouponRef: freezed == completedCouponRef
          ? _value.completedCouponRef
          : completedCouponRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PointHistoryCopyWith<$Res>
    implements $PointHistoryCopyWith<$Res> {
  factory _$$_PointHistoryCopyWith(
          _$_PointHistory value, $Res Function(_$_PointHistory) then) =
      __$$_PointHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int point,
      int pointBeforeEarning,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedParentBaseRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedTitleRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? answeredQuestionnaireRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedWalkRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedEventRef,
      @DocumentReferenceConverter()
          DocumentReference<Object?>? completedCouponRef,
      @TimestampConverter()
          DateTime? updatedAt,
      @TimestampConverter()
          DateTime? createdAt});
}

/// @nodoc
class __$$_PointHistoryCopyWithImpl<$Res>
    extends _$PointHistoryCopyWithImpl<$Res, _$_PointHistory>
    implements _$$_PointHistoryCopyWith<$Res> {
  __$$_PointHistoryCopyWithImpl(
      _$_PointHistory _value, $Res Function(_$_PointHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? point = null,
    Object? pointBeforeEarning = null,
    Object? completedParentBaseRef = freezed,
    Object? completedTitleRef = freezed,
    Object? answeredQuestionnaireRef = freezed,
    Object? completedWalkRef = freezed,
    Object? completedEventRef = freezed,
    Object? completedCouponRef = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PointHistory(
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      pointBeforeEarning: null == pointBeforeEarning
          ? _value.pointBeforeEarning
          : pointBeforeEarning // ignore: cast_nullable_to_non_nullable
              as int,
      completedParentBaseRef: freezed == completedParentBaseRef
          ? _value.completedParentBaseRef
          : completedParentBaseRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedTitleRef: freezed == completedTitleRef
          ? _value.completedTitleRef
          : completedTitleRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      answeredQuestionnaireRef: freezed == answeredQuestionnaireRef
          ? _value.answeredQuestionnaireRef
          : answeredQuestionnaireRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedWalkRef: freezed == completedWalkRef
          ? _value.completedWalkRef
          : completedWalkRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedEventRef: freezed == completedEventRef
          ? _value.completedEventRef
          : completedEventRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      completedCouponRef: freezed == completedCouponRef
          ? _value.completedCouponRef
          : completedCouponRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_PointHistory implements _PointHistory {
  const _$_PointHistory(
      {required this.point,
      required this.pointBeforeEarning,
      @DocumentReferenceConverter() this.completedParentBaseRef,
      @DocumentReferenceConverter() this.completedTitleRef,
      @DocumentReferenceConverter() this.answeredQuestionnaireRef,
      @DocumentReferenceConverter() this.completedWalkRef,
      @DocumentReferenceConverter() this.completedEventRef,
      @DocumentReferenceConverter() this.completedCouponRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_PointHistory.fromJson(Map<String, dynamic> json) =>
      _$$_PointHistoryFromJson(json);

// 獲得ポイント
  @override
  final int point;
// 獲得前のポイント
  @override
  final int pointBeforeEarning;
// 拠点制覇情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? completedParentBaseRef;
// 称号獲得情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? completedTitleRef;
// アンケート回答情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? answeredQuestionnaireRef;
// ウォーク達成情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? completedWalkRef;
// イベント達成情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? completedEventRef;
// クーポン獲得情報のリファレンス
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?>? completedCouponRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PointHistory(point: $point, pointBeforeEarning: $pointBeforeEarning, completedParentBaseRef: $completedParentBaseRef, completedTitleRef: $completedTitleRef, answeredQuestionnaireRef: $answeredQuestionnaireRef, completedWalkRef: $completedWalkRef, completedEventRef: $completedEventRef, completedCouponRef: $completedCouponRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PointHistory &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.pointBeforeEarning, pointBeforeEarning) ||
                other.pointBeforeEarning == pointBeforeEarning) &&
            (identical(other.completedParentBaseRef, completedParentBaseRef) ||
                other.completedParentBaseRef == completedParentBaseRef) &&
            (identical(other.completedTitleRef, completedTitleRef) ||
                other.completedTitleRef == completedTitleRef) &&
            (identical(
                    other.answeredQuestionnaireRef, answeredQuestionnaireRef) ||
                other.answeredQuestionnaireRef == answeredQuestionnaireRef) &&
            (identical(other.completedWalkRef, completedWalkRef) ||
                other.completedWalkRef == completedWalkRef) &&
            (identical(other.completedEventRef, completedEventRef) ||
                other.completedEventRef == completedEventRef) &&
            (identical(other.completedCouponRef, completedCouponRef) ||
                other.completedCouponRef == completedCouponRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      point,
      pointBeforeEarning,
      completedParentBaseRef,
      completedTitleRef,
      answeredQuestionnaireRef,
      completedWalkRef,
      completedEventRef,
      completedCouponRef,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PointHistoryCopyWith<_$_PointHistory> get copyWith =>
      __$$_PointHistoryCopyWithImpl<_$_PointHistory>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PointHistoryToJson(
      this,
    );
  }
}

abstract class _PointHistory implements PointHistory {
  const factory _PointHistory(
      {required final int point,
      required final int pointBeforeEarning,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? completedParentBaseRef,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? completedTitleRef,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? answeredQuestionnaireRef,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? completedWalkRef,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? completedEventRef,
      @DocumentReferenceConverter()
          final DocumentReference<Object?>? completedCouponRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_PointHistory;

  factory _PointHistory.fromJson(Map<String, dynamic> json) =
      _$_PointHistory.fromJson;

  @override // 獲得ポイント
  int get point;
  @override // 獲得前のポイント
  int get pointBeforeEarning;
  @override // 拠点制覇情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedParentBaseRef;
  @override // 称号獲得情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedTitleRef;
  @override // アンケート回答情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get answeredQuestionnaireRef;
  @override // ウォーク達成情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedWalkRef;
  @override // イベント達成情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedEventRef;
  @override // クーポン獲得情報のリファレンス
  @DocumentReferenceConverter()
  DocumentReference<Object?>? get completedCouponRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PointHistoryCopyWith<_$_PointHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

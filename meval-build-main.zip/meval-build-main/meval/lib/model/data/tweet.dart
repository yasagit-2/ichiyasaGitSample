import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'tweet.freezed.dart';
part 'tweet.g.dart';

@freezed
class Tweet with _$Tweet {
  @firestoreSerializable
  const factory Tweet({
    // つぶやきID
    required String id,
    // メッセージ
    required String message,
    // 加盟店のReference
    @DocumentReferenceConverter() required DocumentReference merchantRef,
    // つぶやき表示期限
    required DateTime expiration,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Tweet;

  factory Tweet.fromJson(Map<String, Object?> json) => _$TweetFromJson(json);
}

@Collection<Tweet>('tweets')
final tweetsRef = TweetCollectionReference();

TweetDocumentReference tweetRef({required String id}) =>
    TweetDocumentReference(tweetsRef.doc(id).reference);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

part 'map_icon.freezed.dart';
part 'map_icon.g.dart';

/// マップアイコン
@freezed
class MapIcon with _$MapIcon {
  const factory MapIcon({
    // 拠点アイコン
    required BitmapDescriptor baseIcon,
    // チェックイン済みアイコン
    required BitmapDescriptor baseCheckedInIcon,
    // サブ拠点アイコン
    required BitmapDescriptor subBaseIcon,
    // 加盟店アイコン
    required BitmapDescriptor merchantIcon,
    // 加盟店つぶやきアイコン
    required BitmapDescriptor merchantTweetIcon,
    // 投稿アイコン
    required BitmapDescriptor postIcon,
    // 行政投稿アラートアイコン
    required BitmapDescriptor adminAlertIcon,
    // 行政投稿アンケートアイコン
    required BitmapDescriptor adminQuestionnaireIcon,
    // いいね数単位の投稿アイコン
    List<MapPostIcon>? mapPostIcons,
  }) = _MapIcon;

  factory MapIcon.fromJson(Map<String, Object?> json) =>
      _$MapIconFromJson(json);
}

/// いいね数単位の投稿アイコン
@freezed
class MapPostIcon with _$MapPostIcon {
  const factory MapPostIcon({
    // いいね数単位の投稿アイコン
    required BitmapDescriptor unitOfLikePostIcon,
    // いいね数
    required int likeCount,
  }) = _MapPostIcon;

  factory MapPostIcon.fromJson(Map<String, Object?> json) =>
      _$MapPostIconFromJson(json);
}

// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'map_icon.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MapIcon _$$_MapIconFromJson(Map<String, dynamic> json) => _$_MapIcon(
      baseIcon: BitmapDescriptor.fromJson(json['baseIcon'] as Object),
      baseCheckedInIcon:
          BitmapDescriptor.fromJson(json['baseCheckedInIcon'] as Object),
      subBaseIcon: BitmapDescriptor.fromJson(json['subBaseIcon'] as Object),
      merchantIcon: BitmapDescriptor.fromJson(json['merchantIcon'] as Object),
      merchantTweetIcon:
          BitmapDescriptor.fromJson(json['merchantTweetIcon'] as Object),
      postIcon: BitmapDescriptor.fromJson(json['postIcon'] as Object),
      adminAlertIcon:
          BitmapDescriptor.fromJson(json['adminAlertIcon'] as Object),
      adminQuestionnaireIcon:
          BitmapDescriptor.fromJson(json['adminQuestionnaireIcon'] as Object),
      mapPostIcons: (json['mapPostIcons'] as List<dynamic>?)
          ?.map((e) => MapPostIcon.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

const _$$_MapIconFieldMap = <String, String>{
  'baseIcon': 'baseIcon',
  'baseCheckedInIcon': 'baseCheckedInIcon',
  'subBaseIcon': 'subBaseIcon',
  'merchantIcon': 'merchantIcon',
  'merchantTweetIcon': 'merchantTweetIcon',
  'postIcon': 'postIcon',
  'adminAlertIcon': 'adminAlertIcon',
  'adminQuestionnaireIcon': 'adminQuestionnaireIcon',
  'mapPostIcons': 'mapPostIcons',
};

Map<String, dynamic> _$$_MapIconToJson(_$_MapIcon instance) =>
    <String, dynamic>{
      'baseIcon': instance.baseIcon.toJson(),
      'baseCheckedInIcon': instance.baseCheckedInIcon.toJson(),
      'subBaseIcon': instance.subBaseIcon.toJson(),
      'merchantIcon': instance.merchantIcon.toJson(),
      'merchantTweetIcon': instance.merchantTweetIcon.toJson(),
      'postIcon': instance.postIcon.toJson(),
      'adminAlertIcon': instance.adminAlertIcon.toJson(),
      'adminQuestionnaireIcon': instance.adminQuestionnaireIcon.toJson(),
      'mapPostIcons': instance.mapPostIcons?.map((e) => e.toJson()).toList(),
    };

_$_MapPostIcon _$$_MapPostIconFromJson(Map<String, dynamic> json) =>
    _$_MapPostIcon(
      unitOfLikePostIcon:
          BitmapDescriptor.fromJson(json['unitOfLikePostIcon'] as Object),
      likeCount: json['likeCount'] as int,
    );

const _$$_MapPostIconFieldMap = <String, String>{
  'unitOfLikePostIcon': 'unitOfLikePostIcon',
  'likeCount': 'likeCount',
};

Map<String, dynamic> _$$_MapPostIconToJson(_$_MapPostIcon instance) =>
    <String, dynamic>{
      'unitOfLikePostIcon': instance.unitOfLikePostIcon.toJson(),
      'likeCount': instance.likeCount,
    };

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'completed_title.freezed.dart';
part 'completed_title.g.dart';

/// 称号獲得情報
@freezed
class CompletedTitle with _$CompletedTitle {
  @firestoreSerializable
  const factory CompletedTitle({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CompletedTitle;

  factory CompletedTitle.fromJson(Map<String, Object?> json) =>
      _$CompletedTitleFromJson(json);
}

@Collection<CompletedTitle>('completedTitles')
@Collection<TitleHistory>('completedTitles/*/titleHistories',
    name: 'titleHistories')
final completedTitlesRef = CompletedTitleCollectionReference();

CompletedTitleDocumentReference completedTitleRef({required String id}) =>
    CompletedTitleDocumentReference(completedTitlesRef.doc(id).reference);

/// 称号獲得履歴
@freezed
class TitleHistory with _$TitleHistory {
  @firestoreSerializable
  const factory TitleHistory({
    // 称号ID
    required String id,
    // 称号名称
    required String name,
    // 称号獲得ポイント
    required int point,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _TitleHistory;

  factory TitleHistory.fromJson(Map<String, Object?> json) =>
      _$TitleHistoryFromJson(json);
}

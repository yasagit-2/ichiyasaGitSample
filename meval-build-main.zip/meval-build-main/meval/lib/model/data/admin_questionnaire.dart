import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'admin_post_mixin.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'admin_questionnaire.freezed.dart';
part 'admin_questionnaire.g.dart';

/// 行政投稿（アンケート）
@freezed
class AdminQuestionnaire
    with MapPositionMixin, AdminPostMixin, _$AdminQuestionnaire {
  @firestoreSerializable
  const factory AdminQuestionnaire({
    // アンケートID
    required String id,
    // アンケート本文
    required String message,
    // アンケート期限
    required DateTime dueDate,
    // アンケートの位置情報
    required MapPosition position,
    // アンケート画像のURL
    String? imageUrl,
    // アンケート画像の保存先
    String? imagePath,
    // アンケート回答獲得ポイント
    required int point,
    // ポイント付与制限人数
    required int pointLimit,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _AdminQuestionnaire;

  factory AdminQuestionnaire.fromJson(Map<String, Object?> json) =>
      _$AdminQuestionnaireFromJson(json);
}

@Collection<AdminQuestionnaire>('adminQuestionnaires')
@Collection<Choice>('adminQuestionnaires/*/choices', name: 'choices')
@Collection<QuestionnaireTransaction>(
    'adminQuestionnaires/*/questionnaireTransactions',
    name: 'questionnaireTransactions')
final adminQuestionnairesRef = AdminQuestionnaireCollectionReference();

AdminQuestionnaireDocumentReference adminQuestionnaireRef(
        {required String id}) =>
    AdminQuestionnaireDocumentReference(
        adminQuestionnairesRef.doc(id).reference);

/// アンケートの選択肢
@freezed
class Choice with _$Choice {
  @firestoreSerializable
  const factory Choice({
    // 選択肢ID
    required String id,
    // 選択肢の文言
    required String choice,
    // 選択肢の表示順序
    required int displayOrder,
    // アンケートの回答数
    required int answer,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Choice;

  factory Choice.fromJson(Map<String, Object?> json) => _$ChoiceFromJson(json);
}

/// アンケートトランザクション
@freezed
class QuestionnaireTransaction with _$QuestionnaireTransaction {
  @firestoreSerializable
  const factory QuestionnaireTransaction({
    // ポイント付与制限人数残り
    required int pointLimitRemain,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _QuestionnaireTransaction;

  factory QuestionnaireTransaction.fromJson(Map<String, Object?> json) =>
      _$QuestionnaireTransactionFromJson(json);
}

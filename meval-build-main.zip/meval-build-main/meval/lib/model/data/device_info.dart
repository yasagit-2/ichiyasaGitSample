import 'package:freezed_annotation/freezed_annotation.dart';

import 'firestore_serializable.dart';

part 'device_info.freezed.dart';
part 'device_info.g.dart';

@freezed
class DeviceInfo with _$DeviceInfo {
  @firestoreSerializable
  const factory DeviceInfo({
    // OS
    required String os,
    // OSバージョン
    required String version,
    // 機種名
    required String device,
  }) = _DeviceInfo;

  factory DeviceInfo.fromJson(Map<String, Object?> json) =>
      _$DeviceInfoFromJson(json);
}

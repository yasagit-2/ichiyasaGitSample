import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'setting.freezed.dart';
part 'setting.g.dart';

const settingDocumentId = 'mevalAppSettings';

@freezed
class Setting with _$Setting {
  @firestoreSerializable
  const factory Setting({
    // 拠点アイコンURL
    required String baseIconUrl,
    // チェックイン済み拠点アイコンURL
    required String baseCheckedInIconUrl,
    // サブ拠点アイコンURL
    required String subBaseIconUrl,
    // 加盟店アイコンURL
    required String merchantIconUrl,
    // 加盟店つぶやきアイコンURL
    required String merchantTweetIconUrl,
    // 投稿アイコンURL
    required String postIconUrl,
    // 行政投稿アラートアイコンURL
    required String adminAlertIconUrl,
    // 行政投稿アンケートアイコンURL
    required String adminQuestionnaireIconUrl,
    // チェックイン可能距離（meter）
    required double checkInRadius,
    // 拠点/投稿/加盟店収集半径(km)
    required double collectionRadius,
    // 週間規定歩数
    required int targetStepPerWeek,
    // 週間規定歩数達成ポイント
    required int stepAchievedPoint,
    // 投稿間隔制限（hour）
    required int postIntervalLimitHour,
    // 行政報告間隔制限（hour）
    required int reportIntervalLimitHour,
    // コメント間隔制限（minute）
    required int commentIntervalLimitMinute,
    // お知らせ保存日数
    required int notificationRetentionDay,
    // イベント保存日数
    required int eventRetentionDay,
    // プライバシーポリシーURL
    required String privacyPolicyUrl,
    // ヘルプページURL
    required String helpPageUrl,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Setting;

  factory Setting.fromJson(Map<String, Object?> json) =>
      _$SettingFromJson(json);
}

@Collection<Setting>('settings')
@Collection<Week>('settings/*/weeks', name: 'weeks')
@Collection<PostIcon>('settings/*/postIcons', name: 'postIcons')
final settingsRef = SettingCollectionReference();

SettingDocumentReference settingRef({required String id}) =>
    SettingDocumentReference(settingsRef.doc(id).reference);

/// 週単位設定
@freezed
class Week with _$Week {
  @firestoreSerializable
  const factory Week({
    // ポイント付与制限人数
    required int stepPointLimit,
    // ポイント付与制限人数残り
    required int stepPointLimitRemain,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Week;

  factory Week.fromJson(Map<String, Object?> json) => _$WeekFromJson(json);
}

/// 投稿アイコン設定
@freezed
class PostIcon with _$PostIcon {
  @firestoreSerializable
  const factory PostIcon({
    // いいね数単位の投稿アイコンURL
    required String unitOfLikePostIconUrl,
    // いいね数
    required int likeCount,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _PostIcon;

  factory PostIcon.fromJson(Map<String, Object?> json) =>
      _$PostIconFromJson(json);
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'like.freezed.dart';
part 'like.g.dart';

@freezed
class Like with _$Like {
  @firestoreSerializable
  const factory Like({
    // いいねID
    required String id,
    // 投稿のReference
    @DocumentReferenceConverter() required DocumentReference postRef,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Like;

  factory Like.fromJson(Map<String, Object?> json) => _$LikeFromJson(json);
}

@Collection<Like>('likes')
final likesRef = LikeCollectionReference();

LikeDocumentReference likeRef({required String id}) =>
    LikeDocumentReference(likesRef.doc(id).reference);

// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'answered_questionnaire.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class AnsweredQuestionnaireCollectionReference
    implements
        AnsweredQuestionnaireQuery,
        FirestoreCollectionReference<AnsweredQuestionnaire,
            AnsweredQuestionnaireQuerySnapshot> {
  factory AnsweredQuestionnaireCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$AnsweredQuestionnaireCollectionReference;

  static AnsweredQuestionnaire fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return AnsweredQuestionnaire.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    AnsweredQuestionnaire value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<AnsweredQuestionnaire> get reference;

  @override
  AnsweredQuestionnaireDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<AnsweredQuestionnaireDocumentReference> add(
      AnsweredQuestionnaire value);
}

class _$AnsweredQuestionnaireCollectionReference
    extends _$AnsweredQuestionnaireQuery
    implements AnsweredQuestionnaireCollectionReference {
  factory _$AnsweredQuestionnaireCollectionReference(
      [FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$AnsweredQuestionnaireCollectionReference._(
      firestore.collection('answeredQuestionnaires').withConverter(
            fromFirestore:
                AnsweredQuestionnaireCollectionReference.fromFirestore,
            toFirestore: AnsweredQuestionnaireCollectionReference.toFirestore,
          ),
    );
  }

  _$AnsweredQuestionnaireCollectionReference._(
    CollectionReference<AnsweredQuestionnaire> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<AnsweredQuestionnaire> get reference =>
      super.reference as CollectionReference<AnsweredQuestionnaire>;

  @override
  AnsweredQuestionnaireDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return AnsweredQuestionnaireDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<AnsweredQuestionnaireDocumentReference> add(
      AnsweredQuestionnaire value) {
    return reference
        .add(value)
        .then((ref) => AnsweredQuestionnaireDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$AnsweredQuestionnaireCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class AnsweredQuestionnaireDocumentReference
    extends FirestoreDocumentReference<AnsweredQuestionnaire,
        AnsweredQuestionnaireDocumentSnapshot> {
  factory AnsweredQuestionnaireDocumentReference(
          DocumentReference<AnsweredQuestionnaire> reference) =
      _$AnsweredQuestionnaireDocumentReference;

  DocumentReference<AnsweredQuestionnaire> get reference;

  /// A reference to the [AnsweredQuestionnaireCollectionReference] containing this document.
  AnsweredQuestionnaireCollectionReference get parent {
    return _$AnsweredQuestionnaireCollectionReference(reference.firestore);
  }

  late final QuestionnaireHistoryCollectionReference questionnaireHistories =
      _$QuestionnaireHistoryCollectionReference(
    reference,
  );

  @override
  Stream<AnsweredQuestionnaireDocumentSnapshot> snapshots();

  @override
  Future<AnsweredQuestionnaireDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$AnsweredQuestionnaireDocumentReference
    extends FirestoreDocumentReference<AnsweredQuestionnaire,
        AnsweredQuestionnaireDocumentSnapshot>
    implements AnsweredQuestionnaireDocumentReference {
  _$AnsweredQuestionnaireDocumentReference(this.reference);

  @override
  final DocumentReference<AnsweredQuestionnaire> reference;

  /// A reference to the [AnsweredQuestionnaireCollectionReference] containing this document.
  AnsweredQuestionnaireCollectionReference get parent {
    return _$AnsweredQuestionnaireCollectionReference(reference.firestore);
  }

  late final QuestionnaireHistoryCollectionReference questionnaireHistories =
      _$QuestionnaireHistoryCollectionReference(
    reference,
  );

  @override
  Stream<AnsweredQuestionnaireDocumentSnapshot> snapshots() {
    return reference.snapshots().map(AnsweredQuestionnaireDocumentSnapshot._);
  }

  @override
  Future<AnsweredQuestionnaireDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(AnsweredQuestionnaireDocumentSnapshot._);
  }

  @override
  Future<AnsweredQuestionnaireDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction
        .get(reference)
        .then(AnsweredQuestionnaireDocumentSnapshot._);
  }

  Future<void> update({
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is AnsweredQuestionnaireDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class AnsweredQuestionnaireQuery
    implements
        QueryReference<AnsweredQuestionnaire,
            AnsweredQuestionnaireQuerySnapshot> {
  @override
  AnsweredQuestionnaireQuery limit(int limit);

  @override
  AnsweredQuestionnaireQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  AnsweredQuestionnaireQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  AnsweredQuestionnaireQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  AnsweredQuestionnaireQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  AnsweredQuestionnaireQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  AnsweredQuestionnaireQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  AnsweredQuestionnaireQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AnsweredQuestionnaireQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AnsweredQuestionnaireQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  });
}

class _$AnsweredQuestionnaireQuery extends QueryReference<AnsweredQuestionnaire,
    AnsweredQuestionnaireQuerySnapshot> implements AnsweredQuestionnaireQuery {
  _$AnsweredQuestionnaireQuery(
    this._collection, {
    required Query<AnsweredQuestionnaire> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<AnsweredQuestionnaireQuerySnapshot> snapshots(
      [SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(AnsweredQuestionnaireQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<AnsweredQuestionnaireQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(AnsweredQuestionnaireQuerySnapshot._fromQuerySnapshot);
  }

  @override
  AnsweredQuestionnaireQuery limit(int limit) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  AnsweredQuestionnaireQuery limitToLast(int limit) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  AnsweredQuestionnaireQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AnsweredQuestionnaireQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AnsweredQuestionnaireQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AnsweredQuestionnaireQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AnsweredQuestionnaireFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AnsweredQuestionnaireQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AnsweredQuestionnaireFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AnsweredQuestionnaireQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AnsweredQuestionnaireQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AnsweredQuestionnaireFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AnsweredQuestionnaireQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AnsweredQuestionnaireDocumentSnapshot? startAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endAtDocument,
    AnsweredQuestionnaireDocumentSnapshot? endBeforeDocument,
    AnsweredQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AnsweredQuestionnaireFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AnsweredQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$AnsweredQuestionnaireQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class AnsweredQuestionnaireDocumentSnapshot
    extends FirestoreDocumentSnapshot<AnsweredQuestionnaire> {
  AnsweredQuestionnaireDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final DocumentSnapshot<AnsweredQuestionnaire> snapshot;

  @override
  AnsweredQuestionnaireDocumentReference get reference {
    return AnsweredQuestionnaireDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final AnsweredQuestionnaire? data;
}

class AnsweredQuestionnaireQuerySnapshot extends FirestoreQuerySnapshot<
    AnsweredQuestionnaire, AnsweredQuestionnaireQueryDocumentSnapshot> {
  AnsweredQuestionnaireQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory AnsweredQuestionnaireQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<AnsweredQuestionnaire> snapshot,
  ) {
    final docs = snapshot.docs
        .map(AnsweredQuestionnaireQueryDocumentSnapshot._)
        .toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        AnsweredQuestionnaireDocumentSnapshot._,
      );
    }).toList();

    return AnsweredQuestionnaireQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<AnsweredQuestionnaireDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    AnsweredQuestionnaireDocumentSnapshot Function(DocumentSnapshot<T> doc)
        decodeDoc,
  ) {
    return FirestoreDocumentChange<AnsweredQuestionnaireDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<AnsweredQuestionnaire> snapshot;

  @override
  final List<AnsweredQuestionnaireQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<AnsweredQuestionnaireDocumentSnapshot>>
      docChanges;
}

class AnsweredQuestionnaireQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<AnsweredQuestionnaire>
    implements AnsweredQuestionnaireDocumentSnapshot {
  AnsweredQuestionnaireQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<AnsweredQuestionnaire> snapshot;

  @override
  final AnsweredQuestionnaire data;

  @override
  AnsweredQuestionnaireDocumentReference get reference {
    return AnsweredQuestionnaireDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class QuestionnaireHistoryCollectionReference
    implements
        QuestionnaireHistoryQuery,
        FirestoreCollectionReference<QuestionnaireHistory,
            QuestionnaireHistoryQuerySnapshot> {
  factory QuestionnaireHistoryCollectionReference(
    DocumentReference<AnsweredQuestionnaire> parent,
  ) = _$QuestionnaireHistoryCollectionReference;

  static QuestionnaireHistory fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return QuestionnaireHistory.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    QuestionnaireHistory value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<QuestionnaireHistory> get reference;

  /// A reference to the containing [AnsweredQuestionnaireDocumentReference] if this is a subcollection.
  AnsweredQuestionnaireDocumentReference get parent;

  @override
  QuestionnaireHistoryDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<QuestionnaireHistoryDocumentReference> add(QuestionnaireHistory value);
}

class _$QuestionnaireHistoryCollectionReference
    extends _$QuestionnaireHistoryQuery
    implements QuestionnaireHistoryCollectionReference {
  factory _$QuestionnaireHistoryCollectionReference(
    DocumentReference<AnsweredQuestionnaire> parent,
  ) {
    return _$QuestionnaireHistoryCollectionReference._(
      AnsweredQuestionnaireDocumentReference(parent),
      parent.collection('questionnaireHistories').withConverter(
            fromFirestore:
                QuestionnaireHistoryCollectionReference.fromFirestore,
            toFirestore: QuestionnaireHistoryCollectionReference.toFirestore,
          ),
    );
  }

  _$QuestionnaireHistoryCollectionReference._(
    this.parent,
    CollectionReference<QuestionnaireHistory> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final AnsweredQuestionnaireDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<QuestionnaireHistory> get reference =>
      super.reference as CollectionReference<QuestionnaireHistory>;

  @override
  QuestionnaireHistoryDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return QuestionnaireHistoryDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<QuestionnaireHistoryDocumentReference> add(
      QuestionnaireHistory value) {
    return reference
        .add(value)
        .then((ref) => QuestionnaireHistoryDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$QuestionnaireHistoryCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class QuestionnaireHistoryDocumentReference
    extends FirestoreDocumentReference<QuestionnaireHistory,
        QuestionnaireHistoryDocumentSnapshot> {
  factory QuestionnaireHistoryDocumentReference(
          DocumentReference<QuestionnaireHistory> reference) =
      _$QuestionnaireHistoryDocumentReference;

  DocumentReference<QuestionnaireHistory> get reference;

  /// A reference to the [QuestionnaireHistoryCollectionReference] containing this document.
  QuestionnaireHistoryCollectionReference get parent {
    return _$QuestionnaireHistoryCollectionReference(
      reference.parent.parent!.withConverter<AnsweredQuestionnaire>(
        fromFirestore: AnsweredQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AnsweredQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<QuestionnaireHistoryDocumentSnapshot> snapshots();

  @override
  Future<QuestionnaireHistoryDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String id,
    FieldValue idFieldValue,
    String message,
    FieldValue messageFieldValue,
    String choiceId,
    FieldValue choiceIdFieldValue,
    String choiceMessage,
    FieldValue choiceMessageFieldValue,
    int point,
    FieldValue pointFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String id,
    FieldValue idFieldValue,
    String message,
    FieldValue messageFieldValue,
    String choiceId,
    FieldValue choiceIdFieldValue,
    String choiceMessage,
    FieldValue choiceMessageFieldValue,
    int point,
    FieldValue pointFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$QuestionnaireHistoryDocumentReference
    extends FirestoreDocumentReference<QuestionnaireHistory,
        QuestionnaireHistoryDocumentSnapshot>
    implements QuestionnaireHistoryDocumentReference {
  _$QuestionnaireHistoryDocumentReference(this.reference);

  @override
  final DocumentReference<QuestionnaireHistory> reference;

  /// A reference to the [QuestionnaireHistoryCollectionReference] containing this document.
  QuestionnaireHistoryCollectionReference get parent {
    return _$QuestionnaireHistoryCollectionReference(
      reference.parent.parent!.withConverter<AnsweredQuestionnaire>(
        fromFirestore: AnsweredQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AnsweredQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<QuestionnaireHistoryDocumentSnapshot> snapshots() {
    return reference.snapshots().map(QuestionnaireHistoryDocumentSnapshot._);
  }

  @override
  Future<QuestionnaireHistoryDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(QuestionnaireHistoryDocumentSnapshot._);
  }

  @override
  Future<QuestionnaireHistoryDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction
        .get(reference)
        .then(QuestionnaireHistoryDocumentSnapshot._);
  }

  Future<void> update({
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? message = _sentinel,
    FieldValue? messageFieldValue,
    Object? choiceId = _sentinel,
    FieldValue? choiceIdFieldValue,
    Object? choiceMessage = _sentinel,
    FieldValue? choiceMessageFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      message == _sentinel || messageFieldValue == null,
      "Cannot specify both message and messageFieldValue",
    );
    assert(
      choiceId == _sentinel || choiceIdFieldValue == null,
      "Cannot specify both choiceId and choiceIdFieldValue",
    );
    assert(
      choiceMessage == _sentinel || choiceMessageFieldValue == null,
      "Cannot specify both choiceMessage and choiceMessageFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (message != _sentinel) 'message': message as String,
      if (messageFieldValue != null) 'message': messageFieldValue,
      if (choiceId != _sentinel) 'choiceId': choiceId as String,
      if (choiceIdFieldValue != null) 'choiceId': choiceIdFieldValue,
      if (choiceMessage != _sentinel) 'choiceMessage': choiceMessage as String,
      if (choiceMessageFieldValue != null)
        'choiceMessage': choiceMessageFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? message = _sentinel,
    FieldValue? messageFieldValue,
    Object? choiceId = _sentinel,
    FieldValue? choiceIdFieldValue,
    Object? choiceMessage = _sentinel,
    FieldValue? choiceMessageFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      message == _sentinel || messageFieldValue == null,
      "Cannot specify both message and messageFieldValue",
    );
    assert(
      choiceId == _sentinel || choiceIdFieldValue == null,
      "Cannot specify both choiceId and choiceIdFieldValue",
    );
    assert(
      choiceMessage == _sentinel || choiceMessageFieldValue == null,
      "Cannot specify both choiceMessage and choiceMessageFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (message != _sentinel) 'message': message as String,
      if (messageFieldValue != null) 'message': messageFieldValue,
      if (choiceId != _sentinel) 'choiceId': choiceId as String,
      if (choiceIdFieldValue != null) 'choiceId': choiceIdFieldValue,
      if (choiceMessage != _sentinel) 'choiceMessage': choiceMessage as String,
      if (choiceMessageFieldValue != null)
        'choiceMessage': choiceMessageFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is QuestionnaireHistoryDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class QuestionnaireHistoryQuery
    implements
        QueryReference<QuestionnaireHistory,
            QuestionnaireHistoryQuerySnapshot> {
  @override
  QuestionnaireHistoryQuery limit(int limit);

  @override
  QuestionnaireHistoryQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  QuestionnaireHistoryQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  QuestionnaireHistoryQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  QuestionnaireHistoryQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereChoiceId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereChoiceMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireHistoryQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  QuestionnaireHistoryQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  QuestionnaireHistoryQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderById({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByMessage({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByChoiceId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByChoiceMessage({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByPoint({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireHistoryQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  });
}

class _$QuestionnaireHistoryQuery extends QueryReference<QuestionnaireHistory,
    QuestionnaireHistoryQuerySnapshot> implements QuestionnaireHistoryQuery {
  _$QuestionnaireHistoryQuery(
    this._collection, {
    required Query<QuestionnaireHistory> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<QuestionnaireHistoryQuerySnapshot> snapshots(
      [SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(QuestionnaireHistoryQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<QuestionnaireHistoryQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(QuestionnaireHistoryQuerySnapshot._fromQuerySnapshot);
  }

  @override
  QuestionnaireHistoryQuery limit(int limit) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  QuestionnaireHistoryQuery limitToLast(int limit) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['id']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['message']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereChoiceId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['choiceId']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereChoiceMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['choiceMessage']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['point']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireHistoryFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderById({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['id']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByMessage({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['message']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByChoiceId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['choiceId']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByChoiceMessage({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['choiceMessage']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByPoint({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['point']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireHistoryQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireHistoryDocumentSnapshot? startAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endAtDocument,
    QuestionnaireHistoryDocumentSnapshot? endBeforeDocument,
    QuestionnaireHistoryDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireHistoryFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireHistoryQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$QuestionnaireHistoryQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class QuestionnaireHistoryDocumentSnapshot
    extends FirestoreDocumentSnapshot<QuestionnaireHistory> {
  QuestionnaireHistoryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final DocumentSnapshot<QuestionnaireHistory> snapshot;

  @override
  QuestionnaireHistoryDocumentReference get reference {
    return QuestionnaireHistoryDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final QuestionnaireHistory? data;
}

class QuestionnaireHistoryQuerySnapshot extends FirestoreQuerySnapshot<
    QuestionnaireHistory, QuestionnaireHistoryQueryDocumentSnapshot> {
  QuestionnaireHistoryQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory QuestionnaireHistoryQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<QuestionnaireHistory> snapshot,
  ) {
    final docs =
        snapshot.docs.map(QuestionnaireHistoryQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        QuestionnaireHistoryDocumentSnapshot._,
      );
    }).toList();

    return QuestionnaireHistoryQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<QuestionnaireHistoryDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    QuestionnaireHistoryDocumentSnapshot Function(DocumentSnapshot<T> doc)
        decodeDoc,
  ) {
    return FirestoreDocumentChange<QuestionnaireHistoryDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<QuestionnaireHistory> snapshot;

  @override
  final List<QuestionnaireHistoryQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<QuestionnaireHistoryDocumentSnapshot>>
      docChanges;
}

class QuestionnaireHistoryQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<QuestionnaireHistory>
    implements QuestionnaireHistoryDocumentSnapshot {
  QuestionnaireHistoryQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<QuestionnaireHistory> snapshot;

  @override
  final QuestionnaireHistory data;

  @override
  QuestionnaireHistoryDocumentReference get reference {
    return QuestionnaireHistoryDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AnsweredQuestionnaire _$$_AnsweredQuestionnaireFromJson(
        Map<String, dynamic> json) =>
    _$_AnsweredQuestionnaire(
      memberRef: const DocumentReferenceConverter()
          .fromJson(json['memberRef'] as DocumentReference<Object?>),
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_AnsweredQuestionnaireFieldMap = <String, String>{
  'memberRef': 'memberRef',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_AnsweredQuestionnaireToJson(
    _$_AnsweredQuestionnaire instance) {
  final val = <String, dynamic>{
    'memberRef': const DocumentReferenceConverter().toJson(instance.memberRef),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_QuestionnaireHistory _$$_QuestionnaireHistoryFromJson(
        Map<String, dynamic> json) =>
    _$_QuestionnaireHistory(
      id: json['id'] as String,
      message: json['message'] as String,
      choiceId: json['choiceId'] as String,
      choiceMessage: json['choiceMessage'] as String,
      point: json['point'] as int,
      memberRef: const DocumentReferenceConverter()
          .fromJson(json['memberRef'] as DocumentReference<Object?>),
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_QuestionnaireHistoryFieldMap = <String, String>{
  'id': 'id',
  'message': 'message',
  'choiceId': 'choiceId',
  'choiceMessage': 'choiceMessage',
  'point': 'point',
  'memberRef': 'memberRef',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_QuestionnaireHistoryToJson(
    _$_QuestionnaireHistory instance) {
  final val = <String, dynamic>{
    'id': instance.id,
    'message': instance.message,
    'choiceId': instance.choiceId,
    'choiceMessage': instance.choiceMessage,
    'point': instance.point,
    'memberRef': const DocumentReferenceConverter().toJson(instance.memberRef),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

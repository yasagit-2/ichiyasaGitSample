// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'setting.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Setting _$SettingFromJson(Map<String, dynamic> json) {
  return _Setting.fromJson(json);
}

/// @nodoc
mixin _$Setting {
// 拠点アイコンURL
  String get baseIconUrl =>
      throw _privateConstructorUsedError; // チェックイン済み拠点アイコンURL
  String get baseCheckedInIconUrl =>
      throw _privateConstructorUsedError; // サブ拠点アイコンURL
  String get subBaseIconUrl => throw _privateConstructorUsedError; // 加盟店アイコンURL
  String get merchantIconUrl =>
      throw _privateConstructorUsedError; // 加盟店つぶやきアイコンURL
  String get merchantTweetIconUrl =>
      throw _privateConstructorUsedError; // 投稿アイコンURL
  String get postIconUrl =>
      throw _privateConstructorUsedError; // 行政投稿アラートアイコンURL
  String get adminAlertIconUrl =>
      throw _privateConstructorUsedError; // 行政投稿アンケートアイコンURL
  String get adminQuestionnaireIconUrl =>
      throw _privateConstructorUsedError; // チェックイン可能距離（meter）
  double get checkInRadius =>
      throw _privateConstructorUsedError; // 拠点/投稿/加盟店収集半径(km)
  double get collectionRadius => throw _privateConstructorUsedError; // 週間規定歩数
  int get targetStepPerWeek =>
      throw _privateConstructorUsedError; // 週間規定歩数達成ポイント
  int get stepAchievedPoint =>
      throw _privateConstructorUsedError; // 投稿間隔制限（hour）
  int get postIntervalLimitHour =>
      throw _privateConstructorUsedError; // 行政報告間隔制限（hour）
  int get reportIntervalLimitHour =>
      throw _privateConstructorUsedError; // コメント間隔制限（minute）
  int get commentIntervalLimitMinute =>
      throw _privateConstructorUsedError; // お知らせ保存日数
  int get notificationRetentionDay =>
      throw _privateConstructorUsedError; // イベント保存日数
  int get eventRetentionDay =>
      throw _privateConstructorUsedError; // プライバシーポリシーURL
  String get privacyPolicyUrl =>
      throw _privateConstructorUsedError; // ヘルプページURL
  String get helpPageUrl => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SettingCopyWith<Setting> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SettingCopyWith<$Res> {
  factory $SettingCopyWith(Setting value, $Res Function(Setting) then) =
      _$SettingCopyWithImpl<$Res, Setting>;
  @useResult
  $Res call(
      {String baseIconUrl,
      String baseCheckedInIconUrl,
      String subBaseIconUrl,
      String merchantIconUrl,
      String merchantTweetIconUrl,
      String postIconUrl,
      String adminAlertIconUrl,
      String adminQuestionnaireIconUrl,
      double checkInRadius,
      double collectionRadius,
      int targetStepPerWeek,
      int stepAchievedPoint,
      int postIntervalLimitHour,
      int reportIntervalLimitHour,
      int commentIntervalLimitMinute,
      int notificationRetentionDay,
      int eventRetentionDay,
      String privacyPolicyUrl,
      String helpPageUrl,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$SettingCopyWithImpl<$Res, $Val extends Setting>
    implements $SettingCopyWith<$Res> {
  _$SettingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIconUrl = null,
    Object? baseCheckedInIconUrl = null,
    Object? subBaseIconUrl = null,
    Object? merchantIconUrl = null,
    Object? merchantTweetIconUrl = null,
    Object? postIconUrl = null,
    Object? adminAlertIconUrl = null,
    Object? adminQuestionnaireIconUrl = null,
    Object? checkInRadius = null,
    Object? collectionRadius = null,
    Object? targetStepPerWeek = null,
    Object? stepAchievedPoint = null,
    Object? postIntervalLimitHour = null,
    Object? reportIntervalLimitHour = null,
    Object? commentIntervalLimitMinute = null,
    Object? notificationRetentionDay = null,
    Object? eventRetentionDay = null,
    Object? privacyPolicyUrl = null,
    Object? helpPageUrl = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      baseIconUrl: null == baseIconUrl
          ? _value.baseIconUrl
          : baseIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      baseCheckedInIconUrl: null == baseCheckedInIconUrl
          ? _value.baseCheckedInIconUrl
          : baseCheckedInIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      subBaseIconUrl: null == subBaseIconUrl
          ? _value.subBaseIconUrl
          : subBaseIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      merchantIconUrl: null == merchantIconUrl
          ? _value.merchantIconUrl
          : merchantIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      merchantTweetIconUrl: null == merchantTweetIconUrl
          ? _value.merchantTweetIconUrl
          : merchantTweetIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      postIconUrl: null == postIconUrl
          ? _value.postIconUrl
          : postIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      adminAlertIconUrl: null == adminAlertIconUrl
          ? _value.adminAlertIconUrl
          : adminAlertIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      adminQuestionnaireIconUrl: null == adminQuestionnaireIconUrl
          ? _value.adminQuestionnaireIconUrl
          : adminQuestionnaireIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      checkInRadius: null == checkInRadius
          ? _value.checkInRadius
          : checkInRadius // ignore: cast_nullable_to_non_nullable
              as double,
      collectionRadius: null == collectionRadius
          ? _value.collectionRadius
          : collectionRadius // ignore: cast_nullable_to_non_nullable
              as double,
      targetStepPerWeek: null == targetStepPerWeek
          ? _value.targetStepPerWeek
          : targetStepPerWeek // ignore: cast_nullable_to_non_nullable
              as int,
      stepAchievedPoint: null == stepAchievedPoint
          ? _value.stepAchievedPoint
          : stepAchievedPoint // ignore: cast_nullable_to_non_nullable
              as int,
      postIntervalLimitHour: null == postIntervalLimitHour
          ? _value.postIntervalLimitHour
          : postIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      reportIntervalLimitHour: null == reportIntervalLimitHour
          ? _value.reportIntervalLimitHour
          : reportIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      commentIntervalLimitMinute: null == commentIntervalLimitMinute
          ? _value.commentIntervalLimitMinute
          : commentIntervalLimitMinute // ignore: cast_nullable_to_non_nullable
              as int,
      notificationRetentionDay: null == notificationRetentionDay
          ? _value.notificationRetentionDay
          : notificationRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      eventRetentionDay: null == eventRetentionDay
          ? _value.eventRetentionDay
          : eventRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      privacyPolicyUrl: null == privacyPolicyUrl
          ? _value.privacyPolicyUrl
          : privacyPolicyUrl // ignore: cast_nullable_to_non_nullable
              as String,
      helpPageUrl: null == helpPageUrl
          ? _value.helpPageUrl
          : helpPageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_SettingCopyWith<$Res> implements $SettingCopyWith<$Res> {
  factory _$$_SettingCopyWith(
          _$_Setting value, $Res Function(_$_Setting) then) =
      __$$_SettingCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String baseIconUrl,
      String baseCheckedInIconUrl,
      String subBaseIconUrl,
      String merchantIconUrl,
      String merchantTweetIconUrl,
      String postIconUrl,
      String adminAlertIconUrl,
      String adminQuestionnaireIconUrl,
      double checkInRadius,
      double collectionRadius,
      int targetStepPerWeek,
      int stepAchievedPoint,
      int postIntervalLimitHour,
      int reportIntervalLimitHour,
      int commentIntervalLimitMinute,
      int notificationRetentionDay,
      int eventRetentionDay,
      String privacyPolicyUrl,
      String helpPageUrl,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_SettingCopyWithImpl<$Res>
    extends _$SettingCopyWithImpl<$Res, _$_Setting>
    implements _$$_SettingCopyWith<$Res> {
  __$$_SettingCopyWithImpl(_$_Setting _value, $Res Function(_$_Setting) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseIconUrl = null,
    Object? baseCheckedInIconUrl = null,
    Object? subBaseIconUrl = null,
    Object? merchantIconUrl = null,
    Object? merchantTweetIconUrl = null,
    Object? postIconUrl = null,
    Object? adminAlertIconUrl = null,
    Object? adminQuestionnaireIconUrl = null,
    Object? checkInRadius = null,
    Object? collectionRadius = null,
    Object? targetStepPerWeek = null,
    Object? stepAchievedPoint = null,
    Object? postIntervalLimitHour = null,
    Object? reportIntervalLimitHour = null,
    Object? commentIntervalLimitMinute = null,
    Object? notificationRetentionDay = null,
    Object? eventRetentionDay = null,
    Object? privacyPolicyUrl = null,
    Object? helpPageUrl = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Setting(
      baseIconUrl: null == baseIconUrl
          ? _value.baseIconUrl
          : baseIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      baseCheckedInIconUrl: null == baseCheckedInIconUrl
          ? _value.baseCheckedInIconUrl
          : baseCheckedInIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      subBaseIconUrl: null == subBaseIconUrl
          ? _value.subBaseIconUrl
          : subBaseIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      merchantIconUrl: null == merchantIconUrl
          ? _value.merchantIconUrl
          : merchantIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      merchantTweetIconUrl: null == merchantTweetIconUrl
          ? _value.merchantTweetIconUrl
          : merchantTweetIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      postIconUrl: null == postIconUrl
          ? _value.postIconUrl
          : postIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      adminAlertIconUrl: null == adminAlertIconUrl
          ? _value.adminAlertIconUrl
          : adminAlertIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      adminQuestionnaireIconUrl: null == adminQuestionnaireIconUrl
          ? _value.adminQuestionnaireIconUrl
          : adminQuestionnaireIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      checkInRadius: null == checkInRadius
          ? _value.checkInRadius
          : checkInRadius // ignore: cast_nullable_to_non_nullable
              as double,
      collectionRadius: null == collectionRadius
          ? _value.collectionRadius
          : collectionRadius // ignore: cast_nullable_to_non_nullable
              as double,
      targetStepPerWeek: null == targetStepPerWeek
          ? _value.targetStepPerWeek
          : targetStepPerWeek // ignore: cast_nullable_to_non_nullable
              as int,
      stepAchievedPoint: null == stepAchievedPoint
          ? _value.stepAchievedPoint
          : stepAchievedPoint // ignore: cast_nullable_to_non_nullable
              as int,
      postIntervalLimitHour: null == postIntervalLimitHour
          ? _value.postIntervalLimitHour
          : postIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      reportIntervalLimitHour: null == reportIntervalLimitHour
          ? _value.reportIntervalLimitHour
          : reportIntervalLimitHour // ignore: cast_nullable_to_non_nullable
              as int,
      commentIntervalLimitMinute: null == commentIntervalLimitMinute
          ? _value.commentIntervalLimitMinute
          : commentIntervalLimitMinute // ignore: cast_nullable_to_non_nullable
              as int,
      notificationRetentionDay: null == notificationRetentionDay
          ? _value.notificationRetentionDay
          : notificationRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      eventRetentionDay: null == eventRetentionDay
          ? _value.eventRetentionDay
          : eventRetentionDay // ignore: cast_nullable_to_non_nullable
              as int,
      privacyPolicyUrl: null == privacyPolicyUrl
          ? _value.privacyPolicyUrl
          : privacyPolicyUrl // ignore: cast_nullable_to_non_nullable
              as String,
      helpPageUrl: null == helpPageUrl
          ? _value.helpPageUrl
          : helpPageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Setting implements _Setting {
  const _$_Setting(
      {required this.baseIconUrl,
      required this.baseCheckedInIconUrl,
      required this.subBaseIconUrl,
      required this.merchantIconUrl,
      required this.merchantTweetIconUrl,
      required this.postIconUrl,
      required this.adminAlertIconUrl,
      required this.adminQuestionnaireIconUrl,
      required this.checkInRadius,
      required this.collectionRadius,
      required this.targetStepPerWeek,
      required this.stepAchievedPoint,
      required this.postIntervalLimitHour,
      required this.reportIntervalLimitHour,
      required this.commentIntervalLimitMinute,
      required this.notificationRetentionDay,
      required this.eventRetentionDay,
      required this.privacyPolicyUrl,
      required this.helpPageUrl,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Setting.fromJson(Map<String, dynamic> json) =>
      _$$_SettingFromJson(json);

// 拠点アイコンURL
  @override
  final String baseIconUrl;
// チェックイン済み拠点アイコンURL
  @override
  final String baseCheckedInIconUrl;
// サブ拠点アイコンURL
  @override
  final String subBaseIconUrl;
// 加盟店アイコンURL
  @override
  final String merchantIconUrl;
// 加盟店つぶやきアイコンURL
  @override
  final String merchantTweetIconUrl;
// 投稿アイコンURL
  @override
  final String postIconUrl;
// 行政投稿アラートアイコンURL
  @override
  final String adminAlertIconUrl;
// 行政投稿アンケートアイコンURL
  @override
  final String adminQuestionnaireIconUrl;
// チェックイン可能距離（meter）
  @override
  final double checkInRadius;
// 拠点/投稿/加盟店収集半径(km)
  @override
  final double collectionRadius;
// 週間規定歩数
  @override
  final int targetStepPerWeek;
// 週間規定歩数達成ポイント
  @override
  final int stepAchievedPoint;
// 投稿間隔制限（hour）
  @override
  final int postIntervalLimitHour;
// 行政報告間隔制限（hour）
  @override
  final int reportIntervalLimitHour;
// コメント間隔制限（minute）
  @override
  final int commentIntervalLimitMinute;
// お知らせ保存日数
  @override
  final int notificationRetentionDay;
// イベント保存日数
  @override
  final int eventRetentionDay;
// プライバシーポリシーURL
  @override
  final String privacyPolicyUrl;
// ヘルプページURL
  @override
  final String helpPageUrl;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Setting(baseIconUrl: $baseIconUrl, baseCheckedInIconUrl: $baseCheckedInIconUrl, subBaseIconUrl: $subBaseIconUrl, merchantIconUrl: $merchantIconUrl, merchantTweetIconUrl: $merchantTweetIconUrl, postIconUrl: $postIconUrl, adminAlertIconUrl: $adminAlertIconUrl, adminQuestionnaireIconUrl: $adminQuestionnaireIconUrl, checkInRadius: $checkInRadius, collectionRadius: $collectionRadius, targetStepPerWeek: $targetStepPerWeek, stepAchievedPoint: $stepAchievedPoint, postIntervalLimitHour: $postIntervalLimitHour, reportIntervalLimitHour: $reportIntervalLimitHour, commentIntervalLimitMinute: $commentIntervalLimitMinute, notificationRetentionDay: $notificationRetentionDay, eventRetentionDay: $eventRetentionDay, privacyPolicyUrl: $privacyPolicyUrl, helpPageUrl: $helpPageUrl, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Setting &&
            (identical(other.baseIconUrl, baseIconUrl) ||
                other.baseIconUrl == baseIconUrl) &&
            (identical(other.baseCheckedInIconUrl, baseCheckedInIconUrl) ||
                other.baseCheckedInIconUrl == baseCheckedInIconUrl) &&
            (identical(other.subBaseIconUrl, subBaseIconUrl) ||
                other.subBaseIconUrl == subBaseIconUrl) &&
            (identical(other.merchantIconUrl, merchantIconUrl) ||
                other.merchantIconUrl == merchantIconUrl) &&
            (identical(other.merchantTweetIconUrl, merchantTweetIconUrl) ||
                other.merchantTweetIconUrl == merchantTweetIconUrl) &&
            (identical(other.postIconUrl, postIconUrl) ||
                other.postIconUrl == postIconUrl) &&
            (identical(other.adminAlertIconUrl, adminAlertIconUrl) ||
                other.adminAlertIconUrl == adminAlertIconUrl) &&
            (identical(other.adminQuestionnaireIconUrl,
                    adminQuestionnaireIconUrl) ||
                other.adminQuestionnaireIconUrl == adminQuestionnaireIconUrl) &&
            (identical(other.checkInRadius, checkInRadius) ||
                other.checkInRadius == checkInRadius) &&
            (identical(other.collectionRadius, collectionRadius) ||
                other.collectionRadius == collectionRadius) &&
            (identical(other.targetStepPerWeek, targetStepPerWeek) ||
                other.targetStepPerWeek == targetStepPerWeek) &&
            (identical(other.stepAchievedPoint, stepAchievedPoint) ||
                other.stepAchievedPoint == stepAchievedPoint) &&
            (identical(other.postIntervalLimitHour, postIntervalLimitHour) ||
                other.postIntervalLimitHour == postIntervalLimitHour) &&
            (identical(other.reportIntervalLimitHour, reportIntervalLimitHour) ||
                other.reportIntervalLimitHour == reportIntervalLimitHour) &&
            (identical(other.commentIntervalLimitMinute,
                    commentIntervalLimitMinute) ||
                other.commentIntervalLimitMinute ==
                    commentIntervalLimitMinute) &&
            (identical(
                    other.notificationRetentionDay, notificationRetentionDay) ||
                other.notificationRetentionDay == notificationRetentionDay) &&
            (identical(other.eventRetentionDay, eventRetentionDay) ||
                other.eventRetentionDay == eventRetentionDay) &&
            (identical(other.privacyPolicyUrl, privacyPolicyUrl) ||
                other.privacyPolicyUrl == privacyPolicyUrl) &&
            (identical(other.helpPageUrl, helpPageUrl) ||
                other.helpPageUrl == helpPageUrl) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        baseIconUrl,
        baseCheckedInIconUrl,
        subBaseIconUrl,
        merchantIconUrl,
        merchantTweetIconUrl,
        postIconUrl,
        adminAlertIconUrl,
        adminQuestionnaireIconUrl,
        checkInRadius,
        collectionRadius,
        targetStepPerWeek,
        stepAchievedPoint,
        postIntervalLimitHour,
        reportIntervalLimitHour,
        commentIntervalLimitMinute,
        notificationRetentionDay,
        eventRetentionDay,
        privacyPolicyUrl,
        helpPageUrl,
        updatedAt,
        createdAt
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SettingCopyWith<_$_Setting> get copyWith =>
      __$$_SettingCopyWithImpl<_$_Setting>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SettingToJson(
      this,
    );
  }
}

abstract class _Setting implements Setting {
  const factory _Setting(
      {required final String baseIconUrl,
      required final String baseCheckedInIconUrl,
      required final String subBaseIconUrl,
      required final String merchantIconUrl,
      required final String merchantTweetIconUrl,
      required final String postIconUrl,
      required final String adminAlertIconUrl,
      required final String adminQuestionnaireIconUrl,
      required final double checkInRadius,
      required final double collectionRadius,
      required final int targetStepPerWeek,
      required final int stepAchievedPoint,
      required final int postIntervalLimitHour,
      required final int reportIntervalLimitHour,
      required final int commentIntervalLimitMinute,
      required final int notificationRetentionDay,
      required final int eventRetentionDay,
      required final String privacyPolicyUrl,
      required final String helpPageUrl,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Setting;

  factory _Setting.fromJson(Map<String, dynamic> json) = _$_Setting.fromJson;

  @override // 拠点アイコンURL
  String get baseIconUrl;
  @override // チェックイン済み拠点アイコンURL
  String get baseCheckedInIconUrl;
  @override // サブ拠点アイコンURL
  String get subBaseIconUrl;
  @override // 加盟店アイコンURL
  String get merchantIconUrl;
  @override // 加盟店つぶやきアイコンURL
  String get merchantTweetIconUrl;
  @override // 投稿アイコンURL
  String get postIconUrl;
  @override // 行政投稿アラートアイコンURL
  String get adminAlertIconUrl;
  @override // 行政投稿アンケートアイコンURL
  String get adminQuestionnaireIconUrl;
  @override // チェックイン可能距離（meter）
  double get checkInRadius;
  @override // 拠点/投稿/加盟店収集半径(km)
  double get collectionRadius;
  @override // 週間規定歩数
  int get targetStepPerWeek;
  @override // 週間規定歩数達成ポイント
  int get stepAchievedPoint;
  @override // 投稿間隔制限（hour）
  int get postIntervalLimitHour;
  @override // 行政報告間隔制限（hour）
  int get reportIntervalLimitHour;
  @override // コメント間隔制限（minute）
  int get commentIntervalLimitMinute;
  @override // お知らせ保存日数
  int get notificationRetentionDay;
  @override // イベント保存日数
  int get eventRetentionDay;
  @override // プライバシーポリシーURL
  String get privacyPolicyUrl;
  @override // ヘルプページURL
  String get helpPageUrl;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_SettingCopyWith<_$_Setting> get copyWith =>
      throw _privateConstructorUsedError;
}

Week _$WeekFromJson(Map<String, dynamic> json) {
  return _Week.fromJson(json);
}

/// @nodoc
mixin _$Week {
// ポイント付与制限人数
  int get stepPointLimit => throw _privateConstructorUsedError; // ポイント付与制限人数残り
  int get stepPointLimitRemain => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WeekCopyWith<Week> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WeekCopyWith<$Res> {
  factory $WeekCopyWith(Week value, $Res Function(Week) then) =
      _$WeekCopyWithImpl<$Res, Week>;
  @useResult
  $Res call(
      {int stepPointLimit,
      int stepPointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$WeekCopyWithImpl<$Res, $Val extends Week>
    implements $WeekCopyWith<$Res> {
  _$WeekCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? stepPointLimit = null,
    Object? stepPointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      stepPointLimit: null == stepPointLimit
          ? _value.stepPointLimit
          : stepPointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      stepPointLimitRemain: null == stepPointLimitRemain
          ? _value.stepPointLimitRemain
          : stepPointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_WeekCopyWith<$Res> implements $WeekCopyWith<$Res> {
  factory _$$_WeekCopyWith(_$_Week value, $Res Function(_$_Week) then) =
      __$$_WeekCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int stepPointLimit,
      int stepPointLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_WeekCopyWithImpl<$Res> extends _$WeekCopyWithImpl<$Res, _$_Week>
    implements _$$_WeekCopyWith<$Res> {
  __$$_WeekCopyWithImpl(_$_Week _value, $Res Function(_$_Week) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? stepPointLimit = null,
    Object? stepPointLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Week(
      stepPointLimit: null == stepPointLimit
          ? _value.stepPointLimit
          : stepPointLimit // ignore: cast_nullable_to_non_nullable
              as int,
      stepPointLimitRemain: null == stepPointLimitRemain
          ? _value.stepPointLimitRemain
          : stepPointLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Week implements _Week {
  const _$_Week(
      {required this.stepPointLimit,
      required this.stepPointLimitRemain,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Week.fromJson(Map<String, dynamic> json) => _$$_WeekFromJson(json);

// ポイント付与制限人数
  @override
  final int stepPointLimit;
// ポイント付与制限人数残り
  @override
  final int stepPointLimitRemain;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Week(stepPointLimit: $stepPointLimit, stepPointLimitRemain: $stepPointLimitRemain, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Week &&
            (identical(other.stepPointLimit, stepPointLimit) ||
                other.stepPointLimit == stepPointLimit) &&
            (identical(other.stepPointLimitRemain, stepPointLimitRemain) ||
                other.stepPointLimitRemain == stepPointLimitRemain) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, stepPointLimit, stepPointLimitRemain, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WeekCopyWith<_$_Week> get copyWith =>
      __$$_WeekCopyWithImpl<_$_Week>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WeekToJson(
      this,
    );
  }
}

abstract class _Week implements Week {
  const factory _Week(
      {required final int stepPointLimit,
      required final int stepPointLimitRemain,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Week;

  factory _Week.fromJson(Map<String, dynamic> json) = _$_Week.fromJson;

  @override // ポイント付与制限人数
  int get stepPointLimit;
  @override // ポイント付与制限人数残り
  int get stepPointLimitRemain;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_WeekCopyWith<_$_Week> get copyWith => throw _privateConstructorUsedError;
}

PostIcon _$PostIconFromJson(Map<String, dynamic> json) {
  return _PostIcon.fromJson(json);
}

/// @nodoc
mixin _$PostIcon {
// いいね数単位の投稿アイコンURL
  String get unitOfLikePostIconUrl =>
      throw _privateConstructorUsedError; // いいね数
  int get likeCount => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PostIconCopyWith<PostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostIconCopyWith<$Res> {
  factory $PostIconCopyWith(PostIcon value, $Res Function(PostIcon) then) =
      _$PostIconCopyWithImpl<$Res, PostIcon>;
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$PostIconCopyWithImpl<$Res, $Val extends PostIcon>
    implements $PostIconCopyWith<$Res> {
  _$PostIconCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PostIconCopyWith<$Res> implements $PostIconCopyWith<$Res> {
  factory _$$_PostIconCopyWith(
          _$_PostIcon value, $Res Function(_$_PostIcon) then) =
      __$$_PostIconCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String unitOfLikePostIconUrl,
      int likeCount,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_PostIconCopyWithImpl<$Res>
    extends _$PostIconCopyWithImpl<$Res, _$_PostIcon>
    implements _$$_PostIconCopyWith<$Res> {
  __$$_PostIconCopyWithImpl(
      _$_PostIcon _value, $Res Function(_$_PostIcon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? unitOfLikePostIconUrl = null,
    Object? likeCount = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PostIcon(
      unitOfLikePostIconUrl: null == unitOfLikePostIconUrl
          ? _value.unitOfLikePostIconUrl
          : unitOfLikePostIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      likeCount: null == likeCount
          ? _value.likeCount
          : likeCount // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_PostIcon implements _PostIcon {
  const _$_PostIcon(
      {required this.unitOfLikePostIconUrl,
      required this.likeCount,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_PostIcon.fromJson(Map<String, dynamic> json) =>
      _$$_PostIconFromJson(json);

// いいね数単位の投稿アイコンURL
  @override
  final String unitOfLikePostIconUrl;
// いいね数
  @override
  final int likeCount;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PostIcon(unitOfLikePostIconUrl: $unitOfLikePostIconUrl, likeCount: $likeCount, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PostIcon &&
            (identical(other.unitOfLikePostIconUrl, unitOfLikePostIconUrl) ||
                other.unitOfLikePostIconUrl == unitOfLikePostIconUrl) &&
            (identical(other.likeCount, likeCount) ||
                other.likeCount == likeCount) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, unitOfLikePostIconUrl, likeCount, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostIconCopyWith<_$_PostIcon> get copyWith =>
      __$$_PostIconCopyWithImpl<_$_PostIcon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PostIconToJson(
      this,
    );
  }
}

abstract class _PostIcon implements PostIcon {
  const factory _PostIcon(
      {required final String unitOfLikePostIconUrl,
      required final int likeCount,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_PostIcon;

  factory _PostIcon.fromJson(Map<String, dynamic> json) = _$_PostIcon.fromJson;

  @override // いいね数単位の投稿アイコンURL
  String get unitOfLikePostIconUrl;
  @override // いいね数
  int get likeCount;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostIconCopyWith<_$_PostIcon> get copyWith =>
      throw _privateConstructorUsedError;
}

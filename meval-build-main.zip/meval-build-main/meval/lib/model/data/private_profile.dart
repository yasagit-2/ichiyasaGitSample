import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'device_info.dart';
import 'firestore_serializable.dart';

part 'private_profile.freezed.dart';
part 'private_profile.g.dart';

@freezed
class PrivateProfile with _$PrivateProfile {
  @firestoreSerializable
  const factory PrivateProfile({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // デバイス情報
    required DeviceInfo deviceInfo,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _PrivateProfile;

  factory PrivateProfile.fromJson(Map<String, Object?> json) =>
      _$PrivateProfileFromJson(json);
}

@Collection<PrivateProfile>('privateProfiles')
final privateProfilesRef = PrivateProfileCollectionReference();

PrivateProfileDocumentReference privateProfileRef({required String id}) =>
    PrivateProfileDocumentReference(privateProfilesRef.doc(id).reference);

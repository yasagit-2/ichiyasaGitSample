import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'summary.freezed.dart';
part 'summary.g.dart';

const summaryDocumentId = 'mevalAppSummaries';

/// サマリ
@freezed
class Summary with _$Summary {
  @firestoreSerializable
  const factory Summary({
    // 会員数
    required int totalMember,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Summary;

  factory Summary.fromJson(Map<String, Object?> json) =>
      _$SummaryFromJson(json);
}

@Collection<Summary>('summaries')
@Collection<Ranking>('summaries/*/rankings', name: 'rankings')
final summariesRef = SummaryCollectionReference();

SummaryDocumentReference summaryRef({required String id}) =>
    SummaryDocumentReference(summariesRef.doc(id).reference);

/// ランキング
@freezed
class Ranking with _$Ranking {
  @firestoreSerializable
  const factory Ranking({
    // 順位
    required int rank,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Ranking;

  factory Ranking.fromJson(Map<String, Object?> json) =>
      _$RankingFromJson(json);
}

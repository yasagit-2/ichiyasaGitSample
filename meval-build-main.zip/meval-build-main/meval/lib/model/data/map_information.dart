import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

part 'map_information.freezed.dart';
part 'map_information.g.dart';

@freezed
class MapInformation with _$MapInformation {
  const factory MapInformation({
    // 拠点ドキュメントリスト
    @Default(<DocumentSnapshot>[]) bases,
    // 投稿ドキュメントリスト
    @Default(<DocumentSnapshot>[]) posts,
    // 行政投稿アラートドキュメントリスト
    @Default(<DocumentSnapshot>[]) adminAlert,
    // 行政投稿アンケートドキュメントリスト
    @Default(<DocumentSnapshot>[]) adminQuestionnaire,
    // 加盟店ドキュメントリスト
    @Default(<DocumentSnapshot>[]) merchants,
    // 拠点マーカー
    @Default(<Marker>{}) baseMarkers,
    // 投稿マーカー
    @Default(<Marker>{}) postMarkers,
    // 行政投稿アラートマーカー
    @Default(<Marker>{}) adminAlertMarkers,
    // 行政投稿アンケートマーカー
    @Default(<Marker>{}) adminQuestionnaireMarkers,
    // 加盟店マーカー
    @Default(<Marker>{}) merchantMarkers,
    // 拠点サークル
    @Default(<Circle>{}) baseCircles,
    // 投稿準備マーカー
    @Default(<Marker>{}) postingPreparationMarker,
  }) = _MapInformation;

  factory MapInformation.fromJson(Map<String, Object?> json) =>
      _$MapInformationFromJson(json);
}

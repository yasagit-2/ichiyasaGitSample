// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'device_info.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DeviceInfo _$$_DeviceInfoFromJson(Map<String, dynamic> json) =>
    _$_DeviceInfo(
      os: json['os'] as String,
      version: json['version'] as String,
      device: json['device'] as String,
    );

const _$$_DeviceInfoFieldMap = <String, String>{
  'os': 'os',
  'version': 'version',
  'device': 'device',
};

Map<String, dynamic> _$$_DeviceInfoToJson(_$_DeviceInfo instance) =>
    <String, dynamic>{
      'os': instance.os,
      'version': instance.version,
      'device': instance.device,
    };

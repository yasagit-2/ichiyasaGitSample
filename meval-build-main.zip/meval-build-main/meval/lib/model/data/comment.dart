import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'comment.freezed.dart';
part 'comment.g.dart';

@freezed
class Comment with _$Comment {
  @firestoreSerializable
  const factory Comment({
    // コメントID
    required String id,
    // コメント本文
    required String message,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 投稿のReference
    @DocumentReferenceConverter() required DocumentReference postRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Comment;

  factory Comment.fromJson(Map<String, Object?> json) =>
      _$CommentFromJson(json);
}

@Collection<Comment>('comments')
final commentsRef = CommentCollectionReference();

CommentDocumentReference commentRef({required String id}) =>
    CommentDocumentReference(commentsRef.doc(id).reference);

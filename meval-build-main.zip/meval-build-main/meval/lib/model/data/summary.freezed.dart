// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'summary.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Summary _$SummaryFromJson(Map<String, dynamic> json) {
  return _Summary.fromJson(json);
}

/// @nodoc
mixin _$Summary {
// 会員数
  int get totalMember => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SummaryCopyWith<Summary> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SummaryCopyWith<$Res> {
  factory $SummaryCopyWith(Summary value, $Res Function(Summary) then) =
      _$SummaryCopyWithImpl<$Res, Summary>;
  @useResult
  $Res call(
      {int totalMember,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$SummaryCopyWithImpl<$Res, $Val extends Summary>
    implements $SummaryCopyWith<$Res> {
  _$SummaryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalMember = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      totalMember: null == totalMember
          ? _value.totalMember
          : totalMember // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_SummaryCopyWith<$Res> implements $SummaryCopyWith<$Res> {
  factory _$$_SummaryCopyWith(
          _$_Summary value, $Res Function(_$_Summary) then) =
      __$$_SummaryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int totalMember,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_SummaryCopyWithImpl<$Res>
    extends _$SummaryCopyWithImpl<$Res, _$_Summary>
    implements _$$_SummaryCopyWith<$Res> {
  __$$_SummaryCopyWithImpl(_$_Summary _value, $Res Function(_$_Summary) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalMember = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Summary(
      totalMember: null == totalMember
          ? _value.totalMember
          : totalMember // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Summary implements _Summary {
  const _$_Summary(
      {required this.totalMember,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Summary.fromJson(Map<String, dynamic> json) =>
      _$$_SummaryFromJson(json);

// 会員数
  @override
  final int totalMember;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Summary(totalMember: $totalMember, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Summary &&
            (identical(other.totalMember, totalMember) ||
                other.totalMember == totalMember) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, totalMember, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SummaryCopyWith<_$_Summary> get copyWith =>
      __$$_SummaryCopyWithImpl<_$_Summary>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SummaryToJson(
      this,
    );
  }
}

abstract class _Summary implements Summary {
  const factory _Summary(
      {required final int totalMember,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Summary;

  factory _Summary.fromJson(Map<String, dynamic> json) = _$_Summary.fromJson;

  @override // 会員数
  int get totalMember;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_SummaryCopyWith<_$_Summary> get copyWith =>
      throw _privateConstructorUsedError;
}

Ranking _$RankingFromJson(Map<String, dynamic> json) {
  return _Ranking.fromJson(json);
}

/// @nodoc
mixin _$Ranking {
// 順位
  int get rank => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RankingCopyWith<Ranking> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RankingCopyWith<$Res> {
  factory $RankingCopyWith(Ranking value, $Res Function(Ranking) then) =
      _$RankingCopyWithImpl<$Res, Ranking>;
  @useResult
  $Res call(
      {int rank,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$RankingCopyWithImpl<$Res, $Val extends Ranking>
    implements $RankingCopyWith<$Res> {
  _$RankingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rank = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      rank: null == rank
          ? _value.rank
          : rank // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_RankingCopyWith<$Res> implements $RankingCopyWith<$Res> {
  factory _$$_RankingCopyWith(
          _$_Ranking value, $Res Function(_$_Ranking) then) =
      __$$_RankingCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int rank,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_RankingCopyWithImpl<$Res>
    extends _$RankingCopyWithImpl<$Res, _$_Ranking>
    implements _$$_RankingCopyWith<$Res> {
  __$$_RankingCopyWithImpl(_$_Ranking _value, $Res Function(_$_Ranking) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rank = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Ranking(
      rank: null == rank
          ? _value.rank
          : rank // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Ranking implements _Ranking {
  const _$_Ranking(
      {required this.rank,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Ranking.fromJson(Map<String, dynamic> json) =>
      _$$_RankingFromJson(json);

// 順位
  @override
  final int rank;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Ranking(rank: $rank, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Ranking &&
            (identical(other.rank, rank) || other.rank == rank) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, rank, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_RankingCopyWith<_$_Ranking> get copyWith =>
      __$$_RankingCopyWithImpl<_$_Ranking>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_RankingToJson(
      this,
    );
  }
}

abstract class _Ranking implements Ranking {
  const factory _Ranking(
      {required final int rank,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_Ranking;

  factory _Ranking.fromJson(Map<String, dynamic> json) = _$_Ranking.fromJson;

  @override // 順位
  int get rank;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_RankingCopyWith<_$_Ranking> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';
import 'map_position.dart';
import 'map_position_mixin.dart';

part 'report.freezed.dart';
part 'report.g.dart';

/// 行政報告
@freezed
class Report with MapPositionMixin, _$Report {
  @firestoreSerializable
  const factory Report({
    // 行政報告ID
    required String id,
    // メッセージ
    required String message,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 行政報告地点の位置情報
    required MapPosition position,
    // 行政報告画像
    String? imageUrl,
    // 行政報告画像の保存先
    String? imagePath,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Report;

  factory Report.fromJson(Map<String, Object?> json) => _$ReportFromJson(json);
}

@Collection<Report>('reports')
final reportsRef = ReportCollectionReference();

ReportDocumentReference reportRef({required String id}) =>
    ReportDocumentReference(reportsRef.doc(id).reference);

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'answered_questionnaire.freezed.dart';
part 'answered_questionnaire.g.dart';

/// アンケート回答情報
@freezed
class AnsweredQuestionnaire with _$AnsweredQuestionnaire {
  @firestoreSerializable
  const factory AnsweredQuestionnaire({
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _AnsweredQuestionnaire;

  factory AnsweredQuestionnaire.fromJson(Map<String, Object?> json) =>
      _$AnsweredQuestionnaireFromJson(json);
}

@Collection<AnsweredQuestionnaire>('answeredQuestionnaires')
@Collection<QuestionnaireHistory>(
    'answeredQuestionnaires/*/questionnaireHistories',
    name: 'questionnaireHistories')
final answeredQuestionnairesRef = AnsweredQuestionnaireCollectionReference();

AnsweredQuestionnaireDocumentReference answeredQuestionnaireRef(
        {required String id}) =>
    AnsweredQuestionnaireDocumentReference(
        answeredQuestionnairesRef.doc(id).reference);

/// アンケート回答履歴
@freezed
class QuestionnaireHistory with _$QuestionnaireHistory {
  @firestoreSerializable
  const factory QuestionnaireHistory({
    // アンケートID
    required String id,
    // アンケートのメッセージ
    required String message,
    // 選択肢ID
    required String choiceId,
    // 選択肢の文言
    required String choiceMessage,
    // アンケート回答獲得ポイント
    required int point,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _QuestionnaireHistory;

  factory QuestionnaireHistory.fromJson(Map<String, Object?> json) =>
      _$QuestionnaireHistoryFromJson(json);
}

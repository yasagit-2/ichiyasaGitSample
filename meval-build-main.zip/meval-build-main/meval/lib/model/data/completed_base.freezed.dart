// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'completed_base.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CompletedBase _$CompletedBaseFromJson(Map<String, dynamic> json) {
  return _CompletedBase.fromJson(json);
}

/// @nodoc
mixin _$CompletedBase {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedBaseCopyWith<CompletedBase> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedBaseCopyWith<$Res> {
  factory $CompletedBaseCopyWith(
          CompletedBase value, $Res Function(CompletedBase) then) =
      _$CompletedBaseCopyWithImpl<$Res, CompletedBase>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CompletedBaseCopyWithImpl<$Res, $Val extends CompletedBase>
    implements $CompletedBaseCopyWith<$Res> {
  _$CompletedBaseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CompletedBaseCopyWith<$Res>
    implements $CompletedBaseCopyWith<$Res> {
  factory _$$_CompletedBaseCopyWith(
          _$_CompletedBase value, $Res Function(_$_CompletedBase) then) =
      __$$_CompletedBaseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CompletedBaseCopyWithImpl<$Res>
    extends _$CompletedBaseCopyWithImpl<$Res, _$_CompletedBase>
    implements _$$_CompletedBaseCopyWith<$Res> {
  __$$_CompletedBaseCopyWithImpl(
      _$_CompletedBase _value, $Res Function(_$_CompletedBase) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedBase(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedBase implements _CompletedBase {
  const _$_CompletedBase(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedBase.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedBaseFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedBase(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedBase &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedBaseCopyWith<_$_CompletedBase> get copyWith =>
      __$$_CompletedBaseCopyWithImpl<_$_CompletedBase>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedBaseToJson(
      this,
    );
  }
}

abstract class _CompletedBase implements CompletedBase {
  const factory _CompletedBase(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedBase;

  factory _CompletedBase.fromJson(Map<String, dynamic> json) =
      _$_CompletedBase.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedBaseCopyWith<_$_CompletedBase> get copyWith =>
      throw _privateConstructorUsedError;
}

CompletedParentBase _$CompletedParentBaseFromJson(Map<String, dynamic> json) {
  return _CompletedParentBase.fromJson(json);
}

/// @nodoc
mixin _$CompletedParentBase {
// 親拠点ID
  String get id => throw _privateConstructorUsedError; // 親拠点名称
  String get name => throw _privateConstructorUsedError; // 配下のサブ拠点数
  int get subBaseCount => throw _privateConstructorUsedError; // 称号ID
  String get titleId => throw _privateConstructorUsedError; // 称号名称
  String get titleName => throw _privateConstructorUsedError; // 獲得ポイント
  int get point => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 親拠点の位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedParentBaseCopyWith<CompletedParentBase> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedParentBaseCopyWith<$Res> {
  factory $CompletedParentBaseCopyWith(
          CompletedParentBase value, $Res Function(CompletedParentBase) then) =
      _$CompletedParentBaseCopyWithImpl<$Res, CompletedParentBase>;
  @useResult
  $Res call(
      {String id,
      String name,
      int subBaseCount,
      String titleId,
      String titleName,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$CompletedParentBaseCopyWithImpl<$Res, $Val extends CompletedParentBase>
    implements $CompletedParentBaseCopyWith<$Res> {
  _$CompletedParentBaseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? subBaseCount = null,
    Object? titleId = null,
    Object? titleName = null,
    Object? point = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      titleId: null == titleId
          ? _value.titleId
          : titleId // ignore: cast_nullable_to_non_nullable
              as String,
      titleName: null == titleName
          ? _value.titleName
          : titleName // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_CompletedParentBaseCopyWith<$Res>
    implements $CompletedParentBaseCopyWith<$Res> {
  factory _$$_CompletedParentBaseCopyWith(_$_CompletedParentBase value,
          $Res Function(_$_CompletedParentBase) then) =
      __$$_CompletedParentBaseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      int subBaseCount,
      String titleId,
      String titleName,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_CompletedParentBaseCopyWithImpl<$Res>
    extends _$CompletedParentBaseCopyWithImpl<$Res, _$_CompletedParentBase>
    implements _$$_CompletedParentBaseCopyWith<$Res> {
  __$$_CompletedParentBaseCopyWithImpl(_$_CompletedParentBase _value,
      $Res Function(_$_CompletedParentBase) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? subBaseCount = null,
    Object? titleId = null,
    Object? titleName = null,
    Object? point = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedParentBase(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      subBaseCount: null == subBaseCount
          ? _value.subBaseCount
          : subBaseCount // ignore: cast_nullable_to_non_nullable
              as int,
      titleId: null == titleId
          ? _value.titleId
          : titleId // ignore: cast_nullable_to_non_nullable
              as String,
      titleName: null == titleName
          ? _value.titleName
          : titleName // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedParentBase implements _CompletedParentBase {
  const _$_CompletedParentBase(
      {required this.id,
      required this.name,
      required this.subBaseCount,
      required this.titleId,
      required this.titleName,
      required this.point,
      @DocumentReferenceConverter() required this.memberRef,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedParentBase.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedParentBaseFromJson(json);

// 親拠点ID
  @override
  final String id;
// 親拠点名称
  @override
  final String name;
// 配下のサブ拠点数
  @override
  final int subBaseCount;
// 称号ID
  @override
  final String titleId;
// 称号名称
  @override
  final String titleName;
// 獲得ポイント
  @override
  final int point;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 親拠点の位置情報
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedParentBase(id: $id, name: $name, subBaseCount: $subBaseCount, titleId: $titleId, titleName: $titleName, point: $point, memberRef: $memberRef, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedParentBase &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.subBaseCount, subBaseCount) ||
                other.subBaseCount == subBaseCount) &&
            (identical(other.titleId, titleId) || other.titleId == titleId) &&
            (identical(other.titleName, titleName) ||
                other.titleName == titleName) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, subBaseCount, titleId,
      titleName, point, memberRef, position, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedParentBaseCopyWith<_$_CompletedParentBase> get copyWith =>
      __$$_CompletedParentBaseCopyWithImpl<_$_CompletedParentBase>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedParentBaseToJson(
      this,
    );
  }
}

abstract class _CompletedParentBase implements CompletedParentBase {
  const factory _CompletedParentBase(
      {required final String id,
      required final String name,
      required final int subBaseCount,
      required final String titleId,
      required final String titleName,
      required final int point,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      required final MapPosition position,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedParentBase;

  factory _CompletedParentBase.fromJson(Map<String, dynamic> json) =
      _$_CompletedParentBase.fromJson;

  @override // 親拠点ID
  String get id;
  @override // 親拠点名称
  String get name;
  @override // 配下のサブ拠点数
  int get subBaseCount;
  @override // 称号ID
  String get titleId;
  @override // 称号名称
  String get titleName;
  @override // 獲得ポイント
  int get point;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 親拠点の位置情報
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedParentBaseCopyWith<_$_CompletedParentBase> get copyWith =>
      throw _privateConstructorUsedError;
}

CompletedSubBase _$CompletedSubBaseFromJson(Map<String, dynamic> json) {
  return _CompletedSubBase.fromJson(json);
}

/// @nodoc
mixin _$CompletedSubBase {
// サブ拠点ID
  String get id => throw _privateConstructorUsedError; // サブ拠点名称
  String get name => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // サブ拠点の位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedSubBaseCopyWith<CompletedSubBase> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedSubBaseCopyWith<$Res> {
  factory $CompletedSubBaseCopyWith(
          CompletedSubBase value, $Res Function(CompletedSubBase) then) =
      _$CompletedSubBaseCopyWithImpl<$Res, CompletedSubBase>;
  @useResult
  $Res call(
      {String id,
      String name,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$CompletedSubBaseCopyWithImpl<$Res, $Val extends CompletedSubBase>
    implements $CompletedSubBaseCopyWith<$Res> {
  _$CompletedSubBaseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_CompletedSubBaseCopyWith<$Res>
    implements $CompletedSubBaseCopyWith<$Res> {
  factory _$$_CompletedSubBaseCopyWith(
          _$_CompletedSubBase value, $Res Function(_$_CompletedSubBase) then) =
      __$$_CompletedSubBaseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_CompletedSubBaseCopyWithImpl<$Res>
    extends _$CompletedSubBaseCopyWithImpl<$Res, _$_CompletedSubBase>
    implements _$$_CompletedSubBaseCopyWith<$Res> {
  __$$_CompletedSubBaseCopyWithImpl(
      _$_CompletedSubBase _value, $Res Function(_$_CompletedSubBase) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedSubBase(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedSubBase implements _CompletedSubBase {
  const _$_CompletedSubBase(
      {required this.id,
      required this.name,
      @DocumentReferenceConverter() required this.memberRef,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedSubBase.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedSubBaseFromJson(json);

// サブ拠点ID
  @override
  final String id;
// サブ拠点名称
  @override
  final String name;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// サブ拠点の位置情報
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedSubBase(id: $id, name: $name, memberRef: $memberRef, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedSubBase &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, memberRef, position, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedSubBaseCopyWith<_$_CompletedSubBase> get copyWith =>
      __$$_CompletedSubBaseCopyWithImpl<_$_CompletedSubBase>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedSubBaseToJson(
      this,
    );
  }
}

abstract class _CompletedSubBase implements CompletedSubBase {
  const factory _CompletedSubBase(
      {required final String id,
      required final String name,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      required final MapPosition position,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedSubBase;

  factory _CompletedSubBase.fromJson(Map<String, dynamic> json) =
      _$_CompletedSubBase.fromJson;

  @override // サブ拠点ID
  String get id;
  @override // サブ拠点名称
  String get name;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // サブ拠点の位置情報
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedSubBaseCopyWith<_$_CompletedSubBase> get copyWith =>
      throw _privateConstructorUsedError;
}

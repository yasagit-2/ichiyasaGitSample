// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'admin_questionnaire.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class AdminQuestionnaireCollectionReference
    implements
        AdminQuestionnaireQuery,
        FirestoreCollectionReference<AdminQuestionnaire,
            AdminQuestionnaireQuerySnapshot> {
  factory AdminQuestionnaireCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$AdminQuestionnaireCollectionReference;

  static AdminQuestionnaire fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return AdminQuestionnaire.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    AdminQuestionnaire value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<AdminQuestionnaire> get reference;

  @override
  AdminQuestionnaireDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<AdminQuestionnaireDocumentReference> add(AdminQuestionnaire value);
}

class _$AdminQuestionnaireCollectionReference extends _$AdminQuestionnaireQuery
    implements AdminQuestionnaireCollectionReference {
  factory _$AdminQuestionnaireCollectionReference(
      [FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$AdminQuestionnaireCollectionReference._(
      firestore.collection('adminQuestionnaires').withConverter(
            fromFirestore: AdminQuestionnaireCollectionReference.fromFirestore,
            toFirestore: AdminQuestionnaireCollectionReference.toFirestore,
          ),
    );
  }

  _$AdminQuestionnaireCollectionReference._(
    CollectionReference<AdminQuestionnaire> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<AdminQuestionnaire> get reference =>
      super.reference as CollectionReference<AdminQuestionnaire>;

  @override
  AdminQuestionnaireDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return AdminQuestionnaireDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<AdminQuestionnaireDocumentReference> add(AdminQuestionnaire value) {
    return reference
        .add(value)
        .then((ref) => AdminQuestionnaireDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$AdminQuestionnaireCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class AdminQuestionnaireDocumentReference
    extends FirestoreDocumentReference<AdminQuestionnaire,
        AdminQuestionnaireDocumentSnapshot> {
  factory AdminQuestionnaireDocumentReference(
          DocumentReference<AdminQuestionnaire> reference) =
      _$AdminQuestionnaireDocumentReference;

  DocumentReference<AdminQuestionnaire> get reference;

  /// A reference to the [AdminQuestionnaireCollectionReference] containing this document.
  AdminQuestionnaireCollectionReference get parent {
    return _$AdminQuestionnaireCollectionReference(reference.firestore);
  }

  late final ChoiceCollectionReference choices = _$ChoiceCollectionReference(
    reference,
  );

  late final QuestionnaireTransactionCollectionReference
      questionnaireTransactions = _$QuestionnaireTransactionCollectionReference(
    reference,
  );

  @override
  Stream<AdminQuestionnaireDocumentSnapshot> snapshots();

  @override
  Future<AdminQuestionnaireDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String id,
    FieldValue idFieldValue,
    String message,
    FieldValue messageFieldValue,
    DateTime dueDate,
    FieldValue dueDateFieldValue,
    String? imageUrl,
    FieldValue imageUrlFieldValue,
    String? imagePath,
    FieldValue imagePathFieldValue,
    int point,
    FieldValue pointFieldValue,
    int pointLimit,
    FieldValue pointLimitFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String id,
    FieldValue idFieldValue,
    String message,
    FieldValue messageFieldValue,
    DateTime dueDate,
    FieldValue dueDateFieldValue,
    String? imageUrl,
    FieldValue imageUrlFieldValue,
    String? imagePath,
    FieldValue imagePathFieldValue,
    int point,
    FieldValue pointFieldValue,
    int pointLimit,
    FieldValue pointLimitFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$AdminQuestionnaireDocumentReference extends FirestoreDocumentReference<
        AdminQuestionnaire, AdminQuestionnaireDocumentSnapshot>
    implements AdminQuestionnaireDocumentReference {
  _$AdminQuestionnaireDocumentReference(this.reference);

  @override
  final DocumentReference<AdminQuestionnaire> reference;

  /// A reference to the [AdminQuestionnaireCollectionReference] containing this document.
  AdminQuestionnaireCollectionReference get parent {
    return _$AdminQuestionnaireCollectionReference(reference.firestore);
  }

  late final ChoiceCollectionReference choices = _$ChoiceCollectionReference(
    reference,
  );

  late final QuestionnaireTransactionCollectionReference
      questionnaireTransactions = _$QuestionnaireTransactionCollectionReference(
    reference,
  );

  @override
  Stream<AdminQuestionnaireDocumentSnapshot> snapshots() {
    return reference.snapshots().map(AdminQuestionnaireDocumentSnapshot._);
  }

  @override
  Future<AdminQuestionnaireDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(AdminQuestionnaireDocumentSnapshot._);
  }

  @override
  Future<AdminQuestionnaireDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction
        .get(reference)
        .then(AdminQuestionnaireDocumentSnapshot._);
  }

  Future<void> update({
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? message = _sentinel,
    FieldValue? messageFieldValue,
    Object? dueDate = _sentinel,
    FieldValue? dueDateFieldValue,
    Object? imageUrl = _sentinel,
    FieldValue? imageUrlFieldValue,
    Object? imagePath = _sentinel,
    FieldValue? imagePathFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? pointLimit = _sentinel,
    FieldValue? pointLimitFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      message == _sentinel || messageFieldValue == null,
      "Cannot specify both message and messageFieldValue",
    );
    assert(
      dueDate == _sentinel || dueDateFieldValue == null,
      "Cannot specify both dueDate and dueDateFieldValue",
    );
    assert(
      imageUrl == _sentinel || imageUrlFieldValue == null,
      "Cannot specify both imageUrl and imageUrlFieldValue",
    );
    assert(
      imagePath == _sentinel || imagePathFieldValue == null,
      "Cannot specify both imagePath and imagePathFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      pointLimit == _sentinel || pointLimitFieldValue == null,
      "Cannot specify both pointLimit and pointLimitFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (message != _sentinel) 'message': message as String,
      if (messageFieldValue != null) 'message': messageFieldValue,
      if (dueDate != _sentinel) 'dueDate': dueDate as DateTime,
      if (dueDateFieldValue != null) 'dueDate': dueDateFieldValue,
      if (imageUrl != _sentinel) 'imageUrl': imageUrl as String?,
      if (imageUrlFieldValue != null) 'imageUrl': imageUrlFieldValue,
      if (imagePath != _sentinel) 'imagePath': imagePath as String?,
      if (imagePathFieldValue != null) 'imagePath': imagePathFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (pointLimit != _sentinel) 'pointLimit': pointLimit as int,
      if (pointLimitFieldValue != null) 'pointLimit': pointLimitFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? message = _sentinel,
    FieldValue? messageFieldValue,
    Object? dueDate = _sentinel,
    FieldValue? dueDateFieldValue,
    Object? imageUrl = _sentinel,
    FieldValue? imageUrlFieldValue,
    Object? imagePath = _sentinel,
    FieldValue? imagePathFieldValue,
    Object? point = _sentinel,
    FieldValue? pointFieldValue,
    Object? pointLimit = _sentinel,
    FieldValue? pointLimitFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      message == _sentinel || messageFieldValue == null,
      "Cannot specify both message and messageFieldValue",
    );
    assert(
      dueDate == _sentinel || dueDateFieldValue == null,
      "Cannot specify both dueDate and dueDateFieldValue",
    );
    assert(
      imageUrl == _sentinel || imageUrlFieldValue == null,
      "Cannot specify both imageUrl and imageUrlFieldValue",
    );
    assert(
      imagePath == _sentinel || imagePathFieldValue == null,
      "Cannot specify both imagePath and imagePathFieldValue",
    );
    assert(
      point == _sentinel || pointFieldValue == null,
      "Cannot specify both point and pointFieldValue",
    );
    assert(
      pointLimit == _sentinel || pointLimitFieldValue == null,
      "Cannot specify both pointLimit and pointLimitFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (message != _sentinel) 'message': message as String,
      if (messageFieldValue != null) 'message': messageFieldValue,
      if (dueDate != _sentinel) 'dueDate': dueDate as DateTime,
      if (dueDateFieldValue != null) 'dueDate': dueDateFieldValue,
      if (imageUrl != _sentinel) 'imageUrl': imageUrl as String?,
      if (imageUrlFieldValue != null) 'imageUrl': imageUrlFieldValue,
      if (imagePath != _sentinel) 'imagePath': imagePath as String?,
      if (imagePathFieldValue != null) 'imagePath': imagePathFieldValue,
      if (point != _sentinel) 'point': point as int,
      if (pointFieldValue != null) 'point': pointFieldValue,
      if (pointLimit != _sentinel) 'pointLimit': pointLimit as int,
      if (pointLimitFieldValue != null) 'pointLimit': pointLimitFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is AdminQuestionnaireDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class AdminQuestionnaireQuery
    implements
        QueryReference<AdminQuestionnaire, AdminQuestionnaireQuerySnapshot> {
  @override
  AdminQuestionnaireQuery limit(int limit);

  @override
  AdminQuestionnaireQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  AdminQuestionnaireQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  AdminQuestionnaireQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  AdminQuestionnaireQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  AdminQuestionnaireQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  AdminQuestionnaireQuery whereMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  AdminQuestionnaireQuery whereDueDate({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime>? whereIn,
    List<DateTime>? whereNotIn,
  });
  AdminQuestionnaireQuery whereImageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  AdminQuestionnaireQuery whereImagePath({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  });
  AdminQuestionnaireQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  AdminQuestionnaireQuery wherePointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  AdminQuestionnaireQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  AdminQuestionnaireQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  AdminQuestionnaireQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderById({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByMessage({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByDueDate({
    bool descending = false,
    DateTime startAt,
    DateTime startAfter,
    DateTime endAt,
    DateTime endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByImageUrl({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByImagePath({
    bool descending = false,
    String? startAt,
    String? startAfter,
    String? endAt,
    String? endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByPoint({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByPointLimit({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });

  AdminQuestionnaireQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  });
}

class _$AdminQuestionnaireQuery
    extends QueryReference<AdminQuestionnaire, AdminQuestionnaireQuerySnapshot>
    implements AdminQuestionnaireQuery {
  _$AdminQuestionnaireQuery(
    this._collection, {
    required Query<AdminQuestionnaire> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<AdminQuestionnaireQuerySnapshot> snapshots(
      [SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(AdminQuestionnaireQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<AdminQuestionnaireQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(AdminQuestionnaireQuerySnapshot._fromQuerySnapshot);
  }

  @override
  AdminQuestionnaireQuery limit(int limit) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  AdminQuestionnaireQuery limitToLast(int limit) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['id']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereMessage({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['message']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereDueDate({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime>? whereIn,
    List<DateTime>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['dueDate']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereImageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['imageUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereImagePath({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String?>? whereIn,
    List<String?>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['imagePath']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery wherePoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['point']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery wherePointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['pointLimit']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_AdminQuestionnaireFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderById({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_AdminQuestionnaireFieldMap['id']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByMessage({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['message']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByDueDate({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['dueDate']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByImageUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['imageUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByImagePath({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['imagePath']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByPoint({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['point']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByPointLimit({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['pointLimit']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  AdminQuestionnaireQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    AdminQuestionnaireDocumentSnapshot? startAtDocument,
    AdminQuestionnaireDocumentSnapshot? endAtDocument,
    AdminQuestionnaireDocumentSnapshot? endBeforeDocument,
    AdminQuestionnaireDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_AdminQuestionnaireFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$AdminQuestionnaireQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$AdminQuestionnaireQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class AdminQuestionnaireDocumentSnapshot
    extends FirestoreDocumentSnapshot<AdminQuestionnaire> {
  AdminQuestionnaireDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<AdminQuestionnaire> snapshot;

  @override
  AdminQuestionnaireDocumentReference get reference {
    return AdminQuestionnaireDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final AdminQuestionnaire? data;
}

class AdminQuestionnaireQuerySnapshot extends FirestoreQuerySnapshot<
    AdminQuestionnaire, AdminQuestionnaireQueryDocumentSnapshot> {
  AdminQuestionnaireQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory AdminQuestionnaireQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<AdminQuestionnaire> snapshot,
  ) {
    final docs =
        snapshot.docs.map(AdminQuestionnaireQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        AdminQuestionnaireDocumentSnapshot._,
      );
    }).toList();

    return AdminQuestionnaireQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<AdminQuestionnaireDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    AdminQuestionnaireDocumentSnapshot Function(DocumentSnapshot<T> doc)
        decodeDoc,
  ) {
    return FirestoreDocumentChange<AdminQuestionnaireDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<AdminQuestionnaire> snapshot;

  @override
  final List<AdminQuestionnaireQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<AdminQuestionnaireDocumentSnapshot>>
      docChanges;
}

class AdminQuestionnaireQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<AdminQuestionnaire>
    implements AdminQuestionnaireDocumentSnapshot {
  AdminQuestionnaireQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<AdminQuestionnaire> snapshot;

  @override
  final AdminQuestionnaire data;

  @override
  AdminQuestionnaireDocumentReference get reference {
    return AdminQuestionnaireDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class ChoiceCollectionReference
    implements
        ChoiceQuery,
        FirestoreCollectionReference<Choice, ChoiceQuerySnapshot> {
  factory ChoiceCollectionReference(
    DocumentReference<AdminQuestionnaire> parent,
  ) = _$ChoiceCollectionReference;

  static Choice fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return Choice.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    Choice value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<Choice> get reference;

  /// A reference to the containing [AdminQuestionnaireDocumentReference] if this is a subcollection.
  AdminQuestionnaireDocumentReference get parent;

  @override
  ChoiceDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<ChoiceDocumentReference> add(Choice value);
}

class _$ChoiceCollectionReference extends _$ChoiceQuery
    implements ChoiceCollectionReference {
  factory _$ChoiceCollectionReference(
    DocumentReference<AdminQuestionnaire> parent,
  ) {
    return _$ChoiceCollectionReference._(
      AdminQuestionnaireDocumentReference(parent),
      parent.collection('choices').withConverter(
            fromFirestore: ChoiceCollectionReference.fromFirestore,
            toFirestore: ChoiceCollectionReference.toFirestore,
          ),
    );
  }

  _$ChoiceCollectionReference._(
    this.parent,
    CollectionReference<Choice> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final AdminQuestionnaireDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<Choice> get reference =>
      super.reference as CollectionReference<Choice>;

  @override
  ChoiceDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return ChoiceDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<ChoiceDocumentReference> add(Choice value) {
    return reference.add(value).then((ref) => ChoiceDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$ChoiceCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class ChoiceDocumentReference
    extends FirestoreDocumentReference<Choice, ChoiceDocumentSnapshot> {
  factory ChoiceDocumentReference(DocumentReference<Choice> reference) =
      _$ChoiceDocumentReference;

  DocumentReference<Choice> get reference;

  /// A reference to the [ChoiceCollectionReference] containing this document.
  ChoiceCollectionReference get parent {
    return _$ChoiceCollectionReference(
      reference.parent.parent!.withConverter<AdminQuestionnaire>(
        fromFirestore: AdminQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AdminQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<ChoiceDocumentSnapshot> snapshots();

  @override
  Future<ChoiceDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String id,
    FieldValue idFieldValue,
    String choice,
    FieldValue choiceFieldValue,
    int displayOrder,
    FieldValue displayOrderFieldValue,
    int answer,
    FieldValue answerFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String id,
    FieldValue idFieldValue,
    String choice,
    FieldValue choiceFieldValue,
    int displayOrder,
    FieldValue displayOrderFieldValue,
    int answer,
    FieldValue answerFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$ChoiceDocumentReference
    extends FirestoreDocumentReference<Choice, ChoiceDocumentSnapshot>
    implements ChoiceDocumentReference {
  _$ChoiceDocumentReference(this.reference);

  @override
  final DocumentReference<Choice> reference;

  /// A reference to the [ChoiceCollectionReference] containing this document.
  ChoiceCollectionReference get parent {
    return _$ChoiceCollectionReference(
      reference.parent.parent!.withConverter<AdminQuestionnaire>(
        fromFirestore: AdminQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AdminQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<ChoiceDocumentSnapshot> snapshots() {
    return reference.snapshots().map(ChoiceDocumentSnapshot._);
  }

  @override
  Future<ChoiceDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(ChoiceDocumentSnapshot._);
  }

  @override
  Future<ChoiceDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(ChoiceDocumentSnapshot._);
  }

  Future<void> update({
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? choice = _sentinel,
    FieldValue? choiceFieldValue,
    Object? displayOrder = _sentinel,
    FieldValue? displayOrderFieldValue,
    Object? answer = _sentinel,
    FieldValue? answerFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      choice == _sentinel || choiceFieldValue == null,
      "Cannot specify both choice and choiceFieldValue",
    );
    assert(
      displayOrder == _sentinel || displayOrderFieldValue == null,
      "Cannot specify both displayOrder and displayOrderFieldValue",
    );
    assert(
      answer == _sentinel || answerFieldValue == null,
      "Cannot specify both answer and answerFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (choice != _sentinel) 'choice': choice as String,
      if (choiceFieldValue != null) 'choice': choiceFieldValue,
      if (displayOrder != _sentinel) 'displayOrder': displayOrder as int,
      if (displayOrderFieldValue != null)
        'displayOrder': displayOrderFieldValue,
      if (answer != _sentinel) 'answer': answer as int,
      if (answerFieldValue != null) 'answer': answerFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? id = _sentinel,
    FieldValue? idFieldValue,
    Object? choice = _sentinel,
    FieldValue? choiceFieldValue,
    Object? displayOrder = _sentinel,
    FieldValue? displayOrderFieldValue,
    Object? answer = _sentinel,
    FieldValue? answerFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      id == _sentinel || idFieldValue == null,
      "Cannot specify both id and idFieldValue",
    );
    assert(
      choice == _sentinel || choiceFieldValue == null,
      "Cannot specify both choice and choiceFieldValue",
    );
    assert(
      displayOrder == _sentinel || displayOrderFieldValue == null,
      "Cannot specify both displayOrder and displayOrderFieldValue",
    );
    assert(
      answer == _sentinel || answerFieldValue == null,
      "Cannot specify both answer and answerFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (id != _sentinel) 'id': id as String,
      if (idFieldValue != null) 'id': idFieldValue,
      if (choice != _sentinel) 'choice': choice as String,
      if (choiceFieldValue != null) 'choice': choiceFieldValue,
      if (displayOrder != _sentinel) 'displayOrder': displayOrder as int,
      if (displayOrderFieldValue != null)
        'displayOrder': displayOrderFieldValue,
      if (answer != _sentinel) 'answer': answer as int,
      if (answerFieldValue != null) 'answer': answerFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is ChoiceDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class ChoiceQuery
    implements QueryReference<Choice, ChoiceQuerySnapshot> {
  @override
  ChoiceQuery limit(int limit);

  @override
  ChoiceQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  ChoiceQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  ChoiceQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  ChoiceQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  ChoiceQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  ChoiceQuery whereChoice({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  ChoiceQuery whereDisplayOrder({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  ChoiceQuery whereAnswer({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  ChoiceQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  ChoiceQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  ChoiceQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderById({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderByChoice({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderByDisplayOrder({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderByAnswer({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });

  ChoiceQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  });
}

class _$ChoiceQuery extends QueryReference<Choice, ChoiceQuerySnapshot>
    implements ChoiceQuery {
  _$ChoiceQuery(
    this._collection, {
    required Query<Choice> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<ChoiceQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference.snapshots().map(ChoiceQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<ChoiceQuerySnapshot> get([GetOptions? options]) {
    return reference.get(options).then(ChoiceQuerySnapshot._fromQuerySnapshot);
  }

  @override
  ChoiceQuery limit(int limit) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  ChoiceQuery limitToLast(int limit) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['id']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereChoice({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['choice']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereDisplayOrder({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['displayOrder']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereAnswer({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['answer']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_ChoiceFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  ChoiceQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderById({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_ChoiceFieldMap['id']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderByChoice({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_ChoiceFieldMap['choice']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderByDisplayOrder({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_ChoiceFieldMap['displayOrder']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderByAnswer({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(_$$_ChoiceFieldMap['answer']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_ChoiceFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  ChoiceQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    ChoiceDocumentSnapshot? startAtDocument,
    ChoiceDocumentSnapshot? endAtDocument,
    ChoiceDocumentSnapshot? endBeforeDocument,
    ChoiceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_ChoiceFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$ChoiceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$ChoiceQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class ChoiceDocumentSnapshot extends FirestoreDocumentSnapshot<Choice> {
  ChoiceDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<Choice> snapshot;

  @override
  ChoiceDocumentReference get reference {
    return ChoiceDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final Choice? data;
}

class ChoiceQuerySnapshot
    extends FirestoreQuerySnapshot<Choice, ChoiceQueryDocumentSnapshot> {
  ChoiceQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory ChoiceQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<Choice> snapshot,
  ) {
    final docs = snapshot.docs.map(ChoiceQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        ChoiceDocumentSnapshot._,
      );
    }).toList();

    return ChoiceQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<ChoiceDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    ChoiceDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<ChoiceDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<Choice> snapshot;

  @override
  final List<ChoiceQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<ChoiceDocumentSnapshot>> docChanges;
}

class ChoiceQueryDocumentSnapshot extends FirestoreQueryDocumentSnapshot<Choice>
    implements ChoiceDocumentSnapshot {
  ChoiceQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<Choice> snapshot;

  @override
  final Choice data;

  @override
  ChoiceDocumentReference get reference {
    return ChoiceDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class QuestionnaireTransactionCollectionReference
    implements
        QuestionnaireTransactionQuery,
        FirestoreCollectionReference<QuestionnaireTransaction,
            QuestionnaireTransactionQuerySnapshot> {
  factory QuestionnaireTransactionCollectionReference(
    DocumentReference<AdminQuestionnaire> parent,
  ) = _$QuestionnaireTransactionCollectionReference;

  static QuestionnaireTransaction fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return QuestionnaireTransaction.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    QuestionnaireTransaction value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<QuestionnaireTransaction> get reference;

  /// A reference to the containing [AdminQuestionnaireDocumentReference] if this is a subcollection.
  AdminQuestionnaireDocumentReference get parent;

  @override
  QuestionnaireTransactionDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<QuestionnaireTransactionDocumentReference> add(
      QuestionnaireTransaction value);
}

class _$QuestionnaireTransactionCollectionReference
    extends _$QuestionnaireTransactionQuery
    implements QuestionnaireTransactionCollectionReference {
  factory _$QuestionnaireTransactionCollectionReference(
    DocumentReference<AdminQuestionnaire> parent,
  ) {
    return _$QuestionnaireTransactionCollectionReference._(
      AdminQuestionnaireDocumentReference(parent),
      parent.collection('questionnaireTransactions').withConverter(
            fromFirestore:
                QuestionnaireTransactionCollectionReference.fromFirestore,
            toFirestore:
                QuestionnaireTransactionCollectionReference.toFirestore,
          ),
    );
  }

  _$QuestionnaireTransactionCollectionReference._(
    this.parent,
    CollectionReference<QuestionnaireTransaction> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final AdminQuestionnaireDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<QuestionnaireTransaction> get reference =>
      super.reference as CollectionReference<QuestionnaireTransaction>;

  @override
  QuestionnaireTransactionDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return QuestionnaireTransactionDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<QuestionnaireTransactionDocumentReference> add(
      QuestionnaireTransaction value) {
    return reference
        .add(value)
        .then((ref) => QuestionnaireTransactionDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$QuestionnaireTransactionCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class QuestionnaireTransactionDocumentReference
    extends FirestoreDocumentReference<QuestionnaireTransaction,
        QuestionnaireTransactionDocumentSnapshot> {
  factory QuestionnaireTransactionDocumentReference(
          DocumentReference<QuestionnaireTransaction> reference) =
      _$QuestionnaireTransactionDocumentReference;

  DocumentReference<QuestionnaireTransaction> get reference;

  /// A reference to the [QuestionnaireTransactionCollectionReference] containing this document.
  QuestionnaireTransactionCollectionReference get parent {
    return _$QuestionnaireTransactionCollectionReference(
      reference.parent.parent!.withConverter<AdminQuestionnaire>(
        fromFirestore: AdminQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AdminQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<QuestionnaireTransactionDocumentSnapshot> snapshots();

  @override
  Future<QuestionnaireTransactionDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    int pointLimitRemain,
    FieldValue pointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    int pointLimitRemain,
    FieldValue pointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$QuestionnaireTransactionDocumentReference
    extends FirestoreDocumentReference<QuestionnaireTransaction,
        QuestionnaireTransactionDocumentSnapshot>
    implements QuestionnaireTransactionDocumentReference {
  _$QuestionnaireTransactionDocumentReference(this.reference);

  @override
  final DocumentReference<QuestionnaireTransaction> reference;

  /// A reference to the [QuestionnaireTransactionCollectionReference] containing this document.
  QuestionnaireTransactionCollectionReference get parent {
    return _$QuestionnaireTransactionCollectionReference(
      reference.parent.parent!.withConverter<AdminQuestionnaire>(
        fromFirestore: AdminQuestionnaireCollectionReference.fromFirestore,
        toFirestore: AdminQuestionnaireCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<QuestionnaireTransactionDocumentSnapshot> snapshots() {
    return reference
        .snapshots()
        .map(QuestionnaireTransactionDocumentSnapshot._);
  }

  @override
  Future<QuestionnaireTransactionDocumentSnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(QuestionnaireTransactionDocumentSnapshot._);
  }

  @override
  Future<QuestionnaireTransactionDocumentSnapshot> transactionGet(
      Transaction transaction) {
    return transaction
        .get(reference)
        .then(QuestionnaireTransactionDocumentSnapshot._);
  }

  Future<void> update({
    Object? pointLimitRemain = _sentinel,
    FieldValue? pointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      pointLimitRemain == _sentinel || pointLimitRemainFieldValue == null,
      "Cannot specify both pointLimitRemain and pointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (pointLimitRemain != _sentinel)
        'pointLimitRemain': pointLimitRemain as int,
      if (pointLimitRemainFieldValue != null)
        'pointLimitRemain': pointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? pointLimitRemain = _sentinel,
    FieldValue? pointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      pointLimitRemain == _sentinel || pointLimitRemainFieldValue == null,
      "Cannot specify both pointLimitRemain and pointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (pointLimitRemain != _sentinel)
        'pointLimitRemain': pointLimitRemain as int,
      if (pointLimitRemainFieldValue != null)
        'pointLimitRemain': pointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is QuestionnaireTransactionDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class QuestionnaireTransactionQuery
    implements
        QueryReference<QuestionnaireTransaction,
            QuestionnaireTransactionQuerySnapshot> {
  @override
  QuestionnaireTransactionQuery limit(int limit);

  @override
  QuestionnaireTransactionQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  QuestionnaireTransactionQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  QuestionnaireTransactionQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  QuestionnaireTransactionQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  QuestionnaireTransactionQuery wherePointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  QuestionnaireTransactionQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  QuestionnaireTransactionQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  QuestionnaireTransactionQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireTransactionQuery orderByPointLimitRemain({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireTransactionQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  });

  QuestionnaireTransactionQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  });
}

class _$QuestionnaireTransactionQuery extends QueryReference<
        QuestionnaireTransaction, QuestionnaireTransactionQuerySnapshot>
    implements QuestionnaireTransactionQuery {
  _$QuestionnaireTransactionQuery(
    this._collection, {
    required Query<QuestionnaireTransaction> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<QuestionnaireTransactionQuerySnapshot> snapshots(
      [SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(QuestionnaireTransactionQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<QuestionnaireTransactionQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(QuestionnaireTransactionQuerySnapshot._fromQuerySnapshot);
  }

  @override
  QuestionnaireTransactionQuery limit(int limit) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  QuestionnaireTransactionQuery limitToLast(int limit) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireTransactionQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery wherePointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireTransactionFieldMap['pointLimitRemain']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireTransactionFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_QuestionnaireTransactionFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  QuestionnaireTransactionQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireTransactionQuery orderByPointLimitRemain({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireTransactionFieldMap['pointLimitRemain']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireTransactionQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireTransactionFieldMap['updatedAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  QuestionnaireTransactionQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    QuestionnaireTransactionDocumentSnapshot? startAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endAtDocument,
    QuestionnaireTransactionDocumentSnapshot? endBeforeDocument,
    QuestionnaireTransactionDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_QuestionnaireTransactionFieldMap['createdAt']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$QuestionnaireTransactionQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$QuestionnaireTransactionQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class QuestionnaireTransactionDocumentSnapshot
    extends FirestoreDocumentSnapshot<QuestionnaireTransaction> {
  QuestionnaireTransactionDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final DocumentSnapshot<QuestionnaireTransaction> snapshot;

  @override
  QuestionnaireTransactionDocumentReference get reference {
    return QuestionnaireTransactionDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final QuestionnaireTransaction? data;
}

class QuestionnaireTransactionQuerySnapshot extends FirestoreQuerySnapshot<
    QuestionnaireTransaction, QuestionnaireTransactionQueryDocumentSnapshot> {
  QuestionnaireTransactionQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory QuestionnaireTransactionQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<QuestionnaireTransaction> snapshot,
  ) {
    final docs = snapshot.docs
        .map(QuestionnaireTransactionQueryDocumentSnapshot._)
        .toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        QuestionnaireTransactionDocumentSnapshot._,
      );
    }).toList();

    return QuestionnaireTransactionQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<QuestionnaireTransactionDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    QuestionnaireTransactionDocumentSnapshot Function(DocumentSnapshot<T> doc)
        decodeDoc,
  ) {
    return FirestoreDocumentChange<QuestionnaireTransactionDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<QuestionnaireTransaction> snapshot;

  @override
  final List<QuestionnaireTransactionQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<QuestionnaireTransactionDocumentSnapshot>>
      docChanges;
}

class QuestionnaireTransactionQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<QuestionnaireTransaction>
    implements QuestionnaireTransactionDocumentSnapshot {
  QuestionnaireTransactionQueryDocumentSnapshot._(this.snapshot)
      : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<QuestionnaireTransaction> snapshot;

  @override
  final QuestionnaireTransaction data;

  @override
  QuestionnaireTransactionDocumentReference get reference {
    return QuestionnaireTransactionDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AdminQuestionnaire _$$_AdminQuestionnaireFromJson(
        Map<String, dynamic> json) =>
    _$_AdminQuestionnaire(
      id: json['id'] as String,
      message: json['message'] as String,
      dueDate: const FirestoreDateTimeConverter()
          .fromJson(json['dueDate'] as Timestamp),
      position: MapPosition.fromJson(json['position'] as Map<String, dynamic>),
      imageUrl: json['imageUrl'] as String?,
      imagePath: json['imagePath'] as String?,
      point: json['point'] as int,
      pointLimit: json['pointLimit'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_AdminQuestionnaireFieldMap = <String, String>{
  'id': 'id',
  'message': 'message',
  'dueDate': 'dueDate',
  'position': 'position',
  'imageUrl': 'imageUrl',
  'imagePath': 'imagePath',
  'point': 'point',
  'pointLimit': 'pointLimit',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_AdminQuestionnaireToJson(
    _$_AdminQuestionnaire instance) {
  final val = <String, dynamic>{
    'id': instance.id,
    'message': instance.message,
    'dueDate': const FirestoreDateTimeConverter().toJson(instance.dueDate),
    'position': instance.position.toJson(),
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull('imageUrl', instance.imageUrl);
  writeNotNull('imagePath', instance.imagePath);
  val['point'] = instance.point;
  val['pointLimit'] = instance.pointLimit;
  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_Choice _$$_ChoiceFromJson(Map<String, dynamic> json) => _$_Choice(
      id: json['id'] as String,
      choice: json['choice'] as String,
      displayOrder: json['displayOrder'] as int,
      answer: json['answer'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_ChoiceFieldMap = <String, String>{
  'id': 'id',
  'choice': 'choice',
  'displayOrder': 'displayOrder',
  'answer': 'answer',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_ChoiceToJson(_$_Choice instance) {
  final val = <String, dynamic>{
    'id': instance.id,
    'choice': instance.choice,
    'displayOrder': instance.displayOrder,
    'answer': instance.answer,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_QuestionnaireTransaction _$$_QuestionnaireTransactionFromJson(
        Map<String, dynamic> json) =>
    _$_QuestionnaireTransaction(
      pointLimitRemain: json['pointLimitRemain'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_QuestionnaireTransactionFieldMap = <String, String>{
  'pointLimitRemain': 'pointLimitRemain',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_QuestionnaireTransactionToJson(
    _$_QuestionnaireTransaction instance) {
  final val = <String, dynamic>{
    'pointLimitRemain': instance.pointLimitRemain,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

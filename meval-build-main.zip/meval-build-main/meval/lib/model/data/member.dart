import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../provider/authentication_type_provider.dart';
import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'member.freezed.dart';
part 'member.g.dart';

@freezed
class Member with _$Member {
  @firestoreSerializable
  const factory Member({
    // 会員ID
    required String id,
    // ニックネーム
    required String nickname,
    // 性別
    required String gender,
    // 生年月
    required DateTime monthOfBirth,
    // 居住地
    required String prefecture,
    // 氏名
    required String name,
    // メールアドレス
    required String mailAddress,
    // 認証プロバイダのタイプ
    required AuthenticationType authenticationProvider,
    // 投稿日時（投稿を行った最終日時）
    required DateTime postedAt,
    // 行政報告日時（行政報告を行った最終日時）
    required DateTime reportedAt,
    // コメント日時（コメントを行った最終日時）
    required DateTime commentedAt,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Member;

  factory Member.fromJson(Map<String, Object?> json) => _$MemberFromJson(json);
}

@Collection<Member>('members')
final membersRef = MemberCollectionReference();

MemberDocumentReference memberRef({required String id}) =>
    MemberDocumentReference(membersRef.doc(id).reference);

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'merchant.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Merchant _$MerchantFromJson(Map<String, dynamic> json) {
  return _Merchant.fromJson(json);
}

/// @nodoc
mixin _$Merchant {
// 加盟店ID
  String get id => throw _privateConstructorUsedError; // 加盟店名
  String get name => throw _privateConstructorUsedError; // 加盟店のURL
  String? get merchantsUrl => throw _privateConstructorUsedError; // 加盟店の内容
  String? get content => throw _privateConstructorUsedError; // 加盟店の位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 加盟店画像のURL
  String? get imageUrl => throw _privateConstructorUsedError; // 加盟店画像の保存先
  @override
  String? get imagePath => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantCopyWith<Merchant> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantCopyWith<$Res> {
  factory $MerchantCopyWith(Merchant value, $Res Function(Merchant) then) =
      _$MerchantCopyWithImpl<$Res, Merchant>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? merchantsUrl,
      String? content,
      MapPosition position,
      String? imageUrl,
      @override String? imagePath,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$MerchantCopyWithImpl<$Res, $Val extends Merchant>
    implements $MerchantCopyWith<$Res> {
  _$MerchantCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? merchantsUrl = freezed,
    Object? content = freezed,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      merchantsUrl: freezed == merchantsUrl
          ? _value.merchantsUrl
          : merchantsUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      content: freezed == content
          ? _value.content
          : content // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_MerchantCopyWith<$Res> implements $MerchantCopyWith<$Res> {
  factory _$$_MerchantCopyWith(
          _$_Merchant value, $Res Function(_$_Merchant) then) =
      __$$_MerchantCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? merchantsUrl,
      String? content,
      MapPosition position,
      String? imageUrl,
      @override String? imagePath,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_MerchantCopyWithImpl<$Res>
    extends _$MerchantCopyWithImpl<$Res, _$_Merchant>
    implements _$$_MerchantCopyWith<$Res> {
  __$$_MerchantCopyWithImpl(
      _$_Merchant _value, $Res Function(_$_Merchant) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? merchantsUrl = freezed,
    Object? content = freezed,
    Object? position = null,
    Object? imageUrl = freezed,
    Object? imagePath = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Merchant(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      merchantsUrl: freezed == merchantsUrl
          ? _value.merchantsUrl
          : merchantsUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      content: freezed == content
          ? _value.content
          : content // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      imagePath: freezed == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Merchant implements _Merchant {
  const _$_Merchant(
      {required this.id,
      required this.name,
      this.merchantsUrl,
      this.content,
      required this.position,
      this.imageUrl,
      @override this.imagePath,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Merchant.fromJson(Map<String, dynamic> json) =>
      _$$_MerchantFromJson(json);

// 加盟店ID
  @override
  final String id;
// 加盟店名
  @override
  final String name;
// 加盟店のURL
  @override
  final String? merchantsUrl;
// 加盟店の内容
  @override
  final String? content;
// 加盟店の位置情報
  @override
  final MapPosition position;
// 加盟店画像のURL
  @override
  final String? imageUrl;
// 加盟店画像の保存先
  @override
  @override
  final String? imagePath;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Merchant(id: $id, name: $name, merchantsUrl: $merchantsUrl, content: $content, position: $position, imageUrl: $imageUrl, imagePath: $imagePath, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Merchant &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.merchantsUrl, merchantsUrl) ||
                other.merchantsUrl == merchantsUrl) &&
            (identical(other.content, content) || other.content == content) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, merchantsUrl, content,
      position, imageUrl, imagePath, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantCopyWith<_$_Merchant> get copyWith =>
      __$$_MerchantCopyWithImpl<_$_Merchant>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MerchantToJson(
      this,
    );
  }
}

abstract class _Merchant implements Merchant {
  const factory _Merchant(
      {required final String id,
      required final String name,
      final String? merchantsUrl,
      final String? content,
      required final MapPosition position,
      final String? imageUrl,
      @override final String? imagePath,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Merchant;

  factory _Merchant.fromJson(Map<String, dynamic> json) = _$_Merchant.fromJson;

  @override // 加盟店ID
  String get id;
  @override // 加盟店名
  String get name;
  @override // 加盟店のURL
  String? get merchantsUrl;
  @override // 加盟店の内容
  String? get content;
  @override // 加盟店の位置情報
  MapPosition get position;
  @override // 加盟店画像のURL
  String? get imageUrl;
  @override // 加盟店画像の保存先
  @override
  String? get imagePath;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MerchantCopyWith<_$_Merchant> get copyWith =>
      throw _privateConstructorUsedError;
}

Coupon _$CouponFromJson(Map<String, dynamic> json) {
  return _Coupon.fromJson(json);
}

/// @nodoc
mixin _$Coupon {
// クーポンID
  String get id => throw _privateConstructorUsedError; // 加盟店ID
  String get merchantId => throw _privateConstructorUsedError; // クーポン名称
  String get name => throw _privateConstructorUsedError; // 交換ポイント
  int get exchangePoint => throw _privateConstructorUsedError; // クーポン獲得制限人数
  int get exchangeLimit => throw _privateConstructorUsedError; // クーポン有効期限
  DateTime get dueDate => throw _privateConstructorUsedError; // 掲載期間開始
  DateTime get publicationPeriodBegin =>
      throw _privateConstructorUsedError; // 掲載期間終了
  DateTime get publicationPeriodEnd =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CouponCopyWith<Coupon> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CouponCopyWith<$Res> {
  factory $CouponCopyWith(Coupon value, $Res Function(Coupon) then) =
      _$CouponCopyWithImpl<$Res, Coupon>;
  @useResult
  $Res call(
      {String id,
      String merchantId,
      String name,
      int exchangePoint,
      int exchangeLimit,
      DateTime dueDate,
      DateTime publicationPeriodBegin,
      DateTime publicationPeriodEnd,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CouponCopyWithImpl<$Res, $Val extends Coupon>
    implements $CouponCopyWith<$Res> {
  _$CouponCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? merchantId = null,
    Object? name = null,
    Object? exchangePoint = null,
    Object? exchangeLimit = null,
    Object? dueDate = null,
    Object? publicationPeriodBegin = null,
    Object? publicationPeriodEnd = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      exchangePoint: null == exchangePoint
          ? _value.exchangePoint
          : exchangePoint // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeLimit: null == exchangeLimit
          ? _value.exchangeLimit
          : exchangeLimit // ignore: cast_nullable_to_non_nullable
              as int,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      publicationPeriodBegin: null == publicationPeriodBegin
          ? _value.publicationPeriodBegin
          : publicationPeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      publicationPeriodEnd: null == publicationPeriodEnd
          ? _value.publicationPeriodEnd
          : publicationPeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CouponCopyWith<$Res> implements $CouponCopyWith<$Res> {
  factory _$$_CouponCopyWith(_$_Coupon value, $Res Function(_$_Coupon) then) =
      __$$_CouponCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String merchantId,
      String name,
      int exchangePoint,
      int exchangeLimit,
      DateTime dueDate,
      DateTime publicationPeriodBegin,
      DateTime publicationPeriodEnd,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CouponCopyWithImpl<$Res>
    extends _$CouponCopyWithImpl<$Res, _$_Coupon>
    implements _$$_CouponCopyWith<$Res> {
  __$$_CouponCopyWithImpl(_$_Coupon _value, $Res Function(_$_Coupon) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? merchantId = null,
    Object? name = null,
    Object? exchangePoint = null,
    Object? exchangeLimit = null,
    Object? dueDate = null,
    Object? publicationPeriodBegin = null,
    Object? publicationPeriodEnd = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Coupon(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      exchangePoint: null == exchangePoint
          ? _value.exchangePoint
          : exchangePoint // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeLimit: null == exchangeLimit
          ? _value.exchangeLimit
          : exchangeLimit // ignore: cast_nullable_to_non_nullable
              as int,
      dueDate: null == dueDate
          ? _value.dueDate
          : dueDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      publicationPeriodBegin: null == publicationPeriodBegin
          ? _value.publicationPeriodBegin
          : publicationPeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      publicationPeriodEnd: null == publicationPeriodEnd
          ? _value.publicationPeriodEnd
          : publicationPeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Coupon implements _Coupon {
  const _$_Coupon(
      {required this.id,
      required this.merchantId,
      required this.name,
      required this.exchangePoint,
      required this.exchangeLimit,
      required this.dueDate,
      required this.publicationPeriodBegin,
      required this.publicationPeriodEnd,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Coupon.fromJson(Map<String, dynamic> json) =>
      _$$_CouponFromJson(json);

// クーポンID
  @override
  final String id;
// 加盟店ID
  @override
  final String merchantId;
// クーポン名称
  @override
  final String name;
// 交換ポイント
  @override
  final int exchangePoint;
// クーポン獲得制限人数
  @override
  final int exchangeLimit;
// クーポン有効期限
  @override
  final DateTime dueDate;
// 掲載期間開始
  @override
  final DateTime publicationPeriodBegin;
// 掲載期間終了
  @override
  final DateTime publicationPeriodEnd;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Coupon(id: $id, merchantId: $merchantId, name: $name, exchangePoint: $exchangePoint, exchangeLimit: $exchangeLimit, dueDate: $dueDate, publicationPeriodBegin: $publicationPeriodBegin, publicationPeriodEnd: $publicationPeriodEnd, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Coupon &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.merchantId, merchantId) ||
                other.merchantId == merchantId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.exchangePoint, exchangePoint) ||
                other.exchangePoint == exchangePoint) &&
            (identical(other.exchangeLimit, exchangeLimit) ||
                other.exchangeLimit == exchangeLimit) &&
            (identical(other.dueDate, dueDate) || other.dueDate == dueDate) &&
            (identical(other.publicationPeriodBegin, publicationPeriodBegin) ||
                other.publicationPeriodBegin == publicationPeriodBegin) &&
            (identical(other.publicationPeriodEnd, publicationPeriodEnd) ||
                other.publicationPeriodEnd == publicationPeriodEnd) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      merchantId,
      name,
      exchangePoint,
      exchangeLimit,
      dueDate,
      publicationPeriodBegin,
      publicationPeriodEnd,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CouponCopyWith<_$_Coupon> get copyWith =>
      __$$_CouponCopyWithImpl<_$_Coupon>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CouponToJson(
      this,
    );
  }
}

abstract class _Coupon implements Coupon {
  const factory _Coupon(
      {required final String id,
      required final String merchantId,
      required final String name,
      required final int exchangePoint,
      required final int exchangeLimit,
      required final DateTime dueDate,
      required final DateTime publicationPeriodBegin,
      required final DateTime publicationPeriodEnd,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Coupon;

  factory _Coupon.fromJson(Map<String, dynamic> json) = _$_Coupon.fromJson;

  @override // クーポンID
  String get id;
  @override // 加盟店ID
  String get merchantId;
  @override // クーポン名称
  String get name;
  @override // 交換ポイント
  int get exchangePoint;
  @override // クーポン獲得制限人数
  int get exchangeLimit;
  @override // クーポン有効期限
  DateTime get dueDate;
  @override // 掲載期間開始
  DateTime get publicationPeriodBegin;
  @override // 掲載期間終了
  DateTime get publicationPeriodEnd;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CouponCopyWith<_$_Coupon> get copyWith =>
      throw _privateConstructorUsedError;
}

CouponTransaction _$CouponTransactionFromJson(Map<String, dynamic> json) {
  return _CouponTransaction.fromJson(json);
}

/// @nodoc
mixin _$CouponTransaction {
// クーポン獲得制限人数残り
  int get exchangeLimitRemain => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CouponTransactionCopyWith<CouponTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CouponTransactionCopyWith<$Res> {
  factory $CouponTransactionCopyWith(
          CouponTransaction value, $Res Function(CouponTransaction) then) =
      _$CouponTransactionCopyWithImpl<$Res, CouponTransaction>;
  @useResult
  $Res call(
      {int exchangeLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CouponTransactionCopyWithImpl<$Res, $Val extends CouponTransaction>
    implements $CouponTransactionCopyWith<$Res> {
  _$CouponTransactionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exchangeLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      exchangeLimitRemain: null == exchangeLimitRemain
          ? _value.exchangeLimitRemain
          : exchangeLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CouponTransactionCopyWith<$Res>
    implements $CouponTransactionCopyWith<$Res> {
  factory _$$_CouponTransactionCopyWith(_$_CouponTransaction value,
          $Res Function(_$_CouponTransaction) then) =
      __$$_CouponTransactionCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int exchangeLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CouponTransactionCopyWithImpl<$Res>
    extends _$CouponTransactionCopyWithImpl<$Res, _$_CouponTransaction>
    implements _$$_CouponTransactionCopyWith<$Res> {
  __$$_CouponTransactionCopyWithImpl(
      _$_CouponTransaction _value, $Res Function(_$_CouponTransaction) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exchangeLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CouponTransaction(
      exchangeLimitRemain: null == exchangeLimitRemain
          ? _value.exchangeLimitRemain
          : exchangeLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CouponTransaction implements _CouponTransaction {
  const _$_CouponTransaction(
      {required this.exchangeLimitRemain,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CouponTransaction.fromJson(Map<String, dynamic> json) =>
      _$$_CouponTransactionFromJson(json);

// クーポン獲得制限人数残り
  @override
  final int exchangeLimitRemain;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CouponTransaction(exchangeLimitRemain: $exchangeLimitRemain, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CouponTransaction &&
            (identical(other.exchangeLimitRemain, exchangeLimitRemain) ||
                other.exchangeLimitRemain == exchangeLimitRemain) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, exchangeLimitRemain, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CouponTransactionCopyWith<_$_CouponTransaction> get copyWith =>
      __$$_CouponTransactionCopyWithImpl<_$_CouponTransaction>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CouponTransactionToJson(
      this,
    );
  }
}

abstract class _CouponTransaction implements CouponTransaction {
  const factory _CouponTransaction(
      {required final int exchangeLimitRemain,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_CouponTransaction;

  factory _CouponTransaction.fromJson(Map<String, dynamic> json) =
      _$_CouponTransaction.fromJson;

  @override // クーポン獲得制限人数残り
  int get exchangeLimitRemain;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CouponTransactionCopyWith<_$_CouponTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

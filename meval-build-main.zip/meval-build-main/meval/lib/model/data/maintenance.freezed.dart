// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'maintenance.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Maintenance _$MaintenanceFromJson(Map<String, dynamic> json) {
  return _Maintenance.fromJson(json);
}

/// @nodoc
mixin _$Maintenance {
// アプリケーションバージョン
  String get version =>
      throw _privateConstructorUsedError; // Apple App StoreのURL
  String get appStoreUrl =>
      throw _privateConstructorUsedError; // Google Play StoreのURL
  String get playStoreUrl => throw _privateConstructorUsedError; // メンテナンスフラグ
  bool get isMaintenance => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MaintenanceCopyWith<Maintenance> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MaintenanceCopyWith<$Res> {
  factory $MaintenanceCopyWith(
          Maintenance value, $Res Function(Maintenance) then) =
      _$MaintenanceCopyWithImpl<$Res, Maintenance>;
  @useResult
  $Res call(
      {String version,
      String appStoreUrl,
      String playStoreUrl,
      bool isMaintenance,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$MaintenanceCopyWithImpl<$Res, $Val extends Maintenance>
    implements $MaintenanceCopyWith<$Res> {
  _$MaintenanceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? version = null,
    Object? appStoreUrl = null,
    Object? playStoreUrl = null,
    Object? isMaintenance = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      version: null == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String,
      appStoreUrl: null == appStoreUrl
          ? _value.appStoreUrl
          : appStoreUrl // ignore: cast_nullable_to_non_nullable
              as String,
      playStoreUrl: null == playStoreUrl
          ? _value.playStoreUrl
          : playStoreUrl // ignore: cast_nullable_to_non_nullable
              as String,
      isMaintenance: null == isMaintenance
          ? _value.isMaintenance
          : isMaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MaintenanceCopyWith<$Res>
    implements $MaintenanceCopyWith<$Res> {
  factory _$$_MaintenanceCopyWith(
          _$_Maintenance value, $Res Function(_$_Maintenance) then) =
      __$$_MaintenanceCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String version,
      String appStoreUrl,
      String playStoreUrl,
      bool isMaintenance,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_MaintenanceCopyWithImpl<$Res>
    extends _$MaintenanceCopyWithImpl<$Res, _$_Maintenance>
    implements _$$_MaintenanceCopyWith<$Res> {
  __$$_MaintenanceCopyWithImpl(
      _$_Maintenance _value, $Res Function(_$_Maintenance) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? version = null,
    Object? appStoreUrl = null,
    Object? playStoreUrl = null,
    Object? isMaintenance = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Maintenance(
      version: null == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String,
      appStoreUrl: null == appStoreUrl
          ? _value.appStoreUrl
          : appStoreUrl // ignore: cast_nullable_to_non_nullable
              as String,
      playStoreUrl: null == playStoreUrl
          ? _value.playStoreUrl
          : playStoreUrl // ignore: cast_nullable_to_non_nullable
              as String,
      isMaintenance: null == isMaintenance
          ? _value.isMaintenance
          : isMaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Maintenance implements _Maintenance {
  const _$_Maintenance(
      {required this.version,
      required this.appStoreUrl,
      required this.playStoreUrl,
      required this.isMaintenance,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Maintenance.fromJson(Map<String, dynamic> json) =>
      _$$_MaintenanceFromJson(json);

// アプリケーションバージョン
  @override
  final String version;
// Apple App StoreのURL
  @override
  final String appStoreUrl;
// Google Play StoreのURL
  @override
  final String playStoreUrl;
// メンテナンスフラグ
  @override
  final bool isMaintenance;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Maintenance(version: $version, appStoreUrl: $appStoreUrl, playStoreUrl: $playStoreUrl, isMaintenance: $isMaintenance, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Maintenance &&
            (identical(other.version, version) || other.version == version) &&
            (identical(other.appStoreUrl, appStoreUrl) ||
                other.appStoreUrl == appStoreUrl) &&
            (identical(other.playStoreUrl, playStoreUrl) ||
                other.playStoreUrl == playStoreUrl) &&
            (identical(other.isMaintenance, isMaintenance) ||
                other.isMaintenance == isMaintenance) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, version, appStoreUrl,
      playStoreUrl, isMaintenance, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MaintenanceCopyWith<_$_Maintenance> get copyWith =>
      __$$_MaintenanceCopyWithImpl<_$_Maintenance>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MaintenanceToJson(
      this,
    );
  }
}

abstract class _Maintenance implements Maintenance {
  const factory _Maintenance(
      {required final String version,
      required final String appStoreUrl,
      required final String playStoreUrl,
      required final bool isMaintenance,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Maintenance;

  factory _Maintenance.fromJson(Map<String, dynamic> json) =
      _$_Maintenance.fromJson;

  @override // アプリケーションバージョン
  String get version;
  @override // Apple App StoreのURL
  String get appStoreUrl;
  @override // Google Play StoreのURL
  String get playStoreUrl;
  @override // メンテナンスフラグ
  bool get isMaintenance;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MaintenanceCopyWith<_$_Maintenance> get copyWith =>
      throw _privateConstructorUsedError;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'completed_title.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CompletedTitle _$CompletedTitleFromJson(Map<String, dynamic> json) {
  return _CompletedTitle.fromJson(json);
}

/// @nodoc
mixin _$CompletedTitle {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedTitleCopyWith<CompletedTitle> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedTitleCopyWith<$Res> {
  factory $CompletedTitleCopyWith(
          CompletedTitle value, $Res Function(CompletedTitle) then) =
      _$CompletedTitleCopyWithImpl<$Res, CompletedTitle>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$CompletedTitleCopyWithImpl<$Res, $Val extends CompletedTitle>
    implements $CompletedTitleCopyWith<$Res> {
  _$CompletedTitleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CompletedTitleCopyWith<$Res>
    implements $CompletedTitleCopyWith<$Res> {
  factory _$$_CompletedTitleCopyWith(
          _$_CompletedTitle value, $Res Function(_$_CompletedTitle) then) =
      __$$_CompletedTitleCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_CompletedTitleCopyWithImpl<$Res>
    extends _$CompletedTitleCopyWithImpl<$Res, _$_CompletedTitle>
    implements _$$_CompletedTitleCopyWith<$Res> {
  __$$_CompletedTitleCopyWithImpl(
      _$_CompletedTitle _value, $Res Function(_$_CompletedTitle) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedTitle(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedTitle implements _CompletedTitle {
  const _$_CompletedTitle(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedTitle.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedTitleFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedTitle(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedTitle &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedTitleCopyWith<_$_CompletedTitle> get copyWith =>
      __$$_CompletedTitleCopyWithImpl<_$_CompletedTitle>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedTitleToJson(
      this,
    );
  }
}

abstract class _CompletedTitle implements CompletedTitle {
  const factory _CompletedTitle(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedTitle;

  factory _CompletedTitle.fromJson(Map<String, dynamic> json) =
      _$_CompletedTitle.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedTitleCopyWith<_$_CompletedTitle> get copyWith =>
      throw _privateConstructorUsedError;
}

TitleHistory _$TitleHistoryFromJson(Map<String, dynamic> json) {
  return _TitleHistory.fromJson(json);
}

/// @nodoc
mixin _$TitleHistory {
// 称号ID
  String get id => throw _privateConstructorUsedError; // 称号名称
  String get name => throw _privateConstructorUsedError; // 称号獲得ポイント
  int get point => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TitleHistoryCopyWith<TitleHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TitleHistoryCopyWith<$Res> {
  factory $TitleHistoryCopyWith(
          TitleHistory value, $Res Function(TitleHistory) then) =
      _$TitleHistoryCopyWithImpl<$Res, TitleHistory>;
  @useResult
  $Res call(
      {String id,
      String name,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$TitleHistoryCopyWithImpl<$Res, $Val extends TitleHistory>
    implements $TitleHistoryCopyWith<$Res> {
  _$TitleHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? point = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_TitleHistoryCopyWith<$Res>
    implements $TitleHistoryCopyWith<$Res> {
  factory _$$_TitleHistoryCopyWith(
          _$_TitleHistory value, $Res Function(_$_TitleHistory) then) =
      __$$_TitleHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      int point,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_TitleHistoryCopyWithImpl<$Res>
    extends _$TitleHistoryCopyWithImpl<$Res, _$_TitleHistory>
    implements _$$_TitleHistoryCopyWith<$Res> {
  __$$_TitleHistoryCopyWithImpl(
      _$_TitleHistory _value, $Res Function(_$_TitleHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? point = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_TitleHistory(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_TitleHistory implements _TitleHistory {
  const _$_TitleHistory(
      {required this.id,
      required this.name,
      required this.point,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_TitleHistory.fromJson(Map<String, dynamic> json) =>
      _$$_TitleHistoryFromJson(json);

// 称号ID
  @override
  final String id;
// 称号名称
  @override
  final String name;
// 称号獲得ポイント
  @override
  final int point;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'TitleHistory(id: $id, name: $name, point: $point, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TitleHistory &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, point, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_TitleHistoryCopyWith<_$_TitleHistory> get copyWith =>
      __$$_TitleHistoryCopyWithImpl<_$_TitleHistory>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_TitleHistoryToJson(
      this,
    );
  }
}

abstract class _TitleHistory implements TitleHistory {
  const factory _TitleHistory(
      {required final String id,
      required final String name,
      required final int point,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_TitleHistory;

  factory _TitleHistory.fromJson(Map<String, dynamic> json) =
      _$_TitleHistory.fromJson;

  @override // 称号ID
  String get id;
  @override // 称号名称
  String get name;
  @override // 称号獲得ポイント
  int get point;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_TitleHistoryCopyWith<_$_TitleHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'maintenance.freezed.dart';
part 'maintenance.g.dart';

/// メンテナンス
@freezed
class Maintenance with _$Maintenance {
  @firestoreSerializable
  const factory Maintenance({
    // アプリケーションバージョン
    required String version,
    // Apple App StoreのURL
    required String appStoreUrl,
    // Google Play StoreのURL
    required String playStoreUrl,
    // メンテナンスフラグ
    required bool isMaintenance,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Maintenance;

  factory Maintenance.fromJson(Map<String, Object?> json) =>
      _$MaintenanceFromJson(json);
}

@Collection<Maintenance>('maintenances')
final maintenancesRef = MaintenanceCollectionReference();

MaintenanceDocumentReference maintenanceRef({required String id}) =>
    MaintenanceDocumentReference(maintenancesRef.doc(id).reference);

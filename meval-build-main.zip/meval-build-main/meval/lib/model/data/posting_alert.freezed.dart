// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'posting_alert.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

PostingAlert _$PostingAlertFromJson(Map<String, dynamic> json) {
  return _PostingAlert.fromJson(json);
}

/// @nodoc
mixin _$PostingAlert {
// 通報ID
  String get id => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 投稿のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get postRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PostingAlertCopyWith<PostingAlert> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PostingAlertCopyWith<$Res> {
  factory $PostingAlertCopyWith(
          PostingAlert value, $Res Function(PostingAlert) then) =
      _$PostingAlertCopyWithImpl<$Res, PostingAlert>;
  @useResult
  $Res call(
      {String id,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @DocumentReferenceConverter() DocumentReference<Object?> postRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$PostingAlertCopyWithImpl<$Res, $Val extends PostingAlert>
    implements $PostingAlertCopyWith<$Res> {
  _$PostingAlertCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? memberRef = null,
    Object? postRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      postRef: null == postRef
          ? _value.postRef
          : postRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PostingAlertCopyWith<$Res>
    implements $PostingAlertCopyWith<$Res> {
  factory _$$_PostingAlertCopyWith(
          _$_PostingAlert value, $Res Function(_$_PostingAlert) then) =
      __$$_PostingAlertCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @DocumentReferenceConverter() DocumentReference<Object?> postRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_PostingAlertCopyWithImpl<$Res>
    extends _$PostingAlertCopyWithImpl<$Res, _$_PostingAlert>
    implements _$$_PostingAlertCopyWith<$Res> {
  __$$_PostingAlertCopyWithImpl(
      _$_PostingAlert _value, $Res Function(_$_PostingAlert) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? memberRef = null,
    Object? postRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_PostingAlert(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      postRef: null == postRef
          ? _value.postRef
          : postRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_PostingAlert implements _PostingAlert {
  const _$_PostingAlert(
      {required this.id,
      @DocumentReferenceConverter() required this.memberRef,
      @DocumentReferenceConverter() required this.postRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_PostingAlert.fromJson(Map<String, dynamic> json) =>
      _$$_PostingAlertFromJson(json);

// 通報ID
  @override
  final String id;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 投稿のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> postRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'PostingAlert(id: $id, memberRef: $memberRef, postRef: $postRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PostingAlert &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.postRef, postRef) || other.postRef == postRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, memberRef, postRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PostingAlertCopyWith<_$_PostingAlert> get copyWith =>
      __$$_PostingAlertCopyWithImpl<_$_PostingAlert>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PostingAlertToJson(
      this,
    );
  }
}

abstract class _PostingAlert implements PostingAlert {
  const factory _PostingAlert(
      {required final String id,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> postRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_PostingAlert;

  factory _PostingAlert.fromJson(Map<String, dynamic> json) =
      _$_PostingAlert.fromJson;

  @override // 通報ID
  String get id;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 投稿のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get postRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_PostingAlertCopyWith<_$_PostingAlert> get copyWith =>
      throw _privateConstructorUsedError;
}

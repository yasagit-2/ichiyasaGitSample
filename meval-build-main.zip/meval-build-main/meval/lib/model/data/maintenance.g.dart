// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'maintenance.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class MaintenanceCollectionReference
    implements
        MaintenanceQuery,
        FirestoreCollectionReference<Maintenance, MaintenanceQuerySnapshot> {
  factory MaintenanceCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$MaintenanceCollectionReference;

  static Maintenance fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return Maintenance.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    Maintenance value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<Maintenance> get reference;

  @override
  MaintenanceDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<MaintenanceDocumentReference> add(Maintenance value);
}

class _$MaintenanceCollectionReference extends _$MaintenanceQuery
    implements MaintenanceCollectionReference {
  factory _$MaintenanceCollectionReference([FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$MaintenanceCollectionReference._(
      firestore.collection('maintenances').withConverter(
            fromFirestore: MaintenanceCollectionReference.fromFirestore,
            toFirestore: MaintenanceCollectionReference.toFirestore,
          ),
    );
  }

  _$MaintenanceCollectionReference._(
    CollectionReference<Maintenance> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<Maintenance> get reference =>
      super.reference as CollectionReference<Maintenance>;

  @override
  MaintenanceDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return MaintenanceDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<MaintenanceDocumentReference> add(Maintenance value) {
    return reference
        .add(value)
        .then((ref) => MaintenanceDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$MaintenanceCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class MaintenanceDocumentReference extends FirestoreDocumentReference<
    Maintenance, MaintenanceDocumentSnapshot> {
  factory MaintenanceDocumentReference(
          DocumentReference<Maintenance> reference) =
      _$MaintenanceDocumentReference;

  DocumentReference<Maintenance> get reference;

  /// A reference to the [MaintenanceCollectionReference] containing this document.
  MaintenanceCollectionReference get parent {
    return _$MaintenanceCollectionReference(reference.firestore);
  }

  @override
  Stream<MaintenanceDocumentSnapshot> snapshots();

  @override
  Future<MaintenanceDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String version,
    FieldValue versionFieldValue,
    String appStoreUrl,
    FieldValue appStoreUrlFieldValue,
    String playStoreUrl,
    FieldValue playStoreUrlFieldValue,
    bool isMaintenance,
    FieldValue isMaintenanceFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String version,
    FieldValue versionFieldValue,
    String appStoreUrl,
    FieldValue appStoreUrlFieldValue,
    String playStoreUrl,
    FieldValue playStoreUrlFieldValue,
    bool isMaintenance,
    FieldValue isMaintenanceFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$MaintenanceDocumentReference
    extends FirestoreDocumentReference<Maintenance, MaintenanceDocumentSnapshot>
    implements MaintenanceDocumentReference {
  _$MaintenanceDocumentReference(this.reference);

  @override
  final DocumentReference<Maintenance> reference;

  /// A reference to the [MaintenanceCollectionReference] containing this document.
  MaintenanceCollectionReference get parent {
    return _$MaintenanceCollectionReference(reference.firestore);
  }

  @override
  Stream<MaintenanceDocumentSnapshot> snapshots() {
    return reference.snapshots().map(MaintenanceDocumentSnapshot._);
  }

  @override
  Future<MaintenanceDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(MaintenanceDocumentSnapshot._);
  }

  @override
  Future<MaintenanceDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(MaintenanceDocumentSnapshot._);
  }

  Future<void> update({
    Object? version = _sentinel,
    FieldValue? versionFieldValue,
    Object? appStoreUrl = _sentinel,
    FieldValue? appStoreUrlFieldValue,
    Object? playStoreUrl = _sentinel,
    FieldValue? playStoreUrlFieldValue,
    Object? isMaintenance = _sentinel,
    FieldValue? isMaintenanceFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      version == _sentinel || versionFieldValue == null,
      "Cannot specify both version and versionFieldValue",
    );
    assert(
      appStoreUrl == _sentinel || appStoreUrlFieldValue == null,
      "Cannot specify both appStoreUrl and appStoreUrlFieldValue",
    );
    assert(
      playStoreUrl == _sentinel || playStoreUrlFieldValue == null,
      "Cannot specify both playStoreUrl and playStoreUrlFieldValue",
    );
    assert(
      isMaintenance == _sentinel || isMaintenanceFieldValue == null,
      "Cannot specify both isMaintenance and isMaintenanceFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (version != _sentinel) 'version': version as String,
      if (versionFieldValue != null) 'version': versionFieldValue,
      if (appStoreUrl != _sentinel) 'appStoreUrl': appStoreUrl as String,
      if (appStoreUrlFieldValue != null) 'appStoreUrl': appStoreUrlFieldValue,
      if (playStoreUrl != _sentinel) 'playStoreUrl': playStoreUrl as String,
      if (playStoreUrlFieldValue != null)
        'playStoreUrl': playStoreUrlFieldValue,
      if (isMaintenance != _sentinel) 'isMaintenance': isMaintenance as bool,
      if (isMaintenanceFieldValue != null)
        'isMaintenance': isMaintenanceFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? version = _sentinel,
    FieldValue? versionFieldValue,
    Object? appStoreUrl = _sentinel,
    FieldValue? appStoreUrlFieldValue,
    Object? playStoreUrl = _sentinel,
    FieldValue? playStoreUrlFieldValue,
    Object? isMaintenance = _sentinel,
    FieldValue? isMaintenanceFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      version == _sentinel || versionFieldValue == null,
      "Cannot specify both version and versionFieldValue",
    );
    assert(
      appStoreUrl == _sentinel || appStoreUrlFieldValue == null,
      "Cannot specify both appStoreUrl and appStoreUrlFieldValue",
    );
    assert(
      playStoreUrl == _sentinel || playStoreUrlFieldValue == null,
      "Cannot specify both playStoreUrl and playStoreUrlFieldValue",
    );
    assert(
      isMaintenance == _sentinel || isMaintenanceFieldValue == null,
      "Cannot specify both isMaintenance and isMaintenanceFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (version != _sentinel) 'version': version as String,
      if (versionFieldValue != null) 'version': versionFieldValue,
      if (appStoreUrl != _sentinel) 'appStoreUrl': appStoreUrl as String,
      if (appStoreUrlFieldValue != null) 'appStoreUrl': appStoreUrlFieldValue,
      if (playStoreUrl != _sentinel) 'playStoreUrl': playStoreUrl as String,
      if (playStoreUrlFieldValue != null)
        'playStoreUrl': playStoreUrlFieldValue,
      if (isMaintenance != _sentinel) 'isMaintenance': isMaintenance as bool,
      if (isMaintenanceFieldValue != null)
        'isMaintenance': isMaintenanceFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is MaintenanceDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class MaintenanceQuery
    implements QueryReference<Maintenance, MaintenanceQuerySnapshot> {
  @override
  MaintenanceQuery limit(int limit);

  @override
  MaintenanceQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  MaintenanceQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  MaintenanceQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  MaintenanceQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  MaintenanceQuery whereVersion({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  MaintenanceQuery whereAppStoreUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  MaintenanceQuery wherePlayStoreUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  MaintenanceQuery whereIsMaintenance({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  });
  MaintenanceQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  MaintenanceQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  MaintenanceQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByVersion({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByAppStoreUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByPlayStoreUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByIsMaintenance({
    bool descending = false,
    bool startAt,
    bool startAfter,
    bool endAt,
    bool endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });

  MaintenanceQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  });
}

class _$MaintenanceQuery
    extends QueryReference<Maintenance, MaintenanceQuerySnapshot>
    implements MaintenanceQuery {
  _$MaintenanceQuery(
    this._collection, {
    required Query<Maintenance> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<MaintenanceQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference
        .snapshots()
        .map(MaintenanceQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<MaintenanceQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(MaintenanceQuerySnapshot._fromQuerySnapshot);
  }

  @override
  MaintenanceQuery limit(int limit) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  MaintenanceQuery limitToLast(int limit) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereVersion({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['version']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereAppStoreUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['appStoreUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery wherePlayStoreUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['playStoreUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereIsMaintenance({
    bool? isEqualTo,
    bool? isNotEqualTo,
    bool? isLessThan,
    bool? isLessThanOrEqualTo,
    bool? isGreaterThan,
    bool? isGreaterThanOrEqualTo,
    bool? isNull,
    List<bool>? whereIn,
    List<bool>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['isMaintenance']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_MaintenanceFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  MaintenanceQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByVersion({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_MaintenanceFieldMap['version']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByAppStoreUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_MaintenanceFieldMap['appStoreUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByPlayStoreUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_MaintenanceFieldMap['playStoreUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByIsMaintenance({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_MaintenanceFieldMap['isMaintenance']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_MaintenanceFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  MaintenanceQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    MaintenanceDocumentSnapshot? startAtDocument,
    MaintenanceDocumentSnapshot? endAtDocument,
    MaintenanceDocumentSnapshot? endBeforeDocument,
    MaintenanceDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_MaintenanceFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$MaintenanceQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$MaintenanceQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class MaintenanceDocumentSnapshot
    extends FirestoreDocumentSnapshot<Maintenance> {
  MaintenanceDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<Maintenance> snapshot;

  @override
  MaintenanceDocumentReference get reference {
    return MaintenanceDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final Maintenance? data;
}

class MaintenanceQuerySnapshot extends FirestoreQuerySnapshot<Maintenance,
    MaintenanceQueryDocumentSnapshot> {
  MaintenanceQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory MaintenanceQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<Maintenance> snapshot,
  ) {
    final docs = snapshot.docs.map(MaintenanceQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        MaintenanceDocumentSnapshot._,
      );
    }).toList();

    return MaintenanceQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<MaintenanceDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    MaintenanceDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<MaintenanceDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<Maintenance> snapshot;

  @override
  final List<MaintenanceQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<MaintenanceDocumentSnapshot>> docChanges;
}

class MaintenanceQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<Maintenance>
    implements MaintenanceDocumentSnapshot {
  MaintenanceQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<Maintenance> snapshot;

  @override
  final Maintenance data;

  @override
  MaintenanceDocumentReference get reference {
    return MaintenanceDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Maintenance _$$_MaintenanceFromJson(Map<String, dynamic> json) =>
    _$_Maintenance(
      version: json['version'] as String,
      appStoreUrl: json['appStoreUrl'] as String,
      playStoreUrl: json['playStoreUrl'] as String,
      isMaintenance: json['isMaintenance'] as bool,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_MaintenanceFieldMap = <String, String>{
  'version': 'version',
  'appStoreUrl': 'appStoreUrl',
  'playStoreUrl': 'playStoreUrl',
  'isMaintenance': 'isMaintenance',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_MaintenanceToJson(_$_Maintenance instance) {
  final val = <String, dynamic>{
    'version': instance.version,
    'appStoreUrl': instance.appStoreUrl,
    'playStoreUrl': instance.playStoreUrl,
    'isMaintenance': instance.isMaintenance,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'event_participation_history.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

EventParticipationHistory _$EventParticipationHistoryFromJson(
    Map<String, dynamic> json) {
  return _EventParticipationHistory.fromJson(json);
}

/// @nodoc
mixin _$EventParticipationHistory {
// 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EventParticipationHistoryCopyWith<EventParticipationHistory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventParticipationHistoryCopyWith<$Res> {
  factory $EventParticipationHistoryCopyWith(EventParticipationHistory value,
          $Res Function(EventParticipationHistory) then) =
      _$EventParticipationHistoryCopyWithImpl<$Res, EventParticipationHistory>;
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$EventParticipationHistoryCopyWithImpl<$Res,
        $Val extends EventParticipationHistory>
    implements $EventParticipationHistoryCopyWith<$Res> {
  _$EventParticipationHistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_EventParticipationHistoryCopyWith<$Res>
    implements $EventParticipationHistoryCopyWith<$Res> {
  factory _$$_EventParticipationHistoryCopyWith(
          _$_EventParticipationHistory value,
          $Res Function(_$_EventParticipationHistory) then) =
      __$$_EventParticipationHistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_EventParticipationHistoryCopyWithImpl<$Res>
    extends _$EventParticipationHistoryCopyWithImpl<$Res,
        _$_EventParticipationHistory>
    implements _$$_EventParticipationHistoryCopyWith<$Res> {
  __$$_EventParticipationHistoryCopyWithImpl(
      _$_EventParticipationHistory _value,
      $Res Function(_$_EventParticipationHistory) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_EventParticipationHistory(
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_EventParticipationHistory implements _EventParticipationHistory {
  const _$_EventParticipationHistory(
      {@DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_EventParticipationHistory.fromJson(Map<String, dynamic> json) =>
      _$$_EventParticipationHistoryFromJson(json);

// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'EventParticipationHistory(memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EventParticipationHistory &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventParticipationHistoryCopyWith<_$_EventParticipationHistory>
      get copyWith => __$$_EventParticipationHistoryCopyWithImpl<
          _$_EventParticipationHistory>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_EventParticipationHistoryToJson(
      this,
    );
  }
}

abstract class _EventParticipationHistory implements EventParticipationHistory {
  const factory _EventParticipationHistory(
      {@DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_EventParticipationHistory;

  factory _EventParticipationHistory.fromJson(Map<String, dynamic> json) =
      _$_EventParticipationHistory.fromJson;

  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_EventParticipationHistoryCopyWith<_$_EventParticipationHistory>
      get copyWith => throw _privateConstructorUsedError;
}

ParticipatedEvent _$ParticipatedEventFromJson(Map<String, dynamic> json) {
  return _ParticipatedEvent.fromJson(json);
}

/// @nodoc
mixin _$ParticipatedEvent {
// イベントID
  String get id => throw _privateConstructorUsedError; // イベントタイトル
  String get title => throw _privateConstructorUsedError; // イベント達成獲得ポイント
  int get point => throw _privateConstructorUsedError; // 交換対象種別
  int get exchangeType => throw _privateConstructorUsedError; // イベント達成地点数
  int get completeSpotCount => throw _privateConstructorUsedError; // イベント達成フラグ
  bool get isComplete => throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ParticipatedEventCopyWith<ParticipatedEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ParticipatedEventCopyWith<$Res> {
  factory $ParticipatedEventCopyWith(
          ParticipatedEvent value, $Res Function(ParticipatedEvent) then) =
      _$ParticipatedEventCopyWithImpl<$Res, ParticipatedEvent>;
  @useResult
  $Res call(
      {String id,
      String title,
      int point,
      int exchangeType,
      int completeSpotCount,
      bool isComplete,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$ParticipatedEventCopyWithImpl<$Res, $Val extends ParticipatedEvent>
    implements $ParticipatedEventCopyWith<$Res> {
  _$ParticipatedEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? point = null,
    Object? exchangeType = null,
    Object? completeSpotCount = null,
    Object? isComplete = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeType: null == exchangeType
          ? _value.exchangeType
          : exchangeType // ignore: cast_nullable_to_non_nullable
              as int,
      completeSpotCount: null == completeSpotCount
          ? _value.completeSpotCount
          : completeSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      isComplete: null == isComplete
          ? _value.isComplete
          : isComplete // ignore: cast_nullable_to_non_nullable
              as bool,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ParticipatedEventCopyWith<$Res>
    implements $ParticipatedEventCopyWith<$Res> {
  factory _$$_ParticipatedEventCopyWith(_$_ParticipatedEvent value,
          $Res Function(_$_ParticipatedEvent) then) =
      __$$_ParticipatedEventCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String title,
      int point,
      int exchangeType,
      int completeSpotCount,
      bool isComplete,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_ParticipatedEventCopyWithImpl<$Res>
    extends _$ParticipatedEventCopyWithImpl<$Res, _$_ParticipatedEvent>
    implements _$$_ParticipatedEventCopyWith<$Res> {
  __$$_ParticipatedEventCopyWithImpl(
      _$_ParticipatedEvent _value, $Res Function(_$_ParticipatedEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? point = null,
    Object? exchangeType = null,
    Object? completeSpotCount = null,
    Object? isComplete = null,
    Object? memberRef = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_ParticipatedEvent(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeType: null == exchangeType
          ? _value.exchangeType
          : exchangeType // ignore: cast_nullable_to_non_nullable
              as int,
      completeSpotCount: null == completeSpotCount
          ? _value.completeSpotCount
          : completeSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      isComplete: null == isComplete
          ? _value.isComplete
          : isComplete // ignore: cast_nullable_to_non_nullable
              as bool,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_ParticipatedEvent implements _ParticipatedEvent {
  const _$_ParticipatedEvent(
      {required this.id,
      required this.title,
      required this.point,
      required this.exchangeType,
      required this.completeSpotCount,
      this.isComplete = false,
      @DocumentReferenceConverter() required this.memberRef,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_ParticipatedEvent.fromJson(Map<String, dynamic> json) =>
      _$$_ParticipatedEventFromJson(json);

// イベントID
  @override
  final String id;
// イベントタイトル
  @override
  final String title;
// イベント達成獲得ポイント
  @override
  final int point;
// 交換対象種別
  @override
  final int exchangeType;
// イベント達成地点数
  @override
  final int completeSpotCount;
// イベント達成フラグ
  @override
  @JsonKey()
  final bool isComplete;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'ParticipatedEvent(id: $id, title: $title, point: $point, exchangeType: $exchangeType, completeSpotCount: $completeSpotCount, isComplete: $isComplete, memberRef: $memberRef, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ParticipatedEvent &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.exchangeType, exchangeType) ||
                other.exchangeType == exchangeType) &&
            (identical(other.completeSpotCount, completeSpotCount) ||
                other.completeSpotCount == completeSpotCount) &&
            (identical(other.isComplete, isComplete) ||
                other.isComplete == isComplete) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, title, point, exchangeType,
      completeSpotCount, isComplete, memberRef, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ParticipatedEventCopyWith<_$_ParticipatedEvent> get copyWith =>
      __$$_ParticipatedEventCopyWithImpl<_$_ParticipatedEvent>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ParticipatedEventToJson(
      this,
    );
  }
}

abstract class _ParticipatedEvent implements ParticipatedEvent {
  const factory _ParticipatedEvent(
      {required final String id,
      required final String title,
      required final int point,
      required final int exchangeType,
      required final int completeSpotCount,
      final bool isComplete,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_ParticipatedEvent;

  factory _ParticipatedEvent.fromJson(Map<String, dynamic> json) =
      _$_ParticipatedEvent.fromJson;

  @override // イベントID
  String get id;
  @override // イベントタイトル
  String get title;
  @override // イベント達成獲得ポイント
  int get point;
  @override // 交換対象種別
  int get exchangeType;
  @override // イベント達成地点数
  int get completeSpotCount;
  @override // イベント達成フラグ
  bool get isComplete;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_ParticipatedEventCopyWith<_$_ParticipatedEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

CompletedSpot _$CompletedSpotFromJson(Map<String, dynamic> json) {
  return _CompletedSpot.fromJson(json);
}

/// @nodoc
mixin _$CompletedSpot {
// QRコード識別子
  String get id => throw _privateConstructorUsedError; // イベントスポットID
  String get eventSpotId => throw _privateConstructorUsedError; // イベントスポット名称
  String get eventSpotName =>
      throw _privateConstructorUsedError; // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef =>
      throw _privateConstructorUsedError; // イベントスポットの位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompletedSpotCopyWith<CompletedSpot> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompletedSpotCopyWith<$Res> {
  factory $CompletedSpotCopyWith(
          CompletedSpot value, $Res Function(CompletedSpot) then) =
      _$CompletedSpotCopyWithImpl<$Res, CompletedSpot>;
  @useResult
  $Res call(
      {String id,
      String eventSpotId,
      String eventSpotName,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$CompletedSpotCopyWithImpl<$Res, $Val extends CompletedSpot>
    implements $CompletedSpotCopyWith<$Res> {
  _$CompletedSpotCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? eventSpotId = null,
    Object? eventSpotName = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotId: null == eventSpotId
          ? _value.eventSpotId
          : eventSpotId // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotName: null == eventSpotName
          ? _value.eventSpotName
          : eventSpotName // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_CompletedSpotCopyWith<$Res>
    implements $CompletedSpotCopyWith<$Res> {
  factory _$$_CompletedSpotCopyWith(
          _$_CompletedSpot value, $Res Function(_$_CompletedSpot) then) =
      __$$_CompletedSpotCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String eventSpotId,
      String eventSpotName,
      @DocumentReferenceConverter() DocumentReference<Object?> memberRef,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_CompletedSpotCopyWithImpl<$Res>
    extends _$CompletedSpotCopyWithImpl<$Res, _$_CompletedSpot>
    implements _$$_CompletedSpotCopyWith<$Res> {
  __$$_CompletedSpotCopyWithImpl(
      _$_CompletedSpot _value, $Res Function(_$_CompletedSpot) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? eventSpotId = null,
    Object? eventSpotName = null,
    Object? memberRef = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_CompletedSpot(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotId: null == eventSpotId
          ? _value.eventSpotId
          : eventSpotId // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotName: null == eventSpotName
          ? _value.eventSpotName
          : eventSpotName // ignore: cast_nullable_to_non_nullable
              as String,
      memberRef: null == memberRef
          ? _value.memberRef
          : memberRef // ignore: cast_nullable_to_non_nullable
              as DocumentReference<Object?>,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_CompletedSpot implements _CompletedSpot {
  const _$_CompletedSpot(
      {required this.id,
      required this.eventSpotId,
      required this.eventSpotName,
      @DocumentReferenceConverter() required this.memberRef,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_CompletedSpot.fromJson(Map<String, dynamic> json) =>
      _$$_CompletedSpotFromJson(json);

// QRコード識別子
  @override
  final String id;
// イベントスポットID
  @override
  final String eventSpotId;
// イベントスポット名称
  @override
  final String eventSpotName;
// 会員のReference
  @override
  @DocumentReferenceConverter()
  final DocumentReference<Object?> memberRef;
// イベントスポットの位置情報
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'CompletedSpot(id: $id, eventSpotId: $eventSpotId, eventSpotName: $eventSpotName, memberRef: $memberRef, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CompletedSpot &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.eventSpotId, eventSpotId) ||
                other.eventSpotId == eventSpotId) &&
            (identical(other.eventSpotName, eventSpotName) ||
                other.eventSpotName == eventSpotName) &&
            (identical(other.memberRef, memberRef) ||
                other.memberRef == memberRef) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, eventSpotId, eventSpotName,
      memberRef, position, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CompletedSpotCopyWith<_$_CompletedSpot> get copyWith =>
      __$$_CompletedSpotCopyWithImpl<_$_CompletedSpot>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CompletedSpotToJson(
      this,
    );
  }
}

abstract class _CompletedSpot implements CompletedSpot {
  const factory _CompletedSpot(
      {required final String id,
      required final String eventSpotId,
      required final String eventSpotName,
      @DocumentReferenceConverter()
          required final DocumentReference<Object?> memberRef,
      required final MapPosition position,
      @TimestampConverter()
          final DateTime? updatedAt,
      @TimestampConverter()
          final DateTime? createdAt}) = _$_CompletedSpot;

  factory _CompletedSpot.fromJson(Map<String, dynamic> json) =
      _$_CompletedSpot.fromJson;

  @override // QRコード識別子
  String get id;
  @override // イベントスポットID
  String get eventSpotId;
  @override // イベントスポット名称
  String get eventSpotName;
  @override // 会員のReference
  @DocumentReferenceConverter()
  DocumentReference<Object?> get memberRef;
  @override // イベントスポットの位置情報
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_CompletedSpotCopyWith<_$_CompletedSpot> get copyWith =>
      throw _privateConstructorUsedError;
}

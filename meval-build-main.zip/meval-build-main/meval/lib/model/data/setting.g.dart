// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: type=lint

part of 'setting.dart';

// **************************************************************************
// CollectionGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, require_trailing_commas, prefer_single_quotes, prefer_double_quotes, use_super_parameters

class _Sentinel {
  const _Sentinel();
}

const _sentinel = _Sentinel();

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class SettingCollectionReference
    implements
        SettingQuery,
        FirestoreCollectionReference<Setting, SettingQuerySnapshot> {
  factory SettingCollectionReference([
    FirebaseFirestore? firestore,
  ]) = _$SettingCollectionReference;

  static Setting fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return Setting.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    Setting value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<Setting> get reference;

  @override
  SettingDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<SettingDocumentReference> add(Setting value);
}

class _$SettingCollectionReference extends _$SettingQuery
    implements SettingCollectionReference {
  factory _$SettingCollectionReference([FirebaseFirestore? firestore]) {
    firestore ??= FirebaseFirestore.instance;

    return _$SettingCollectionReference._(
      firestore.collection('settings').withConverter(
            fromFirestore: SettingCollectionReference.fromFirestore,
            toFirestore: SettingCollectionReference.toFirestore,
          ),
    );
  }

  _$SettingCollectionReference._(
    CollectionReference<Setting> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  String get path => reference.path;

  @override
  CollectionReference<Setting> get reference =>
      super.reference as CollectionReference<Setting>;

  @override
  SettingDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return SettingDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<SettingDocumentReference> add(Setting value) {
    return reference.add(value).then((ref) => SettingDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$SettingCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class SettingDocumentReference
    extends FirestoreDocumentReference<Setting, SettingDocumentSnapshot> {
  factory SettingDocumentReference(DocumentReference<Setting> reference) =
      _$SettingDocumentReference;

  DocumentReference<Setting> get reference;

  /// A reference to the [SettingCollectionReference] containing this document.
  SettingCollectionReference get parent {
    return _$SettingCollectionReference(reference.firestore);
  }

  late final WeekCollectionReference weeks = _$WeekCollectionReference(
    reference,
  );

  late final PostIconCollectionReference postIcons =
      _$PostIconCollectionReference(
    reference,
  );

  @override
  Stream<SettingDocumentSnapshot> snapshots();

  @override
  Future<SettingDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String baseIconUrl,
    FieldValue baseIconUrlFieldValue,
    String baseCheckedInIconUrl,
    FieldValue baseCheckedInIconUrlFieldValue,
    String subBaseIconUrl,
    FieldValue subBaseIconUrlFieldValue,
    String merchantIconUrl,
    FieldValue merchantIconUrlFieldValue,
    String merchantTweetIconUrl,
    FieldValue merchantTweetIconUrlFieldValue,
    String postIconUrl,
    FieldValue postIconUrlFieldValue,
    String adminAlertIconUrl,
    FieldValue adminAlertIconUrlFieldValue,
    String adminQuestionnaireIconUrl,
    FieldValue adminQuestionnaireIconUrlFieldValue,
    double checkInRadius,
    FieldValue checkInRadiusFieldValue,
    double collectionRadius,
    FieldValue collectionRadiusFieldValue,
    int targetStepPerWeek,
    FieldValue targetStepPerWeekFieldValue,
    int stepAchievedPoint,
    FieldValue stepAchievedPointFieldValue,
    int postIntervalLimitHour,
    FieldValue postIntervalLimitHourFieldValue,
    int reportIntervalLimitHour,
    FieldValue reportIntervalLimitHourFieldValue,
    int commentIntervalLimitMinute,
    FieldValue commentIntervalLimitMinuteFieldValue,
    int notificationRetentionDay,
    FieldValue notificationRetentionDayFieldValue,
    int eventRetentionDay,
    FieldValue eventRetentionDayFieldValue,
    String privacyPolicyUrl,
    FieldValue privacyPolicyUrlFieldValue,
    String helpPageUrl,
    FieldValue helpPageUrlFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String baseIconUrl,
    FieldValue baseIconUrlFieldValue,
    String baseCheckedInIconUrl,
    FieldValue baseCheckedInIconUrlFieldValue,
    String subBaseIconUrl,
    FieldValue subBaseIconUrlFieldValue,
    String merchantIconUrl,
    FieldValue merchantIconUrlFieldValue,
    String merchantTweetIconUrl,
    FieldValue merchantTweetIconUrlFieldValue,
    String postIconUrl,
    FieldValue postIconUrlFieldValue,
    String adminAlertIconUrl,
    FieldValue adminAlertIconUrlFieldValue,
    String adminQuestionnaireIconUrl,
    FieldValue adminQuestionnaireIconUrlFieldValue,
    double checkInRadius,
    FieldValue checkInRadiusFieldValue,
    double collectionRadius,
    FieldValue collectionRadiusFieldValue,
    int targetStepPerWeek,
    FieldValue targetStepPerWeekFieldValue,
    int stepAchievedPoint,
    FieldValue stepAchievedPointFieldValue,
    int postIntervalLimitHour,
    FieldValue postIntervalLimitHourFieldValue,
    int reportIntervalLimitHour,
    FieldValue reportIntervalLimitHourFieldValue,
    int commentIntervalLimitMinute,
    FieldValue commentIntervalLimitMinuteFieldValue,
    int notificationRetentionDay,
    FieldValue notificationRetentionDayFieldValue,
    int eventRetentionDay,
    FieldValue eventRetentionDayFieldValue,
    String privacyPolicyUrl,
    FieldValue privacyPolicyUrlFieldValue,
    String helpPageUrl,
    FieldValue helpPageUrlFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$SettingDocumentReference
    extends FirestoreDocumentReference<Setting, SettingDocumentSnapshot>
    implements SettingDocumentReference {
  _$SettingDocumentReference(this.reference);

  @override
  final DocumentReference<Setting> reference;

  /// A reference to the [SettingCollectionReference] containing this document.
  SettingCollectionReference get parent {
    return _$SettingCollectionReference(reference.firestore);
  }

  late final WeekCollectionReference weeks = _$WeekCollectionReference(
    reference,
  );

  late final PostIconCollectionReference postIcons =
      _$PostIconCollectionReference(
    reference,
  );

  @override
  Stream<SettingDocumentSnapshot> snapshots() {
    return reference.snapshots().map(SettingDocumentSnapshot._);
  }

  @override
  Future<SettingDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(SettingDocumentSnapshot._);
  }

  @override
  Future<SettingDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(SettingDocumentSnapshot._);
  }

  Future<void> update({
    Object? baseIconUrl = _sentinel,
    FieldValue? baseIconUrlFieldValue,
    Object? baseCheckedInIconUrl = _sentinel,
    FieldValue? baseCheckedInIconUrlFieldValue,
    Object? subBaseIconUrl = _sentinel,
    FieldValue? subBaseIconUrlFieldValue,
    Object? merchantIconUrl = _sentinel,
    FieldValue? merchantIconUrlFieldValue,
    Object? merchantTweetIconUrl = _sentinel,
    FieldValue? merchantTweetIconUrlFieldValue,
    Object? postIconUrl = _sentinel,
    FieldValue? postIconUrlFieldValue,
    Object? adminAlertIconUrl = _sentinel,
    FieldValue? adminAlertIconUrlFieldValue,
    Object? adminQuestionnaireIconUrl = _sentinel,
    FieldValue? adminQuestionnaireIconUrlFieldValue,
    Object? checkInRadius = _sentinel,
    FieldValue? checkInRadiusFieldValue,
    Object? collectionRadius = _sentinel,
    FieldValue? collectionRadiusFieldValue,
    Object? targetStepPerWeek = _sentinel,
    FieldValue? targetStepPerWeekFieldValue,
    Object? stepAchievedPoint = _sentinel,
    FieldValue? stepAchievedPointFieldValue,
    Object? postIntervalLimitHour = _sentinel,
    FieldValue? postIntervalLimitHourFieldValue,
    Object? reportIntervalLimitHour = _sentinel,
    FieldValue? reportIntervalLimitHourFieldValue,
    Object? commentIntervalLimitMinute = _sentinel,
    FieldValue? commentIntervalLimitMinuteFieldValue,
    Object? notificationRetentionDay = _sentinel,
    FieldValue? notificationRetentionDayFieldValue,
    Object? eventRetentionDay = _sentinel,
    FieldValue? eventRetentionDayFieldValue,
    Object? privacyPolicyUrl = _sentinel,
    FieldValue? privacyPolicyUrlFieldValue,
    Object? helpPageUrl = _sentinel,
    FieldValue? helpPageUrlFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      baseIconUrl == _sentinel || baseIconUrlFieldValue == null,
      "Cannot specify both baseIconUrl and baseIconUrlFieldValue",
    );
    assert(
      baseCheckedInIconUrl == _sentinel ||
          baseCheckedInIconUrlFieldValue == null,
      "Cannot specify both baseCheckedInIconUrl and baseCheckedInIconUrlFieldValue",
    );
    assert(
      subBaseIconUrl == _sentinel || subBaseIconUrlFieldValue == null,
      "Cannot specify both subBaseIconUrl and subBaseIconUrlFieldValue",
    );
    assert(
      merchantIconUrl == _sentinel || merchantIconUrlFieldValue == null,
      "Cannot specify both merchantIconUrl and merchantIconUrlFieldValue",
    );
    assert(
      merchantTweetIconUrl == _sentinel ||
          merchantTweetIconUrlFieldValue == null,
      "Cannot specify both merchantTweetIconUrl and merchantTweetIconUrlFieldValue",
    );
    assert(
      postIconUrl == _sentinel || postIconUrlFieldValue == null,
      "Cannot specify both postIconUrl and postIconUrlFieldValue",
    );
    assert(
      adminAlertIconUrl == _sentinel || adminAlertIconUrlFieldValue == null,
      "Cannot specify both adminAlertIconUrl and adminAlertIconUrlFieldValue",
    );
    assert(
      adminQuestionnaireIconUrl == _sentinel ||
          adminQuestionnaireIconUrlFieldValue == null,
      "Cannot specify both adminQuestionnaireIconUrl and adminQuestionnaireIconUrlFieldValue",
    );
    assert(
      checkInRadius == _sentinel || checkInRadiusFieldValue == null,
      "Cannot specify both checkInRadius and checkInRadiusFieldValue",
    );
    assert(
      collectionRadius == _sentinel || collectionRadiusFieldValue == null,
      "Cannot specify both collectionRadius and collectionRadiusFieldValue",
    );
    assert(
      targetStepPerWeek == _sentinel || targetStepPerWeekFieldValue == null,
      "Cannot specify both targetStepPerWeek and targetStepPerWeekFieldValue",
    );
    assert(
      stepAchievedPoint == _sentinel || stepAchievedPointFieldValue == null,
      "Cannot specify both stepAchievedPoint and stepAchievedPointFieldValue",
    );
    assert(
      postIntervalLimitHour == _sentinel ||
          postIntervalLimitHourFieldValue == null,
      "Cannot specify both postIntervalLimitHour and postIntervalLimitHourFieldValue",
    );
    assert(
      reportIntervalLimitHour == _sentinel ||
          reportIntervalLimitHourFieldValue == null,
      "Cannot specify both reportIntervalLimitHour and reportIntervalLimitHourFieldValue",
    );
    assert(
      commentIntervalLimitMinute == _sentinel ||
          commentIntervalLimitMinuteFieldValue == null,
      "Cannot specify both commentIntervalLimitMinute and commentIntervalLimitMinuteFieldValue",
    );
    assert(
      notificationRetentionDay == _sentinel ||
          notificationRetentionDayFieldValue == null,
      "Cannot specify both notificationRetentionDay and notificationRetentionDayFieldValue",
    );
    assert(
      eventRetentionDay == _sentinel || eventRetentionDayFieldValue == null,
      "Cannot specify both eventRetentionDay and eventRetentionDayFieldValue",
    );
    assert(
      privacyPolicyUrl == _sentinel || privacyPolicyUrlFieldValue == null,
      "Cannot specify both privacyPolicyUrl and privacyPolicyUrlFieldValue",
    );
    assert(
      helpPageUrl == _sentinel || helpPageUrlFieldValue == null,
      "Cannot specify both helpPageUrl and helpPageUrlFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (baseIconUrl != _sentinel) 'baseIconUrl': baseIconUrl as String,
      if (baseIconUrlFieldValue != null) 'baseIconUrl': baseIconUrlFieldValue,
      if (baseCheckedInIconUrl != _sentinel)
        'baseCheckedInIconUrl': baseCheckedInIconUrl as String,
      if (baseCheckedInIconUrlFieldValue != null)
        'baseCheckedInIconUrl': baseCheckedInIconUrlFieldValue,
      if (subBaseIconUrl != _sentinel)
        'subBaseIconUrl': subBaseIconUrl as String,
      if (subBaseIconUrlFieldValue != null)
        'subBaseIconUrl': subBaseIconUrlFieldValue,
      if (merchantIconUrl != _sentinel)
        'merchantIconUrl': merchantIconUrl as String,
      if (merchantIconUrlFieldValue != null)
        'merchantIconUrl': merchantIconUrlFieldValue,
      if (merchantTweetIconUrl != _sentinel)
        'merchantTweetIconUrl': merchantTweetIconUrl as String,
      if (merchantTweetIconUrlFieldValue != null)
        'merchantTweetIconUrl': merchantTweetIconUrlFieldValue,
      if (postIconUrl != _sentinel) 'postIconUrl': postIconUrl as String,
      if (postIconUrlFieldValue != null) 'postIconUrl': postIconUrlFieldValue,
      if (adminAlertIconUrl != _sentinel)
        'adminAlertIconUrl': adminAlertIconUrl as String,
      if (adminAlertIconUrlFieldValue != null)
        'adminAlertIconUrl': adminAlertIconUrlFieldValue,
      if (adminQuestionnaireIconUrl != _sentinel)
        'adminQuestionnaireIconUrl': adminQuestionnaireIconUrl as String,
      if (adminQuestionnaireIconUrlFieldValue != null)
        'adminQuestionnaireIconUrl': adminQuestionnaireIconUrlFieldValue,
      if (checkInRadius != _sentinel) 'checkInRadius': checkInRadius as double,
      if (checkInRadiusFieldValue != null)
        'checkInRadius': checkInRadiusFieldValue,
      if (collectionRadius != _sentinel)
        'collectionRadius': collectionRadius as double,
      if (collectionRadiusFieldValue != null)
        'collectionRadius': collectionRadiusFieldValue,
      if (targetStepPerWeek != _sentinel)
        'targetStepPerWeek': targetStepPerWeek as int,
      if (targetStepPerWeekFieldValue != null)
        'targetStepPerWeek': targetStepPerWeekFieldValue,
      if (stepAchievedPoint != _sentinel)
        'stepAchievedPoint': stepAchievedPoint as int,
      if (stepAchievedPointFieldValue != null)
        'stepAchievedPoint': stepAchievedPointFieldValue,
      if (postIntervalLimitHour != _sentinel)
        'postIntervalLimitHour': postIntervalLimitHour as int,
      if (postIntervalLimitHourFieldValue != null)
        'postIntervalLimitHour': postIntervalLimitHourFieldValue,
      if (reportIntervalLimitHour != _sentinel)
        'reportIntervalLimitHour': reportIntervalLimitHour as int,
      if (reportIntervalLimitHourFieldValue != null)
        'reportIntervalLimitHour': reportIntervalLimitHourFieldValue,
      if (commentIntervalLimitMinute != _sentinel)
        'commentIntervalLimitMinute': commentIntervalLimitMinute as int,
      if (commentIntervalLimitMinuteFieldValue != null)
        'commentIntervalLimitMinute': commentIntervalLimitMinuteFieldValue,
      if (notificationRetentionDay != _sentinel)
        'notificationRetentionDay': notificationRetentionDay as int,
      if (notificationRetentionDayFieldValue != null)
        'notificationRetentionDay': notificationRetentionDayFieldValue,
      if (eventRetentionDay != _sentinel)
        'eventRetentionDay': eventRetentionDay as int,
      if (eventRetentionDayFieldValue != null)
        'eventRetentionDay': eventRetentionDayFieldValue,
      if (privacyPolicyUrl != _sentinel)
        'privacyPolicyUrl': privacyPolicyUrl as String,
      if (privacyPolicyUrlFieldValue != null)
        'privacyPolicyUrl': privacyPolicyUrlFieldValue,
      if (helpPageUrl != _sentinel) 'helpPageUrl': helpPageUrl as String,
      if (helpPageUrlFieldValue != null) 'helpPageUrl': helpPageUrlFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? baseIconUrl = _sentinel,
    FieldValue? baseIconUrlFieldValue,
    Object? baseCheckedInIconUrl = _sentinel,
    FieldValue? baseCheckedInIconUrlFieldValue,
    Object? subBaseIconUrl = _sentinel,
    FieldValue? subBaseIconUrlFieldValue,
    Object? merchantIconUrl = _sentinel,
    FieldValue? merchantIconUrlFieldValue,
    Object? merchantTweetIconUrl = _sentinel,
    FieldValue? merchantTweetIconUrlFieldValue,
    Object? postIconUrl = _sentinel,
    FieldValue? postIconUrlFieldValue,
    Object? adminAlertIconUrl = _sentinel,
    FieldValue? adminAlertIconUrlFieldValue,
    Object? adminQuestionnaireIconUrl = _sentinel,
    FieldValue? adminQuestionnaireIconUrlFieldValue,
    Object? checkInRadius = _sentinel,
    FieldValue? checkInRadiusFieldValue,
    Object? collectionRadius = _sentinel,
    FieldValue? collectionRadiusFieldValue,
    Object? targetStepPerWeek = _sentinel,
    FieldValue? targetStepPerWeekFieldValue,
    Object? stepAchievedPoint = _sentinel,
    FieldValue? stepAchievedPointFieldValue,
    Object? postIntervalLimitHour = _sentinel,
    FieldValue? postIntervalLimitHourFieldValue,
    Object? reportIntervalLimitHour = _sentinel,
    FieldValue? reportIntervalLimitHourFieldValue,
    Object? commentIntervalLimitMinute = _sentinel,
    FieldValue? commentIntervalLimitMinuteFieldValue,
    Object? notificationRetentionDay = _sentinel,
    FieldValue? notificationRetentionDayFieldValue,
    Object? eventRetentionDay = _sentinel,
    FieldValue? eventRetentionDayFieldValue,
    Object? privacyPolicyUrl = _sentinel,
    FieldValue? privacyPolicyUrlFieldValue,
    Object? helpPageUrl = _sentinel,
    FieldValue? helpPageUrlFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      baseIconUrl == _sentinel || baseIconUrlFieldValue == null,
      "Cannot specify both baseIconUrl and baseIconUrlFieldValue",
    );
    assert(
      baseCheckedInIconUrl == _sentinel ||
          baseCheckedInIconUrlFieldValue == null,
      "Cannot specify both baseCheckedInIconUrl and baseCheckedInIconUrlFieldValue",
    );
    assert(
      subBaseIconUrl == _sentinel || subBaseIconUrlFieldValue == null,
      "Cannot specify both subBaseIconUrl and subBaseIconUrlFieldValue",
    );
    assert(
      merchantIconUrl == _sentinel || merchantIconUrlFieldValue == null,
      "Cannot specify both merchantIconUrl and merchantIconUrlFieldValue",
    );
    assert(
      merchantTweetIconUrl == _sentinel ||
          merchantTweetIconUrlFieldValue == null,
      "Cannot specify both merchantTweetIconUrl and merchantTweetIconUrlFieldValue",
    );
    assert(
      postIconUrl == _sentinel || postIconUrlFieldValue == null,
      "Cannot specify both postIconUrl and postIconUrlFieldValue",
    );
    assert(
      adminAlertIconUrl == _sentinel || adminAlertIconUrlFieldValue == null,
      "Cannot specify both adminAlertIconUrl and adminAlertIconUrlFieldValue",
    );
    assert(
      adminQuestionnaireIconUrl == _sentinel ||
          adminQuestionnaireIconUrlFieldValue == null,
      "Cannot specify both adminQuestionnaireIconUrl and adminQuestionnaireIconUrlFieldValue",
    );
    assert(
      checkInRadius == _sentinel || checkInRadiusFieldValue == null,
      "Cannot specify both checkInRadius and checkInRadiusFieldValue",
    );
    assert(
      collectionRadius == _sentinel || collectionRadiusFieldValue == null,
      "Cannot specify both collectionRadius and collectionRadiusFieldValue",
    );
    assert(
      targetStepPerWeek == _sentinel || targetStepPerWeekFieldValue == null,
      "Cannot specify both targetStepPerWeek and targetStepPerWeekFieldValue",
    );
    assert(
      stepAchievedPoint == _sentinel || stepAchievedPointFieldValue == null,
      "Cannot specify both stepAchievedPoint and stepAchievedPointFieldValue",
    );
    assert(
      postIntervalLimitHour == _sentinel ||
          postIntervalLimitHourFieldValue == null,
      "Cannot specify both postIntervalLimitHour and postIntervalLimitHourFieldValue",
    );
    assert(
      reportIntervalLimitHour == _sentinel ||
          reportIntervalLimitHourFieldValue == null,
      "Cannot specify both reportIntervalLimitHour and reportIntervalLimitHourFieldValue",
    );
    assert(
      commentIntervalLimitMinute == _sentinel ||
          commentIntervalLimitMinuteFieldValue == null,
      "Cannot specify both commentIntervalLimitMinute and commentIntervalLimitMinuteFieldValue",
    );
    assert(
      notificationRetentionDay == _sentinel ||
          notificationRetentionDayFieldValue == null,
      "Cannot specify both notificationRetentionDay and notificationRetentionDayFieldValue",
    );
    assert(
      eventRetentionDay == _sentinel || eventRetentionDayFieldValue == null,
      "Cannot specify both eventRetentionDay and eventRetentionDayFieldValue",
    );
    assert(
      privacyPolicyUrl == _sentinel || privacyPolicyUrlFieldValue == null,
      "Cannot specify both privacyPolicyUrl and privacyPolicyUrlFieldValue",
    );
    assert(
      helpPageUrl == _sentinel || helpPageUrlFieldValue == null,
      "Cannot specify both helpPageUrl and helpPageUrlFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (baseIconUrl != _sentinel) 'baseIconUrl': baseIconUrl as String,
      if (baseIconUrlFieldValue != null) 'baseIconUrl': baseIconUrlFieldValue,
      if (baseCheckedInIconUrl != _sentinel)
        'baseCheckedInIconUrl': baseCheckedInIconUrl as String,
      if (baseCheckedInIconUrlFieldValue != null)
        'baseCheckedInIconUrl': baseCheckedInIconUrlFieldValue,
      if (subBaseIconUrl != _sentinel)
        'subBaseIconUrl': subBaseIconUrl as String,
      if (subBaseIconUrlFieldValue != null)
        'subBaseIconUrl': subBaseIconUrlFieldValue,
      if (merchantIconUrl != _sentinel)
        'merchantIconUrl': merchantIconUrl as String,
      if (merchantIconUrlFieldValue != null)
        'merchantIconUrl': merchantIconUrlFieldValue,
      if (merchantTweetIconUrl != _sentinel)
        'merchantTweetIconUrl': merchantTweetIconUrl as String,
      if (merchantTweetIconUrlFieldValue != null)
        'merchantTweetIconUrl': merchantTweetIconUrlFieldValue,
      if (postIconUrl != _sentinel) 'postIconUrl': postIconUrl as String,
      if (postIconUrlFieldValue != null) 'postIconUrl': postIconUrlFieldValue,
      if (adminAlertIconUrl != _sentinel)
        'adminAlertIconUrl': adminAlertIconUrl as String,
      if (adminAlertIconUrlFieldValue != null)
        'adminAlertIconUrl': adminAlertIconUrlFieldValue,
      if (adminQuestionnaireIconUrl != _sentinel)
        'adminQuestionnaireIconUrl': adminQuestionnaireIconUrl as String,
      if (adminQuestionnaireIconUrlFieldValue != null)
        'adminQuestionnaireIconUrl': adminQuestionnaireIconUrlFieldValue,
      if (checkInRadius != _sentinel) 'checkInRadius': checkInRadius as double,
      if (checkInRadiusFieldValue != null)
        'checkInRadius': checkInRadiusFieldValue,
      if (collectionRadius != _sentinel)
        'collectionRadius': collectionRadius as double,
      if (collectionRadiusFieldValue != null)
        'collectionRadius': collectionRadiusFieldValue,
      if (targetStepPerWeek != _sentinel)
        'targetStepPerWeek': targetStepPerWeek as int,
      if (targetStepPerWeekFieldValue != null)
        'targetStepPerWeek': targetStepPerWeekFieldValue,
      if (stepAchievedPoint != _sentinel)
        'stepAchievedPoint': stepAchievedPoint as int,
      if (stepAchievedPointFieldValue != null)
        'stepAchievedPoint': stepAchievedPointFieldValue,
      if (postIntervalLimitHour != _sentinel)
        'postIntervalLimitHour': postIntervalLimitHour as int,
      if (postIntervalLimitHourFieldValue != null)
        'postIntervalLimitHour': postIntervalLimitHourFieldValue,
      if (reportIntervalLimitHour != _sentinel)
        'reportIntervalLimitHour': reportIntervalLimitHour as int,
      if (reportIntervalLimitHourFieldValue != null)
        'reportIntervalLimitHour': reportIntervalLimitHourFieldValue,
      if (commentIntervalLimitMinute != _sentinel)
        'commentIntervalLimitMinute': commentIntervalLimitMinute as int,
      if (commentIntervalLimitMinuteFieldValue != null)
        'commentIntervalLimitMinute': commentIntervalLimitMinuteFieldValue,
      if (notificationRetentionDay != _sentinel)
        'notificationRetentionDay': notificationRetentionDay as int,
      if (notificationRetentionDayFieldValue != null)
        'notificationRetentionDay': notificationRetentionDayFieldValue,
      if (eventRetentionDay != _sentinel)
        'eventRetentionDay': eventRetentionDay as int,
      if (eventRetentionDayFieldValue != null)
        'eventRetentionDay': eventRetentionDayFieldValue,
      if (privacyPolicyUrl != _sentinel)
        'privacyPolicyUrl': privacyPolicyUrl as String,
      if (privacyPolicyUrlFieldValue != null)
        'privacyPolicyUrl': privacyPolicyUrlFieldValue,
      if (helpPageUrl != _sentinel) 'helpPageUrl': helpPageUrl as String,
      if (helpPageUrlFieldValue != null) 'helpPageUrl': helpPageUrlFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is SettingDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class SettingQuery
    implements QueryReference<Setting, SettingQuerySnapshot> {
  @override
  SettingQuery limit(int limit);

  @override
  SettingQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  SettingQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  SettingQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  SettingQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereBaseIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereBaseCheckedInIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereSubBaseIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereMerchantIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereMerchantTweetIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery wherePostIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereAdminAlertIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereAdminQuestionnaireIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereCheckInRadius({
    double? isEqualTo,
    double? isNotEqualTo,
    double? isLessThan,
    double? isLessThanOrEqualTo,
    double? isGreaterThan,
    double? isGreaterThanOrEqualTo,
    bool? isNull,
    List<double>? whereIn,
    List<double>? whereNotIn,
  });
  SettingQuery whereCollectionRadius({
    double? isEqualTo,
    double? isNotEqualTo,
    double? isLessThan,
    double? isLessThanOrEqualTo,
    double? isGreaterThan,
    double? isGreaterThanOrEqualTo,
    bool? isNull,
    List<double>? whereIn,
    List<double>? whereNotIn,
  });
  SettingQuery whereTargetStepPerWeek({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery whereStepAchievedPoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery wherePostIntervalLimitHour({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery whereReportIntervalLimitHour({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery whereCommentIntervalLimitMinute({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery whereNotificationRetentionDay({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery whereEventRetentionDay({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  SettingQuery wherePrivacyPolicyUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereHelpPageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  SettingQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  SettingQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  SettingQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByBaseIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByBaseCheckedInIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderBySubBaseIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByMerchantIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByMerchantTweetIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByPostIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByAdminAlertIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByAdminQuestionnaireIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByCheckInRadius({
    bool descending = false,
    double startAt,
    double startAfter,
    double endAt,
    double endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByCollectionRadius({
    bool descending = false,
    double startAt,
    double startAfter,
    double endAt,
    double endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByTargetStepPerWeek({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByStepAchievedPoint({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByPostIntervalLimitHour({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByReportIntervalLimitHour({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByCommentIntervalLimitMinute({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByNotificationRetentionDay({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByEventRetentionDay({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByPrivacyPolicyUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByHelpPageUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });

  SettingQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  });
}

class _$SettingQuery extends QueryReference<Setting, SettingQuerySnapshot>
    implements SettingQuery {
  _$SettingQuery(
    this._collection, {
    required Query<Setting> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<SettingQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference.snapshots().map(SettingQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<SettingQuerySnapshot> get([GetOptions? options]) {
    return reference.get(options).then(SettingQuerySnapshot._fromQuerySnapshot);
  }

  @override
  SettingQuery limit(int limit) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  SettingQuery limitToLast(int limit) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereBaseIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['baseIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereBaseCheckedInIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['baseCheckedInIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereSubBaseIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['subBaseIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereMerchantIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['merchantIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereMerchantTweetIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['merchantTweetIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery wherePostIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['postIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereAdminAlertIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['adminAlertIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereAdminQuestionnaireIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['adminQuestionnaireIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereCheckInRadius({
    double? isEqualTo,
    double? isNotEqualTo,
    double? isLessThan,
    double? isLessThanOrEqualTo,
    double? isGreaterThan,
    double? isGreaterThanOrEqualTo,
    bool? isNull,
    List<double>? whereIn,
    List<double>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['checkInRadius']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereCollectionRadius({
    double? isEqualTo,
    double? isNotEqualTo,
    double? isLessThan,
    double? isLessThanOrEqualTo,
    double? isGreaterThan,
    double? isGreaterThanOrEqualTo,
    bool? isNull,
    List<double>? whereIn,
    List<double>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['collectionRadius']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereTargetStepPerWeek({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['targetStepPerWeek']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereStepAchievedPoint({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['stepAchievedPoint']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery wherePostIntervalLimitHour({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['postIntervalLimitHour']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereReportIntervalLimitHour({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['reportIntervalLimitHour']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereCommentIntervalLimitMinute({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['commentIntervalLimitMinute']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereNotificationRetentionDay({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['notificationRetentionDay']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereEventRetentionDay({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['eventRetentionDay']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery wherePrivacyPolicyUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['privacyPolicyUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereHelpPageUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['helpPageUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_SettingFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  SettingQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByBaseIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['baseIconUrl']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByBaseCheckedInIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['baseCheckedInIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderBySubBaseIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['subBaseIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByMerchantIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['merchantIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByMerchantTweetIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['merchantTweetIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByPostIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['postIconUrl']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByAdminAlertIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['adminAlertIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByAdminQuestionnaireIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['adminQuestionnaireIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByCheckInRadius({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['checkInRadius']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByCollectionRadius({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['collectionRadius']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByTargetStepPerWeek({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['targetStepPerWeek']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByStepAchievedPoint({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['stepAchievedPoint']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByPostIntervalLimitHour({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['postIntervalLimitHour']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByReportIntervalLimitHour({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['reportIntervalLimitHour']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByCommentIntervalLimitMinute({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['commentIntervalLimitMinute']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByNotificationRetentionDay({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['notificationRetentionDay']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByEventRetentionDay({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['eventRetentionDay']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByPrivacyPolicyUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_SettingFieldMap['privacyPolicyUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByHelpPageUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['helpPageUrl']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  SettingQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    SettingDocumentSnapshot? startAtDocument,
    SettingDocumentSnapshot? endAtDocument,
    SettingDocumentSnapshot? endBeforeDocument,
    SettingDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_SettingFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$SettingQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$SettingQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class SettingDocumentSnapshot extends FirestoreDocumentSnapshot<Setting> {
  SettingDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<Setting> snapshot;

  @override
  SettingDocumentReference get reference {
    return SettingDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final Setting? data;
}

class SettingQuerySnapshot
    extends FirestoreQuerySnapshot<Setting, SettingQueryDocumentSnapshot> {
  SettingQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory SettingQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<Setting> snapshot,
  ) {
    final docs = snapshot.docs.map(SettingQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        SettingDocumentSnapshot._,
      );
    }).toList();

    return SettingQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<SettingDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    SettingDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<SettingDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<Setting> snapshot;

  @override
  final List<SettingQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<SettingDocumentSnapshot>> docChanges;
}

class SettingQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<Setting>
    implements SettingDocumentSnapshot {
  SettingQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<Setting> snapshot;

  @override
  final Setting data;

  @override
  SettingDocumentReference get reference {
    return SettingDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class WeekCollectionReference
    implements
        WeekQuery,
        FirestoreCollectionReference<Week, WeekQuerySnapshot> {
  factory WeekCollectionReference(
    DocumentReference<Setting> parent,
  ) = _$WeekCollectionReference;

  static Week fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return Week.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    Week value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<Week> get reference;

  /// A reference to the containing [SettingDocumentReference] if this is a subcollection.
  SettingDocumentReference get parent;

  @override
  WeekDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<WeekDocumentReference> add(Week value);
}

class _$WeekCollectionReference extends _$WeekQuery
    implements WeekCollectionReference {
  factory _$WeekCollectionReference(
    DocumentReference<Setting> parent,
  ) {
    return _$WeekCollectionReference._(
      SettingDocumentReference(parent),
      parent.collection('weeks').withConverter(
            fromFirestore: WeekCollectionReference.fromFirestore,
            toFirestore: WeekCollectionReference.toFirestore,
          ),
    );
  }

  _$WeekCollectionReference._(
    this.parent,
    CollectionReference<Week> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final SettingDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<Week> get reference =>
      super.reference as CollectionReference<Week>;

  @override
  WeekDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return WeekDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<WeekDocumentReference> add(Week value) {
    return reference.add(value).then((ref) => WeekDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$WeekCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class WeekDocumentReference
    extends FirestoreDocumentReference<Week, WeekDocumentSnapshot> {
  factory WeekDocumentReference(DocumentReference<Week> reference) =
      _$WeekDocumentReference;

  DocumentReference<Week> get reference;

  /// A reference to the [WeekCollectionReference] containing this document.
  WeekCollectionReference get parent {
    return _$WeekCollectionReference(
      reference.parent.parent!.withConverter<Setting>(
        fromFirestore: SettingCollectionReference.fromFirestore,
        toFirestore: SettingCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<WeekDocumentSnapshot> snapshots();

  @override
  Future<WeekDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    int stepPointLimit,
    FieldValue stepPointLimitFieldValue,
    int stepPointLimitRemain,
    FieldValue stepPointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    int stepPointLimit,
    FieldValue stepPointLimitFieldValue,
    int stepPointLimitRemain,
    FieldValue stepPointLimitRemainFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$WeekDocumentReference
    extends FirestoreDocumentReference<Week, WeekDocumentSnapshot>
    implements WeekDocumentReference {
  _$WeekDocumentReference(this.reference);

  @override
  final DocumentReference<Week> reference;

  /// A reference to the [WeekCollectionReference] containing this document.
  WeekCollectionReference get parent {
    return _$WeekCollectionReference(
      reference.parent.parent!.withConverter<Setting>(
        fromFirestore: SettingCollectionReference.fromFirestore,
        toFirestore: SettingCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<WeekDocumentSnapshot> snapshots() {
    return reference.snapshots().map(WeekDocumentSnapshot._);
  }

  @override
  Future<WeekDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(WeekDocumentSnapshot._);
  }

  @override
  Future<WeekDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(WeekDocumentSnapshot._);
  }

  Future<void> update({
    Object? stepPointLimit = _sentinel,
    FieldValue? stepPointLimitFieldValue,
    Object? stepPointLimitRemain = _sentinel,
    FieldValue? stepPointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      stepPointLimit == _sentinel || stepPointLimitFieldValue == null,
      "Cannot specify both stepPointLimit and stepPointLimitFieldValue",
    );
    assert(
      stepPointLimitRemain == _sentinel ||
          stepPointLimitRemainFieldValue == null,
      "Cannot specify both stepPointLimitRemain and stepPointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (stepPointLimit != _sentinel) 'stepPointLimit': stepPointLimit as int,
      if (stepPointLimitFieldValue != null)
        'stepPointLimit': stepPointLimitFieldValue,
      if (stepPointLimitRemain != _sentinel)
        'stepPointLimitRemain': stepPointLimitRemain as int,
      if (stepPointLimitRemainFieldValue != null)
        'stepPointLimitRemain': stepPointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? stepPointLimit = _sentinel,
    FieldValue? stepPointLimitFieldValue,
    Object? stepPointLimitRemain = _sentinel,
    FieldValue? stepPointLimitRemainFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      stepPointLimit == _sentinel || stepPointLimitFieldValue == null,
      "Cannot specify both stepPointLimit and stepPointLimitFieldValue",
    );
    assert(
      stepPointLimitRemain == _sentinel ||
          stepPointLimitRemainFieldValue == null,
      "Cannot specify both stepPointLimitRemain and stepPointLimitRemainFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (stepPointLimit != _sentinel) 'stepPointLimit': stepPointLimit as int,
      if (stepPointLimitFieldValue != null)
        'stepPointLimit': stepPointLimitFieldValue,
      if (stepPointLimitRemain != _sentinel)
        'stepPointLimitRemain': stepPointLimitRemain as int,
      if (stepPointLimitRemainFieldValue != null)
        'stepPointLimitRemain': stepPointLimitRemainFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is WeekDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class WeekQuery implements QueryReference<Week, WeekQuerySnapshot> {
  @override
  WeekQuery limit(int limit);

  @override
  WeekQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  WeekQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  WeekQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  WeekQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  WeekQuery whereStepPointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  WeekQuery whereStepPointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  WeekQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  WeekQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  WeekQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });

  WeekQuery orderByStepPointLimit({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });

  WeekQuery orderByStepPointLimitRemain({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });

  WeekQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });

  WeekQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  });
}

class _$WeekQuery extends QueryReference<Week, WeekQuerySnapshot>
    implements WeekQuery {
  _$WeekQuery(
    this._collection, {
    required Query<Week> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<WeekQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference.snapshots().map(WeekQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<WeekQuerySnapshot> get([GetOptions? options]) {
    return reference.get(options).then(WeekQuerySnapshot._fromQuerySnapshot);
  }

  @override
  WeekQuery limit(int limit) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  WeekQuery limitToLast(int limit) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  WeekQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery whereStepPointLimit({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_WeekFieldMap['stepPointLimit']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery whereStepPointLimitRemain({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_WeekFieldMap['stepPointLimitRemain']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_WeekFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_WeekFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  WeekQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  WeekQuery orderByStepPointLimit({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_WeekFieldMap['stepPointLimit']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  WeekQuery orderByStepPointLimitRemain({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_WeekFieldMap['stepPointLimitRemain']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  WeekQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_WeekFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  WeekQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    WeekDocumentSnapshot? startAtDocument,
    WeekDocumentSnapshot? endAtDocument,
    WeekDocumentSnapshot? endBeforeDocument,
    WeekDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_WeekFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$WeekQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$WeekQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class WeekDocumentSnapshot extends FirestoreDocumentSnapshot<Week> {
  WeekDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<Week> snapshot;

  @override
  WeekDocumentReference get reference {
    return WeekDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final Week? data;
}

class WeekQuerySnapshot
    extends FirestoreQuerySnapshot<Week, WeekQueryDocumentSnapshot> {
  WeekQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory WeekQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<Week> snapshot,
  ) {
    final docs = snapshot.docs.map(WeekQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        WeekDocumentSnapshot._,
      );
    }).toList();

    return WeekQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<WeekDocumentSnapshot> _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    WeekDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<WeekDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<Week> snapshot;

  @override
  final List<WeekQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<WeekDocumentSnapshot>> docChanges;
}

class WeekQueryDocumentSnapshot extends FirestoreQueryDocumentSnapshot<Week>
    implements WeekDocumentSnapshot {
  WeekQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<Week> snapshot;

  @override
  final Week data;

  @override
  WeekDocumentReference get reference {
    return WeekDocumentReference(snapshot.reference);
  }
}

/// A collection reference object can be used for adding documents,
/// getting document references, and querying for documents
/// (using the methods inherited from Query).
abstract class PostIconCollectionReference
    implements
        PostIconQuery,
        FirestoreCollectionReference<PostIcon, PostIconQuerySnapshot> {
  factory PostIconCollectionReference(
    DocumentReference<Setting> parent,
  ) = _$PostIconCollectionReference;

  static PostIcon fromFirestore(
    DocumentSnapshot<Map<String, Object?>> snapshot,
    SnapshotOptions? options,
  ) {
    return PostIcon.fromJson(snapshot.data()!);
  }

  static Map<String, Object?> toFirestore(
    PostIcon value,
    SetOptions? options,
  ) {
    return value.toJson();
  }

  @override
  CollectionReference<PostIcon> get reference;

  /// A reference to the containing [SettingDocumentReference] if this is a subcollection.
  SettingDocumentReference get parent;

  @override
  PostIconDocumentReference doc([String? id]);

  /// Add a new document to this collection with the specified data,
  /// assigning it a document ID automatically.
  Future<PostIconDocumentReference> add(PostIcon value);
}

class _$PostIconCollectionReference extends _$PostIconQuery
    implements PostIconCollectionReference {
  factory _$PostIconCollectionReference(
    DocumentReference<Setting> parent,
  ) {
    return _$PostIconCollectionReference._(
      SettingDocumentReference(parent),
      parent.collection('postIcons').withConverter(
            fromFirestore: PostIconCollectionReference.fromFirestore,
            toFirestore: PostIconCollectionReference.toFirestore,
          ),
    );
  }

  _$PostIconCollectionReference._(
    this.parent,
    CollectionReference<PostIcon> reference,
  ) : super(reference, $referenceWithoutCursor: reference);

  @override
  final SettingDocumentReference parent;

  String get path => reference.path;

  @override
  CollectionReference<PostIcon> get reference =>
      super.reference as CollectionReference<PostIcon>;

  @override
  PostIconDocumentReference doc([String? id]) {
    assert(
      id == null || id.split('/').length == 1,
      'The document ID cannot be from a different collection',
    );
    return PostIconDocumentReference(
      reference.doc(id),
    );
  }

  @override
  Future<PostIconDocumentReference> add(PostIcon value) {
    return reference.add(value).then((ref) => PostIconDocumentReference(ref));
  }

  @override
  bool operator ==(Object other) {
    return other is _$PostIconCollectionReference &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

abstract class PostIconDocumentReference
    extends FirestoreDocumentReference<PostIcon, PostIconDocumentSnapshot> {
  factory PostIconDocumentReference(DocumentReference<PostIcon> reference) =
      _$PostIconDocumentReference;

  DocumentReference<PostIcon> get reference;

  /// A reference to the [PostIconCollectionReference] containing this document.
  PostIconCollectionReference get parent {
    return _$PostIconCollectionReference(
      reference.parent.parent!.withConverter<Setting>(
        fromFirestore: SettingCollectionReference.fromFirestore,
        toFirestore: SettingCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<PostIconDocumentSnapshot> snapshots();

  @override
  Future<PostIconDocumentSnapshot> get([GetOptions? options]);

  @override
  Future<void> delete();

  /// Updates data on the document. Data will be merged with any existing
  /// document data.
  ///
  /// If no document exists yet, the update will fail.
  Future<void> update({
    String unitOfLikePostIconUrl,
    FieldValue unitOfLikePostIconUrlFieldValue,
    int likeCount,
    FieldValue likeCountFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });

  /// Updates fields in the current document using the transaction API.
  ///
  /// The update will fail if applied to a document that does not exist.
  void transactionUpdate(
    Transaction transaction, {
    String unitOfLikePostIconUrl,
    FieldValue unitOfLikePostIconUrlFieldValue,
    int likeCount,
    FieldValue likeCountFieldValue,
    DateTime? updatedAt,
    FieldValue updatedAtFieldValue,
    DateTime? createdAt,
    FieldValue createdAtFieldValue,
  });
}

class _$PostIconDocumentReference
    extends FirestoreDocumentReference<PostIcon, PostIconDocumentSnapshot>
    implements PostIconDocumentReference {
  _$PostIconDocumentReference(this.reference);

  @override
  final DocumentReference<PostIcon> reference;

  /// A reference to the [PostIconCollectionReference] containing this document.
  PostIconCollectionReference get parent {
    return _$PostIconCollectionReference(
      reference.parent.parent!.withConverter<Setting>(
        fromFirestore: SettingCollectionReference.fromFirestore,
        toFirestore: SettingCollectionReference.toFirestore,
      ),
    );
  }

  @override
  Stream<PostIconDocumentSnapshot> snapshots() {
    return reference.snapshots().map(PostIconDocumentSnapshot._);
  }

  @override
  Future<PostIconDocumentSnapshot> get([GetOptions? options]) {
    return reference.get(options).then(PostIconDocumentSnapshot._);
  }

  @override
  Future<PostIconDocumentSnapshot> transactionGet(Transaction transaction) {
    return transaction.get(reference).then(PostIconDocumentSnapshot._);
  }

  Future<void> update({
    Object? unitOfLikePostIconUrl = _sentinel,
    FieldValue? unitOfLikePostIconUrlFieldValue,
    Object? likeCount = _sentinel,
    FieldValue? likeCountFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) async {
    assert(
      unitOfLikePostIconUrl == _sentinel ||
          unitOfLikePostIconUrlFieldValue == null,
      "Cannot specify both unitOfLikePostIconUrl and unitOfLikePostIconUrlFieldValue",
    );
    assert(
      likeCount == _sentinel || likeCountFieldValue == null,
      "Cannot specify both likeCount and likeCountFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (unitOfLikePostIconUrl != _sentinel)
        'unitOfLikePostIconUrl': unitOfLikePostIconUrl as String,
      if (unitOfLikePostIconUrlFieldValue != null)
        'unitOfLikePostIconUrl': unitOfLikePostIconUrlFieldValue,
      if (likeCount != _sentinel) 'likeCount': likeCount as int,
      if (likeCountFieldValue != null) 'likeCount': likeCountFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    return reference.update(json);
  }

  void transactionUpdate(
    Transaction transaction, {
    Object? unitOfLikePostIconUrl = _sentinel,
    FieldValue? unitOfLikePostIconUrlFieldValue,
    Object? likeCount = _sentinel,
    FieldValue? likeCountFieldValue,
    Object? updatedAt = _sentinel,
    FieldValue? updatedAtFieldValue,
    Object? createdAt = _sentinel,
    FieldValue? createdAtFieldValue,
  }) {
    assert(
      unitOfLikePostIconUrl == _sentinel ||
          unitOfLikePostIconUrlFieldValue == null,
      "Cannot specify both unitOfLikePostIconUrl and unitOfLikePostIconUrlFieldValue",
    );
    assert(
      likeCount == _sentinel || likeCountFieldValue == null,
      "Cannot specify both likeCount and likeCountFieldValue",
    );
    assert(
      updatedAt == _sentinel || updatedAtFieldValue == null,
      "Cannot specify both updatedAt and updatedAtFieldValue",
    );
    assert(
      createdAt == _sentinel || createdAtFieldValue == null,
      "Cannot specify both createdAt and createdAtFieldValue",
    );
    final json = {
      if (unitOfLikePostIconUrl != _sentinel)
        'unitOfLikePostIconUrl': unitOfLikePostIconUrl as String,
      if (unitOfLikePostIconUrlFieldValue != null)
        'unitOfLikePostIconUrl': unitOfLikePostIconUrlFieldValue,
      if (likeCount != _sentinel) 'likeCount': likeCount as int,
      if (likeCountFieldValue != null) 'likeCount': likeCountFieldValue,
      if (updatedAt != _sentinel) 'updatedAt': updatedAt as DateTime?,
      if (updatedAtFieldValue != null) 'updatedAt': updatedAtFieldValue,
      if (createdAt != _sentinel) 'createdAt': createdAt as DateTime?,
      if (createdAtFieldValue != null) 'createdAt': createdAtFieldValue,
    };

    transaction.update(reference, json);
  }

  @override
  bool operator ==(Object other) {
    return other is PostIconDocumentReference &&
        other.runtimeType == runtimeType &&
        other.parent == parent &&
        other.id == id;
  }

  @override
  int get hashCode => Object.hash(runtimeType, parent, id);
}

abstract class PostIconQuery
    implements QueryReference<PostIcon, PostIconQuerySnapshot> {
  @override
  PostIconQuery limit(int limit);

  @override
  PostIconQuery limitToLast(int limit);

  /// Perform an order query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of order queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.orderByFieldPath(
  ///   FieldPath.fromString('title'),
  ///   startAt: 'title',
  /// );
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.orderByTitle(startAt: 'title');
  /// ```
  PostIconQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt,
    Object? startAfter,
    Object? endAt,
    Object? endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });

  /// Perform a where query based on a [FieldPath].
  ///
  /// This method is considered unsafe as it does check that the field path
  /// maps to a valid property or that parameters such as [isEqualTo] receive
  /// a value of the correct type.
  ///
  /// If possible, instead use the more explicit variant of where queries:
  ///
  /// **AVOID**:
  /// ```dart
  /// collection.whereFieldPath(FieldPath.fromString('title'), isEqualTo: 'title');
  /// ```
  ///
  /// **PREFER**:
  /// ```dart
  /// collection.whereTitle(isEqualTo: 'title');
  /// ```
  PostIconQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  });

  PostIconQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  PostIconQuery whereUnitOfLikePostIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  });
  PostIconQuery whereLikeCount({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  });
  PostIconQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });
  PostIconQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  });

  PostIconQuery orderByDocumentId({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });

  PostIconQuery orderByUnitOfLikePostIconUrl({
    bool descending = false,
    String startAt,
    String startAfter,
    String endAt,
    String endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });

  PostIconQuery orderByLikeCount({
    bool descending = false,
    int startAt,
    int startAfter,
    int endAt,
    int endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });

  PostIconQuery orderByUpdatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });

  PostIconQuery orderByCreatedAt({
    bool descending = false,
    DateTime? startAt,
    DateTime? startAfter,
    DateTime? endAt,
    DateTime? endBefore,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  });
}

class _$PostIconQuery extends QueryReference<PostIcon, PostIconQuerySnapshot>
    implements PostIconQuery {
  _$PostIconQuery(
    this._collection, {
    required Query<PostIcon> $referenceWithoutCursor,
    $QueryCursor $queryCursor = const $QueryCursor(),
  }) : super(
          $referenceWithoutCursor: $referenceWithoutCursor,
          $queryCursor: $queryCursor,
        );

  final CollectionReference<Object?> _collection;

  @override
  Stream<PostIconQuerySnapshot> snapshots([SnapshotOptions? options]) {
    return reference.snapshots().map(PostIconQuerySnapshot._fromQuerySnapshot);
  }

  @override
  Future<PostIconQuerySnapshot> get([GetOptions? options]) {
    return reference
        .get(options)
        .then(PostIconQuerySnapshot._fromQuerySnapshot);
  }

  @override
  PostIconQuery limit(int limit) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limit(limit),
      $queryCursor: $queryCursor,
    );
  }

  @override
  PostIconQuery limitToLast(int limit) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.limitToLast(limit),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery orderByFieldPath(
    FieldPath fieldPath, {
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query =
        $referenceWithoutCursor.orderBy(fieldPath, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PostIconQuery whereFieldPath(
    FieldPath fieldPath, {
    Object? isEqualTo,
    Object? isNotEqualTo,
    Object? isLessThan,
    Object? isLessThanOrEqualTo,
    Object? isGreaterThan,
    Object? isGreaterThanOrEqualTo,
    Object? arrayContains,
    List<Object?>? arrayContainsAny,
    List<Object?>? whereIn,
    List<Object?>? whereNotIn,
    bool? isNull,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery whereDocumentId({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        FieldPath.documentId,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery whereUnitOfLikePostIconUrl({
    String? isEqualTo,
    String? isNotEqualTo,
    String? isLessThan,
    String? isLessThanOrEqualTo,
    String? isGreaterThan,
    String? isGreaterThanOrEqualTo,
    bool? isNull,
    List<String>? whereIn,
    List<String>? whereNotIn,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PostIconFieldMap['unitOfLikePostIconUrl']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery whereLikeCount({
    int? isEqualTo,
    int? isNotEqualTo,
    int? isLessThan,
    int? isLessThanOrEqualTo,
    int? isGreaterThan,
    int? isGreaterThanOrEqualTo,
    bool? isNull,
    List<int>? whereIn,
    List<int>? whereNotIn,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PostIconFieldMap['likeCount']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery whereUpdatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PostIconFieldMap['updatedAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery whereCreatedAt({
    DateTime? isEqualTo,
    DateTime? isNotEqualTo,
    DateTime? isLessThan,
    DateTime? isLessThanOrEqualTo,
    DateTime? isGreaterThan,
    DateTime? isGreaterThanOrEqualTo,
    bool? isNull,
    List<DateTime?>? whereIn,
    List<DateTime?>? whereNotIn,
  }) {
    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: $referenceWithoutCursor.where(
        _$$_PostIconFieldMap['createdAt']!,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        isNull: isNull,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
      ),
      $queryCursor: $queryCursor,
    );
  }

  PostIconQuery orderByDocumentId({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(FieldPath.documentId,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PostIconQuery orderByUnitOfLikePostIconUrl({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor.orderBy(
        _$$_PostIconFieldMap['unitOfLikePostIconUrl']!,
        descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PostIconQuery orderByLikeCount({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_PostIconFieldMap['likeCount']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PostIconQuery orderByUpdatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_PostIconFieldMap['updatedAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  PostIconQuery orderByCreatedAt({
    bool descending = false,
    Object? startAt = _sentinel,
    Object? startAfter = _sentinel,
    Object? endAt = _sentinel,
    Object? endBefore = _sentinel,
    PostIconDocumentSnapshot? startAtDocument,
    PostIconDocumentSnapshot? endAtDocument,
    PostIconDocumentSnapshot? endBeforeDocument,
    PostIconDocumentSnapshot? startAfterDocument,
  }) {
    final query = $referenceWithoutCursor
        .orderBy(_$$_PostIconFieldMap['createdAt']!, descending: descending);
    var queryCursor = $queryCursor;

    if (startAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAt: const [],
        startAtDocumentSnapshot: startAtDocument.snapshot,
      );
    }
    if (startAfterDocument != null) {
      queryCursor = queryCursor.copyWith(
        startAfter: const [],
        startAfterDocumentSnapshot: startAfterDocument.snapshot,
      );
    }
    if (endAtDocument != null) {
      queryCursor = queryCursor.copyWith(
        endAt: const [],
        endAtDocumentSnapshot: endAtDocument.snapshot,
      );
    }
    if (endBeforeDocument != null) {
      queryCursor = queryCursor.copyWith(
        endBefore: const [],
        endBeforeDocumentSnapshot: endBeforeDocument.snapshot,
      );
    }

    if (startAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAt: [...queryCursor.startAt, startAt],
        startAtDocumentSnapshot: null,
      );
    }
    if (startAfter != _sentinel) {
      queryCursor = queryCursor.copyWith(
        startAfter: [...queryCursor.startAfter, startAfter],
        startAfterDocumentSnapshot: null,
      );
    }
    if (endAt != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endAt: [...queryCursor.endAt, endAt],
        endAtDocumentSnapshot: null,
      );
    }
    if (endBefore != _sentinel) {
      queryCursor = queryCursor.copyWith(
        endBefore: [...queryCursor.endBefore, endBefore],
        endBeforeDocumentSnapshot: null,
      );
    }

    return _$PostIconQuery(
      _collection,
      $referenceWithoutCursor: query,
      $queryCursor: queryCursor,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is _$PostIconQuery &&
        other.runtimeType == runtimeType &&
        other.reference == reference;
  }

  @override
  int get hashCode => Object.hash(runtimeType, reference);
}

class PostIconDocumentSnapshot extends FirestoreDocumentSnapshot<PostIcon> {
  PostIconDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final DocumentSnapshot<PostIcon> snapshot;

  @override
  PostIconDocumentReference get reference {
    return PostIconDocumentReference(
      snapshot.reference,
    );
  }

  @override
  final PostIcon? data;
}

class PostIconQuerySnapshot
    extends FirestoreQuerySnapshot<PostIcon, PostIconQueryDocumentSnapshot> {
  PostIconQuerySnapshot._(
    this.snapshot,
    this.docs,
    this.docChanges,
  );

  factory PostIconQuerySnapshot._fromQuerySnapshot(
    QuerySnapshot<PostIcon> snapshot,
  ) {
    final docs = snapshot.docs.map(PostIconQueryDocumentSnapshot._).toList();

    final docChanges = snapshot.docChanges.map((change) {
      return _decodeDocumentChange(
        change,
        PostIconDocumentSnapshot._,
      );
    }).toList();

    return PostIconQuerySnapshot._(
      snapshot,
      docs,
      docChanges,
    );
  }

  static FirestoreDocumentChange<PostIconDocumentSnapshot>
      _decodeDocumentChange<T>(
    DocumentChange<T> docChange,
    PostIconDocumentSnapshot Function(DocumentSnapshot<T> doc) decodeDoc,
  ) {
    return FirestoreDocumentChange<PostIconDocumentSnapshot>(
      type: docChange.type,
      oldIndex: docChange.oldIndex,
      newIndex: docChange.newIndex,
      doc: decodeDoc(docChange.doc),
    );
  }

  final QuerySnapshot<PostIcon> snapshot;

  @override
  final List<PostIconQueryDocumentSnapshot> docs;

  @override
  final List<FirestoreDocumentChange<PostIconDocumentSnapshot>> docChanges;
}

class PostIconQueryDocumentSnapshot
    extends FirestoreQueryDocumentSnapshot<PostIcon>
    implements PostIconDocumentSnapshot {
  PostIconQueryDocumentSnapshot._(this.snapshot) : data = snapshot.data();

  @override
  final QueryDocumentSnapshot<PostIcon> snapshot;

  @override
  final PostIcon data;

  @override
  PostIconDocumentReference get reference {
    return PostIconDocumentReference(snapshot.reference);
  }
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Setting _$$_SettingFromJson(Map<String, dynamic> json) => _$_Setting(
      baseIconUrl: json['baseIconUrl'] as String,
      baseCheckedInIconUrl: json['baseCheckedInIconUrl'] as String,
      subBaseIconUrl: json['subBaseIconUrl'] as String,
      merchantIconUrl: json['merchantIconUrl'] as String,
      merchantTweetIconUrl: json['merchantTweetIconUrl'] as String,
      postIconUrl: json['postIconUrl'] as String,
      adminAlertIconUrl: json['adminAlertIconUrl'] as String,
      adminQuestionnaireIconUrl: json['adminQuestionnaireIconUrl'] as String,
      checkInRadius: (json['checkInRadius'] as num).toDouble(),
      collectionRadius: (json['collectionRadius'] as num).toDouble(),
      targetStepPerWeek: json['targetStepPerWeek'] as int,
      stepAchievedPoint: json['stepAchievedPoint'] as int,
      postIntervalLimitHour: json['postIntervalLimitHour'] as int,
      reportIntervalLimitHour: json['reportIntervalLimitHour'] as int,
      commentIntervalLimitMinute: json['commentIntervalLimitMinute'] as int,
      notificationRetentionDay: json['notificationRetentionDay'] as int,
      eventRetentionDay: json['eventRetentionDay'] as int,
      privacyPolicyUrl: json['privacyPolicyUrl'] as String,
      helpPageUrl: json['helpPageUrl'] as String,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_SettingFieldMap = <String, String>{
  'baseIconUrl': 'baseIconUrl',
  'baseCheckedInIconUrl': 'baseCheckedInIconUrl',
  'subBaseIconUrl': 'subBaseIconUrl',
  'merchantIconUrl': 'merchantIconUrl',
  'merchantTweetIconUrl': 'merchantTweetIconUrl',
  'postIconUrl': 'postIconUrl',
  'adminAlertIconUrl': 'adminAlertIconUrl',
  'adminQuestionnaireIconUrl': 'adminQuestionnaireIconUrl',
  'checkInRadius': 'checkInRadius',
  'collectionRadius': 'collectionRadius',
  'targetStepPerWeek': 'targetStepPerWeek',
  'stepAchievedPoint': 'stepAchievedPoint',
  'postIntervalLimitHour': 'postIntervalLimitHour',
  'reportIntervalLimitHour': 'reportIntervalLimitHour',
  'commentIntervalLimitMinute': 'commentIntervalLimitMinute',
  'notificationRetentionDay': 'notificationRetentionDay',
  'eventRetentionDay': 'eventRetentionDay',
  'privacyPolicyUrl': 'privacyPolicyUrl',
  'helpPageUrl': 'helpPageUrl',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_SettingToJson(_$_Setting instance) {
  final val = <String, dynamic>{
    'baseIconUrl': instance.baseIconUrl,
    'baseCheckedInIconUrl': instance.baseCheckedInIconUrl,
    'subBaseIconUrl': instance.subBaseIconUrl,
    'merchantIconUrl': instance.merchantIconUrl,
    'merchantTweetIconUrl': instance.merchantTweetIconUrl,
    'postIconUrl': instance.postIconUrl,
    'adminAlertIconUrl': instance.adminAlertIconUrl,
    'adminQuestionnaireIconUrl': instance.adminQuestionnaireIconUrl,
    'checkInRadius': instance.checkInRadius,
    'collectionRadius': instance.collectionRadius,
    'targetStepPerWeek': instance.targetStepPerWeek,
    'stepAchievedPoint': instance.stepAchievedPoint,
    'postIntervalLimitHour': instance.postIntervalLimitHour,
    'reportIntervalLimitHour': instance.reportIntervalLimitHour,
    'commentIntervalLimitMinute': instance.commentIntervalLimitMinute,
    'notificationRetentionDay': instance.notificationRetentionDay,
    'eventRetentionDay': instance.eventRetentionDay,
    'privacyPolicyUrl': instance.privacyPolicyUrl,
    'helpPageUrl': instance.helpPageUrl,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_Week _$$_WeekFromJson(Map<String, dynamic> json) => _$_Week(
      stepPointLimit: json['stepPointLimit'] as int,
      stepPointLimitRemain: json['stepPointLimitRemain'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_WeekFieldMap = <String, String>{
  'stepPointLimit': 'stepPointLimit',
  'stepPointLimitRemain': 'stepPointLimitRemain',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_WeekToJson(_$_Week instance) {
  final val = <String, dynamic>{
    'stepPointLimit': instance.stepPointLimit,
    'stepPointLimitRemain': instance.stepPointLimitRemain,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

_$_PostIcon _$$_PostIconFromJson(Map<String, dynamic> json) => _$_PostIcon(
      unitOfLikePostIconUrl: json['unitOfLikePostIconUrl'] as String,
      likeCount: json['likeCount'] as int,
      updatedAt: const TimestampConverter().fromJson(json['updatedAt']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

const _$$_PostIconFieldMap = <String, String>{
  'unitOfLikePostIconUrl': 'unitOfLikePostIconUrl',
  'likeCount': 'likeCount',
  'updatedAt': 'updatedAt',
  'createdAt': 'createdAt',
};

Map<String, dynamic> _$$_PostIconToJson(_$_PostIcon instance) {
  final val = <String, dynamic>{
    'unitOfLikePostIconUrl': instance.unitOfLikePostIconUrl,
    'likeCount': instance.likeCount,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull(
      'updatedAt', const TimestampConverter().toJson(instance.updatedAt));
  writeNotNull(
      'createdAt', const TimestampConverter().toJson(instance.createdAt));
  return val;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'withdrawal.freezed.dart';
part 'withdrawal.g.dart';

/// 退会申請
@freezed
class Withdrawal with _$Withdrawal {
  @firestoreSerializable
  const factory Withdrawal({
    // 会員ID
    required String id,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _Withdrawal;

  factory Withdrawal.fromJson(Map<String, Object?> json) =>
      _$WithdrawalFromJson(json);
}

@Collection<Withdrawal>('withdrawals')
final withdrawalsRef = WithdrawalCollectionReference();

WithdrawalDocumentReference withdrawalRef({required String id}) =>
    WithdrawalDocumentReference(withdrawalsRef.doc(id).reference);

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'event.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Event _$EventFromJson(Map<String, dynamic> json) {
  return _Event.fromJson(json);
}

/// @nodoc
mixin _$Event {
// イベントID
  String get id => throw _privateConstructorUsedError; // イベントタイトル
  String get title => throw _privateConstructorUsedError; // イベント画像のURL
  String? get imageUrl => throw _privateConstructorUsedError; // イベント期間開始
  DateTime get effectivePeriodBegin =>
      throw _privateConstructorUsedError; // イベント期間終了
  DateTime get effectivePeriodEnd =>
      throw _privateConstructorUsedError; // イベントアイコンURL
  String get eventIconUrl =>
      throw _privateConstructorUsedError; // スタンプ獲得済アイコンURL
  String get completeSpotIconUrl =>
      throw _privateConstructorUsedError; // イベント達成地点数
  int get completeSpotCount => throw _privateConstructorUsedError; // 位置情報の利用
  bool get isUseLocation =>
      throw _privateConstructorUsedError; // QRコード読み取り可能距離（meter）
  double get qrCodeRadius => throw _privateConstructorUsedError; // イベント達成獲得ポイント
  int get point => throw _privateConstructorUsedError; // 交換制限人数
  int get exchangeLimit => throw _privateConstructorUsedError; // 交換対象種別
  int get exchangeType => throw _privateConstructorUsedError; // イベントスポット数
  int get eventSpotCount => throw _privateConstructorUsedError; // イベントの開催位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EventCopyWith<Event> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventCopyWith<$Res> {
  factory $EventCopyWith(Event value, $Res Function(Event) then) =
      _$EventCopyWithImpl<$Res, Event>;
  @useResult
  $Res call(
      {String id,
      String title,
      String? imageUrl,
      DateTime effectivePeriodBegin,
      DateTime effectivePeriodEnd,
      String eventIconUrl,
      String completeSpotIconUrl,
      int completeSpotCount,
      bool isUseLocation,
      double qrCodeRadius,
      int point,
      int exchangeLimit,
      int exchangeType,
      int eventSpotCount,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$EventCopyWithImpl<$Res, $Val extends Event>
    implements $EventCopyWith<$Res> {
  _$EventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? imageUrl = freezed,
    Object? effectivePeriodBegin = null,
    Object? effectivePeriodEnd = null,
    Object? eventIconUrl = null,
    Object? completeSpotIconUrl = null,
    Object? completeSpotCount = null,
    Object? isUseLocation = null,
    Object? qrCodeRadius = null,
    Object? point = null,
    Object? exchangeLimit = null,
    Object? exchangeType = null,
    Object? eventSpotCount = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: null == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      effectivePeriodEnd: null == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      eventIconUrl: null == eventIconUrl
          ? _value.eventIconUrl
          : eventIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      completeSpotIconUrl: null == completeSpotIconUrl
          ? _value.completeSpotIconUrl
          : completeSpotIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      completeSpotCount: null == completeSpotCount
          ? _value.completeSpotCount
          : completeSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      isUseLocation: null == isUseLocation
          ? _value.isUseLocation
          : isUseLocation // ignore: cast_nullable_to_non_nullable
              as bool,
      qrCodeRadius: null == qrCodeRadius
          ? _value.qrCodeRadius
          : qrCodeRadius // ignore: cast_nullable_to_non_nullable
              as double,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeLimit: null == exchangeLimit
          ? _value.exchangeLimit
          : exchangeLimit // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeType: null == exchangeType
          ? _value.exchangeType
          : exchangeType // ignore: cast_nullable_to_non_nullable
              as int,
      eventSpotCount: null == eventSpotCount
          ? _value.eventSpotCount
          : eventSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_EventCopyWith<$Res> implements $EventCopyWith<$Res> {
  factory _$$_EventCopyWith(_$_Event value, $Res Function(_$_Event) then) =
      __$$_EventCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String title,
      String? imageUrl,
      DateTime effectivePeriodBegin,
      DateTime effectivePeriodEnd,
      String eventIconUrl,
      String completeSpotIconUrl,
      int completeSpotCount,
      bool isUseLocation,
      double qrCodeRadius,
      int point,
      int exchangeLimit,
      int exchangeType,
      int eventSpotCount,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_EventCopyWithImpl<$Res> extends _$EventCopyWithImpl<$Res, _$_Event>
    implements _$$_EventCopyWith<$Res> {
  __$$_EventCopyWithImpl(_$_Event _value, $Res Function(_$_Event) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? imageUrl = freezed,
    Object? effectivePeriodBegin = null,
    Object? effectivePeriodEnd = null,
    Object? eventIconUrl = null,
    Object? completeSpotIconUrl = null,
    Object? completeSpotCount = null,
    Object? isUseLocation = null,
    Object? qrCodeRadius = null,
    Object? point = null,
    Object? exchangeLimit = null,
    Object? exchangeType = null,
    Object? eventSpotCount = null,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_Event(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: null == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      effectivePeriodEnd: null == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      eventIconUrl: null == eventIconUrl
          ? _value.eventIconUrl
          : eventIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      completeSpotIconUrl: null == completeSpotIconUrl
          ? _value.completeSpotIconUrl
          : completeSpotIconUrl // ignore: cast_nullable_to_non_nullable
              as String,
      completeSpotCount: null == completeSpotCount
          ? _value.completeSpotCount
          : completeSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      isUseLocation: null == isUseLocation
          ? _value.isUseLocation
          : isUseLocation // ignore: cast_nullable_to_non_nullable
              as bool,
      qrCodeRadius: null == qrCodeRadius
          ? _value.qrCodeRadius
          : qrCodeRadius // ignore: cast_nullable_to_non_nullable
              as double,
      point: null == point
          ? _value.point
          : point // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeLimit: null == exchangeLimit
          ? _value.exchangeLimit
          : exchangeLimit // ignore: cast_nullable_to_non_nullable
              as int,
      exchangeType: null == exchangeType
          ? _value.exchangeType
          : exchangeType // ignore: cast_nullable_to_non_nullable
              as int,
      eventSpotCount: null == eventSpotCount
          ? _value.eventSpotCount
          : eventSpotCount // ignore: cast_nullable_to_non_nullable
              as int,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_Event implements _Event {
  const _$_Event(
      {required this.id,
      required this.title,
      this.imageUrl,
      required this.effectivePeriodBegin,
      required this.effectivePeriodEnd,
      required this.eventIconUrl,
      required this.completeSpotIconUrl,
      required this.completeSpotCount,
      required this.isUseLocation,
      required this.qrCodeRadius,
      required this.point,
      required this.exchangeLimit,
      required this.exchangeType,
      required this.eventSpotCount,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_Event.fromJson(Map<String, dynamic> json) =>
      _$$_EventFromJson(json);

// イベントID
  @override
  final String id;
// イベントタイトル
  @override
  final String title;
// イベント画像のURL
  @override
  final String? imageUrl;
// イベント期間開始
  @override
  final DateTime effectivePeriodBegin;
// イベント期間終了
  @override
  final DateTime effectivePeriodEnd;
// イベントアイコンURL
  @override
  final String eventIconUrl;
// スタンプ獲得済アイコンURL
  @override
  final String completeSpotIconUrl;
// イベント達成地点数
  @override
  final int completeSpotCount;
// 位置情報の利用
  @override
  final bool isUseLocation;
// QRコード読み取り可能距離（meter）
  @override
  final double qrCodeRadius;
// イベント達成獲得ポイント
  @override
  final int point;
// 交換制限人数
  @override
  final int exchangeLimit;
// 交換対象種別
  @override
  final int exchangeType;
// イベントスポット数
  @override
  final int eventSpotCount;
// イベントの開催位置情報
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'Event(id: $id, title: $title, imageUrl: $imageUrl, effectivePeriodBegin: $effectivePeriodBegin, effectivePeriodEnd: $effectivePeriodEnd, eventIconUrl: $eventIconUrl, completeSpotIconUrl: $completeSpotIconUrl, completeSpotCount: $completeSpotCount, isUseLocation: $isUseLocation, qrCodeRadius: $qrCodeRadius, point: $point, exchangeLimit: $exchangeLimit, exchangeType: $exchangeType, eventSpotCount: $eventSpotCount, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Event &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.effectivePeriodBegin, effectivePeriodBegin) ||
                other.effectivePeriodBegin == effectivePeriodBegin) &&
            (identical(other.effectivePeriodEnd, effectivePeriodEnd) ||
                other.effectivePeriodEnd == effectivePeriodEnd) &&
            (identical(other.eventIconUrl, eventIconUrl) ||
                other.eventIconUrl == eventIconUrl) &&
            (identical(other.completeSpotIconUrl, completeSpotIconUrl) ||
                other.completeSpotIconUrl == completeSpotIconUrl) &&
            (identical(other.completeSpotCount, completeSpotCount) ||
                other.completeSpotCount == completeSpotCount) &&
            (identical(other.isUseLocation, isUseLocation) ||
                other.isUseLocation == isUseLocation) &&
            (identical(other.qrCodeRadius, qrCodeRadius) ||
                other.qrCodeRadius == qrCodeRadius) &&
            (identical(other.point, point) || other.point == point) &&
            (identical(other.exchangeLimit, exchangeLimit) ||
                other.exchangeLimit == exchangeLimit) &&
            (identical(other.exchangeType, exchangeType) ||
                other.exchangeType == exchangeType) &&
            (identical(other.eventSpotCount, eventSpotCount) ||
                other.eventSpotCount == eventSpotCount) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      title,
      imageUrl,
      effectivePeriodBegin,
      effectivePeriodEnd,
      eventIconUrl,
      completeSpotIconUrl,
      completeSpotCount,
      isUseLocation,
      qrCodeRadius,
      point,
      exchangeLimit,
      exchangeType,
      eventSpotCount,
      position,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventCopyWith<_$_Event> get copyWith =>
      __$$_EventCopyWithImpl<_$_Event>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_EventToJson(
      this,
    );
  }
}

abstract class _Event implements Event {
  const factory _Event(
      {required final String id,
      required final String title,
      final String? imageUrl,
      required final DateTime effectivePeriodBegin,
      required final DateTime effectivePeriodEnd,
      required final String eventIconUrl,
      required final String completeSpotIconUrl,
      required final int completeSpotCount,
      required final bool isUseLocation,
      required final double qrCodeRadius,
      required final int point,
      required final int exchangeLimit,
      required final int exchangeType,
      required final int eventSpotCount,
      required final MapPosition position,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_Event;

  factory _Event.fromJson(Map<String, dynamic> json) = _$_Event.fromJson;

  @override // イベントID
  String get id;
  @override // イベントタイトル
  String get title;
  @override // イベント画像のURL
  String? get imageUrl;
  @override // イベント期間開始
  DateTime get effectivePeriodBegin;
  @override // イベント期間終了
  DateTime get effectivePeriodEnd;
  @override // イベントアイコンURL
  String get eventIconUrl;
  @override // スタンプ獲得済アイコンURL
  String get completeSpotIconUrl;
  @override // イベント達成地点数
  int get completeSpotCount;
  @override // 位置情報の利用
  bool get isUseLocation;
  @override // QRコード読み取り可能距離（meter）
  double get qrCodeRadius;
  @override // イベント達成獲得ポイント
  int get point;
  @override // 交換制限人数
  int get exchangeLimit;
  @override // 交換対象種別
  int get exchangeType;
  @override // イベントスポット数
  int get eventSpotCount;
  @override // イベントの開催位置情報
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_EventCopyWith<_$_Event> get copyWith =>
      throw _privateConstructorUsedError;
}

EventSpot _$EventSpotFromJson(Map<String, dynamic> json) {
  return _EventSpot.fromJson(json);
}

/// @nodoc
mixin _$EventSpot {
// イベントスポットID
  String get id => throw _privateConstructorUsedError; // イベントスポット名称
  String get name => throw _privateConstructorUsedError; // イベントスポットのURL
  String? get imageUrl => throw _privateConstructorUsedError; // イベントスポットの位置情報
  MapPosition get position => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EventSpotCopyWith<EventSpot> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventSpotCopyWith<$Res> {
  factory $EventSpotCopyWith(EventSpot value, $Res Function(EventSpot) then) =
      _$EventSpotCopyWithImpl<$Res, EventSpot>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? imageUrl,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class _$EventSpotCopyWithImpl<$Res, $Val extends EventSpot>
    implements $EventSpotCopyWith<$Res> {
  _$EventSpotCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? imageUrl = freezed,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MapPositionCopyWith<$Res> get position {
    return $MapPositionCopyWith<$Res>(_value.position, (value) {
      return _then(_value.copyWith(position: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_EventSpotCopyWith<$Res> implements $EventSpotCopyWith<$Res> {
  factory _$$_EventSpotCopyWith(
          _$_EventSpot value, $Res Function(_$_EventSpot) then) =
      __$$_EventSpotCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? imageUrl,
      MapPosition position,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});

  @override
  $MapPositionCopyWith<$Res> get position;
}

/// @nodoc
class __$$_EventSpotCopyWithImpl<$Res>
    extends _$EventSpotCopyWithImpl<$Res, _$_EventSpot>
    implements _$$_EventSpotCopyWith<$Res> {
  __$$_EventSpotCopyWithImpl(
      _$_EventSpot _value, $Res Function(_$_EventSpot) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? imageUrl = freezed,
    Object? position = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_EventSpot(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as MapPosition,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_EventSpot implements _EventSpot {
  const _$_EventSpot(
      {required this.id,
      required this.name,
      this.imageUrl,
      required this.position,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_EventSpot.fromJson(Map<String, dynamic> json) =>
      _$$_EventSpotFromJson(json);

// イベントスポットID
  @override
  final String id;
// イベントスポット名称
  @override
  final String name;
// イベントスポットのURL
  @override
  final String? imageUrl;
// イベントスポットの位置情報
  @override
  final MapPosition position;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'EventSpot(id: $id, name: $name, imageUrl: $imageUrl, position: $position, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EventSpot &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.position, position) ||
                other.position == position) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, imageUrl, position, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventSpotCopyWith<_$_EventSpot> get copyWith =>
      __$$_EventSpotCopyWithImpl<_$_EventSpot>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_EventSpotToJson(
      this,
    );
  }
}

abstract class _EventSpot implements EventSpot {
  const factory _EventSpot(
      {required final String id,
      required final String name,
      final String? imageUrl,
      required final MapPosition position,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_EventSpot;

  factory _EventSpot.fromJson(Map<String, dynamic> json) =
      _$_EventSpot.fromJson;

  @override // イベントスポットID
  String get id;
  @override // イベントスポット名称
  String get name;
  @override // イベントスポットのURL
  String? get imageUrl;
  @override // イベントスポットの位置情報
  MapPosition get position;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_EventSpotCopyWith<_$_EventSpot> get copyWith =>
      throw _privateConstructorUsedError;
}

EventTransaction _$EventTransactionFromJson(Map<String, dynamic> json) {
  return _EventTransaction.fromJson(json);
}

/// @nodoc
mixin _$EventTransaction {
// 交換制限人数残り
  int get exchangeLimitRemain => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EventTransactionCopyWith<EventTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventTransactionCopyWith<$Res> {
  factory $EventTransactionCopyWith(
          EventTransaction value, $Res Function(EventTransaction) then) =
      _$EventTransactionCopyWithImpl<$Res, EventTransaction>;
  @useResult
  $Res call(
      {int exchangeLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$EventTransactionCopyWithImpl<$Res, $Val extends EventTransaction>
    implements $EventTransactionCopyWith<$Res> {
  _$EventTransactionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exchangeLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      exchangeLimitRemain: null == exchangeLimitRemain
          ? _value.exchangeLimitRemain
          : exchangeLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_EventTransactionCopyWith<$Res>
    implements $EventTransactionCopyWith<$Res> {
  factory _$$_EventTransactionCopyWith(
          _$_EventTransaction value, $Res Function(_$_EventTransaction) then) =
      __$$_EventTransactionCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int exchangeLimitRemain,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_EventTransactionCopyWithImpl<$Res>
    extends _$EventTransactionCopyWithImpl<$Res, _$_EventTransaction>
    implements _$$_EventTransactionCopyWith<$Res> {
  __$$_EventTransactionCopyWithImpl(
      _$_EventTransaction _value, $Res Function(_$_EventTransaction) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exchangeLimitRemain = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_EventTransaction(
      exchangeLimitRemain: null == exchangeLimitRemain
          ? _value.exchangeLimitRemain
          : exchangeLimitRemain // ignore: cast_nullable_to_non_nullable
              as int,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_EventTransaction implements _EventTransaction {
  const _$_EventTransaction(
      {required this.exchangeLimitRemain,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_EventTransaction.fromJson(Map<String, dynamic> json) =>
      _$$_EventTransactionFromJson(json);

// 交換制限人数残り
  @override
  final int exchangeLimitRemain;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'EventTransaction(exchangeLimitRemain: $exchangeLimitRemain, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EventTransaction &&
            (identical(other.exchangeLimitRemain, exchangeLimitRemain) ||
                other.exchangeLimitRemain == exchangeLimitRemain) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, exchangeLimitRemain, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventTransactionCopyWith<_$_EventTransaction> get copyWith =>
      __$$_EventTransactionCopyWithImpl<_$_EventTransaction>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_EventTransactionToJson(
      this,
    );
  }
}

abstract class _EventTransaction implements EventTransaction {
  const factory _EventTransaction(
      {required final int exchangeLimitRemain,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_EventTransaction;

  factory _EventTransaction.fromJson(Map<String, dynamic> json) =
      _$_EventTransaction.fromJson;

  @override // 交換制限人数残り
  int get exchangeLimitRemain;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_EventTransactionCopyWith<_$_EventTransaction> get copyWith =>
      throw _privateConstructorUsedError;
}

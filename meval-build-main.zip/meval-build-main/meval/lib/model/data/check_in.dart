import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore_odm/cloud_firestore_odm.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../converters/json_converter.dart';
import 'firestore_serializable.dart';

part 'check_in.freezed.dart';
part 'check_in.g.dart';

/// チェックイン
@freezed
class CheckIn with _$CheckIn {
  @firestoreSerializable
  const factory CheckIn({
    // チェックインID
    required String id,
    // チェックインした拠点が親拠点か否か（true:親拠点、false:サブ拠点）
    required bool isParent,
    // 拠点のReference
    @DocumentReferenceConverter() required DocumentReference baseRef,
    // 会員のReference
    @DocumentReferenceConverter() required DocumentReference memberRef,
    // 更新日時
    @TimestampConverter() DateTime? updatedAt,
    // 登録日時
    @TimestampConverter() DateTime? createdAt,
  }) = _CheckIn;

  factory CheckIn.fromJson(Map<String, Object?> json) =>
      _$CheckInFromJson(json);
}

@Collection<CheckIn>('checkIns')
final checkInsRef = CheckInCollectionReference();

CheckInDocumentReference checkInRef({required String id}) =>
    CheckInDocumentReference(checkInsRef.doc(id).reference);

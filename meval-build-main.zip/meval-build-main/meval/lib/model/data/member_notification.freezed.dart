// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'member_notification.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MemberNotification _$MemberNotificationFromJson(Map<String, dynamic> json) {
  return _MemberNotification.fromJson(json);
}

/// @nodoc
mixin _$MemberNotification {
// お知らせID
  String get id => throw _privateConstructorUsedError; // タイトル
  String get title => throw _privateConstructorUsedError; // お知らせURL
  String? get contentUrl => throw _privateConstructorUsedError; // 有効期間開始
  @TimestampConverter()
  DateTime get effectivePeriodBegin =>
      throw _privateConstructorUsedError; // 有効期間終了
  @TimestampConverter()
  DateTime get effectivePeriodEnd => throw _privateConstructorUsedError; // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt => throw _privateConstructorUsedError; // 登録日時
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MemberNotificationCopyWith<MemberNotification> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MemberNotificationCopyWith<$Res> {
  factory $MemberNotificationCopyWith(
          MemberNotification value, $Res Function(MemberNotification) then) =
      _$MemberNotificationCopyWithImpl<$Res, MemberNotification>;
  @useResult
  $Res call(
      {String id,
      String title,
      String? contentUrl,
      @TimestampConverter() DateTime effectivePeriodBegin,
      @TimestampConverter() DateTime effectivePeriodEnd,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class _$MemberNotificationCopyWithImpl<$Res, $Val extends MemberNotification>
    implements $MemberNotificationCopyWith<$Res> {
  _$MemberNotificationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? contentUrl = freezed,
    Object? effectivePeriodBegin = null,
    Object? effectivePeriodEnd = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      contentUrl: freezed == contentUrl
          ? _value.contentUrl
          : contentUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: null == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      effectivePeriodEnd: null == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MemberNotificationCopyWith<$Res>
    implements $MemberNotificationCopyWith<$Res> {
  factory _$$_MemberNotificationCopyWith(_$_MemberNotification value,
          $Res Function(_$_MemberNotification) then) =
      __$$_MemberNotificationCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String title,
      String? contentUrl,
      @TimestampConverter() DateTime effectivePeriodBegin,
      @TimestampConverter() DateTime effectivePeriodEnd,
      @TimestampConverter() DateTime? updatedAt,
      @TimestampConverter() DateTime? createdAt});
}

/// @nodoc
class __$$_MemberNotificationCopyWithImpl<$Res>
    extends _$MemberNotificationCopyWithImpl<$Res, _$_MemberNotification>
    implements _$$_MemberNotificationCopyWith<$Res> {
  __$$_MemberNotificationCopyWithImpl(
      _$_MemberNotification _value, $Res Function(_$_MemberNotification) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? contentUrl = freezed,
    Object? effectivePeriodBegin = null,
    Object? effectivePeriodEnd = null,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$_MemberNotification(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      contentUrl: freezed == contentUrl
          ? _value.contentUrl
          : contentUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      effectivePeriodBegin: null == effectivePeriodBegin
          ? _value.effectivePeriodBegin
          : effectivePeriodBegin // ignore: cast_nullable_to_non_nullable
              as DateTime,
      effectivePeriodEnd: null == effectivePeriodEnd
          ? _value.effectivePeriodEnd
          : effectivePeriodEnd // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

@firestoreSerializable
class _$_MemberNotification implements _MemberNotification {
  const _$_MemberNotification(
      {required this.id,
      required this.title,
      this.contentUrl,
      @TimestampConverter() required this.effectivePeriodBegin,
      @TimestampConverter() required this.effectivePeriodEnd,
      @TimestampConverter() this.updatedAt,
      @TimestampConverter() this.createdAt});

  factory _$_MemberNotification.fromJson(Map<String, dynamic> json) =>
      _$$_MemberNotificationFromJson(json);

// お知らせID
  @override
  final String id;
// タイトル
  @override
  final String title;
// お知らせURL
  @override
  final String? contentUrl;
// 有効期間開始
  @override
  @TimestampConverter()
  final DateTime effectivePeriodBegin;
// 有効期間終了
  @override
  @TimestampConverter()
  final DateTime effectivePeriodEnd;
// 更新日時
  @override
  @TimestampConverter()
  final DateTime? updatedAt;
// 登録日時
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'MemberNotification(id: $id, title: $title, contentUrl: $contentUrl, effectivePeriodBegin: $effectivePeriodBegin, effectivePeriodEnd: $effectivePeriodEnd, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MemberNotification &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.contentUrl, contentUrl) ||
                other.contentUrl == contentUrl) &&
            (identical(other.effectivePeriodBegin, effectivePeriodBegin) ||
                other.effectivePeriodBegin == effectivePeriodBegin) &&
            (identical(other.effectivePeriodEnd, effectivePeriodEnd) ||
                other.effectivePeriodEnd == effectivePeriodEnd) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, title, contentUrl,
      effectivePeriodBegin, effectivePeriodEnd, updatedAt, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MemberNotificationCopyWith<_$_MemberNotification> get copyWith =>
      __$$_MemberNotificationCopyWithImpl<_$_MemberNotification>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MemberNotificationToJson(
      this,
    );
  }
}

abstract class _MemberNotification implements MemberNotification {
  const factory _MemberNotification(
      {required final String id,
      required final String title,
      final String? contentUrl,
      @TimestampConverter() required final DateTime effectivePeriodBegin,
      @TimestampConverter() required final DateTime effectivePeriodEnd,
      @TimestampConverter() final DateTime? updatedAt,
      @TimestampConverter() final DateTime? createdAt}) = _$_MemberNotification;

  factory _MemberNotification.fromJson(Map<String, dynamic> json) =
      _$_MemberNotification.fromJson;

  @override // お知らせID
  String get id;
  @override // タイトル
  String get title;
  @override // お知らせURL
  String? get contentUrl;
  @override // 有効期間開始
  @TimestampConverter()
  DateTime get effectivePeriodBegin;
  @override // 有効期間終了
  @TimestampConverter()
  DateTime get effectivePeriodEnd;
  @override // 更新日時
  @TimestampConverter()
  DateTime? get updatedAt;
  @override // 登録日時
  @TimestampConverter()
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$_MemberNotificationCopyWith<_$_MemberNotification> get copyWith =>
      throw _privateConstructorUsedError;
}

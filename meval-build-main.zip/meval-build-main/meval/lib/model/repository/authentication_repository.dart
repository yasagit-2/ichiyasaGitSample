import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:twitter_login/twitter_login.dart';

import '../../const/constant.dart';
import '../../util/logger.dart';

class AuthenticationRepository {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final Uri _appleSignIn =
      Uri.parse(dotenv.get(Env.appleCallbackUrl, fallback: ''));
  final _twitterLogin = TwitterLogin(
    apiKey: dotenv.get(Env.twitterApiKey, fallback: ''),
    apiSecretKey: dotenv.get(Env.twitterApiSecret, fallback: ''),
    redirectURI: dotenv.get(Env.twitterCallbackUrl, fallback: ''),
  );

  /// 認証状態を確認します。
  /// 認証されていない場合、nullを返却します。
  Stream<User?> isLogin() {
    return FirebaseAuth.instance.authStateChanges();
  }

  /// 現在のユーザをログアウトします。
  Future<void> logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      await _googleSignIn.signOut();
      await FacebookAuth.instance.logOut();

      // Appleの場合、signOutメソッドは存在しない。see below
      // https://github.com/aboutyou/dart_packages/issues/277
      // https://github.com/aboutyou/dart_packages/issues/84

      // Twitterの場合、signOutメソッドは存在しない。see below
      // https://github.com/0maru/twitter_login/issues/5
      // https://github.com/0maru/twitter_login/issues/68

      await FirebaseFirestore.instance.terminate();
      await FirebaseFirestore.instance.clearPersistence();
    } on FirebaseException catch (e) {
      // ログアウト時の異常はWarning扱いとし、ユーザには見せない
      logger.warning(e);
    }
  }

  /// 電話番号の検証を行います。
  Future<User?> verifyPhoneNumber({
    required String phoneNumber,
    required AsyncValueGetter smsAuthCode,
    required Function(Exception e) verificationFailed,
  }) async {
    final verificationComplete = Completer<PhoneAuthCredential>();

    // 電話番号の検証
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        // ANDROID ONLY!

        logger.fine('verificationCompleted');
        logger.fine('credential=$credential');

        // 自動生成されたクレデンシャルでログイン
        await FirebaseAuth.instance.signInWithCredential(credential);

        verificationComplete.complete(credential);
      },
      verificationFailed: (FirebaseAuthException error) {
        verificationFailed(error);
        verificationComplete.completeError(error);
      },
      codeSent: (String verificationId, int? resendToken) async {
        // resendToken is ANDROID ONLY!

        logger.fine('codeSent');
        logger.fine('verificationId=$verificationId');
        logger.fine('resendToken=$resendToken');

        // 確認コードダイアログを表示
        final smsCode = await smsAuthCode();
        if (smsCode == null) {
          verificationComplete
              .completeError('SMS confirmation code is missing.');
          return;
        }

        // 確認コードを指定してPhoneAuthCredentialを生成
        PhoneAuthCredential credential = PhoneAuthProvider.credential(
            verificationId: verificationId, smsCode: smsCode);

        try {
          // クレデンシャルでログイン
          final userCredential =
              await FirebaseAuth.instance.signInWithCredential(credential);
          logger.fine('userCredential=$userCredential');
          verificationComplete.complete(credential);
        } on FirebaseAuthException catch (e) {
          verificationFailed(e);
          verificationComplete.completeError(e);
        }
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        // ANDROID ONLY!

        logger.fine('codeAutoRetrievalTimeout');
        logger.fine('verificationId=$verificationId');

        // verificationComplete
        //     .completeError(TimeoutException('Verification request timed out'));
      },
    );

    await verificationComplete.future;

    return FirebaseAuth.instance.currentUser;
  }

  /// Googleアカウントにてログインします。
  Future<User?> googleSignIn() async {
    // https://firebase.google.com/docs/auth/flutter/federated-auth#google

    // Google Sign-in認証フローの開始
    final signInAccount = await _googleSignIn.signIn();

    // 認証情報を取得
    final signInAuthentication = await signInAccount?.authentication;

    if (signInAuthentication == null) {
      logger.fine('GoogleSignInAuthentication is null.');
      return null;
    }

    // クレデンシャルの生成
    final credential = GoogleAuthProvider.credential(
      accessToken: signInAuthentication.accessToken,
      idToken: signInAuthentication.idToken,
    );

    final userCredential =
        await FirebaseAuth.instance.signInWithCredential(credential);
    logger.fine('userCredential=$userCredential');

    return FirebaseAuth.instance.currentUser;
  }

  /// https://firebase.google.com/docs/auth/flutter/federated-auth#apple
  /// Generates a cryptographically secure random nonce, to be included in a
  /// credential request.
  String generateNonce([int length = 32]) {
    const charset =
        '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
    final random = Random.secure();
    return List.generate(length, (_) => charset[random.nextInt(charset.length)])
        .join();
  }

  /// https://firebase.google.com/docs/auth/flutter/federated-auth#apple
  /// Returns the sha256 hash of [input] in hex notation.
  String sha256ofString(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  /// Appleアカウントにてログインします。
  Future<User?> appleSignIn() async {
    final rawNonce = generateNonce();
    final nonce = sha256ofString(rawNonce);

    try {
      // 現在サインインしているAppleアカウントのクレデンシャルを要求
      final appleCredential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
        webAuthenticationOptions: WebAuthenticationOptions(
          clientId: 'jp.co.mki.meval.appleid',
          redirectUri: _appleSignIn,
        ),
        nonce: nonce,
      );

      logger.fine('authorizationCode=${appleCredential.authorizationCode}');
      logger.fine('identityToken=${appleCredential.identityToken}');

      // Appleから返却されたクレデンシャルを用いて、`OAuthCredential`を生成
      OAuthProvider oauthProvider = OAuthProvider('apple.com');
      final credential = oauthProvider.credential(
        idToken: appleCredential.identityToken,
        accessToken: appleCredential.authorizationCode,
        rawNonce: rawNonce,
      );

      final userCredential =
          await FirebaseAuth.instance.signInWithCredential(credential);
      logger.fine('userCredential=$userCredential');
    } on SignInWithAppleAuthorizationException catch (e) {
      if (e.code != AuthorizationErrorCode.canceled) {
        // キャンセル以外の異常
        logger.severe(e);
        rethrow;
      }
    }

    return FirebaseAuth.instance.currentUser;
  }

  /// Facebookアカウントにてログインします。
  Future<User?> facebookSignIn() async {
    // https://firebase.google.com/docs/auth/flutter/federated-auth#facebook

    // サインインフローの開始
    // public_profileのみアクセス（emailにはアクセスしない）
    final LoginResult loginResult =
        await FacebookAuth.instance.login(permissions: ['public_profile']);
    final accessToken = loginResult.accessToken;
    if (accessToken == null) {
      logger.fine('FacebookAuth accessToken is null.');
      return null;
    }

    // アクセストークンからクレデンシャルを生成
    final OAuthCredential facebookAuthCredential =
        FacebookAuthProvider.credential(accessToken.token);

    final userCredential = await FirebaseAuth.instance
        .signInWithCredential(facebookAuthCredential);
    logger.fine('userCredential=$userCredential');

    return FirebaseAuth.instance.currentUser;
  }

  /// Twitterアカウントにてログインします。
  Future<User?> twitterSignIn() async {
    // https://firebase.google.com/docs/auth/flutter/federated-auth#twitter

    // サインインフローの開始
    final authResult = await _twitterLogin.login(forceLogin: true);

    switch (authResult.status) {
      case TwitterLoginStatus.loggedIn:
        // success
        logger.fine('twitterSignIn success.');

        // アクセストークンからクレデンシャルを生成
        final twitterAuthCredential = TwitterAuthProvider.credential(
          accessToken: authResult.authToken!,
          secret: authResult.authTokenSecret!,
        );

        final userCredential = await FirebaseAuth.instance
            .signInWithCredential(twitterAuthCredential);
        logger.fine('userCredential=$userCredential');

        return FirebaseAuth.instance.currentUser;
      case TwitterLoginStatus.cancelledByUser:
        // cancel
        logger.fine('twitterSignIn cancel.');
        return null;
      case TwitterLoginStatus.error:
        // error
        logger.fine('twitterSignIn error.');
        logger.severe(authResult.errorMessage);
        throw Exception(authResult.errorMessage);
      default:
        return null;
    }
  }

  /// 認証済みのカレントユーザをリロードします。
  Future<void> currentUserReload() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    await currentUser.reload();
  }

  /// 認証済みのカレントユーザの電話番号を返却します。
  String? getPhoneNumber() {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return null;

    return currentUser.phoneNumber;
  }
}

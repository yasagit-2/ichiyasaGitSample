import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../const/constant.dart';
import '../data/admin_alert.dart';
import '../data/admin_questionnaire.dart';
import '../data/base.dart';
import '../data/check_in.dart';
import '../data/completed_base.dart';
import '../data/completed_coupon.dart';
import '../data/member.dart';
import '../data/merchant.dart';
import '../data/point.dart';
import '../data/post.dart';
import '../data/tweet.dart';

final mapRepositoryProvider = Provider.autoDispose((ref) => MapRepository());

class MapRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// [centerLocation]を中心点として半径[collectionRadius]km以内の拠点を取得します。
  Stream<List<DocumentSnapshot>> getBasesByRange(
      GeoFlutterFire geo, LatLng centerLocation, double collectionRadius) {
    // 公開ステータスが「公開済み」の拠点/サブ拠点のみを取得
    final queryRef = _db.collection(basesRef.reference.path).where(
        'publishStatus',
        isEqualTo: publishStatusToInt(PublishStatus.published));

    return geo.collection(collectionRef: queryRef).within(
          center: geo.point(
              latitude: centerLocation.latitude,
              longitude: centerLocation.longitude),
          radius: collectionRadius,
          field: 'position',
          strictMode: true,
        );
  }

  /// [centerLocation]を中心点として半径[collectionRadius]km以内の加盟店を取得します。
  Stream<List<DocumentSnapshot>> getMerchantsByRange(
      GeoFlutterFire geo, LatLng centerLocation, double collectionRadius) {
    return geo
        .collection(collectionRef: _db.collection(merchantsRef.reference.path))
        .within(
          center: geo.point(
              latitude: centerLocation.latitude,
              longitude: centerLocation.longitude),
          radius: collectionRadius,
          field: 'position',
          strictMode: true,
        );
  }

  /// [centerLocation]を中心点として半径[collectionRadius]km以内の投稿を取得します。
  Stream<List<DocumentSnapshot>> getPostsByRange(
      GeoFlutterFire geo, LatLng centerLocation, double collectionRadius) {
    final queryRef = _db.collection(postsRef.reference.path).where(
        'visibleStatus',
        isEqualTo: visibleStatusToInt(VisibleStatus.visible));

    return geo.collection(collectionRef: queryRef).within(
          center: geo.point(
              latitude: centerLocation.latitude,
              longitude: centerLocation.longitude),
          radius: collectionRadius,
          field: 'position',
          strictMode: true,
        );
  }

  /// [centerLocation]を中心点として半径[collectionRadius]km以内の行政投稿(注意)を取得します。
  Stream<List<DocumentSnapshot>> getAdminAlertsByRange(
      GeoFlutterFire geo, LatLng centerLocation, double collectionRadius) {
    return geo
        .collection(
            collectionRef: _db.collection(adminAlertsRef.reference.path))
        .within(
          center: geo.point(
              latitude: centerLocation.latitude,
              longitude: centerLocation.longitude),
          radius: collectionRadius,
          field: 'position',
          strictMode: true,
        );
  }

  /// [centerLocation]を中心点として半径[collectionRadius]km以内の行政投稿(アンケート)を取得します。
  Stream<List<DocumentSnapshot>> getAdminQuestionnairesByRange(
      GeoFlutterFire geo, LatLng centerLocation, double collectionRadius) {
    return geo
        .collection(
            collectionRef:
                _db.collection(adminQuestionnairesRef.reference.path))
        .within(
          center: geo.point(
              latitude: centerLocation.latitude,
              longitude: centerLocation.longitude),
          radius: collectionRadius,
          field: 'position',
          strictMode: true,
        );
  }

  /// 拠点[baseId]へのチェックイン情報を保存します。
  /// 拠点[baseId]の公開ステータスが「公開済み」ではない場合、チェックイン情報を保存しません。
  /// 保存したチェックイン情報を返却します。（保存しない場合はnullを返却します。）
  Future<CheckIn?> checkIn(
      String baseId, String memberId, bool isParent) async {
    // チェックインID（拠点ID_会員ID）
    final checkInId = '${baseId}_$memberId';
    final checkIn = CheckIn(
      id: checkInId,
      isParent: isParent,
      baseRef: baseRef(id: baseId).reference,
      memberRef: memberRef(id: memberId).reference,
    );

    await _db.runTransaction((transaction) async {
      final docSnapshot = await transaction.get(baseRef(id: baseId).reference);
      final base = docSnapshot.data();

      // 公開ステータスが「公開済み」ではない場合、チェックイン情報を保存しない
      if (base != null &&
          base.publishStatus == publishStatusToInt(PublishStatus.published)) {
        // チェックイン情報登録
        await checkInRef(id: checkInId).set(checkIn);
      }
    });

    // 保存したチェックイン情報を返却
    final checkInDocSnapshot = await checkInRef(id: checkInId).get();
    return checkInDocSnapshot.data;
  }

  /// ログイン中の会員に該当するチェックイン情報（Stream）を取得します。
  Stream<List<CheckIn>> getCheckInByMemberIdStream(String memberId) {
    return checkInsRef.reference
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) => querySnapshot.docs
            .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
            .toList());
  }

  /// [memberId]に該当するチェックイン情報を返却します。
  /// チェックイン情報が存在しない場合、空のリストを返却します。
  Future<List<CheckIn>> getCheckInByMemberId(String memberId) async {
    final querySnapshot = await checkInsRef.reference
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .get();
    if (querySnapshot.docs.isEmpty) {
      return [];
    }

    return querySnapshot.docs
        .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
        .toList();
  }

  /// [baseId]および[memberId]に該当するチェックイン情報（Stream）を取得します。
  Stream<CheckIn?> getCheckInByBaseId(String baseId, String memberId) {
    return checkInsRef.reference
        .where('baseRef', isEqualTo: baseRef(id: baseId).reference)
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) {
      if (querySnapshot.docs.isEmpty) {
        return null;
      }
      return querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .first;
    });
  }

  /// [baseId]に該当する拠点（Stream）を取得します。
  Stream<Base?> getBaseById(String baseId) {
    return baseRef(id: baseId)
        .reference
        .snapshots()
        .map((documentSnapshot) => documentSnapshot.data());
  }

  /// [baseId]に該当する拠点（Future）を取得します。
  /// 公開ステータスが「公開済み」ではない場合、拠点が存在しないものとしてnullを返却します。
  Future<Base?> getBaseByIdFuture(String baseId) async {
    return await _db.runTransaction((transaction) async {
      final docSnapshot = await transaction.get(baseRef(id: baseId).reference);
      final base = docSnapshot.data();
      if (base == null ||
          base.publishStatus != publishStatusToInt(PublishStatus.published)) {
        return null;
      }

      return base;
    });
  }

  /// [merchantId]に該当する加盟店（Stream）を取得します。
  Stream<Merchant?> getMerchantById(String merchantId) {
    return merchantRef(id: merchantId)
        .reference
        .snapshots()
        .map((documentSnapshot) => documentSnapshot.data());
  }

  /// [merchantIdList]に該当するつぶやきを返却します。
  /// つぶやきが複数存在する場合、それぞれの加盟店における最新のつぶやきをListとして返却します。
  Stream<List<Tweet>> getTweetsByMerchantIdList(List<String> merchantIdList) {
    if (merchantIdList.isEmpty) {
      return Stream.value([]);
    }

    // Firestoreのクエリ制限に伴い、whereInを使用することはできない。
    // （パラメータで指定される加盟店IDのリストは、10件を超える可能性があるため。）
    // そのため、ここではつぶやきを全件取得した上で、アプリケーションにてフィルタする。
    // see...
    //   https://firebase.google.com/docs/firestore/query-data/queries#query_limitations

    return tweetsRef.reference
        .orderBy('createdAt', descending: true)
        // つぶやき登録日時で降順ソート
        .snapshots()
        .map((querySnapshot) {
      if (querySnapshot.docs.isEmpty) {
        return <Tweet>[];
      }

      final tweets = querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .toList();

      // パラメータで指定される加盟店IDリストのつぶやきをフィルタ
      final filteredTweets = tweets
          .where((tweet) => merchantIdList.contains(tweet.merchantRef.id))
          .toList();

      // 「つぶやきは一つだけとし、つぶやきを削除するかつぶやき表示期間が終了するまでは、次のつぶやきを投稿することはできない」
      // 上記仕様に従い、つぶやきを登録日時順で降順ソートした上で、加盟店ごとの最初の1件を抽出
      final idSet = <String>{};
      final distinguishTweets = <Tweet>[];
      for (var tweet in filteredTweets) {
        if (idSet.add(tweet.merchantRef.id)) {
          distinguishTweets.add(tweet);
        }
      }

      return distinguishTweets;
    });
  }

  /// [merchantId]に該当するつぶやきを返却します。
  /// つぶやきが複数存在する場合、最新のつぶやきを返却します。
  Stream<Tweet?> getTweetsByMerchantId(String merchantId) {
    final merchantDocRef = merchantRef(id: merchantId).reference;

    // 「つぶやきは一つだけとし、つぶやきを削除するかつぶやき表示期間が終了するまでは、次のつぶやきを投稿することはできない」
    // 上記仕様に従い、つぶやきを登録日時順で降順ソートした上で最初の1件を抽出
    return tweetsRef.reference
        .where('merchantRef', isEqualTo: merchantDocRef)
        // つぶやき登録日時で降順ソート
        .orderBy('createdAt', descending: true)
        .limit(1)
        .snapshots()
        .map((querySnapshot) {
      if (querySnapshot.docs.isEmpty) {
        return null;
      }

      return querySnapshot.docs.first.data();
    });
  }

  /// [memberId]に該当する拠点制覇情報（親拠点）（Stream）を取得します。
  Stream<List<CompletedParentBase>> getCompletedParentBases(String memberId) {
    return completedBaseRef(id: memberId).completedParentBases.snapshots().map(
        (completedParentBaseQuerySnapshot) => completedParentBaseQuerySnapshot
            .docs
            .map((completedParentBaseQueryDocumentSnapshot) =>
                completedParentBaseQueryDocumentSnapshot.data)
            .toList());
  }

  /// 加盟店[merchantId]に該当するクーポンのリスト（Stream）を取得します。
  Stream<List<Coupon>> getCouponsByMerchantId(String merchantId) {
    return merchantRef(id: merchantId)
        .coupons
        .orderByPublicationPeriodEnd()
        .snapshots()
        .map((couponQuerySnapshot) => couponQuerySnapshot.docs
            .map((couponQueryDocumentSnapshot) =>
                couponQueryDocumentSnapshot.data)
            .toList());
  }

  /// クーポン獲得/使用履歴を保存します。
  Future<void> createCouponHistory(String memberId, Coupon coupon) {
    final memberDocRef = memberRef(id: memberId).reference;

    return _db.runTransaction((transaction) async {
      final completedCouponDocRef = completedCouponRef(id: memberId).reference;
      final completedCouponDocSnap =
          await transaction.get(completedCouponDocRef);
      final completedCoupon = completedCouponDocSnap.data();

      if (completedCoupon == null) {
        // クーポン獲得情報作成
        transaction.set(
            completedCouponDocRef, CompletedCoupon(memberRef: memberDocRef));
      }

      final couponHistory = CouponHistory(
        id: coupon.id,
        merchantId: coupon.merchantId,
        name: coupon.name,
        exchangePoint: coupon.exchangePoint,
        dueDate: coupon.dueDate,
        isPointUsed: false,
        isCouponUsed: false,
        memberRef: memberDocRef,
      );

      // クーポン獲得/使用履歴作成
      transaction.set(
          completedCouponRef(id: memberId)
              .couponHistories
              .doc(coupon.id)
              .reference,
          couponHistory);
    });
  }

  /// 会員[memberId]におけるクーポン[couponId]のクーポン獲得/使用履歴を取得します。
  Stream<CouponHistory?> getCouponHistoryById(
      String memberId, String couponId) {
    return completedCouponRef(id: memberId)
        .couponHistories
        .doc(couponId)
        .snapshots()
        .map((couponHistoryDocSnap) => couponHistoryDocSnap.data);
  }

  /// 会員[memberId]における加盟店[merchantId]の獲得済みクーポンを取得します。
  Stream<List<CouponHistory>> getCouponHistoriesByMerchantId(
      String memberId, String merchantId) {
    return completedCouponRef(id: memberId)
        .couponHistories
        .whereMerchantId(isEqualTo: merchantId)
        .orderByDueDate()
        .snapshots()
        .map((couponHistoryQuerySnapshot) => couponHistoryQuerySnapshot.docs
            .map((couponHistoryQueryDocSnap) => couponHistoryQueryDocSnap.data)
            .toList());
  }

  /// 加盟店[merchantId]におけるクーポン[couponId]のクーポン獲得制限人数残りを取得します。
  /// 該当ドキュメントが存在しない場合、0を返却します。
  Stream<int> getExchangeLimitRemain(String merchantId, String couponId) {
    return merchantRef(id: merchantId)
        .coupons
        .doc(couponId)
        .couponTransactions
        .doc(couponTransactionDocumentId)
        .snapshots()
        .map((couponTransactionDocSnap) {
      final couponTransaction = couponTransactionDocSnap.data;
      if (couponTransaction == null) return 0;

      return couponTransaction.exchangeLimitRemain;
    });
  }

  /// [couponHistory]のクーポンを使用済みとして更新します。
  Future<void> useCoupon(String memberId, CouponHistory couponHistory) async {
    final couponHistoryDocRef = completedCouponRef(id: memberId)
        .couponHistories
        .doc(couponHistory.id)
        .reference;
    await _db.runTransaction(
      (transaction) async {
        final couponHistoryDocSnap = await transaction.get(couponHistoryDocRef);
        final couponHistory = couponHistoryDocSnap.data();
        if (
            // クーポン獲得していない場合は使用不可
            couponHistory == null ||
                // クーポン使用済みの場合は追加使用不可
                couponHistory.isCouponUsed ||
                // クーポン獲得処理のポイント減算処理が終了していない場合は使用不可
                !couponHistory.isPointUsed) {
          return;
        }

        // クーポン使用
        transaction.update(couponHistoryDocRef, {
          'isCouponUsed': true,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      },
    );
  }

  /// ポイント交換未済（バックエンド処理中）のクーポン獲得/使用履歴を取得します。
  Stream<List<CouponHistory>> getUnusedPointCoupons(String memberId) {
    return completedCouponRef(id: memberId)
        .couponHistories
        .whereIsPointUsed(isEqualTo: false)
        .snapshots()
        .map((couponHistoryQuerySnapshot) => couponHistoryQuerySnapshot.docs
            .map((couponHistoryQueryDocSnap) => couponHistoryQueryDocSnap.data)
            .toList());
  }

  /// 会員[memberId]のポイント(Stream)を取得します。
  /// ポイントドキュメントが存在しない場合、0を返却します。
  Stream<int> getPoint(String memberId) {
    return pointRef(id: memberId).snapshots().map((pointDocSnapshot) {
      final point = pointDocSnapshot.data;
      if (point == null) {
        return 0;
      }
      return point.point;
    });
  }
}

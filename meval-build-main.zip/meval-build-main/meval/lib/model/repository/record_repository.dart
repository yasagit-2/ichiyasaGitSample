import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../const/constant.dart';
import '../../util/datetime_util.dart';
import '../../util/logger.dart';
import '../data/base.dart';
import '../data/check_in.dart';
import '../data/completed_base.dart';
import '../data/completed_title.dart';
import '../data/completed_walk.dart';
import '../data/event.dart';
import '../data/event_participation_history.dart';
import '../data/member.dart';
import '../data/title.dart';

final recordRepositoryProvider =
    Provider.autoDispose((ref) => RecordRepository());

class RecordRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// [memberId]に該当するチェックイン情報をStreamで返却します。
  /// チェックイン情報が存在しない場合、空のリストを返却します。
  Stream<List<CheckIn>> getCheckInByMemberId(String memberId) {
    return checkInsRef.reference
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) {
      return querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .toList();
    });
  }

  /// 全ての称号をStreamで返却します。
  Stream<List<Title>> getStreamTitles() {
    return titlesRef.reference.snapshots().map(
      (querySnapshot) {
        return querySnapshot.docs
            .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
            .toList();
      },
    );
  }

  /// 拠点制覇情報、および称号獲得履歴を保存します。（同一トランザクションで処理します。）
  Future<void> saveCompletedBases(
      String memberId, Title title, Base parent, List<Base>? subBases) async {
    return await _db.runTransaction((transaction) async {
      // 拠点制覇情報
      final completedBaseDocSnapshot =
          await transaction.get(completedBaseRef(id: memberId).reference);

      // 称号獲得情報
      final completedTitleDocSnapshot =
          await transaction.get(completedTitleRef(id: memberId).reference);

      // 称号獲得履歴
      final titleHistoryDocRef = completedTitleRef(id: memberId)
          .titleHistories
          .doc(title.id)
          .reference;
      final documentSnapshot = await transaction.get(titleHistoryDocRef);
      final titleHistory = documentSnapshot.data();

      final memberDocRef = memberRef(id: memberId).reference;
      if (titleHistory == null) {
        // 称号獲得未済のため、称号獲得情報保存処理実行

        // 称号
        final titleDocRef = titleRef(id: title.id).reference;
        await transaction.get(titleDocRef);

        // 称号に紐づく拠点（親拠点）
        final basesQuerySnapshot = await basesRef.reference
            .where('titleRef', isEqualTo: titleDocRef)
            .where('publishStatus',
                isEqualTo: publishStatusToInt(PublishStatus.published))
            .get();
        final baseList = basesQuerySnapshot.docs
            .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
            .toList();

        // 拠点制覇情報
        final completedParentBaseQuerySnapshot =
            await completedBaseRef(id: memberId)
                .completedParentBases
                .whereTitleId(isEqualTo: title.id)
                .get();
        // 拠点制覇済み親拠点IDリスト
        final completedParentBaseIdList = completedParentBaseQuerySnapshot.docs
            .map((docSnapshot) => docSnapshot.data.id)
            .toList()
          // 現在処理中の親拠点IDを追加し、拠点制覇済みとして処理
          ..add(parent.id);

        final notYetCheckedInBase = baseList.firstWhereOrNull(
            (base) => !completedParentBaseIdList.contains(base.id));
        // 拠点制覇未済の拠点がなければ、称号獲得と判断（一つでも未制覇の拠点があれば称号獲得不可）
        final isCompleteTitle = notYetCheckedInBase == null;

        if (isCompleteTitle) {
          if (!completedTitleDocSnapshot.exists) {
            // 称号獲得情報
            final completedTitle = CompletedTitle(memberRef: memberDocRef);
            // 称号獲得情報設定
            transaction.set(
                completedTitleRef(id: memberId).reference, completedTitle);
          }

          final titleHistory = TitleHistory(
              id: title.id,
              name: title.name,
              point: title.point,
              memberRef: memberDocRef);

          // 称号獲得履歴設定
          transaction.set(
              completedTitleRef(id: memberId)
                  .titleHistories
                  .doc(title.id)
                  .reference,
              titleHistory);
        }
      }

      if (!completedBaseDocSnapshot.exists) {
        // 拠点制覇情報
        final completedBase = CompletedBase(memberRef: memberDocRef);
        // 拠点制覇情報設定
        transaction.set(
            completedBaseRef(id: memberId).reference, completedBase);
      }

      final completedParentBase = CompletedParentBase(
        // id: parent.id,
        id: parent.id,
        name: parent.name,
        subBaseCount: parent.subBaseCount,
        titleId: title.id,
        titleName: title.name,
        point: parent.point,
        memberRef: memberDocRef,
        position: parent.position,
      );

      final completedParentBaseDocRef =
          completedBaseRef(id: memberId).completedParentBases.doc(parent.id);

      // 拠点制覇情報（親拠点）設定
      transaction.set(completedParentBaseDocRef.reference, completedParentBase);

      if (subBases != null) {
        for (var subBase in subBases) {
          final completedSubBase = CompletedSubBase(
            id: subBase.id,
            name: subBase.name,
            memberRef: memberDocRef,
            position: subBase.position,
          );

          // 拠点制覇情報（サブ拠点）設定
          transaction.set(
            completedParentBaseDocRef.completedSubBases
                .doc(subBase.id)
                .reference,
            completedSubBase,
          );
        }
      }
    });
  }

  /// [titleId]に紐づく拠点（親拠点）(Stream)を取得します。
  Stream<List<Base>> getParentBasesByTitleId(String titleId) {
    return basesRef.reference
        .where('titleRef', isEqualTo: titleRef(id: titleId).reference)
        .where('publishStatus',
            isEqualTo: publishStatusToInt(PublishStatus.published))
        .snapshots()
        .map((querySnapshot) {
      return querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .toList();
    });
  }

  /// 会員[memberId]、および称号[titleId]に紐づく拠点制覇情報（親拠点）を取得します。
  Stream<List<CompletedParentBase>> getCompletedBasesByTitleId(
      String memberId, String titleId) {
    return completedBaseRef(id: memberId)
        .completedParentBases
        .whereTitleId(isEqualTo: titleId)
        .snapshots()
        .map((completedParentBaseQuerySnapshot) {
      return completedParentBaseQuerySnapshot.docs
          .map((completedParentBaseQueryDocumentSnapshot) =>
              completedParentBaseQueryDocumentSnapshot.data)
          .toList();
    });
  }

  /// 拠点[baseId]の拠点(Stream)を取得します。
  Stream<Base?> getBaseById(String baseId) {
    return baseRef(id: baseId).snapshots().map((baseDocumentSnapshot) {
      final base = baseDocumentSnapshot.data;
      if (base?.publishStatus != publishStatusToInt(PublishStatus.published)) {
        // 公開ステータスが公開済みではない場合は対象外
        return null;
      }
      return base;
    });
  }

  /// 親拠点[parentBaseId]に紐づくサブ拠点(Stream)を取得します。
  Stream<List<Base>> getSubBasesByParentBaseId(String parentBaseId) {
    final parentBaseDocRef = baseRef(id: parentBaseId).reference;
    return basesRef.reference
        .where('parentRef', isEqualTo: parentBaseDocRef)
        .where('publishStatus',
            isEqualTo: publishStatusToInt(PublishStatus.published))
        .snapshots()
        .map((querySnapshot) {
      return querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .toList();
    });
  }

  /// 称号[titleId]の称号獲得情報(Stream)を取得します。
  Stream<TitleHistory?> getCompletedTitleById(String memberId, String titleId) {
    return completedTitleRef(id: memberId)
        .titleHistories
        .doc(titleId)
        .snapshots()
        .map((titleHistoryDocumentSnapshot) =>
            titleHistoryDocumentSnapshot.data);
  }

  /// ウォーク達成情報、およびウォーク達成履歴を保存します。（同一トランザクションで処理します。）
  Future<void> saveCompletedWalks(String memberId, int stepsOfWeek,
      int stepAchievedPoint, DateTime now) async {
    // USA方式の週番号を生成（YYYYWww）
    final weeksNumAsStandardForm = createWeeksNumAsStandardForm(now);

    return await _db.runTransaction((transaction) async {
      final completedWalkDocRef = completedWalkRef(id: memberId).reference;

      // ウォーク達成情報
      final completedWalkDocSnapshot =
          await transaction.get(completedWalkDocRef);

      // ウォーク達成履歴
      final walkHistoryDocRef = completedWalkRef(id: memberId)
          .walkHistories
          .doc(weeksNumAsStandardForm)
          .reference;
      final walkHistoryDocSnapshot = await transaction.get(walkHistoryDocRef);
      final walkHistory = walkHistoryDocSnapshot.data();

      final memberDocRef = memberRef(id: memberId).reference;
      if (walkHistory == null) {
        // ウォーク達成未済のため、ウォーク達成履歴保存処理実行

        final walkHistory = WalkHistory(
          id: weeksNumAsStandardForm,
          point: stepAchievedPoint,
          step: stepsOfWeek,
          memberRef: memberDocRef,
        );

        // ウォーク達成履歴保存
        transaction.set(walkHistoryDocRef, walkHistory);
      }

      if (!completedWalkDocSnapshot.exists) {
        // ウォーク達成情報が存在しない場合は新規生成
        final completedWalk = CompletedWalk(memberRef: memberDocRef);
        transaction.set(completedWalkDocRef, completedWalk);
      }
    });
  }

  /// [id]のウォーク達成履歴(Stream)を取得します。
  Stream<WalkHistory?> getWalkHistory(String memberId, String id) {
    return completedWalkRef(id: memberId)
        .walkHistories
        .doc(id)
        .snapshots()
        .map((walkHistoryDocSnapshot) => walkHistoryDocSnapshot.data);
  }

  /// 全てのイベント(Stream)を取得します。
  Stream<List<Event>> getEvents() {
    return eventsRef
        .orderByEffectivePeriodBegin(descending: true)
        .orderByEffectivePeriodEnd(descending: true)
        .snapshots()
        .map((eventQuerySnapshot) => eventQuerySnapshot.docs
            .map(
                (eventQueryDocumentSnapshot) => eventQueryDocumentSnapshot.data)
            .toList());
  }

  /// [eventId]のイベント(Stream)を取得します。
  Stream<Event?> getEventById(String eventId) {
    return eventRef(id: eventId)
        .snapshots()
        .map((eventDocumentSnapshot) => eventDocumentSnapshot.data);
  }

  /// [eventId]の全てのイベントスポット(Stream)を取得します。
  Stream<List<EventSpot>> getEventSpots(String eventId) {
    return eventRef(id: eventId).eventSpots.snapshots().map(
        (eventSpotQuerySnapshot) => eventSpotQuerySnapshot.docs
            .map((eventSpotQueryDocSnapshot) => eventSpotQueryDocSnapshot.data)
            .toList());
  }

  /// [eventId]のイベントスポット(Stream)を取得します。
  Stream<EventSpot?> getEventSpotById(String eventId, String eventSpotId) {
    return eventRef(id: eventId)
        .eventSpots
        .doc(eventSpotId)
        .snapshots()
        .map((eventSpotDocSnapshot) => eventSpotDocSnapshot.data);
  }

  /// 会員[memberId]のイベント[eventId]の参加イベント(Stream)を取得します。
  Stream<ParticipatedEvent?> getParticipatedEventByEventId(
      String memberId, String eventId) {
    return eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(eventId)
        .snapshots()
        .map((participatedEventDocSnapshot) =>
            participatedEventDocSnapshot.data);
  }

  /// 会員[memberId]のイベント[eventId]のイベント参加履歴における、達成地点数(Stream)を取得します。
  Stream<int> getCompletedSpotCountByEventId(String memberId, String eventId) {
    return eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(eventId)
        .completedSpots
        .snapshots()
        .map((completedSpotQuerySnapshot) =>
            completedSpotQuerySnapshot.docs.length);
  }

  /// 会員[memberId]のイベント[eventId]のイベント参加履歴における、全ての達成地点(Stream)を取得します。
  Stream<List<CompletedSpot>> getCompletedSpotByEventId(
      String memberId, String eventId) {
    return eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(eventId)
        .completedSpots
        .snapshots()
        .map((completedSpotQuerySnapshot) => completedSpotQuerySnapshot.docs
            .map((completedSpotQueryDocSnapshot) =>
                completedSpotQueryDocSnapshot.data)
            .toList());
  }

  /// 会員[memberId]のイベント参加履歴を保存します。
  /// QRコード識別子[qrCodeId]が既に記録済みである場合、処理を行わずに終了します。
  Future<void> completeSpot(String memberId, Event event, EventSpot eventSpot,
      String qrCodeId) async {
    // 会員のReference
    final memberDocRef = memberRef(id: memberId).reference;

    // イベント参加履歴のReference
    final eventParticipationHistoryDocRef =
        eventParticipationHistoryRef(id: memberId).reference;

    // 参加イベントのReference
    final participatedEventDocRef = eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(event.id)
        .reference;

    // 達成地点のReference
    final completedSpotDocRef = eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(event.id)
        .completedSpots
        .doc(qrCodeId)
        .reference;

    return await _db.runTransaction((transaction) async {
      // 達成地点取得
      final completedSpotDocSnapshot =
          await transaction.get(completedSpotDocRef);
      CompletedSpot? completedSpot = completedSpotDocSnapshot.data();
      if (completedSpot != null) {
        // 対象のイベントスポットが既に達成済みのため処理しない
        logger.fine('Target spot is completed. id=$qrCodeId');
        return;
      }

      // イベント参加履歴取得
      final eventParticipationHistoryDocSnapshot =
          await transaction.get(eventParticipationHistoryDocRef);
      EventParticipationHistory? eventParticipationHistory =
          eventParticipationHistoryDocSnapshot.data();

      // 参加イベント取得
      final participatedEventDocSnapshot =
          await transaction.get(participatedEventDocRef);
      final participatedEvent = participatedEventDocSnapshot.data();

      if (eventParticipationHistory == null) {
        // イベント参加履歴新規作成
        eventParticipationHistory =
            EventParticipationHistory(memberRef: memberDocRef);
        transaction.set(
            eventParticipationHistoryDocRef, eventParticipationHistory);
      }

      if (participatedEvent == null) {
        // 参加イベント新規作成
        final participatedEvent = ParticipatedEvent(
          id: event.id,
          title: event.title,
          point: event.point,
          exchangeType: event.exchangeType,
          completeSpotCount: event.completeSpotCount,
          memberRef: memberDocRef,
        );
        transaction.set(participatedEventDocRef, participatedEvent);
      }

      // 達成地点新規作成
      completedSpot = CompletedSpot(
        id: qrCodeId,
        eventSpotId: eventSpot.id,
        eventSpotName: eventSpot.name,
        memberRef: memberDocRef,
        position: eventSpot.position,
      );
      transaction.set(completedSpotDocRef, completedSpot);
    });
  }

  /// 会員[memberId]の参加イベント[event]を達成状態として更新します。
  Future<void> completeEvent(String memberId, Event event) async {
    // 参加イベントのReference
    final participatedEventDocRef = eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(event.id)
        .reference;

    await _db.runTransaction((transaction) async {
      // 参加イベント
      final participatedEventDocSnap =
          await transaction.get(participatedEventDocRef);
      final participatedEvent = participatedEventDocSnap.data();

      if (participatedEvent == null || participatedEvent.isComplete) {
        logger.fine('Target event is not found or completed. id=${event.id}');
        return;
      }

      // 参加イベントを達成状態として更新
      transaction.update(participatedEventDocRef, {
        'isComplete': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../data/check_in.dart';
import '../data/completed_title.dart';
import '../data/member.dart';
import '../data/member_notification.dart';
import '../data/summary.dart';

final homeRepositoryProvider = Provider.autoDispose((ref) => HomeRepository());

class HomeRepository {
  /// 会員[memberId]における親拠点へのチェックイン総数((Stream)を取得します。
  Stream<int> getTotalCheckedInParentBases(String memberId) {
    return checkInsRef
        .whereIsParent(isEqualTo: true)
        .reference
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) => querySnapshot.docs.length);
  }

  /// 会員[memberId]におけるサブ拠点へのチェックイン総数(Stream)を取得します。
  Stream<int> getTotalCheckedInSubBases(String memberId) {
    return checkInsRef
        .whereIsParent(isEqualTo: false)
        .reference
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) => querySnapshot.docs.length);
  }

  /// 会員[memberId]における獲得済み称号の総数(Stream)を取得します。
  Stream<int> getTotalCompletedTitles(String memberId) {
    return completedTitleRef(id: memberId).titleHistories.snapshots().map(
        (titleHistoryQuerySnapshot) => titleHistoryQuerySnapshot.docs.length);
  }

  /// 会員数(Stream)を取得します。
  /// 会員数が存在しない場合、0を返却します。
  Stream<int> getTotalMember() {
    return summaryRef(id: summaryDocumentId).snapshots().map(
        (summaryDocumentSnapshot) =>
            summaryDocumentSnapshot.data?.totalMember ?? 0);
  }

  /// 会員[memberId]のランキング(Stream)を取得します。
  /// ランキングが存在しない場合、0を返却します。
  Stream<int> getRank(String memberId) {
    return summaryRef(id: summaryDocumentId)
        .rankings
        .doc(memberId)
        .snapshots()
        .map((rankingDocumentSnapshot) =>
            rankingDocumentSnapshot.data?.rank ?? 0);
  }

  /// 全てのお知らせ(Stream)を取得します。
  Stream<List<MemberNotification>> getMemberNotifications() {
    return memberNotificationsRef
        .orderByEffectivePeriodBegin(descending: true)
        .orderByEffectivePeriodEnd(descending: true)
        .snapshots()
        .map((memberNotificationQuerySnapshot) =>
            memberNotificationQuerySnapshot.docs
                .map((memberNotificationQueryDocSnapshot) =>
                    memberNotificationQueryDocSnapshot.data)
                .toList());
  }
}

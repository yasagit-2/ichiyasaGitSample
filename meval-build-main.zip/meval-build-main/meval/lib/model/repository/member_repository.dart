import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../const/constant.dart';
import '../../provider/authentication_type_provider.dart';
import '../data/device_info.dart';
import '../data/member.dart';
import '../data/private_profile.dart';
import '../data/withdrawal.dart';

final memberRepositoryProvider =
    Provider.autoDispose((ref) => MemberRepository());

class MemberRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// カレントユーザの会員情報を返却します。
  /// 会員情報が存在しない場合、nullを返却します。
  Future<Member?> getCurrentMember() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return null;

    final memberDocumentSnapshot = await memberRef(id: currentUser.uid).get();
    return memberDocumentSnapshot.data;
  }

  /// 会員情報を登録します。
  Future<void> register({
    required String nickname,
    required String gender,
    required DateTime monthOfBirth,
    required String prefecture,
    required String name,
    required String mailAddress,
    required AuthenticationType authenticationProvider,
    required DeviceInfo deviceInfo,
  }) async {
    final member = Member(
      // ログイン済みの場合のみ呼び出されるため、currentUserは必ず存在する
      id: FirebaseAuth.instance.currentUser!.uid,
      nickname: nickname,
      gender: gender,
      monthOfBirth: monthOfBirth,
      prefecture: prefecture,
      name: name,
      mailAddress: mailAddress,
      authenticationProvider: authenticationProvider,
      postedAt: Const.epoch,
      reportedAt: Const.epoch,
      commentedAt: Const.epoch,
    );

    final memberDocRef = memberRef(id: member.id);
    final privateProfileDocRef = privateProfileRef(id: member.id);

    final privateProfile = PrivateProfile(
      memberRef: memberDocRef.reference,
      deviceInfo: deviceInfo,
    );

    await _db.runTransaction((transaction) async {
      // 会員登録
      transaction.set(memberDocRef.reference, member);

      // プライベートプロフィール登録
      transaction.set(privateProfileDocRef.reference, privateProfile);
    });
  }

  /// [memberId]に該当するユーザをmembersコレクション、privateProfilesコレクションから削除します。
  Future<void> remove({required String memberId}) async {
    await _db.runTransaction((transaction) async {
      transaction.delete(memberRef(id: memberId).reference);
      transaction.delete(privateProfileRef(id: memberId).reference);
    });
  }

  /// 会員情報を更新します。
  Future<void> updateMember({
    required String memberId,
    required String nickname,
    required String gender,
    required DateTime monthOfBirth,
    required String prefecture,
    required String name,
    required String mailAddress,
  }) async {
    final memberDocRef = memberRef(id: memberId);

    // TODO cloud_firestore_odmにて処理したいが、現状ではupdatedAtを上手く処理することができないためフィールド名を直接指定している。
    return await memberDocRef.reference.update(
      {
        'nickname': nickname,
        'gender': gender,
        'monthOfBirth': monthOfBirth.toUtc(),
        'prefecture': prefecture,
        'name': name,
        'mailAddress': mailAddress,
        'updatedAt': FieldValue.serverTimestamp(),
      },
    ).timeout(Duration(seconds: Const.timeoutSec));
  }

  /// [memberId]の会員情報（Stream）を取得します。
  Stream<Member?> getMember(String memberId) {
    return memberRef(id: memberId)
        .snapshots()
        .map((memberDocumentSnapshot) => memberDocumentSnapshot.data);
  }

  /// 会員[memberId]のプライベートプロフィールを取得します。
  Future<PrivateProfile?> getPrivateProfile(String memberId) async {
    final documentSnapshot =
        await privateProfileRef(id: memberId).reference.get();
    return documentSnapshot.data();
  }

  /// 会員[memberId]のデバイス情報を更新します。
  Future<void> updateDeviceInfo(String memberId, DeviceInfo deviceInfo) async {
    // cloud_firestore_odm がネストしたオブジェクトのupdateに未対応のため直接フィールド指定している。
    // see...
    //   https://github.com/firebase/flutterfire/discussions/7475#discussioncomment-1782651
    return await privateProfileRef(id: memberId).reference.update(
      {
        'deviceInfo': {
          'os': deviceInfo.os,
          'version': deviceInfo.version,
          'device': deviceInfo.device,
        },
        'updatedAt': FieldValue.serverTimestamp(),
      },
    ).timeout(Duration(seconds: Const.timeoutSec));
  }

  /// 会員[memberId]の投稿日時(Stream)を返却します。
  Stream<DateTime?> getPostedAt(String memberId) {
    return memberRef(id: memberId)
        .snapshots()
        .map((memberDocumentSnapshot) => memberDocumentSnapshot.data?.postedAt);
  }

  /// 会員[memberId]の行政報告日時(Stream)を返却します。
  Stream<DateTime?> getReportedAt(String memberId) {
    return memberRef(id: memberId).snapshots().map(
        (memberDocumentSnapshot) => memberDocumentSnapshot.data?.reportedAt);
  }

  /// 会員[memberId]のコメント日時(Stream)を返却します。
  Stream<DateTime?> getCommentedAt(String memberId) {
    return memberRef(id: memberId).snapshots().map(
        (memberDocumentSnapshot) => memberDocumentSnapshot.data?.commentedAt);
  }

  /// 会員[memberId]の退会申請(Stream)を返却します。
  Stream<Withdrawal?> getWithdrawal(String memberId) {
    return withdrawalRef(id: memberId)
        .snapshots()
        .map((withdrawalDocSnapshot) => withdrawalDocSnapshot.data);
  }

  /// 会員[memberId]の退会申請を作成します。
  Future<void> createWithdrawal(String memberId) async {
    // オフラインモードにおけるキャッシュの影響を考慮し、ここではトランザクションを利用してFirestoreへアクセスを行う。
    // （キャッシュへ書き込んだとしても、Firestore上に退会申請を作成できていなければ、Cloud Functionsによ会員情報の削除が機能しないため。）
    return await _db.runTransaction((transaction) async {
      transaction.set(
          withdrawalRef(id: memberId).reference, Withdrawal(id: memberId));
    });
  }

  /// 会員[memberId]の退会申請を削除します。
  Future<void> cancelWithdrawal(String memberId) async {
    // オフラインモードにおけるキャッシュの影響を考慮し、ここではトランザクションを利用してFirestoreへアクセスを行う。
    // （キャッシュから削除したとしてもFirestore上の退会申請が削除できていなければ、Cloud Functionsにより会員情報は削除されてしまうため。）
    return await _db.runTransaction((transaction) async {
      transaction.delete(withdrawalRef(id: memberId).reference);
    });
  }
}

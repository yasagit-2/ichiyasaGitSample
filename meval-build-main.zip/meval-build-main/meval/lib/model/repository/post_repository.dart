import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../const/constant.dart';
import '../data/admin_alert.dart';
import '../data/admin_questionnaire.dart';
import '../data/answered_questionnaire.dart';
import '../data/comment.dart';
import '../data/like.dart';
import '../data/map_position.dart';
import '../data/member.dart';
import '../data/post.dart';
import '../data/posting_alert.dart';
import '../data/report.dart';

// 投稿リポジトリプロバイダ
final postRepositoryProvider = Provider.autoDispose((ref) => PostRepository());

class PostRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// 投稿を保存します。
  Future<Post?> post(GeoFlutterFire geo, String memberId, DateTime postedAt,
      String message, LatLng position, File? imageFile) async {
    return await _db.runTransaction((transaction) async {
      final memberDocumentReference = memberRef(id: memberId).reference;
      final documentSnapshot = await transaction.get(memberDocumentReference);
      final transactionMember = documentSnapshot.data()!;

      if (transactionMember.postedAt.compareTo(postedAt) != 0) {
        // optimistic locking
        return null;
      }

      // 投稿ID
      final postId = const Uuid().v4();

      String? imageUrl;
      String? imagePath;
      if (imageFile != null) {
        // 投稿画像の保存

        final storageRef =
            FirebaseStorage.instance.ref().child('posts/$memberId/$postId');

        // 投稿画像をStorageへ保存
        final taskSnapshot = await storageRef.putFile(imageFile);
        imageUrl = await taskSnapshot.ref.getDownloadURL();
        imagePath = taskSnapshot.ref.fullPath;
      }

      // 投稿の位置情報
      final postPosition =
          geo.point(latitude: position.latitude, longitude: position.longitude);

      final post = Post(
        id: postId,
        message: message,
        memberRef: memberRef(id: memberId).reference,
        position: MapPosition(
            geohash: postPosition.hash, geopoint: postPosition.geoPoint),
        imageUrl: imageUrl,
        imagePath: imagePath,
      );

      // 投稿を保存
      transaction.set(postRef(id: postId).reference, post);
      // 最終投稿日時を更新
      transaction.update(memberDocumentReference, {
        'postedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return post;
    });
  }

  /// 行政報告を保存します。
  Future<Report?> report(
      GeoFlutterFire geo,
      String memberId,
      DateTime reportedAt,
      String message,
      LatLng position,
      File? imageFile) async {
    await _db.runTransaction((transaction) async {
      final memberDocumentReference = memberRef(id: memberId).reference;
      final documentSnapshot = await transaction.get(memberDocumentReference);
      final transactionMember = documentSnapshot.data()!;

      if (transactionMember.reportedAt.compareTo(reportedAt) != 0) {
        // optimistic locking
        return null;
      }

      final reportId = const Uuid().v4();

      String? imageUrl;
      String? imagePath;
      if (imageFile != null) {
        // 行政報告画像の保存

        final storageRef =
            FirebaseStorage.instance.ref().child('reports/$memberId/$reportId');

        // 行政報告画像をStorageへ保存
        final taskSnapshot = await storageRef.putFile(imageFile);
        imageUrl = await taskSnapshot.ref.getDownloadURL();
        imagePath = taskSnapshot.ref.fullPath;
      }

      // 行政報告の位置情報
      final reportPosition =
          geo.point(latitude: position.latitude, longitude: position.longitude);

      final report = Report(
        id: reportId,
        message: message,
        memberRef: memberRef(id: memberId).reference,
        position: MapPosition(
            geohash: reportPosition.hash, geopoint: reportPosition.geoPoint),
        imageUrl: imageUrl,
        imagePath: imagePath,
      );

      // 行政報告を保存
      transaction.set(reportRef(id: reportId).reference, report);
      // 最終行政報告日時を更新
      transaction.update(memberDocumentReference, {
        'reportedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return report;
    });
  }

  /// 投稿者の情報を返却します。
  /// 会員が存在しない場合、nullを返却します。
  Future<Member?> getPostMember(Post post) async {
    final documentSnapshot = await memberRef(id: post.memberRef.id).get();
    return documentSnapshot.data;
  }

  /// コメントを保存します。
  Future<Comment?> comment(
      String postId, String memberId, String message) async {
    return await _db.runTransaction((transaction) async {
      final memberDocumentReference = memberRef(id: memberId).reference;

      final postDocSnapshot =
          await transaction.get(postRef(id: postId).reference);
      if (postDocSnapshot.exists) {
        final commentId = const Uuid().v4();
        final comment = Comment(
          id: commentId,
          message: message,
          memberRef: memberRef(id: memberId).reference,
          postRef: postRef(id: postId).reference,
        );

        // コメントを保存
        transaction.set(commentRef(id: commentId).reference, comment);
        // 最終コメント日時を更新
        transaction.update(memberDocumentReference, {
          'commentedAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
        return comment;
      }
    });
  }

  /// [postId]の投稿(Stream)を取得します。
  Stream<Post?> getPostById(String postId) {
    return postRef(id: postId).snapshots().map((postDocumentSnapshot) {
      final post = postDocumentSnapshot.data;
      if (post == null ||
          post.visibleStatus != visibleStatusToInt(VisibleStatus.visible)) {
        return null;
      }
      return post;
    });
  }

  /// [postId]の投稿のコメント(Stream)を取得します。
  Stream<List<Comment>> getCommentsByPostId(String postId) {
    final postDocRef = postRef(id: postId).reference;

    return commentsRef.reference
        .where('postRef', isEqualTo: postDocRef)
        // コメント登録日時で降順ソート
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((QuerySnapshot<Comment> querySnapshot) {
      return querySnapshot.docs
          .map((QueryDocumentSnapshot<Comment> queryDocumentSnapshot) {
        return queryDocumentSnapshot.data();
      }).toList();
    });
  }

  /// 投稿[post]を削除します。
  Future<void> deletePost(Post post) async {
    // 投稿削除
    return await postRef(id: post.id)
        .delete()
        .timeout(Duration(seconds: Const.timeoutSec));
  }

  /// 投稿[post]を通報します。
  Future<void> alertPost(String memberId, Post post) async {
    // 通報ID（投稿ID_会員ID）
    final id = '${post.id}_$memberId';

    final postingAlert = PostingAlert(
      id: id,
      memberRef: memberRef(id: memberId).reference,
      postRef: postRef(id: post.id).reference,
    );

    return postingAlertRef(id: id)
        .set(postingAlert)
        .timeout(Duration(seconds: Const.timeoutSec));
  }

  /// [postId]の投稿に対するいいね情報を保存します。
  Future<void> like(String postId, String memberId) async {
    final likeId = '${postId}_$memberId';
    final like = Like(
      id: likeId,
      postRef: postRef(id: postId).reference,
      memberRef: memberRef(id: memberId).reference,
    );

    return await _db.runTransaction((transaction) async {
      final likeDocumentReference = likeRef(id: likeId).reference;
      final documentSnapshot = await transaction.get(likeDocumentReference);
      if (!documentSnapshot.exists) {
        transaction.update(postRef(id: postId).reference, {
          'likeCount': FieldValue.increment(1),
          'updatedAt': FieldValue.serverTimestamp(),
        });
        transaction.set(likeDocumentReference, like);
      }
    });
  }

  /// [likeId]に該当するいいね情報を削除します。
  Future<void> deleteLike(String likeId, String postId) async {
    await _db.runTransaction((transaction) async {
      final likeDocumentReference = likeRef(id: likeId).reference;
      final documentSnapshot = await transaction.get(likeDocumentReference);
      if (documentSnapshot.exists) {
        transaction.update(postRef(id: postId).reference, {
          'likeCount': FieldValue.increment(-1),
          'updatedAt': FieldValue.serverTimestamp(),
        });
        transaction.delete(likeDocumentReference);
      }
    });
  }

  /// [postId]および[memberId]に該当するいいね情報を取得します。
  Stream<Like?> getLike(String postId, String memberId) {
    return likesRef.reference
        .where('postRef', isEqualTo: postRef(id: postId).reference)
        .where('memberRef', isEqualTo: memberRef(id: memberId).reference)
        .snapshots()
        .map((querySnapshot) {
      if (querySnapshot.docs.isEmpty) {
        return null;
      }
      return querySnapshot.docs
          .map((queryDocumentSnapshot) => queryDocumentSnapshot.data())
          .first;
    });
  }

  /// [adminAlertId]の行政投稿（注意）(Stream)を取得します。
  Stream<AdminAlert?> getAdminAlertById(String adminAlertId) {
    return adminAlertRef(id: adminAlertId)
        .snapshots()
        .map((adminAlertDocumentSnapshot) => adminAlertDocumentSnapshot.data);
  }

  /// [adminQuestionnaireId]の行政投稿（アンケート）(Stream)を取得します。
  Stream<AdminQuestionnaire?> getAdminQuestionnaireById(
      String adminQuestionnaireId) {
    return adminQuestionnaireRef(id: adminQuestionnaireId).snapshots().map(
        (adminQuestionnaireDocumentSnapshot) =>
            adminQuestionnaireDocumentSnapshot.data);
  }

  /// [adminQuestionnaireId]の行政投稿（アンケート）の選択肢(Stream)を取得します。
  Stream<List<Choice>> getChoiceByAdminQuestionnaireId(
      String adminQuestionnaireId) {
    return adminQuestionnaireRef(id: adminQuestionnaireId)
        .choices
        .orderByDisplayOrder()
        .snapshots()
        .map((choiceQuerySnapshot) {
      return choiceQuerySnapshot.docs
          .map(
              (choiceQueryDocumentSnapshot) => choiceQueryDocumentSnapshot.data)
          .toList();
    });
  }

  /// 会員[memberId]における[adminQuestionnaireId]のアンケート回答履歴を取得します。
  Stream<QuestionnaireHistory?> getQuestionnaireHistoryById(
      String memberId, String adminQuestionnaireId) {
    return answeredQuestionnaireRef(id: memberId)
        .questionnaireHistories
        .doc(adminQuestionnaireId)
        .snapshots()
        .map((questionnaireHistoryDocSnapshot) =>
            questionnaireHistoryDocSnapshot.data);
  }

  /// アンケート回答情報を保存します。
  Future<void> answerQuestionnaire(String memberId, String adminQuestionnaireId,
      String selectedChoiceId) async {
    return await _db.runTransaction((transaction) async {
      final memberDocRef = memberRef(id: memberId).reference;

      // アンケート
      final adminQuestionnaireDocSnapshot = await transaction
          .get(adminQuestionnaireRef(id: adminQuestionnaireId).reference);
      final adminQuestionnaire = adminQuestionnaireDocSnapshot.data();
      if (adminQuestionnaire == null) {
        return;
      }

      // 選択肢
      final choiceDocSnapshot = await transaction.get(
          adminQuestionnaireRef(id: adminQuestionnaireId)
              .choices
              .doc(selectedChoiceId)
              .reference);
      final choice = choiceDocSnapshot.data();
      if (choice == null) {
        return;
      }

      final answeredQuestionnaireDocRef =
          answeredQuestionnaireRef(id: memberId).reference;

      // アンケート回答情報
      final answeredQuestionnaireDocSnapshot =
          await transaction.get(answeredQuestionnaireDocRef);
      final answeredQuestionnaire = answeredQuestionnaireDocSnapshot.data();
      if (answeredQuestionnaire == null) {
        // アンケート回答情報保存
        final answeredQuestionnaire =
            AnsweredQuestionnaire(memberRef: memberDocRef);
        transaction.set(answeredQuestionnaireDocRef, answeredQuestionnaire);
      }

      final questionnaireHistory = QuestionnaireHistory(
        id: adminQuestionnaireId,
        message: adminQuestionnaire.message,
        choiceId: selectedChoiceId,
        choiceMessage: choice.choice,
        point: adminQuestionnaire.point,
        memberRef: memberDocRef,
      );

      // アンケート回答履歴保存
      transaction.set(
          answeredQuestionnaireRef(id: memberId)
              .questionnaireHistories
              .doc(adminQuestionnaireId)
              .reference,
          questionnaireHistory);
    });
  }

  /// 会員[memberId]のニックネームを取得します。
  Future<String?> getMemberNickname(String memberId) async {
    final memberDocSnapshot = await memberRef(id: memberId).get();
    return memberDocSnapshot.data?.nickname;
  }

  /// 通報[postingAlertId]の存在有無を返却します。
  Stream<bool> getPostingAlertExistsById(String postingAlertId) {
    return postingAlertRef(id: postingAlertId)
        .snapshots()
        .map((postingAlertDocSnap) => postingAlertDocSnap.exists);
  }
}

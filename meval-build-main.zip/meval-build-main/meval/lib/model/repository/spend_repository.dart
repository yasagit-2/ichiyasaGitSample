import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../data/completed_base.dart';
import '../data/completed_coupon.dart';
import '../data/completed_title.dart';
import '../data/event_participation_history.dart';
import '../data/merchant.dart';
import '../data/point.dart';

final spendRepositoryProvider =
    Provider.autoDispose((ref) => SpendRepository());

class SpendRepository {
  /// 会員[memberId]のポイント(Stream)を取得します。
  /// ポイントドキュメントが存在しない場合、0を返却します。
  Stream<int> getPoint(String memberId) {
    return pointRef(id: memberId).snapshots().map((pointDocSnapshot) {
      final point = pointDocSnapshot.data;
      if (point == null) {
        return 0;
      }
      return point.point;
    });
  }

  /// 会員[memberId]のポイント獲得履歴(Stream)を取得します。
  Stream<List<PointHistory>> getPointHistories(String memberId) {
    return pointRef(id: memberId)
        .pointHistories
        .orderByCreatedAt(descending: true)
        .snapshots()
        .map((pointHistoryQuerySnapshot) => pointHistoryQuerySnapshot.docs
            .map((pointHistoryQueryDocSnapshot) =>
                pointHistoryQueryDocSnapshot.data)
            .toList());
  }

  /// 会員[memberId]の[completedBasesId]に該当する拠点制覇情報を取得します。
  Future<CompletedParentBase?> getCompletedBase(
      String memberId, String completedBasesId) async {
    final docSnapshot = await completedBaseRef(id: memberId)
        .completedParentBases
        .doc(completedBasesId)
        .get();
    return docSnapshot.data;
  }

  /// 会員[memberId]の[completedTitleId]に該当する称号獲得情報を取得します。
  Future<TitleHistory?> getCompletedTitle(
      String memberId, String completedTitleId) async {
    final docSnapshot = await completedTitleRef(id: memberId)
        .titleHistories
        .doc(completedTitleId)
        .get();
    return docSnapshot.data;
  }

  /// 会員[memberId]の[completedEventId]に該当する達成済み参加イベントを取得します。
  /// 当該イベントが未達成の場合、nullを返却します。
  Future<ParticipatedEvent?> getCompletedEvent(
      String memberId, String completedEventId) async {
    final docSnapshot = await eventParticipationHistoryRef(id: memberId)
        .participatedEvents
        .doc(completedEventId)
        .get();

    final participatedEvent = docSnapshot.data;
    if (participatedEvent == null || !participatedEvent.isComplete) {
      // イベント未達成
      return null;
    }

    return participatedEvent;
  }

  /// 会員[memberId]のクーポン獲得/使用履歴を取得します。
  Stream<List<CouponHistory>> getCouponHistories(String memberId) {
    return completedCouponRef(id: memberId).couponHistories.snapshots().map(
        (couponHistoryQuerySnap) => couponHistoryQuerySnap.docs
            .map((couponHistoryQueryDocSnap) => couponHistoryQueryDocSnap.data)
            .toList());
  }

  /// 加盟店IDリスト[merchantIds]に該当する加盟店を取得します。
  Stream<List<Merchant>> getMerchantsByIds(List<String> merchantIds) {
    return merchantsRef.orderById().snapshots().map(
          (merchantQuerySnapshot) => merchantQuerySnapshot.docs
              .map(
                (merchantQueryDocSnap) {
                  if (merchantIds.contains(merchantQueryDocSnap.id)) {
                    return merchantQueryDocSnap.data;
                  }
                  return null;
                },
              )
              .whereType<Merchant>()
              .toList(),
        );
  }
}

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../util/logger.dart';
import '../model/repository/authentication_repository.dart';

// LoginViewModelプロバイダ
final loginViewModelProvider = StateNotifierProvider<LoginViewModel, User?>(
  (ref) {
    ref.onDispose(() {
      logger.fine('loginViewModelProvider dispose.');
    });

    return LoginViewModel(
      AuthenticationRepository(),
    );
  },
);

// 認証状態確認プロバイダ
final authStateChangesProvider = StreamProvider.autoDispose<User?>((ref) {
  ref.onDispose(() {
    logger.fine('authStateChangesProvider dispose.');
  });

  return ref.watch(loginViewModelProvider.notifier).isLogin();
});

class LoginViewModel extends StateNotifier<User?> {
  final AuthenticationRepository _userRepository;

  LoginViewModel(this._userRepository) : super(null);

  /// 電話番号でログインします。
  Future<void> loginPhoneNumber({
    required String phoneNumber,
    required AsyncValueGetter smsAuthCode,
    required Function(Exception e) verificationFailed,
  }) async {
    try {
      logger.fine('phoneNumber=$phoneNumber');

      await logout();
      final user = await _userRepository.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        smsAuthCode: smsAuthCode,
        verificationFailed: verificationFailed,
      );
      logger.fine('SMS login successful. user=$user');

      state = user;
    } on Exception catch (e) {
      logger.severe(e);
      state = null;
      rethrow;
    }
  }

  /// 認証状態を確認します。
  /// 認証されていない場合、nullを返却します。
  Stream<User?> isLogin() {
    return _userRepository.isLogin();
  }

  /// ログアウトし状態をクリアします。
  Future<void> logout() async {
    await _userRepository.logout();
    state = null;
  }

  /// Googleアカウントにてログインします。
  Future<void> googleSignIn() async {
    try {
      await logout();
      final user = await _userRepository.googleSignIn();
      logger.fine('Google sign-in successful. user=$user');

      state = user;
    } on Exception catch (e) {
      logger.severe(e);
      state = null;
      rethrow;
    }
  }

  /// Appleアカウントにてログインします。
  Future<void> appleSignIn() async {
    try {
      await logout();
      final user = await _userRepository.appleSignIn();
      logger.fine('Apple sign-in successful. user=$user');

      state = user;
    } on Exception catch (e) {
      logger.severe(e);
      state = null;
      rethrow;
    }
  }

  /// Facebookアカウントにてログインします。
  Future<void> facebookSignIn() async {
    try {
      await logout();
      final user = await _userRepository.facebookSignIn();
      logger.fine('Facebook sign-in successful. user=$user');

      state = user;
    } on Exception catch (e) {
      logger.severe(e);
      state = null;
      rethrow;
    }
  }

  /// Twitterアカウントにてログインします。
  Future<void> twitterSignIn() async {
    try {
      await logout();
      final user = await _userRepository.twitterSignIn();
      logger.fine('Twitter sign-in successful. user=$user');

      state = user;
    } on Exception catch (e) {
      logger.severe(e);
      state = null;
      rethrow;
    }
  }

  /// 認証済みのカレントユーザをリロードします。
  Future<void> currentUserReload() async {
    return await _userRepository.currentUserReload();
  }

  /// 認証済みのカレントユーザの電話番号を返却します。
  String? getPhoneNumber() {
    // 国番号が付与された電話番号
    final phoneNumber = _userRepository.getPhoneNumber();
    if (phoneNumber == null) {
      return null;
    }

    return phoneNumber.replaceFirst('+81', '0');
  }
}

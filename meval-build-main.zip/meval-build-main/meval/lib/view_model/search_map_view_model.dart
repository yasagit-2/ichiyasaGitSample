import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';
import 'package:uuid/uuid.dart';

import '../const/constant.dart';
import '../model/data/admin_alert.dart';
import '../model/data/admin_questionnaire.dart';
import '../model/data/base.dart';
import '../model/data/check_in.dart';
import '../model/data/completed_base.dart';
import '../model/data/map_icon.dart';
import '../model/data/map_information.dart';
import '../model/data/merchant.dart';
import '../model/data/post.dart';
import '../model/data/tweet.dart';
import '../model/repository/map_repository.dart';
import '../provider/location_provider.dart';
import '../provider/settings_provider.dart';
import '../util/logger.dart';
import '../util/show_toast.dart';
import '../util/analytics_util.dart';
import '../view/component/loading_service.dart';
import '../util/analytics_util.dart';
import 'member_view_model.dart';

// SearchMapViewModelプロバイダ
final searchMapViewModelProvider =
    StateNotifierProvider.autoDispose<SearchMapViewModel, MapInformation>(
  (ref) {
    ref.onDispose(() {
      logger.fine('searchMapViewModelProvider dispose.');
    });

    return SearchMapViewModel(
      ref,
      ref.read(mapRepositoryProvider),
    );
  },
);

/// 現在時刻[now]にて、[base]の拠点表示条件の判定を行います。(true:表示、false:非表示)
bool judgeDisplayCondition(Base base, DateTime now) {
  // 期間判定
  final effectivePeriodBegin = base.effectivePeriodBegin;
  final effectivePeriodEnd = base.effectivePeriodEnd;
  if (effectivePeriodBegin != null && effectivePeriodEnd != null) {
    // 有効期間判定(現在日時が「有効期間開始 ≦ 現在日時 ≦ 有効期間終了」ではない場合は非表示)
    if (now.compareTo(effectivePeriodBegin) == -1 ||
        now.compareTo(effectivePeriodEnd) == 1) {
      // 期間判定結果：非表示
      return false;
    }
  }

  // 曜日判定
  final effectiveDaysOfWeek = base.effectiveDaysOfWeek;
  if (effectiveDaysOfWeek != null && effectiveDaysOfWeek.isNotEmpty) {
    // 有効曜日判定
    if (!effectiveDaysOfWeek.contains(now.weekday)) {
      // 曜日判定結果：非表示
      return false;
    }
  }

  // 時刻判定
  final effectiveTimeBegin = base.effectiveTimeBegin;
  final effectiveTimeEnd = base.effectiveTimeEnd;
  if (effectiveTimeBegin != null && effectiveTimeEnd != null) {
    final parsedBegin = Const.hourMinuteFormat.parseStrict(effectiveTimeBegin);
    final parsedEnd = Const.hourMinuteFormat.parseStrict(effectiveTimeEnd);

    final begin = DateTime(
        now.year, now.month, now.day, parsedBegin.hour, parsedBegin.minute);
    final end = DateTime(
        now.year, now.month, now.day, parsedEnd.hour, parsedEnd.minute);

    logger.fine('parsedBegin=$parsedBegin, parsedEnd=$parsedEnd');
    logger.fine('begin=$begin, end=$end');

    // 有効期間判定(現在日時が「有効時刻開始 ≦ 現在日時 ≦ 有効時刻終了」ではない場合は非表示)
    if (now.compareTo(begin) == -1 || now.compareTo(end) == 1) {
      // 時刻判定結果：非表示
      return false;
    }
  }

  return true;
}

class SearchMapViewModel extends StateNotifier<MapInformation> {
  final Ref _ref;
  final MapRepository _mapRepository;

  SearchMapViewModel(this._ref, this._mapRepository)
      : super(
          const MapInformation(),
        );

  /// [location]に投稿準備マーカーを追加します。
  void addPostingPreparationMarker(LatLng location) {
    state = state.copyWith(postingPreparationMarker: {
      Marker(
        markerId: MarkerId(const Uuid().v4()),
        position: location,
        onTap: () {},
      ),
    });
  }

  /// 拠点マーカー/サークルを生成し、状態を更新します。
  Future<void> createBaseMarkers(
    List<DocumentSnapshot> baseDocumentList,
    void Function(String baseName) onSuccessOfCheckInToBase,
    Future<void> Function(String baseName) onSuccessOfCheckInToSubBase,
    void Function(Base base, AsyncCallback checkIn, bool isAvailCheckIn)
        showBaseInformation,
  ) async {
    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider)!;
    // チェックイン情報取得
    final checkInList = await _mapRepository.getCheckInByMemberId(member.id);

    final mapIcon = await _ref.read(mapIconProvider.future);

    // 表示対象拠点のインスタンスを保持するためのMap
    final displayTargetBaseMap = <String, Base>{};

    // 拠点マーカー生成
    final baseMarkers = await _createBaseMarkers(
      member.id,
      baseDocumentList,
      checkInList,
      mapIcon.baseIcon,
      mapIcon.baseCheckedInIcon,
      mapIcon.subBaseIcon,
      onSuccessOfCheckInToBase,
      onSuccessOfCheckInToSubBase,
      showBaseInformation,
      displayTargetBaseMap,
    );

    // 拠点サークル生成
    final baseCircles = await _createBaseCircles(
      checkInList,
      displayTargetBaseMap,
    );

    // 状態更新
    state = state.copyWith(
        bases: baseDocumentList,
        baseMarkers: baseMarkers,
        baseCircles: baseCircles);
  }

  /// 加盟店マーカーを生成し、状態を更新します。
  Future<void> createMerchantMarkers(
    List<DocumentSnapshot> merchantDocList,
    List<Tweet> tweets,
    void Function(Merchant merchant) showMerchantInformation,
  ) async {
    final mapIcon = await _ref.read(mapIconProvider.future);

    final merchantMarkers = (await Future.wait(
      merchantDocList.map(
        (document) async {
          final merchantDocumentSnapshot =
              await merchantRef(id: document.id).get();
          if (!merchantDocumentSnapshot.exists) return null;

          final merchant = merchantDocumentSnapshot.data!;

          // 当該加盟店のつぶやき
          final targetTweet =
              tweets.where((tweet) => tweet.merchantRef.id == merchant.id);
          // つぶやきは加盟店あたり最大一つのみ
          final tweet = targetTweet.isEmpty ? null : targetTweet.first;

          if (tweet != null) {
            return Marker(
              markerId: MarkerId(merchant.id),
              position: LatLng(merchant.position.geopoint.latitude,
                  merchant.position.geopoint.longitude),
              icon: mapIcon.merchantTweetIcon,
              onTap: () => showMerchantInformation(merchant),
            );
          }

          return _createMarker(
            merchant.id,
            mapIcon.merchantIcon,
            merchant.position.geopoint,
            () => showMerchantInformation(merchant),
          );
        },
      ),
    ))
        .whereType<Marker>()
        .toSet();

    // 状態更新
    state = state.copyWith(
      merchants: merchantDocList,
      merchantMarkers: merchantMarkers,
    );
  }

  /// 投稿マーカー（投稿/行政投稿アラート/行政投稿アンケート）を生成し、状態を更新します。
  Future<void> createPostAndAdminMarkers(
    List<DocumentSnapshot>? postDocList,
    List<DocumentSnapshot>? adminAlertDocList,
    List<DocumentSnapshot>? adminQuestionnaireDocList,
    NavigatorState navigator,
    // 投稿アイコンタップ時のコールバック
    Future<void> Function(Ref ref, NavigatorState context, Post post) onTapPost,
    // 行政投稿アラートアイコンタップ時のコールバック
    Future<void> Function(
            Ref ref, NavigatorState context, AdminAlert adminAlert)
        onTapAdminAlert,
    // 行政投稿アンケートアイコンタップ時のコールバック
    Future<void> Function(Ref ref, NavigatorState context,
            AdminQuestionnaire adminQuestionnaire)
        onTapAdminQuestionnaire,
  ) async {
    Set<Marker> postMarkers = state.postMarkers;
    if (postDocList != null) {
      if (postDocList.isEmpty) {
        postMarkers = {};
      } else {
        // 投稿マーカー
        postMarkers =
            await _createPostMarkers(postDocList, navigator, onTapPost);
      }
    }

    final now = await NTP.now();

    Set<Marker> adminAlertMarkers = state.adminAlertMarkers;
    if (adminAlertDocList != null) {
      if (adminAlertDocList.isEmpty) {
        adminAlertMarkers = {};
      } else {
        // 行政投稿アラートマーカー
        adminAlertMarkers = await _createAdminAlertMarkers(
            adminAlertDocList, navigator, onTapAdminAlert, now);
      }
    }

    Set<Marker> adminQuestionnaireMarkers = state.adminQuestionnaireMarkers;
    if (adminQuestionnaireDocList != null) {
      if (adminQuestionnaireDocList.isEmpty) {
        adminQuestionnaireMarkers = {};
      } else {
        // 行政投稿アンケートマーカー
        adminQuestionnaireMarkers = await _createAdminQuestionnaireMarkers(
            adminQuestionnaireDocList, navigator, onTapAdminQuestionnaire, now);
      }
    }

    // 状態更新
    state = state.copyWith(
      posts: postDocList,
      postMarkers: postMarkers,
      adminAlert: adminAlertDocList,
      adminAlertMarkers: adminAlertMarkers,
      adminQuestionnaire: adminQuestionnaireDocList,
      adminQuestionnaireMarkers: adminQuestionnaireMarkers,
    );
  }

  /// 投稿マーカーを生成し、状態を更新します。
  Future<Set<Marker>> _createPostMarkers(
    List<DocumentSnapshot> postDocList,
    NavigatorState navigator,
    Future<void> Function(Ref ref, NavigatorState context, Post post) onTapPost,
  ) async {
    final mapIcon = await _ref.read(mapIconProvider.future);

    final postMarkers = (await Future.wait(
      postDocList.map(
        (document) async {
          final postDocumentSnapshot = await postRef(id: document.id).get();
          if (!postDocumentSnapshot.exists) return null;

          final post = postDocumentSnapshot.data!;

          // いいね数に応じた投稿アイコン
          final postIcon = _getPostIcon(mapIcon, post);

          return _createMarker(
            post.id,
            postIcon,
            post.position.geopoint,
            () async => await onTapPost(_ref, navigator, post),
          );
        },
      ),
    ))
        .whereType<Marker>()
        .toSet();

    return postMarkers;
  }

  /// [post]の[Post.likeCount]に応じた、いいねアイコンを返却します。
  BitmapDescriptor _getPostIcon(MapIcon mapIcon, Post post) {
    final mapPostIcons = mapIcon.mapPostIcons;
    if (mapPostIcons == null || mapPostIcons.isEmpty) {
      return mapIcon.postIcon;
    }

    MapPostIcon? mapPostIcon = mapPostIcons.firstWhereOrNull(
        (mapPostIcon) => post.likeCount <= mapPostIcon.likeCount);

    return mapPostIcon == null
        ? mapIcon.postIcon
        : mapPostIcon.unitOfLikePostIcon;
  }

  /// 行政投稿アラートマーカーを生成し、状態を更新します。
  Future<Set<Marker>> _createAdminAlertMarkers(
    List<DocumentSnapshot> adminAlertDocList,
    NavigatorState navigator,
    Future<void> Function(
            Ref ref, NavigatorState context, AdminAlert adminAlert)
        onTapAdminAlert,
    DateTime now,
  ) async {
    final mapIcon = await _ref.read(mapIconProvider.future);

    final adminAlertMarkers = (await Future.wait(
      adminAlertDocList.map(
        (document) async {
          final adminAlertDocumentSnapshot =
              await adminAlertRef(id: document.id).get();
          if (!adminAlertDocumentSnapshot.exists) return null;

          final adminAlert = adminAlertDocumentSnapshot.data!;

          // 行政投稿アラート期限
          if (now.compareTo(adminAlert.dueDate) > 0) {
            // 期限超過の場合、行政投稿アラートマーカーを生成しない
            return null;
          }

          return _createMarker(
            adminAlert.id,
            mapIcon.adminAlertIcon,
            adminAlert.position.geopoint,
            () async => await onTapAdminAlert(_ref, navigator, adminAlert),
          );
        },
      ),
    ))
        .whereType<Marker>()
        .toSet();

    return adminAlertMarkers;
  }

  /// 行政投稿アンケートマーカーを生成し、状態を更新します。
  Future<Set<Marker>> _createAdminQuestionnaireMarkers(
    List<DocumentSnapshot<Object?>> adminQuestionnaireDocList,
    NavigatorState navigator,
    Future<void> Function(Ref ref, NavigatorState context,
            AdminQuestionnaire adminQuestionnaire)
        onTapAdminQuestionnaire,
    DateTime now,
  ) async {
    final mapIcon = await _ref.read(mapIconProvider.future);

    final adminQuestionnaireMarkers = (await Future.wait(
      adminQuestionnaireDocList.map(
        (document) async {
          final adminQuestionnaireDocumentSnapshot =
              await adminQuestionnaireRef(id: document.id).get();
          if (!adminQuestionnaireDocumentSnapshot.exists) return null;

          final adminQuestionnaire = adminQuestionnaireDocumentSnapshot.data!;

          // 行政投稿アンケート期限
          if (now.compareTo(adminQuestionnaire.dueDate) > 0) {
            // 期限超過の場合、行政投稿アンケートマーカーを生成しない
            return null;
          }

          return _createMarker(
            adminQuestionnaire.id,
            mapIcon.adminQuestionnaireIcon,
            adminQuestionnaire.position.geopoint,
            () async => await onTapAdminQuestionnaire(
                _ref, navigator, adminQuestionnaire),
          );
        },
      ),
    ))
        .whereType<Marker>()
        .toSet();

    return adminQuestionnaireMarkers;
  }

  /// 拠点マーカーを生成し返却します。
  Future<Set<Marker>> _createBaseMarkers(
    String memberId,
    List<DocumentSnapshot>? baseDocumentList,
    List<CheckIn> checkInList,
    BitmapDescriptor baseIcon,
    BitmapDescriptor baseCheckedInIcon,
    BitmapDescriptor subBaseIcon,
    void Function(String baseName) onSuccessOfCheckInToBase,
    Future<void> Function(String baseName) onSuccessOfCheckInToSubBase,
    void Function(Base base, AsyncCallback checkIn, bool isAvailCheckIn)
        showBaseInformation,
    // 表示対象拠点のインスタンスを保持するためのMap
    Map<String, Base> displayTargetBaseMap,
  ) async {
    if (baseDocumentList == null) return {};

    final now = await NTP.now();

    return (await Future.wait(
      baseDocumentList.map(
        (document) async {
          final baseDocumentSnapshot = await baseRef(id: document.id).get();
          if (!baseDocumentSnapshot.exists) return null;

          final base = baseDocumentSnapshot.data!;

          final geopoint = base.position.geopoint;
          final parent = base.parentRef;

          // 拠点表示条件(key:親拠点ID, value:拠点表示条件判定結果(true:表示、false:非表示))
          final judgedDisplayConditionMap = <String, bool>{};

          if (parent == null) {
            // 親拠点(サブ拠点ではない)場合

            if (!judgedDisplayConditionMap.containsKey(base.id)) {
              // 拠点表示条件判定
              final judgeResult = judgeDisplayCondition(base, now);
              judgedDisplayConditionMap.putIfAbsent(base.id, () => judgeResult);
            }

            // 判定結果非表示の場合はマーカー生成しない
            if (!judgedDisplayConditionMap[base.id]!) {
              logger.fine('hidden baseId=${base.id}');
              return null;
            }

            // 表示対象拠点を保持
            displayTargetBaseMap[base.id] = base;

            if (_isCheckedIn(base.id, checkInList)) {
              // チェックイン済み拠点の場合
              return _createMarker(
                base.id,
                baseCheckedInIcon,
                geopoint,
                () => showBaseInformation(
                  base,
                  () async => await _ref
                      .read(loadingServiceProvider.notifier)
                      .wrap(checkIn(
                        base,
                        memberId,
                        () => onSuccessOfCheckInToBase(base.name),
                      )),
                  // チェックイン済みのためチェックイン不可
                  false,
                ),
              );
            } else {
              // チェックイン未済拠点の場合

              // チェックイン可否判定
              final isAvailCheckIn = await checkInAvailability(
                  _ref, LatLng(geopoint.latitude, geopoint.longitude));

              return _createMarker(
                base.id,
                baseIcon,
                geopoint,
                () => showBaseInformation(
                  base,
                  () async =>
                      await _ref.read(loadingServiceProvider.notifier).wrap(
                            checkIn(base, memberId,
                                () => onSuccessOfCheckInToBase(base.name)),
                          ),
                  isAvailCheckIn,
                ),
              );
            }
          } else {
            // サブ拠点の場合

            if (!judgedDisplayConditionMap.containsKey(parent.id)) {
              final parentBaseDocSnapshot = await baseRef(id: parent.id).get();

              // 親拠点が存在しない場合はマーカー生成しない
              if (!parentBaseDocSnapshot.exists) return null;
              final parentBase = parentBaseDocSnapshot.data!;

              // 親拠点の拠点表示条件判定
              final judgeResult = judgeDisplayCondition(parentBase, now);
              judgedDisplayConditionMap.putIfAbsent(
                  parent.id, () => judgeResult);
            }

            // 親拠点の判定結果が非表示の場合、サブ拠点のマーカーも生成しない
            if (!judgedDisplayConditionMap[parent.id]!) {
              logger.fine('hidden subBaseId=${base.id}');
              return null;
            }

            // 親拠点がCOMPLETE済みの場合、サブ拠点マーカーを生成しない
            final completedParentBaseDocSnapshot =
                await completedBaseRef(id: memberId)
                    .completedParentBases
                    .doc(parent.id)
                    .get();
            if (completedParentBaseDocSnapshot.exists) {
              logger.fine(
                  'Parent base is completed. Hidden subBaseId=${base.id}');
              return null;
            }

            // 表示対象拠点を保持
            displayTargetBaseMap[base.id] = base;

            // チェックイン済みのサブ拠点は非表示
            if (!_isCheckedIn(base.id, checkInList)) {
              // 親の拠点ID
              logger.fine('subBaseId=${base.id}, parentBaseId=${parent.id}');

              // チェックイン可否判定
              final isAvailCheckIn = await checkInAvailability(
                  _ref, LatLng(geopoint.latitude, geopoint.longitude));

              if (_isCheckedIn(parent.id, checkInList)) {
                // 親拠点がチェックイン済みの場合、サブ拠点のマーカーを生成する
                return _createMarker(
                  base.id,
                  subBaseIcon,
                  geopoint,
                  isAvailCheckIn
                      ? () async => await _ref
                          .read(loadingServiceProvider.notifier)
                          .wrap(checkIn(base, memberId,
                              () => onSuccessOfCheckInToSubBase(base.name)))
                      // チェックイン不可の場合は何もしない
                      : () {},
                );
              }
            }
          }
        },
      ),
    ))
        .whereType<Marker>()
        .toSet();
  }

  /// [baseId]がチェックイン済み([baseId]が[checkInList]のパスに存在する)場合はtrueを返却します。
  bool _isCheckedIn(String baseId, List<CheckIn> checkInList) {
    // チェックイン済み拠点のリスト(拠点Referenceパスのリスト)
    final basePathList = checkInList.map((e) => e.baseRef.path).toList();
    // チェックイン済み(拠点IDが拠点Referenceパスのリストに存在する)
    return basePathList.any((path) => path.contains(baseId));
  }

  /// Markerインスタンスを生成します。
  Marker _createMarker(String markerId, BitmapDescriptor icon, GeoPoint point,
      VoidCallback? onTap) {
    return Marker(
      markerId: MarkerId(markerId),
      position: LatLng(point.latitude, point.longitude),
      icon: icon,
      onTap: onTap,
    );
  }

  /// 拠点サークルを生成します。
  Future<Set<Circle>> _createBaseCircles(
    List<CheckIn> checkInList,
    Map<String, Base> displayTargetBaseMap,
  ) async {
    if (displayTargetBaseMap.isEmpty) return {};

    return displayTargetBaseMap.values
        .map((base) {
          final parent = base.parentRef;

          if (parent == null) {
            // 拠点(サブ拠点ではない)場合

            if (!_isCheckedIn(base.id, checkInList)) {
              // チェックイン未済拠点の場合
              return _createCircle(base.id,
                  Colors.red.shade100.withOpacity(0.5), base.position.geopoint);
            }
          } else {
            // サブ拠点の場合

            // チェックイン済みのサブ拠点は非表示
            if (!_isCheckedIn(base.id, checkInList)) {
              if (_isCheckedIn(parent.id, checkInList)) {
                // 親拠点がチェックイン済みの場合、サブ拠点のサークルを生成する
                return _createCircle(
                    base.id,
                    Colors.green.shade100.withOpacity(0.5),
                    base.position.geopoint);
              }
            }
          }
        })
        .whereType<Circle>()
        .toSet();
  }

  /// Circleインスタンスを生成します。
  Circle _createCircle(String circleId, Color fillColor, GeoPoint point) {
    final checkInRadius = _ref.read(checkInRadiusProvider);

    return Circle(
      circleId: CircleId(circleId),
      center: LatLng(point.latitude, point.longitude),
      radius: checkInRadius.toDouble(),
      fillColor: fillColor,
      strokeWidth: 0,
    );
  }

  /// [baseId]の拠点についてチェックイン処理を行います。
  /// チェックイン情報登録後に[onSuccessOfCheckInToBase]を呼び出します。
  Future<void> checkIn(
    Base base,
    String memberId,
    VoidCallback onSuccessOfCheckInToBase,
  ) async {
    const failureMessage = 'チェックインできませんでした';

    // チェックインがタップされた際の拠点情報を再取得
    final currentBase = await _mapRepository.getBaseByIdFuture(base.id);
    if (currentBase == null) {
      // 拠点が存在しないため、チェックイン不可（公開ステータスが"公開済み"でない場合も含む）
      showErrorToast(failureMessage);
      return;
    }

    // チェックインタップ時の現在時刻
    final whenTapped = await NTP.now();
    // 拠点表示条件判定
    final judgeResult = judgeDisplayCondition(currentBase, whenTapped);
    if (!judgeResult) {
      // 拠点非表示のため、チェックイン不可
      showErrorToast(failureMessage);
      return;
    }

    // 親拠点のReferenceが存在しない場合は親拠点
    final isParent = base.parentRef == null;

    // チェックイン情報登録
    final checkIn = await _mapRepository.checkIn(base.id, memberId, isParent);
    if (checkIn == null) {
      // チェックイン情報保存不可
      showErrorToast(failureMessage);
      return;
    }

    // チェックインイベント出力
    await AnalyticsUtil.checkIn(base);

    // チェックイン成功時の処理
    onSuccessOfCheckInToBase();
  }

  /// 拠点[base]に対して、チェックイン可否を判定します。
  /// true:チェックイン可能
  Future<bool> baseCheckInAvailability(Base base) async {
    final memberId = _ref.read(memberIdProvider);
    if (memberId == null) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    // チェックインリスト
    final checkInList = await _mapRepository.getCheckInByMemberId(memberId);

    final isCheckedIn = _isCheckedIn(base.id, checkInList);
    if (isCheckedIn) {
      // チェックイン済みのためチェックイン不可
      return false;
    }

    final geopoint = base.position.geopoint;
    return await checkInAvailability(
        _ref, LatLng(geopoint.latitude, geopoint.longitude));
  }
}

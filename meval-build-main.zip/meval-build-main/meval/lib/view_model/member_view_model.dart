import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/member.dart';
import '../model/data/withdrawal.dart';
import '../model/repository/member_repository.dart';
import '../provider/authentication_type_provider.dart';
import '../provider/device_info_provider.dart';
import '../util/logger.dart';

// MemberViewModelプロバイダ
final memberViewModelProvider = StateNotifierProvider<MemberViewModel, Member?>(
  (ref) {
    ref.onDispose(() {
      logger.fine('memberViewModelProvider dispose.');
    });
    return MemberViewModel(
      ref,
      ref.read(memberRepositoryProvider),
    );
  },
);

// 認証済みユーザの会員情報を取得するプロバイダ
final currentMemberFutureProvider = FutureProvider.autoDispose<Member?>((ref) {
  ref.onDispose(() {
    logger.fine('currentMemberFutureProvider dispose.');
  });

  return ref.watch(memberViewModelProvider.notifier).getCurrentMember();
});

// 会員情報ストリームプロバイダ
final memberStreamProvider = StreamProvider.autoDispose<Member?>((ref) {
  ref.onDispose(() {
    logger.fine('memberStreamProvider dispose.');
  });

  return ref.watch(memberViewModelProvider.notifier).getMember();
});

// 会員IDプロバイダ
final memberIdProvider = Provider.autoDispose<String?>((ref) {
  ref.onDispose(() {
    logger.fine('memberIdProvider dispose.');
  });

  return ref.watch(memberViewModelProvider.notifier).getMemberId();
});

// 会員の投稿日時ストリームプロバイダ（会員の投稿日時を監視するプロバイダ）
final memberPostedAtStreamProvider =
    StreamProvider.autoDispose<DateTime?>((ref) {
  ref.onDispose(() {
    logger.fine('memberPostedAtStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(memberViewModelProvider.notifier)._getPostedAt(memberId);
});

// 会員の行政報告日時ストリームプロバイダ（会員の行政報告日時を監視するプロバイダ）
final memberReportedAtStreamProvider =
    StreamProvider.autoDispose<DateTime?>((ref) {
  ref.onDispose(() {
    logger.fine('memberReportedAtStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(memberViewModelProvider.notifier)._getReportedAt(memberId);
});

// 会員のコメント日時ストリームプロバイダ（会員のコメント日時を監視するプロバイダ）
final memberCommentedAtStreamProvider =
    StreamProvider.autoDispose<DateTime?>((ref) {
  ref.onDispose(() {
    logger.fine('memberCommentedAtStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(memberViewModelProvider.notifier)._getCommentedAt(memberId);
});

// 会員の退会申請ストリームプロバイダ
final withdrawalStreamProvider = StreamProvider.autoDispose<Withdrawal?>((ref) {
  ref.onDispose(() {
    logger.fine('withdrawalStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(memberViewModelProvider.notifier)._getWithdrawal(memberId);
});

class MemberViewModel extends StateNotifier<Member?> {
  final Ref _ref;
  final MemberRepository _memberRepository;

  MemberViewModel(this._ref, this._memberRepository) : super(null);

  /// 認証済みユーザの会員情報を取得し、状態を更新します。
  Future<Member?> getCurrentMember() async {
    state = await _memberRepository.getCurrentMember();
    return state;
  }

  /// 会員登録を行います。
  Future<void> register({
    required String nickname,
    required String gender,
    required DateTime monthOfBirth,
    required String prefecture,
    required String name,
    required String mailAddress,
    required AuthenticationType authenticationProvider,
  }) async {
    // デバイス情報
    final deviceInfo = _ref.read(deviceInfoProvider);

    await _memberRepository.register(
      nickname: nickname,
      gender: gender,
      monthOfBirth: monthOfBirth,
      prefecture: prefecture,
      name: name,
      mailAddress: mailAddress,
      authenticationProvider: authenticationProvider,
      deviceInfo: deviceInfo,
    );

    // 会員情報を取得し、状態を更新
    await getCurrentMember();
  }

  /// 会員情報を削除します。
  Future<void> remove() async {
    if (state == null) return;
    return await _memberRepository.remove(memberId: state!.id);
  }

  /// 会員情報を更新します。
  Future<void> updateMember({
    required String nickname,
    required String gender,
    required DateTime monthOfBirth,
    required String prefecture,
    required String name,
    required String mailAddress,
  }) async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    await _memberRepository.updateMember(
        memberId: state!.id,
        nickname: nickname,
        gender: gender,
        monthOfBirth: monthOfBirth,
        prefecture: prefecture,
        name: name,
        mailAddress: mailAddress);

    // 会員情報を再取得
    await getCurrentMember();
  }

  /// 会員情報（Stream）を取得します。
  /// ログイン中の会員が存在しない場合、このメソッドは使用できません。
  Stream<Member?> getMember() {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _memberRepository.getMember(state!.id);
  }

  /// ログイン中会員のデバイス情報を更新します。
  /// 既存のデバイス情報が存在しない場合、または既存のデバイス情報と変更がない場合は処理しません。
  Future<void> updateDeviceInfo() async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    final privateProfile = await _memberRepository.getPrivateProfile(state!.id);
    if (privateProfile == null) {
      return;
    }

    // デバイス情報
    final deviceInfo = _ref.read(deviceInfoProvider);

    logger.fine('deviceInfo=$deviceInfo');

    if (privateProfile.deviceInfo == deviceInfo) {
      // デバイス情報変更なし
      logger.fine('Device information unchanged.');
      return;
    }

    // デバイス情報更新
    await _memberRepository.updateDeviceInfo(state!.id, deviceInfo);
  }

  /// ログイン中会員の会員IDを返却します。
  /// 状態が存在しない場合、nullを返却します。
  String? getMemberId() {
    if (state == null || state!.id.isEmpty) {
      return null;
    }

    return state!.id;
  }

  /// ログイン中会員の退会申請を行います。
  Future<void> createWithdrawal() async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    // 退会申請
    await _memberRepository.createWithdrawal(state!.id);
  }

  /// ログイン中会員の退会申請をキャンセルします。
  Future<void> cancelWithdrawal() async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    // 退会申請キャンセル
    await _memberRepository.cancelWithdrawal(state!.id);
  }

  /// 会員[memberId]の投稿日時(Stream)を返却します。
  Stream<DateTime?> _getPostedAt(String memberId) {
    return _memberRepository.getPostedAt(memberId);
  }

  /// 会員[memberId]の行政報告日時(Stream)を返却します。
  Stream<DateTime?> _getReportedAt(String memberId) {
    return _memberRepository.getReportedAt(memberId);
  }

  /// 会員[memberId]のコメント日時(Stream)を返却します。
  Stream<DateTime?> _getCommentedAt(String memberId) {
    return _memberRepository.getCommentedAt(memberId);
  }

  /// 会員[memberId]の退会申請(Stream)を返却します。
  Stream<Withdrawal?> _getWithdrawal(String memberId) {
    return _memberRepository.getWithdrawal(memberId);
  }
}

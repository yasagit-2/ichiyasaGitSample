import 'dart:io';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/admin_alert.dart';
import '../model/data/admin_questionnaire.dart';
import '../model/data/answered_questionnaire.dart';
import '../model/data/comment.dart';
import '../model/data/like.dart';
import '../model/data/member.dart';
import '../model/data/post.dart';
import '../model/data/report.dart';
import '../model/repository/post_repository.dart';
import '../provider/geoflutterfire_provider.dart';
import '../util/logger.dart';
import 'member_view_model.dart';

// PostViewModelプロバイダ
final postViewModelProvider = StateNotifierProvider<PostViewModel, Post?>(
  (ref) => PostViewModel(
    ref,
    ref.read(postRepositoryProvider),
  ),
);

// 投稿ストリームプロバイダ
final postByIdStreamProvider = StreamProvider.autoDispose<Post?>((ref) {
  ref.onDispose(() {
    logger.fine('postByIdStreamProvider dispose.');
  });

  return ref.read(postViewModelProvider.notifier).getPostById();
});

// コメントストリームプロバイダ
final commentListStreamProvider =
    StreamProvider.autoDispose<List<Comment>>((ref) {
  ref.onDispose(() {
    logger.fine('commentListStreamProvider dispose.');
  });

  return ref.read(postViewModelProvider.notifier).getCommentsByPostId();
});

// 投稿会員プロバイダ
final postMemberProvider = FutureProvider.autoDispose<Member?>((ref) {
  ref.onDispose(() {
    logger.fine('postMemberProvider dispose.');
  });

  return ref.watch(postViewModelProvider.notifier).getPostMember();
});

// いいねストリームプロバイダ（パラメータで指定された投稿における自身のいいねを監視するプロバイダ）
final likeStreamProvider =
    StreamProvider.family.autoDispose<Like?, String>((ref, String postId) {
  ref.onDispose(() {
    logger.fine('likeStreamProvider dispose.');
  });

  return ref.read(postViewModelProvider.notifier).getLike(postId);
});

// 行政投稿（注意）ストリームプロバイダ（パラメータで指定された行政投稿を監視するプロバイダ）
final adminAlertByIdStreamProvider = StreamProvider.family
    .autoDispose<AdminAlert?, String>((ref, String adminAlertId) {
  ref.onDispose(() {
    logger.fine('adminAlertByIdStreamProvider dispose.');
  });

  return ref
      .read(postViewModelProvider.notifier)
      ._getAdminAlertById(adminAlertId);
});

// 行政投稿（アンケート）ストリームプロバイダ（パラメータで指定された行政投稿を監視するプロバイダ）
final adminQuestionnaireByIdStreamProvider = StreamProvider.family
    .autoDispose<AdminQuestionnaire?, String>(
        (ref, String adminQuestionnaireId) {
  ref.onDispose(() {
    logger.fine('adminQuestionnaireByIdStreamProvider dispose.');
  });

  return ref
      .read(postViewModelProvider.notifier)
      ._getAdminQuestionnaireById(adminQuestionnaireId);
});

// 行政投稿（アンケート）の選択肢ストリームプロバイダ（パラメータで指定されたアンケートの選択肢を監視するプロバイダ）
final choiceByAdminQuestionnaireIdStreamProvider = StreamProvider.family
    .autoDispose<List<Choice>, String>((ref, String adminQuestionnaireId) {
  ref.onDispose(() {
    logger.fine('choiceByAdminQuestionnaireIdStreamProvider dispose.');
  });

  return ref
      .read(postViewModelProvider.notifier)
      ._getChoiceByAdminQuestionnaireId(adminQuestionnaireId);
});

// アンケート回答履歴ストリームプロバイダ（パラメータで指定されたアンケートの回答履歴を監視するプロバイダ）
final questionnaireHistoryByIdStreamProvider = StreamProvider.family
    .autoDispose<QuestionnaireHistory?, String>(
        (ref, String adminQuestionnaireId) {
  ref.onDispose(() {
    logger.fine('questionnaireHistoryByIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .read(postViewModelProvider.notifier)
      ._getQuestionnaireHistoryById(memberId, adminQuestionnaireId);
});

// 通報ストリームプロバイダ
final postingAlertExistsStreamProvider =
    StreamProvider.family.autoDispose<bool, String>((ref, String postId) {
  ref.onDispose(() {
    logger.fine('postingAlertStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .read(postViewModelProvider.notifier)
      ._getPostingAlertExistsById(memberId, postId);
});

/// 使用中(画面表示中)の投稿([Post])を状態として保持します。
class PostViewModel extends StateNotifier<Post?> {
  final Ref _ref;
  final PostRepository _postRepository;

  PostViewModel(this._ref, this._postRepository) : super(null);

  /// 投稿を行います。
  Future<Post?> post(String memberId, DateTime postedAt, String message,
      LatLng position, File? imageFile) async {
    return await _postRepository.post(_ref.read(geoflutterfireProvider),
        memberId, postedAt, message, position, imageFile);
  }

  /// 行政報告を行います。
  Future<Report?> report(String memberId, DateTime reportedAt, String message,
      LatLng position, File? imageFile) async {
    return await _postRepository.report(_ref.read(geoflutterfireProvider),
        memberId, reportedAt, message, position, imageFile);
  }

  /// [postId]の投稿に対するいいね情報を保存します。
  /// ログイン中の会員が存在しない場合、このメソッドは使用できません。
  Future<void> like(String postId) async {
    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider);
    if (member == null) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return await _postRepository.like(postId, member.id);
  }

  /// [postId]および[memberId]に該当するいいね情報を取得します。
  /// ログイン中の会員が存在しない場合、このメソッドは使用できません。
  Stream<Like?> getLike(String postId) {
    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider);
    if (member == null) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.getLike(postId, member.id);
  }

  /// [likeId]に該当するいいね情報を削除します。
  Future<void> deleteLike(String likeId, String postId) async {
    return await _postRepository.deleteLike(likeId, postId);
  }

  /// 投稿者の情報を返却します。
  /// 会員が存在しない場合、nullを返却します。
  /// 状態管理中の投稿が存在しない場合、このメソッドは使用できません。
  Future<Member?> getPostMember() async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.getPostMember(state!);
  }

  /// コメントを行います。
  /// 状態管理中の投稿が存在しない場合、このメソッドは使用できません。
  Future<Comment?> comment(String message) async {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider)!;

    return await _postRepository.comment(state!.id, member.id, message);
  }

  /// 状態管理中の投稿([Post](Stream))を取得します。
  /// 状態管理中の投稿が存在しない場合、このメソッドは使用できません。
  Stream<Post?> getPostById() {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.getPostById(state!.id);
  }

  /// 状態管理中の投稿([Post])のコメント(Stream)を取得します。
  /// 状態管理中の投稿が存在しない場合、このメソッドは使用できません。
  Stream<List<Comment>> getCommentsByPostId() {
    if (state == null || state!.id.isEmpty) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.getCommentsByPostId(state!.id);
  }

  /// [post]へ状態を更新します。
  void update(Post post) {
    state = post;
  }

  /// 投稿[post]を削除します。
  Future<void> deletePost(Post post) async {
    return _postRepository.deletePost(post);
  }

  /// 投稿[post]を通報します。
  /// ログイン中の会員が存在しない場合、このメソッドは使用できません。
  Future<void> alertPost(Post post) async {
    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider);
    if (member == null) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.alertPost(member.id, post);
  }

  /// [adminAlertId]の行政投稿（注意）(Stream)を取得します。
  Stream<AdminAlert?> _getAdminAlertById(String adminAlertId) {
    return _postRepository.getAdminAlertById(adminAlertId);
  }

  /// [adminQuestionnaireId]の行政投稿（アンケート）(Stream)を取得します。
  Stream<AdminQuestionnaire?> _getAdminQuestionnaireById(
      String adminQuestionnaireId) {
    return _postRepository.getAdminQuestionnaireById(adminQuestionnaireId);
  }

  /// [adminQuestionnaireId]の行政投稿（アンケート）の選択肢(Stream)を取得します。
  Stream<List<Choice>> _getChoiceByAdminQuestionnaireId(
      String adminQuestionnaireId) {
    return _postRepository
        .getChoiceByAdminQuestionnaireId(adminQuestionnaireId);
  }

  /// 会員[memberId]における[adminQuestionnaireId]のアンケート回答履歴を取得します。
  Stream<QuestionnaireHistory?> _getQuestionnaireHistoryById(
      String memberId, String adminQuestionnaireId) {
    return _postRepository.getQuestionnaireHistoryById(
        memberId, adminQuestionnaireId);
  }

  /// アンケート回答情報を保存します。
  /// ログイン中の会員が存在しない場合、このメソッドは使用できません。
  Future<void> answerQuestionnaire(
      String adminQuestionnaireId, String selectedChoiceId) async {
    // ログイン中の会員情報
    final member = _ref.read(memberViewModelProvider);
    if (member == null) {
      throw UnsupportedError('この操作は許可されていません。');
    }

    return _postRepository.answerQuestionnaire(
        member.id, adminQuestionnaireId, selectedChoiceId);
  }

  /// 会員[memberId]のニックネームを取得します。
  Future<String?> getMemberNickname(String memberId) {
    return _postRepository.getMemberNickname(memberId);
  }

  /// [postId]に対する自身の通報の存在有無を取得します。
  Stream<bool> _getPostingAlertExistsById(String memberId, String postId) {
    final postingAlertId = '${postId}_$memberId';

    return _postRepository.getPostingAlertExistsById(postingAlertId);
  }
}

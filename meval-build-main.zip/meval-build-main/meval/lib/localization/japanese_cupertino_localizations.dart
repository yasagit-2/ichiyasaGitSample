import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

class _CupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const _CupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ja';

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      JapaneseCupertinoLocalizations.load(locale);

  @override
  bool shouldReload(_CupertinoLocalizationDelegate old) => false;

  @override
  String toString() => 'DefaultCupertinoLocalizations.delegate(ja_JP)';
}

class JapaneseCupertinoLocalizations implements CupertinoLocalizations {
  const JapaneseCupertinoLocalizations();

  static const List<String> _months = <String>[
    '1月',
    '2月',
    '3月',
    '4月',
    '5月',
    '6月',
    '7月',
    '8月',
    '9月',
    '10月',
    '11月',
    '12月',
  ];

  @override
  String datePickerYear(int yearIndex) => '$yearIndex年';

  @override
  String datePickerMonth(int monthIndex) => _months[monthIndex - 1];

  @override
  String datePickerDayOfMonth(int dayIndex) => '$dayIndex日';

  @override
  String datePickerHour(int hour) => throw UnimplementedError();

  @override
  String datePickerHourSemanticsLabel(int hour) => throw UnimplementedError();

  @override
  String datePickerMinute(int minute) => throw UnimplementedError();

  @override
  String datePickerMinuteSemanticsLabel(int minute) =>
      throw UnimplementedError();

  @override
  String datePickerMediumDate(DateTime date) => throw UnimplementedError();

  @override
  DatePickerDateOrder get datePickerDateOrder => DatePickerDateOrder.ymd;

  @override
  DatePickerDateTimeOrder get datePickerDateTimeOrder =>
      throw UnimplementedError();

  @override
  String get anteMeridiemAbbreviation => throw UnimplementedError();

  @override
  String get postMeridiemAbbreviation => throw UnimplementedError();

  @override
  String get alertDialogLabel => throw UnimplementedError();

  @override
  String timerPickerHour(int hour) => throw UnimplementedError();

  @override
  String timerPickerMinute(int minute) => throw UnimplementedError();

  @override
  String timerPickerSecond(int second) => throw UnimplementedError();

  @override
  String timerPickerHourLabel(int hour) => throw UnimplementedError();

  @override
  String timerPickerMinuteLabel(int minute) => throw UnimplementedError();

  @override
  String timerPickerSecondLabel(int second) => throw UnimplementedError();

  @override
  String get cutButtonLabel => throw UnimplementedError();

  @override
  String get copyButtonLabel => throw UnimplementedError();

  @override
  String get pasteButtonLabel => throw UnimplementedError();

  @override
  String get selectAllButtonLabel => throw UnimplementedError();

  @override
  String get todayLabel => throw UnimplementedError();

  static Future<CupertinoLocalizations> load(Locale locale) {
    return SynchronousFuture<CupertinoLocalizations>(
        const JapaneseCupertinoLocalizations());
  }

  static const LocalizationsDelegate<CupertinoLocalizations> delegate =
      _CupertinoLocalizationDelegate();

  @override
  String get modalBarrierDismissLabel => throw UnimplementedError();

  @override
  String get searchTextFieldPlaceholderLabel => throw UnimplementedError();

  @override
  String tabSemanticsLabel({required int tabIndex, required int tabCount}) {
    throw UnimplementedError();
  }

  @override
  List<String> get timerPickerHourLabels => throw UnimplementedError();

  @override
  List<String> get timerPickerMinuteLabels => throw UnimplementedError();

  @override
  List<String> get timerPickerSecondLabels => throw UnimplementedError();
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';

import '../provider/location_provider.dart';
import '../model/data/member.dart';
import '../model/data/base.dart';
import '../model/data/post.dart';
import '../model/data/comment.dart';
import '../model/data/report.dart';

class AnalyticsUtil {
  static const _eventNamePrefix = 'meval_';
  static Member? _member = null;

  // ログイン
  static Future<void> login(WidgetRef ref, Member member) async {
    // ログインユーザー情報を保持
    _member = member;

    // イベント名
    const eventName = '${_eventNamePrefix}login';
    // パラメーター作成
    var eventParam = _makeCommonParam(member);
    eventParam.addAll(await _makeCurrentLocation(ref));

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // 拠点表示
  static Future<void> viewBase(WidgetRef ref, Base base) async {
    // イベント名
    const eventName = '${_eventNamePrefix}view_base';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(await _makeCurrentLocation(ref));
    eventParam.addAll(_fromGetPoint('拠点', base.position.geopoint));
    eventParam.addAll({
      '拠点ID': base.id,
      '拠点名': base.name,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // チェックイン
  static Future<void> checkIn(Base base) async {
    // イベント名
    const eventName = '${_eventNamePrefix}checkin';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(_fromGetPoint('拠点', base.position.geopoint));
    eventParam.addAll({
      '拠点ID': base.id,
      '拠点名': base.name,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // ユーザー投稿表示
  static Future<void> viewPost(WidgetRef ref, Post post) async {
    // イベント名
    const eventName = '${_eventNamePrefix}view_post';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(await _makeCurrentLocation(ref));
    eventParam.addAll(_fromGetPoint('投稿', post.position.geopoint));
    eventParam.addAll({
      '投稿ID': post.id,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // ユーザー投稿
  static Future<void> post(WidgetRef ref, Post? post) async {
    if (post == null) {
      return;
    }

    // イベント名
    const eventName = '${_eventNamePrefix}post';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(await _makeCurrentLocation(ref));
    eventParam.addAll(_fromGetPoint('投稿', post.position.geopoint));
    eventParam.addAll({
      '投稿ID': post.id,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // コメント投稿
  static Future<void> comment(
      WidgetRef ref, Post post, Comment? commnet) async {
    if (commnet == null) {
      return;
    }

    // イベント名
    const eventName = '${_eventNamePrefix}comment';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(await _makeCurrentLocation(ref));
    eventParam.addAll(_fromGetPoint('投稿', post.position.geopoint));
    eventParam.addAll({
      'コメントID': commnet.id,
      '投稿ID': post.id,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  // 行政報告
  static Future<void> report(WidgetRef ref, Report? report) async {
    if (report == null) {
      return;
    }

    // イベント名
    const eventName = '${_eventNamePrefix}report';
    // パラメーター作成
    var eventParam = _makeCommonParam(_member);
    eventParam.addAll(await _makeCurrentLocation(ref));
    eventParam.addAll(_fromGetPoint('行政報告', report.position.geopoint));
    eventParam.addAll({
      '行政報告ID': report.id,
    });

    // イベント発行
    return await _fireEvent(eventName, eventParam);
  }

  //=========================================================================
  // 内部関数
  //=========================================================================

  // 共通パラメーター作成
  static Map<String, dynamic> _makeCommonParam(Member? member) {
    final now = DateTime.now();
    return {
      '時刻': DateFormat('yyyy/MM/dd HH:mm:ss').format(now),
      'ユーザー情報_ID': member?.id,
      'ユーザー情報_ニックネーム': member?.nickname,
      'ユーザー情報_性別': member?.gender,
      'ユーザー情報_居住地': member?.prefecture,
      'ユーザー情報_生年月': (null == member
          ? "不明"
          : DateFormat('yyyy/MM').format(member.monthOfBirth)),
      'ユーザー情報_年代': (null == member
          ? "不明"
          : '${((((now.year * 100 + now.month) - (member.monthOfBirth.year * 100 + member.monthOfBirth.month)) / 1000).floor() * 10)}代'),
    };
  }

  // ユーザー現在地パラメーター作成
  static Future<Map<String, dynamic>> _makeCurrentLocation(
      WidgetRef ref) async {
    if (ref.watch(permissionProvider)) {
      final currentPosition = await ref.watch(currentLocationProvider.future);
      if (currentPosition != null) {
        return {
          'ユーザー情報_現在地':
              '${currentPosition.latitude}, ${currentPosition.longitude}',
          'ユーザー情報_緯度': currentPosition.latitude,
          'ユーザー情報_経度': currentPosition.longitude
        };
      }
    }
    return {
      'ユーザー情報_現在地': '不明',
      'ユーザー情報_緯度': '不明',
      'ユーザー情報_経度': '不明',
    };
  }

  // GetPointからパラメーター作成
  static Map<String, dynamic> _fromGetPoint(String prefix, GeoPoint? geopoint) {
    if (geopoint != null) {
      return {
        '${prefix}位置': '${geopoint.latitude}, ${geopoint.longitude}',
        '${prefix}緯度': geopoint.latitude,
        '${prefix}経度': geopoint.longitude
      };
    } else {
      return {
        '${prefix}位置': '不明',
        '${prefix}緯度': '不明',
        '${prefix}経度': '不明',
      };
    }
  }

  // Analyticsイベント発行
  static Future<void> _fireEvent(
      String eventName, Map<String, Object?>? eventParam) {
    final FirebaseAnalytics analytics = FirebaseAnalytics.instance;
    return analytics.logEvent(name: eventName, parameters: eventParam);
  }
}

import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'logger.dart';

/// [path]から画像を読み込み、[BitmapDescriptor]へ変換します。
Future<BitmapDescriptor> createBitmapDescriptorFromLocal(
    {required String path, int? height, int? width}) async {
  logger.fine('createBitmapDescriptorFromLocal $path');

  final uintData = await _imageChangeUint8List(path, height, width);
  return BitmapDescriptor.fromBytes(uintData);
}

/// [path]から画像を読み込み、[Uint8List]へ変換します。
Future<Uint8List> _imageChangeUint8List(
    String path, int? height, int? width) async {
  final byteData = await rootBundle.load(path);
  final Codec codec = await instantiateImageCodec(
    byteData.buffer.asUint8List(),
    targetHeight: height,
    targetWidth: width,
  );
  final uiFI = await codec.getNextFrame();
  return (await uiFI.image.toByteData(format: ImageByteFormat.png))!
      .buffer
      .asUint8List();
}

/// [url](ネットワーク)から画像を読み込み、[BitmapDescriptor]へ変換します。
Future<BitmapDescriptor?> createBitmapDescriptorFromNetwork(
    {required String url, int? height, int? width}) async {
  logger.fine('createBitmapDescriptorFromNetwork $url');

  if (url.isEmpty) {
    return null;
  }

  try {
    final uintData = await _imageChangeUint8ListFromNetwork(url, height, width);
    return BitmapDescriptor.fromBytes(uintData);
  } on Exception catch (e, stackTrace) {
    logger.warning('url=$url, error=$e, stackTrace=$stackTrace');
    return null;
  } on ArgumentError catch (e, stackTrace) {
    logger.warning('url=$url, error=$e, stackTrace=$stackTrace');
    return null;
  }
}

/// [url](ネットワーク)から画像を読み込み、[Uint8List]へ変換します。
Future<Uint8List> _imageChangeUint8ListFromNetwork(
    String url, int? height, int? width) async {
  final uri = Uri.parse(url);
  final imageBytes =
      (await NetworkAssetBundle(uri).load(url)).buffer.asUint8List();

  final codec = await instantiateImageCodec(
    imageBytes,
    targetHeight: height,
    targetWidth: width,
  );
  final uiFI = await codec.getNextFrame();
  return (await uiFI.image.toByteData(format: ImageByteFormat.png))!
      .buffer
      .asUint8List();
}

/// [imageUrl]から画像を読み込み、画像表示のためのWidgetを返却します。
/// 画像が読み込めない場合、[Icons.broken_image]を表示するWidgetを返却します。
Widget createNetworkImage({
  required NavigatorState navigator,
  String? imageUrl,
  VoidCallback? onTap,
  void Function(ImageProvider imageProvider)? onLongPress,
}) {
  if (imageUrl == null) {
    return _errorImage(onTap: onTap);
  }

  return Material(
    elevation: 8.0,
    child: CachedNetworkImage(
      imageUrl: imageUrl,
      imageBuilder: (context, imageProvider) {
        return Ink.image(
          width: 80.0,
          height: 80.0,
          fit: BoxFit.fitHeight,
          image: imageProvider,
          child: InkWell(
            onTap: () {
              if (onTap != null) {
                onTap();
              }
            },
            onLongPress: () {
              if (onLongPress != null) {
                onLongPress(imageProvider);
              }
            },
          ),
        );
      },
      placeholder: (_, __) => const Center(
        child: SizedBox(
          width: 80.0,
          height: 80.0,
          child: CircularProgressIndicator(),
        ),
      ),
      errorWidget: (_, url, error) {
        logger.fine('error=$error, url=$url');
        return _errorImage();
      },
    ),
  );
}

/// エラー発生時に表示するアイコンを返却します。
Widget _errorImage({
  VoidCallback? onTap,
}) {
  return SizedBox(
    width: 80.0,
    height: 80.0,
    child: InkWell(
      onTap: () {
        if (onTap != null) {
          onTap();
        }
      },
      child: const Icon(Icons.broken_image, size: 36.0),
    ),
  );
}

import 'package:jiffy/jiffy.dart';

/// 対象日時[target]において、USA方式の週番号を標準形式（下位省略表記）「YYYYWww」にて生成します。
/// 例：2022/01/01 -> 2022W01
///    2022/01/02 -> 2022W02
///    2022/01/03 -> 2022W02
///    2022/12/31 -> 2022W53
///    2023/01/01 -> 2023W01
String createWeeksNumAsStandardForm(DateTime target) {
  final startOfYear = DateTime(target.year, 1, 1);

  int weeks;
  if (Jiffy(startOfYear).week == 0) {
    weeks = Jiffy(target).week + 1;
  } else {
    weeks = Jiffy(target).week;
  }

  // 標準形式（下位省略表記）「YYYYWww」
  return '${target.year}W${weeks.toString().padLeft(2, '0')}';
}

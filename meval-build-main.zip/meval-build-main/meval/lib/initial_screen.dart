import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:meval/foundation/constants.dart';
import 'package:meval/view/initial/login/robo_login_screen.dart';

import 'view/content/content_root_screen.dart';
import 'view/initial/login/login_screen.dart';
import 'view/initial/tos/root_tos_screen.dart';
import 'view_model/login_view_model.dart';
import 'view_model/member_view_model.dart';

class InitialScreen extends ConsumerWidget {
  static String path = '/';
  static String name = 'initial';

  const InitialScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 初期画面をルーティング
    Future.microtask(() async => await _initialRooting(context, ref));

    return const Scaffold();
  }

  /// 初期画面をルーティングします。
  Future<void> _initialRooting(BuildContext context, WidgetRef ref) async {
    // 認証状態確認
    final firebaseUser = await ref.watch(authStateChangesProvider.future);
    if (firebaseUser == null) {
      // Firebase未認証（ログイン画面へ）
      if (Constants.flavor == Flavor.robo) {
        context.go(RoboLoginScreen.path);
      } else {
        context.go(LoginScreen.path);
      }
      return;
    }

    // 会員情報取得
    final member = await ref.watch(currentMemberFutureProvider.future);
    if (member == null) {
      // Firebase認証済み＆会員登録未済（利用規約ページへ）
      context.go(RootTosScreen.path);
      return;
    }

    // Firebase認証済み＆会員登録済み（コンテンツルート（ホーム画面）へ）
    context.go(ContentRootScreen.path);
  }
}

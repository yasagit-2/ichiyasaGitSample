import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:marquee/marquee.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../model/data/tweet.dart';
import '../../util/logger.dart';
import '../style/style.dart';
import 'image_view.dart';

class BottomSheetContent extends StatelessWidget {
  // 画像URL
  final String? imageUrl;

  // 名称
  final String name;

  // 加盟店URL
  final String? merchantsUrl;

  // 内容
  final String? content;

  // つぶやき
  final Tweet? tweet;

  const BottomSheetContent(
      {Key? key,
      required this.imageUrl,
      required this.name,
      this.merchantsUrl,
      this.content,
      this.tweet})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Column(
        children: [
          // つぶやき
          _createTweet(),
          // 画像
          _createImage(),
          VerticalSpacer.smallish,
          Text(
            name,
            style: const TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.normal,
              color: Colors.black,
              decoration: TextDecoration.none,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          VerticalSpacer.smallish,
          // 加盟店URL
          _createMerchantsUrl(),
          VerticalSpacer.smallish,
          // 加盟店の内容
          _createContent(),
        ],
      ),
    );
  }

  /// ボトムシートへ表示する画像Widgetを生成します。
  Widget _createImage() {
    if (imageUrl != null) {
      return Material(
        child: CachedNetworkImage(
          height: 200.0,
          imageUrl: imageUrl!,
          imageBuilder: (context, imageProvider) {
            return Ink.image(
              fit: BoxFit.fitHeight,
              image: imageProvider,
              child: InkWell(
                onTap: () {
                  // 画像拡大表示
                  context.pushNamed(ImageView.name, extra: imageProvider);
                },
              ),
            );
          },
          placeholder: (_, __) => const Center(
            child: CircularProgressIndicator(),
          ),
          errorWidget: (_, url, error) {
            logger.fine('error=$error, url=$url');
            return _errorImage();
          },
        ),
      );
    } else {
      return _errorImage();
    }
  }

  /// ボトムシートへ表示するつぶやきWidgetを生成します。
  Widget _createTweet() {
    if (tweet == null) {
      return const SizedBox();
    }

    return SizedBox(
      height: 30,
      child: Material(
        child: Marquee(
          text: tweet!.message,
          style: const TextStyle(fontSize: 18.0),
          crossAxisAlignment: CrossAxisAlignment.start,
          blankSpace: 150.0,
          startPadding: 150.0,
        ),
      ),
    );
  }

  /// 加盟店URL表示用のWidgetを生成
  Widget _createMerchantsUrl() {
    if (merchantsUrl == null) {
      return const SizedBox();
    }
    return RichText(
        text: TextSpan(
      text: "お店の詳細はこちらから",
      style: const TextStyle(
        fontSize: 15,
        color: Colors.blue,
        decoration: TextDecoration.underline,
      ),
      recognizer: TapGestureRecognizer()
        ..onTap = () {
          launchUrlString(
            merchantsUrl!,
            mode: LaunchMode.externalApplication,
          );
        },
    ));
  }

  /// 加盟店の内容表示用のWidgetを生成
  Widget _createContent() {
    if (content == null) {
      return const SizedBox();
    }
    return RichText(
        text: TextSpan(
            text: content!,
            style: const TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.normal,
              color: Colors.black,
              decoration: TextDecoration.none,
            )));
  }

  /// エラー表示用のWidgetを生成します。
  Widget _errorImage() {
    return Column(
      children: const [
        Icon(Icons.broken_image, size: 30.0),
        Text(
          '（画像を表示できません）',
          style: TextStyle(
              fontSize: 12.0,
              color: Colors.black,
              decoration: TextDecoration.none),
        ),
      ],
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../provider/search_map_provider.dart';
import '../../style/style.dart';
import 'own_coupon_list_area.dart';

/// 自分のクーポンリスト
class OwnCouponListTab extends ConsumerWidget {
  // 加盟店ID
  final String merchantId;

  const OwnCouponListTab({Key? key, required this.merchantId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          CupertinoSliverRefreshControl(
            onRefresh: () async {
              ref.invalidate(couponHistoriesByMerchantId);
            },
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => Column(
                children: [
                  const Text('※利用すると使用済みとなり元に戻せません',
                      style: TextStyle(color: Color(0xFF0484B4))),
                  const Text('※お店に確認し利用してください',
                      style: TextStyle(color: Color(0xFF0484B4))),
                  VerticalSpacer.smallish,
                  // 自分のクーポン
                  OwnCouponListArea(merchantId: merchantId),
                ],
              ),
              childCount: 1,
            ),
          ),
        ],
      ),
    );
  }
}

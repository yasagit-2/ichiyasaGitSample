import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../provider/data/coupon_data.dart';
import '../../../../../provider/search_map_provider.dart';
import '../loading_service.dart';

/// 交換可能クーポン領域
class ReplaceableCouponListArea extends ConsumerWidget {
  // 加盟店ID
  final String merchantId;

  const ReplaceableCouponListArea({Key? key, required this.merchantId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final couponsAsyncValue =
        ref.watch(couponsByMerchantIdStreamProvider(merchantId));
    final couponHistoriesAsyncValue =
        ref.watch(couponHistoriesByMerchantId(merchantId));
    final pointAsyncValue = ref.watch(pointStreamProvider);

    if (couponsAsyncValue is! AsyncData ||
        couponsAsyncValue.value == null ||
        couponHistoriesAsyncValue is! AsyncData ||
        couponHistoriesAsyncValue.value == null ||
        pointAsyncValue is! AsyncData ||
        pointAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    // クーポンリスト
    final coupons = couponsAsyncValue.value!;
    // クーポン獲得/使用履歴リスト
    final couponHistories = couponHistoriesAsyncValue.value!;

    // 獲得済みクーポンのIDリスト
    final couponHistoryIdList =
        couponHistories.map((couponHistory) => couponHistory.id).toList();

    // 現在保持中のポイント
    final point = pointAsyncValue.value!;

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        final filteredCoupons = coupons
            // 掲載開始日に到来していないものを除外
            .where((coupon) => now.compareTo(coupon.publicationPeriodBegin) >= 0)
            // 掲載期間終了を除外
            .where((coupon) => now.compareTo(coupon.publicationPeriodEnd) <= 0)
            // 有効期限切れを除外
            .where((coupon) => now.compareTo(coupon.dueDate) <= 0)
            .toList();

        return ListView.separated(
          itemCount: filteredCoupons.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (BuildContext context, int index) {
            return const SizedBox(height: 5.0);
          },
          itemBuilder: (BuildContext context, int index) {
            // クーポン
            final coupon = filteredCoupons[index];

            final exchangeLimitRemainAsyncValue = ref.watch(
                couponExchangeLimitRemainStreamProvider(
                    CouponData(merchantId: merchantId, couponId: coupon.id)));
            if (exchangeLimitRemainAsyncValue is! AsyncData ||
                exchangeLimitRemainAsyncValue.value == null) {
              return const SizedBox();
            }

            final exchangeLimitRemain = exchangeLimitRemainAsyncValue.value!;
            // true:クーポン獲得制限到達
            final isExchangeLimit = exchangeLimitRemain == 0;

            // true:クーポン獲得済み
            final isAcquired = couponHistoryIdList.contains(coupon.id);

            return Material(
              elevation: 8.0,
              color: Colors.transparent,
              child: ListTile(
                tileColor: isExchangeLimit || isAcquired
                    ? const Color(0xFFBCECFC)
                    : const Color(0xFF04445C).withOpacity(0.8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  side: isExchangeLimit || isAcquired
                      ? const BorderSide(color: Colors.indigo, width: 3.0)
                      : const BorderSide(color: Color(0xFF04445C), width: 3.0),
                ),
                title: Text(
                  coupon.name,
                  style: const TextStyle(color: Colors.white),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                    '有効期限：${Const.dateFormat.format(coupon.dueDate)}',
                    style: const TextStyle(color: Colors.white)),
                trailing: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    SizedBox(
                      width: 70.0,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerRight,
                        child: Text(
                          Const.numberFormatter.format(coupon.exchangePoint),
                          style: const TextStyle(
                              fontSize: 32.0, color: Colors.white),
                        ),
                      ),
                    ),
                    const Text(
                      'pt',
                      style: TextStyle(
                          fontSize: 16.0, height: 0.5, color: Colors.white),
                    ),
                  ],
                ),
                onTap: isExchangeLimit || isAcquired
                    ? null
                    : () async {
                        if (point < coupon.exchangePoint) {
                          await showOkAlertDialog(
                            context: context,
                            title: coupon.name,
                            message: 'ポイントが不足しています\nこのクーポンは交換できません',
                          );
                          return;
                        }

                        // ポイント交換未済（バックエンド処理中）のクーポン獲得/使用履歴リスト
                        final unusedPointCoupons = await ref
                            .watch(unusedPointCouponsStreamProvider.future);

                        if (unusedPointCoupons.isNotEmpty) {
                          await showOkAlertDialog(
                            context: context,
                            title: coupon.name,
                            message:
                                'システム処理中のため、現在クーポン交換できません\nしばらく時間をおいてから再実行してください',
                          );
                          return;
                        }

                        final result = await showOkCancelAlertDialog(
                          context: context,
                          title: coupon.name,
                          message:
                              '有効期限：${Const.dateFormat.format(coupon.dueDate)}\n${Const.numberFormatter.format(coupon.exchangePoint)}pt消費して交換しますか？',
                          isDestructiveAction: true,
                        );

                        if (result == OkCancelResult.cancel) {
                          return;
                        }

                        // クーポン獲得/使用履歴保存
                        await ref
                            .read(loadingServiceProvider.notifier)
                            .wrap(createCouponHistory(ref, coupon));
                      },
              ),
            );
          },
        );
      },
    );
  }
}

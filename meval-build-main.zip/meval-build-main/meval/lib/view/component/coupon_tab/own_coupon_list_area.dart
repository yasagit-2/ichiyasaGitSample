import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../const/message.dart';
import '../../../../../provider/search_map_provider.dart';
import '../../../../../util/show_toast.dart';
import '../loading_service.dart';

class OwnCouponListArea extends ConsumerWidget {
  // 加盟店ID
  final String merchantId;

  const OwnCouponListArea({Key? key, required this.merchantId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final couponHistoriesAsyncValue =
        ref.watch(couponHistoriesByMerchantId(merchantId));

    if (couponHistoriesAsyncValue is! AsyncData ||
        couponHistoriesAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final couponHistories = couponHistoriesAsyncValue.value!;

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        final filteredCouponHistories = couponHistories
            .where((couponHistory) => now.compareTo(couponHistory.dueDate) <= 0)
            .toList();

        return ListView.separated(
          itemCount: filteredCouponHistories.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (BuildContext context, int index) {
            return const SizedBox(height: 5.0);
          },
          itemBuilder: (BuildContext context, int index) {
            // 獲得済みクーポン
            final couponHistory = filteredCouponHistories[index];

            return Material(
              elevation: 8.0,
              color: Colors.transparent,
              child: ListTile(
                tileColor: couponHistory.isCouponUsed
                    ? const Color(0xFFBCECFC)
                    : const Color(0xFF0484B4).withOpacity(0.8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  side: const BorderSide(color: Colors.indigo, width: 3.0),
                ),
                title: Center(
                  child: Text(
                    couponHistory.name,
                    style: const TextStyle(color: Colors.white),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                subtitle: Column(
                  children: [
                    const Text('クーポン利用',
                        style: TextStyle(fontSize: 20.0, color: Colors.white)),
                    Text(
                        '有効期限：${Const.dateFormat.format(couponHistory.dueDate)}',
                        style: const TextStyle(color: Colors.white)),
                  ],
                ),
                onTap: couponHistory.isCouponUsed
                    ? null
                    : () async {
                        if (!couponHistory.isPointUsed) {
                          await showOkAlertDialog(
                            context: context,
                            title: couponHistory.name,
                            message:
                                'システム処理中のため、このクーポンは現在使用できません\nしばらく時間をおいてから再実行してください',
                          );

                          return;
                        }

                        final result = await showOkCancelAlertDialog(
                          context: context,
                          title: couponHistory.name,
                          message:
                              '有効期限：${Const.dateFormat.format(couponHistory.dueDate)}\nクーポンを使用しますか？',
                          isDestructiveAction: true,
                        );

                        if (result == OkCancelResult.cancel) {
                          return;
                        }

                        final now = await NTP.now();
                        if (now.compareTo(couponHistory.dueDate) > 0) {
                          showErrorToast(DisplayedErrorMessage.usedCoupon);
                          return;
                        }

                        // クーポン使用
                        await ref
                            .read(loadingServiceProvider.notifier)
                            .wrap(useCoupon(ref, couponHistory));
                      },
              ),
            );
          },
        );
      },
    );
  }
}

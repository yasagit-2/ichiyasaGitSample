import 'package:flutter/cupertino.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../provider/search_map_provider.dart';
import '../../style/style.dart';
import 'replaceable_coupon_list_area.dart';

/// 交換可能クーポンリスト
class ReplaceableCouponListTab extends ConsumerWidget {
  // 加盟店ID
  final String merchantId;

  const ReplaceableCouponListTab({Key? key, required this.merchantId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          CupertinoSliverRefreshControl(
            onRefresh: () async {
              ref.invalidate(couponsByMerchantIdStreamProvider);
              ref.invalidate(couponHistoriesByMerchantId);
            },
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => Column(
                children: [
                  const Text('※交換後にキャンセルはできません',
                      style: TextStyle(color: Color(0xFF0484B4))),
                  VerticalSpacer.smallish,
                  // 交換可能クーポン
                  ReplaceableCouponListArea(merchantId: merchantId),
                ],
              ),
              childCount: 1,
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../provider/screen_type_provider.dart';
import '../../provider/search_map_provider.dart';
import '../style/style.dart';
import 'coupon_tab/own_coupon_list_tab.dart';
import 'coupon_tab/replaceable_coupon_list_tab.dart';

class CouponListScreen extends ConsumerWidget {
  static String pathFromSearch = 'couponListFromSearch';
  static String pathFromSpend = 'couponListFromSpend';
  static String nameFromSearch = 'couponListFromSearch';
  static String nameFromSpend = 'couponListFromSpend';

  late final _couponListTabs = [
    _CouponListTabInfo(
      couponListTabType: CouponListTabType.ownCoupon,
      label: '自分のクーポン',
      widget: OwnCouponListTab(merchantId: merchantId),
    ),
    _CouponListTabInfo(
      couponListTabType: CouponListTabType.replaceableCoupon,
      label: '交換可能クーポン',
      widget: ReplaceableCouponListTab(merchantId: merchantId),
    ),
  ];

  // 加盟店ID
  final String merchantId;

  CouponListScreen({Key? key, required this.merchantId}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final merchantAsyncValue =
        ref.watch(merchantByIdStreamProvider(merchantId));
    if (merchantAsyncValue is! AsyncData || merchantAsyncValue.value == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // 加盟店
    final merchant = merchantAsyncValue.value!;

    return DefaultTabController(
      length: _couponListTabs.length,
      child: Builder(builder: (context) {
        final couponListTabType = ref.watch(couponListTabTypeProvider);
        final couponListTabInfo = _couponListTabs
            .firstWhere((tab) => tab.couponListTabType == couponListTabType);
        final index = _couponListTabs.indexOf(couponListTabInfo);

        // プロバイダのタブタイプへ移動
        final tabController = DefaultTabController.of(context)!;
        tabController.animateTo(index);

        tabController.addListener(() {
          if (!tabController.indexIsChanging) {
            // タブが変化した際に状態を更新
            ref
                .read(couponListTabTypeProvider.notifier)
                .update((_) => CouponListTabType.values[tabController.index]);
          }
        });

        return Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).canvasColor,
            elevation: 0.0,
            title: Text(merchant.name, style: TextStyles.appBarTitle),
            centerTitle: true,
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(28.0),
              child: Ink(
                height: 38.0,
                child: TabBar(
                  unselectedLabelColor: Colors.black,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicator: BoxDecoration(
                    color: Colors.blueGrey,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  tabs: _couponListTabs.map((tab) {
                    return Tab(
                      child: Text(tab.label,
                          style: const TextStyle(fontSize: 18.0)),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          body: TabBarView(
            children: _couponListTabs.map((tab) => tab.widget).toList(),
          ),
        );
      }),
    );
  }
}

/// タブの情報を保持するクラスです。
class _CouponListTabInfo {
  // タブタイプ
  final CouponListTabType couponListTabType;

  // タブのラベル
  final String label;

  // タブ選択時に表示するWidget
  final Widget widget;

  const _CouponListTabInfo({
    required this.couponListTabType,
    required this.label,
    required this.widget,
  });
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../provider/authentication_type_provider.dart';
import '../../view_model/login_view_model.dart';
import '../initial/login/login_screen.dart';
import '../style/style.dart';

class CancelToTopButton extends ConsumerWidget {
  final String buttonTitle;

  const CancelToTopButton({Key? key, required this.buttonTitle})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
          onPressed: () async {
            refreshStateForLogout(ref);
            await ref.watch(loginViewModelProvider.notifier).logout();

            // ログイン画面へ
            context.go(LoginScreen.path);
          },
          child: Text(buttonTitle, style: TextStyles.buttonTextStyle)),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../const/constant.dart';
import '../../provider/authentication_type_provider.dart';
import '../../provider/shared_strage_provider.dart';
import '../style/style.dart';

// 電話番号プロバイダ
final phoneNumberProvider = StateProvider<String>((ref) {
  final savedPhoneNumber = ref
      .watch(sharedPreferencesProvider)
      .getString(SharedPreferenceConst.phoneNumber);

  return savedPhoneNumber ?? '';
});

// 電話番号バリデーション成否プロバイダ
final phoneNumberValidProvider = StateProvider<bool>(
    // デバイスに保存済みの電話番号が存在する場合はバリデート済み
    (ref) {
  final savedPhoneNumber = ref
      .watch(sharedPreferencesProvider)
      .getString(SharedPreferenceConst.phoneNumber);

  return savedPhoneNumber != null ? true : false;
});

class PhoneField extends HookConsumerWidget {
  // 有効化(true:有効)
  final bool enabled;

  // 必須入力(true:必須)
  final bool requiredEntry;

  // 電話番号初期表示(true:デバイス内に保存された電話番号を初期表示、false:電話番号プロバイダの値を初期表示)
  final bool useSavedPhoneNumber;

  const PhoneField({
    Key? key,
    this.enabled = true,
    this.requiredEntry = false,
    this.useSavedPhoneNumber = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final savedPhoneNumber = ref
        .watch(sharedPreferencesProvider)
        .getString(SharedPreferenceConst.phoneNumber);
    final phoneNumberController = useSavedPhoneNumber
        ? useTextEditingController(text: savedPhoneNumber)
        : useTextEditingController(text: ref.watch(phoneNumberProvider));

    final authenticationType = ref.watch(authenticationTypeProvider);
    if (authenticationType != AuthenticationType.sms) {
      phoneNumberController.clear();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('電話番号', style: TextStyles.fieldTitleTextStyle),
            HorizontalSpacer.requiredEntry,
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        TextFormField(
          controller: phoneNumberController,
          keyboardType: TextInputType.number,
          enabled: enabled,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: 11,
          validator: (value) {
            if (value == null || value.isEmpty) return null;

            try {
              int.parse(value);
            } on FormatException {
              // 電話番号バリデーション結果更新(NG)
              WidgetsBinding.instance.addPostFrameCallback(
                (_) => ref
                    .read(phoneNumberValidProvider.notifier)
                    .update((_) => false),
              );

              return '電話番号を入力してください。';
            }

            if (!RegExp(Const.phoneNumberRegex).hasMatch(value)) {
              // 電話番号バリデーション結果更新(NG)
              WidgetsBinding.instance.addPostFrameCallback(
                (_) => ref
                    .read(phoneNumberValidProvider.notifier)
                    .update((_) => false),
              );

              return '正しい電話番号を入力してください。';
            }

            WidgetsBinding.instance.addPostFrameCallback((_) {
              // 電話番号更新
              ref.read(phoneNumberProvider.notifier).update((_) => value);
              // 電話番号バリデーション結果更新(OK)
              ref.read(phoneNumberValidProvider.notifier).update((_) => true);

              // 認証タイプをSMSへ更新
              ref
                  .watch(authenticationTypeProvider.notifier)
                  .update((_) => AuthenticationType.sms);
            });

            return null;
          },
          decoration: InputDecoration(
            hintText: '（例）09012345678',
            prefixIcon: const Icon(Icons.phone),
            // クリアボタン
            suffixIcon: enabled
                ? IconButton(
                    onPressed: () {
                      phoneNumberController.clear();
                      ref.watch(phoneNumberProvider.notifier).update((_) => '');
                    },
                    icon: const Icon(
                      Icons.clear,
                      size: 20.0,
                    ),
                  )
                : null,
          ),
        ),
      ],
    );
  }
}

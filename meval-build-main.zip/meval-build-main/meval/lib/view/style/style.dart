import 'package:flutter/material.dart';

const titleFont = 'Roboto_Italic';
const regularFont = 'NotoSansJP_Medium';
const boldFont = 'NotoSansJP_Bold';

final darkTheme = ThemeData(
  brightness: Brightness.dark,
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: Colors.white30,
      textStyle: TextStyles.buttonTextStyle,
    ),
  ),
  primaryIconTheme: const IconThemeData(
    color: Colors.white,
  ),
  iconTheme: const IconThemeData(
    color: Colors.white,
  ),
  fontFamily: regularFont,
);

final lightTheme = ThemeData(
  brightness: Brightness.light,
  appBarTheme: const AppBarTheme(
    // backgroundColor: Colors.blue[400],
    backgroundColor: Colors.white,
    iconTheme: IconThemeData(
      color: Colors.black,
    ),
    titleTextStyle: TextStyle(
      color: Colors.black,
      fontSize: 20.0,
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      foregroundColor: Colors.white,
      backgroundColor: Colors.black54,
      textStyle: TextStyles.buttonTextStyle,
    ),
  ),
  primaryIconTheme: const IconThemeData(
    color: Colors.black,
  ),
  iconTheme: const IconThemeData(
    color: Colors.black,
  ),
  fontFamily: regularFont,
);

class TextLabel {
  static const requiredEntry =
      Text('※必須', style: TextStyles.requiredEntryTextStyle);
}

class TextStyles {
  // AppBarのタイトル
  static const appBarTitle =
      TextStyle(fontSize: 24.0, fontFamily: titleFont, color: Colors.black);

  // ボタンのスタイル
  static const buttonTextStyle = TextStyle(fontSize: 18.0);

  // フィールド項目のタイトルスタイル
  static const fieldTitleTextStyle = TextStyle(fontSize: 18.0);

  // 必須テキストスタイル
  static const requiredEntryTextStyle =
      TextStyle(fontSize: 14.0, color: Colors.red);

  // ユーザ名のスタイル
  static const userNameTextStyle = TextStyle(fontSize: 24.0);
}

class ButtonStyles {
  static const menuButtonSize = 35.0;
}

class VerticalSpacer {
  // Widget間の標準スペース
  static const standard = SizedBox(height: 24.0);

  // Widget間のスペース(小さめ)
  static const smallish = SizedBox(height: 12.0);

  // Widget間のスペース(セパレート)
  static const separator = SizedBox(height: 5.0);
}

class HorizontalSpacer {
  // Widget間の標準スペース
  static const standard = SizedBox(width: 24.0);

  // Widget間のスペース(小さめ)
  static const smallish = SizedBox(width: 12.0);

  // 「※必須」のスペース
  static const requiredEntry = SizedBox(width: 18.0);
}

class AppColors {
  // ホーム画面等で利用するメインカラー
  static final mainColor = const Color(0xFF00BFFF).withOpacity(0.8);

  // InkWell splash color
  static final splashColor = const Color(0xFF00BFFF).withOpacity(0.2);
}

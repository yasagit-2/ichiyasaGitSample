import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../const/constant.dart';
import '../../style/style.dart';

// 生年月プロバイダ
final monthOfBirthProvider =
    StateProvider.autoDispose<DateTime>((ref) => Const.initialDate);

class MonthOfBirthSelection extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  final DateTime? monthOfBirth;

  const MonthOfBirthSelection(
      {Key? key, this.requiredEntry = false, this.monthOfBirth})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final monthOfBirthController = monthOfBirth == null
        ? useTextEditingController()
        : useTextEditingController(
            text: Const.yearMonthFormat.format(monthOfBirth!));

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (monthOfBirth != null) {
          ref.read(monthOfBirthProvider.notifier).update((_) => monthOfBirth!);
        }
      });
      return null;
    }, [monthOfBirth]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('生年月', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(left: 50.0, right: 20.0),
          child: GestureDetector(
            onTap: () async {
              // フォーカスを外す
              FocusScope.of(context).unfocus();

              final initial =
                  (ref.watch(monthOfBirthProvider) == Const.initialDate)
                      ? Const.monthOfBirthInitialDate
                      : ref.watch(monthOfBirthProvider);

              // 生年月取得
              final pickedDate = await _pickMonthOfBirth(context, initial);
              if (pickedDate == null) return;

              // テキストフィールド更新
              monthOfBirthController.text =
                  Const.yearMonthFormat.format(pickedDate);
              // 状態更新
              ref.watch(monthOfBirthProvider.notifier).update((_) =>
                  DateTime.utc(
                      pickedDate.year, pickedDate.month, pickedDate.day));
            },
            child: AbsorbPointer(
              child: TextField(
                controller: monthOfBirthController,
                style: const TextStyle(fontSize: 20.0),
                decoration: const InputDecoration(hintText: '選択してください'),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// 生年月のpickerを表示し、選択された生年月を返却します。
  /// キャンセルの場合はnullを返却します。
  Future<DateTime?> _pickMonthOfBirth(
      BuildContext context, DateTime initial) async {
    return await DatePicker.showPicker(
      context,
      locale: LocaleType.jp,
      pickerModel: YearMonthModel(
        currentTime: initial,
        maxTime: await NTP.now(),
        minTime: Const.monthOfBirthMinimumDate,
        locale: LocaleType.jp,
      ),
    );
  }
}

class YearMonthModel extends DatePickerModel {
  YearMonthModel(
      {required DateTime currentTime,
      required DateTime maxTime,
      required DateTime minTime,
      required LocaleType locale})
      : super(
            currentTime: currentTime,
            maxTime: maxTime,
            minTime: minTime,
            locale: locale);

  @override
  List<int> layoutProportions() {
    return [1, 1, 0];
  }
}

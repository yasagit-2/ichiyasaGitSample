import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../util/logger.dart';
import '../../style/style.dart';

// 名前プロバイダ
final mailAddressProvider = StateProvider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('mailAddressProvider dispose.');
  });
  return '';
});

// ignore: camel_case_types
class mailAddressField extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  // 氏名
  final String mailAddress;

  const mailAddressField(
      {Key? key, this.requiredEntry = false, this.mailAddress = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mailAddressController = useTextEditingController(text: mailAddress);

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mailAddress.isNotEmpty) {
          ref.read(mailAddressProvider.notifier).update((_) => mailAddress);
        }
      });
      return null;
    }, [mailAddress]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('メールアドレス', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        TextFormField(
          controller: mailAddressController,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: TextFieldConst.mailAddressMaxLength,
          validator: (value) {
            if (value == null) return null;

            if ((value == null) || !EmailValidator.validate(value)) {
              return 'Emailが不正です。';
            }

            if (value != value.trim()) {
              return '前後のスペースを取り除いてください。';
            }

            if (value.isEmpty ||
                TextFieldConst.mailAddressMaxLength < value.characters.length) {
              return 'メールアドレスを${TextFieldConst.mailAddressMaxLength}文字以内で入力してください。';
            }

            return null;
          },
          onChanged: (value) {
            ref.watch(mailAddressProvider.notifier).update((_) => value);
          },
          decoration: InputDecoration(
            // クリアボタン
            suffixIcon: IconButton(
              onPressed: () {
                mailAddressController.clear();
                ref.watch(mailAddressProvider.notifier).update((_) => '');
              },
              icon: const Icon(
                Icons.clear,
                size: 20.0,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

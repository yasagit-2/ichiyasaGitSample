import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:meval/view/initial/register/mailaddress_field.dart';
import 'package:meval/view/initial/register/name_field.dart';

import '../../../provider/app_version_provider.dart';
import '../../../provider/authentication_type_provider.dart';
import '../../../view_model/login_view_model.dart';
import '../../component/cancel_to_top_button.dart';
import '../../component/phone_field.dart';
import '../../style/style.dart';
import '../login/login_screen.dart';
import 'gender_selection.dart';
import 'month_of_birth_selection.dart';
import 'nickname_field.dart';
import 'prefecture_selection.dart';
import 'register_button.dart';

class RegisterScreen extends ConsumerWidget {
  static String path = 'register';
  static String name = 'register';

  const RegisterScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 認証状態(Watcher)
    final authWatcher = ref.watch(authStateChangesProvider);

    if (authWatcher is AsyncLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (authWatcher is AsyncError || authWatcher.value == null) {
      // ログイン画面へ
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.go(LoginScreen.path);
      });
    }

    // メンテナンス
    final maintenanceAsyncValue = ref.watch(maintenanceStreamProvider);
    if (maintenanceAsyncValue is! AsyncData ||
        maintenanceAsyncValue.value == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final maintenance = maintenanceAsyncValue.value!;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // メンテナンスチェック
      await maintenanceCheck(context, ref, maintenance);
      if (maintenance.isMaintenance) {
        return;
      }

      // バージョンチェック
      await appVersionCheck(context, ref, maintenance);
    });

    // 認証タイプ
    final authenticationType = ref.read(authenticationTypeProvider);

    // 電話番号フィールドの表示
    final isDisplayPhoneField = authenticationType == AuthenticationType.sms;

    return WillPopScope(
      onWillPop: () async => false,
      child: GestureDetector(
        // フォーカスを外す
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: Theme.of(context).canvasColor,
            automaticallyImplyLeading: false,
            elevation: 0.0,
            title: const Text('新規会員登録', style: TextStyles.appBarTitle),
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // 電話番号
                  isDisplayPhoneField
                      ? const PhoneField(enabled: false, requiredEntry: true)
                      : const SizedBox(),
                  // ニックネーム
                  const NicknameField(requiredEntry: true),
                  // 性別
                  const GenderSelection(requiredEntry: true),
                  VerticalSpacer.smallish,
                  // 生年月
                  const MonthOfBirthSelection(requiredEntry: true),
                  VerticalSpacer.smallish,
                  // 居住地
                  const PrefectureSelection(requiredEntry: true),
                  VerticalSpacer.standard,
                  // 氏名
                  const nameField(requiredEntry: true),
                  VerticalSpacer.standard,
                  // メールアドレス
                  const mailAddressField(requiredEntry: true),
                  VerticalSpacer.standard,
                  const RegisterButton(),
                  VerticalSpacer.standard,
                  const CancelToTopButton(buttonTitle: '登録をやめてトップへ戻る'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

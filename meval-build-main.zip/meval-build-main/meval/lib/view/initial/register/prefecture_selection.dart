import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../style/style.dart';

// 居住地プロバイダ
final prefectureProvider = StateProvider.autoDispose<String>((ref) => '');

class PrefectureSelection extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  // 都道府県
  final String prefecture;

  // 都道府県
  static const _prefectures = [
    '北海道',
    '青森県',
    '岩手県',
    '宮城県',
    '秋田県',
    '山形県',
    '福島県',
    '茨城県',
    '栃木県',
    '群馬県',
    '埼玉県',
    '千葉県',
    '東京都',
    '神奈川県',
    '新潟県',
    '富山県',
    '石川県',
    '福井県',
    '山梨県',
    '長野県',
    '岐阜県',
    '静岡県',
    '愛知県',
    '三重県',
    '滋賀県',
    '京都府',
    '大阪府',
    '兵庫県',
    '奈良県',
    '和歌山県',
    '鳥取県',
    '島根県',
    '岡山県',
    '広島県',
    '山口県',
    '徳島県',
    '香川県',
    '愛媛県',
    '高知県',
    '福岡県',
    '佐賀県',
    '長崎県',
    '熊本県',
    '大分県',
    '宮崎県',
    '鹿児島県',
    '沖縄県',
  ];

  const PrefectureSelection(
      {Key? key, this.requiredEntry = false, this.prefecture = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final prefectureController = useTextEditingController(text: prefecture);

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (prefecture.isNotEmpty) {
          ref.read(prefectureProvider.notifier).update((_) => prefecture);
        }
      });
      return null;
    }, [prefecture]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('居住地', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(left: 50.0, right: 20.0),
          child: GestureDetector(
            onTap: () async {
              // フォーカスを外す
              FocusScope.of(context).unfocus();

              final initial = ref.watch(prefectureProvider).isEmpty
                  ? _prefectures[12]
                  : ref.watch(prefectureProvider);

              // 居住地取得
              final prefecture = await _pickPrefecture(context, initial);
              if (prefecture.isEmpty) return;

              // テキストフィールド更新
              prefectureController.text = prefecture;
              // 状態更新
              ref.watch(prefectureProvider.notifier).update((_) => prefecture);
            },
            child: AbsorbPointer(
              child: TextField(
                controller: prefectureController,
                style: const TextStyle(fontSize: 20.0),
                decoration: const InputDecoration(hintText: '選択してください'),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<String> _pickPrefecture(BuildContext context, String initial) async {
    return await showModalBottomSheet<String>(
          context: context,
          builder: (BuildContext context) {
            String picked = initial;

            return SizedBox(
              height: 300,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CupertinoButton(
                        pressedOpacity: 0.3,
                        padding: const EdgeInsets.only(left: 16, top: 0),
                        child: const Text('キャンセル'),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      CupertinoButton(
                        pressedOpacity: 0.3,
                        padding: const EdgeInsets.only(right: 16, top: 0),
                        child: const Text('完了'),
                        onPressed: () => Navigator.of(context).pop(picked),
                      ),
                    ],
                  ),
                  Expanded(
                    child: CupertinoTheme(
                      data: CupertinoThemeData(
                        textTheme: CupertinoTextThemeData(
                          dateTimePickerTextStyle: TextStyle(
                            fontSize: 22,
                            color: Theme.of(context).textTheme.bodyLarge!.color,
                          ),
                        ),
                      ),
                      child: CupertinoPicker(
                        itemExtent: 40,
                        scrollController: FixedExtentScrollController(
                            initialItem:
                                _prefectures.indexWhere((e) => e == initial)),
                        onSelectedItemChanged: (index) =>
                            picked = _prefectures[index],
                        children: _prefectures
                            .map((prefecture) => Text(prefecture,
                                style: const TextStyle(
                                    fontSize: 26.0, color: Colors.black)))
                            .toList(),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ) ??
        '';
  }
}

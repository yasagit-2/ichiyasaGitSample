import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../util/logger.dart';
import '../../style/style.dart';

// ニックネームプロバイダ
final nicknameProvider = StateProvider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('nicknameProvider dispose.');
  });
  return '';
});

class NicknameField extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  // ニックネーム
  final String nickname;

  const NicknameField(
      {Key? key, this.requiredEntry = false, this.nickname = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final nicknameController = useTextEditingController(text: nickname);

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (nickname.isNotEmpty) {
          ref.read(nicknameProvider.notifier).update((_) => nickname);
        }
      });
      return null;
    }, [nickname]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('ニックネーム', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        const Text(
          '（投稿時やコメント時などに表示されますので個人を特定できる情報は入力しないでください）',
          style: TextStyle(fontSize: 12.0),
        ),
        TextFormField(
          controller: nicknameController,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: TextFieldConst.nicknameMaxLength,
          validator: (value) {
            if (value == null) return null;

            if (value != value.trim()) {
              return '前後のスペースを取り除いてください。';
            }

            if (value.isEmpty ||
                TextFieldConst.nicknameMaxLength < value.characters.length) {
              return 'ニックネームを${TextFieldConst.nicknameMaxLength}文字以内で入力してください。';
            }

            return null;
          },
          onChanged: (value) {
            ref.watch(nicknameProvider.notifier).update((_) => value);
          },
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.person),
            // クリアボタン
            suffixIcon: IconButton(
              onPressed: () {
                nicknameController.clear();
                ref.watch(nicknameProvider.notifier).update((_) => '');
              },
              icon: const Icon(
                Icons.clear,
                size: 20.0,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

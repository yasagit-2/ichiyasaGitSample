import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/authentication_type_provider.dart';
import '../../../view_model/member_view_model.dart';
import '../../component/loading_service.dart';
import '../../component/phone_field.dart';
import '../../content/content_root_screen.dart';
import '../../style/style.dart';
import 'gender_selection.dart';
import 'month_of_birth_selection.dart';
import 'nickname_field.dart';
import 'prefecture_selection.dart';
import 'name_field.dart';
import 'mailaddress_field.dart';

// 登録バリデーションプロバイダ
// 「電話番号」「ニックネーム」「性別」「生年月」「居住地」が設定されている（かつ、それぞれのバリデーションがOK）
final registerValidationProvider = Provider.autoDispose<bool>((ref) {
  final nickname = ref.watch(nicknameProvider);
  final gender = ref.watch(genderProvider);
  final monthOfBirth = ref.watch(monthOfBirthProvider);
  final prefecture = ref.watch(prefectureProvider);
  final name = ref.watch(nameProvider);
  final mailAddress = ref.watch(mailAddressProvider);

  bool isValid = false;
  if (nickname.isNotEmpty &&
      // ニックネームの最大文字数
      nickname.characters.length <= TextFieldConst.nicknameMaxLength &&
      gender.isNotEmpty &&
      monthOfBirth.compareTo(Const.initialDate) != 0 &&
      prefecture.isNotEmpty &&
      name.isNotEmpty &&
      name.characters.length <= TextFieldConst.nicknameMaxLength &&
      mailAddress.isNotEmpty &&
      mailAddress.characters.length <= TextFieldConst.mailAddressMaxLength &&
      EmailValidator.validate(mailAddress)) {
    isValid = true;
  }

  // 認証タイプ
  final authenticationType = ref.watch(authenticationTypeProvider);
  if (authenticationType == AuthenticationType.sms) {
    // SMSの場合は電話番号フィールドのバリデーションを確認
    isValid = isValid && ref.watch(phoneNumberValidProvider);
  }

  return isValid;
});

class RegisterButton extends ConsumerWidget {
  const RegisterButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isValid = ref.watch(registerValidationProvider);

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isValid
            ? () async {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '会員登録を行いますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                await ref.read(loadingServiceProvider.notifier).wrap(
                      _registerMember(context, ref),
                    );
              }
            : null,
        child: const Text('登録', style: TextStyles.buttonTextStyle),
      ),
    );
  }

  // 会員登録を行います。
  _registerMember(BuildContext context, WidgetRef ref) async {
    final nickname = ref.read(nicknameProvider);
    final gender = ref.read(genderProvider);
    final monthOfBirth = ref.read(monthOfBirthProvider);
    final prefecture = ref.read(prefectureProvider);
    final name = ref.read(nameProvider);
    final mailAddress = ref.read(mailAddressProvider);

    // 会員登録
    await ref.read(memberViewModelProvider.notifier).register(
          nickname: nickname,
          gender: gender,
          monthOfBirth: monthOfBirth,
          prefecture: prefecture,
          name: name,
          mailAddress: mailAddress,
          authenticationProvider: ref.read(authenticationTypeProvider),
        );

    // 会員登録成功時の処理（ContentRootScreenへ画面遷移）
    context.go(ContentRootScreen.path);
  }
}

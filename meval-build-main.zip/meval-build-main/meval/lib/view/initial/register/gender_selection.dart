import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../style/style.dart';

// 性別プロバイダ
final genderProvider = StateProvider.autoDispose<String>((ref) => '');

class GenderSelection extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  // 性別
  final String gender;

  const GenderSelection(
      {Key? key, this.requiredEntry = false, this.gender = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final genderController = useTextEditingController(text: gender);

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (gender.isNotEmpty) {
          ref.read(genderProvider.notifier).update((_) => gender);
        }
      });
      return null;
    }, []);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('性別', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(left: 50.0, right: 20.0),
          child: GestureDetector(
            onTap: () async {
              // フォーカスを外す
              FocusScope.of(context).unfocus();

              // pickerの初期値
              final initial = ref.watch(genderProvider).isEmpty
                  ? Const.genderList[0]
                  : ref.watch(genderProvider);

              // 性別選択
              final gender = await _pickGender(context, initial);
              if (gender.isEmpty) return;

              // テキストフィールド更新
              genderController.text = gender;
              // 状態更新
              ref.watch(genderProvider.notifier).update((_) => gender);
            },
            child: AbsorbPointer(
              child: TextField(
                controller: genderController,
                style: const TextStyle(fontSize: 20.0),
                decoration: const InputDecoration(hintText: '選択してください'),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<String> _pickGender(BuildContext context, String initial) async {
    return await showModalBottomSheet<String>(
            context: context,
            builder: (BuildContext context) {
              String picked = initial;

              return SizedBox(
                height: 250,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CupertinoButton(
                          pressedOpacity: 0.3,
                          padding: const EdgeInsets.only(left: 16, top: 0),
                          child: const Text('キャンセル'),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        CupertinoButton(
                          pressedOpacity: 0.3,
                          padding: const EdgeInsets.only(right: 16, top: 0),
                          child: const Text('完了'),
                          onPressed: () => Navigator.of(context).pop(picked),
                        ),
                      ],
                    ),
                    Expanded(
                      child: CupertinoTheme(
                        data: CupertinoThemeData(
                          textTheme: CupertinoTextThemeData(
                            dateTimePickerTextStyle: TextStyle(
                              fontSize: 22,
                              color:
                                  Theme.of(context).textTheme.bodyLarge!.color,
                            ),
                          ),
                        ),
                        child: CupertinoPicker(
                          itemExtent: 40,
                          scrollController: FixedExtentScrollController(
                              initialItem: Const.genderList
                                  .indexWhere((e) => e == initial)),
                          onSelectedItemChanged: (index) =>
                              picked = Const.genderList[index],
                          children: Const.genderList
                              .map((gender) => Text(gender,
                                  style: const TextStyle(
                                      fontSize: 26.0, color: Colors.black)))
                              .toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }) ??
        '';
  }
}

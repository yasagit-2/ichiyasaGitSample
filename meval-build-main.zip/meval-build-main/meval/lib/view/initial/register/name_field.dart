import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../util/logger.dart';
import '../../style/style.dart';

// 名前プロバイダ
final nameProvider = StateProvider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('nameProvider dispose.');
  });
  return '';
});

// ignore: camel_case_types
class nameField extends HookConsumerWidget {
  // 必須入力(true:必須)
  final bool requiredEntry;

  // 氏名
  final String name;

  const nameField({Key? key, this.requiredEntry = false, this.name = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final nameController = useTextEditingController(text: name);

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (name.isNotEmpty) {
          ref.read(nameProvider.notifier).update((_) => name);
        }
      });
      return null;
    }, [name]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('氏名', style: TextStyle(fontSize: 18.0)),
            HorizontalSpacer.requiredEntry,
            // 必須
            requiredEntry ? TextLabel.requiredEntry : const SizedBox(),
          ],
        ),
        const Text(
          '（投稿時やコメント時などには表示されません）',
          style: TextStyle(fontSize: 12.0),
        ),
        TextFormField(
          controller: nameController,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: TextFieldConst.nicknameMaxLength,
          validator: (value) {
            if (value == null) return null;

            if (value != value.trim()) {
              return '前後のスペースを取り除いてください。';
            }

            if (value.isEmpty ||
                TextFieldConst.nicknameMaxLength < value.characters.length) {
              return '氏名を${TextFieldConst.nicknameMaxLength}文字以内で入力してください。';
            }

            return null;
          },
          onChanged: (value) {
            ref.watch(nameProvider.notifier).update((_) => value);
          },
          decoration: InputDecoration(
            // クリアボタン
            suffixIcon: IconButton(
              onPressed: () {
                nameController.clear();
                ref.watch(nameProvider.notifier).update((_) => '');
              },
              icon: const Icon(
                Icons.clear,
                size: 20.0,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

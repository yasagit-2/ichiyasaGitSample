import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/message.dart';
import '../../../provider/authentication_type_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../view_model/login_view_model.dart';
import '../../component/loading_service.dart';
import '../../component/phone_field.dart';
import 'login_functions.dart';
import 'sms_auth_code_screen.dart';

class SmsLoginButton extends ConsumerWidget {
  const SmsLoginButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isValid = ref.watch(phoneNumberValidProvider);
    final navigator = Navigator.of(context);

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isValid
            ? () async {
                // フォーカスを外す
                FocusScope.of(context).unfocus();

                // 認証タイプ:SMS
                ref
                    .read(authenticationTypeProvider.notifier)
                    .update((_) => AuthenticationType.sms);

                // ログイン処理（loading）
                await ref
                    .watch(loadingServiceProvider.notifier)
                    .wrap(_loginPhoneNumber(ref, navigator));
              }
            : null,
        child: const Text('ログイン'),
      ),
    );
  }

  /// SMS認証を行い、会員登録状況に応じて画面遷移します。
  Future<void> _loginPhoneNumber(
    WidgetRef ref,
    NavigatorState navigator,
  ) async {
    // 日本国内利用のみであるため国番号は+81固定とする(QA No.18)
    final phoneNumber = '+81${ref.read(phoneNumberProvider)}';
    logger.fine('phoneNumber=$phoneNumber');

    try {
      // ログイン処理
      await ref.read(loginViewModelProvider.notifier).loginPhoneNumber(
            phoneNumber: phoneNumber,
            smsAuthCode: () => _smsAuthCode(ref, navigator, phoneNumber),
            verificationFailed: _verificationFailed,
          );

      // ログイン成功時の処理（画面遷移）
      await onSuccessLogin(
        ref: ref,
        navigator: navigator,
        phoneNumber: ref.read(phoneNumberProvider),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'web-context-cancelled') {
        // キャンセル
        return;
      }

      if (e.code == 'invalid-verification-code' ||
          e.code == 'invalid-verification-id' ||
          e.code == 'missing-verification-code') {
        // 確認コード入力異常
        // warning扱いとし例外はrethrowしない

        logger.warning(e);
        showErrorToast(DisplayedErrorMessage.smsLoginError);
        return;
      }

      rethrow;
    }
  }

  /// SMS確認コードの入力画面へ遷移し、入力された確認コードを返却します。
  Future<String?> _smsAuthCode(
      WidgetRef ref, NavigatorState navigator, String phoneNumber) async {
    // loading解除
    ref.read(loadingServiceProvider.notifier).dismiss();

    final passCode = await navigator.push(
      MaterialPageRoute(
        builder: (_) => SmsAuthCodeScreen(
          phoneNumber: phoneNumber,
        ),
      ),
    );
    return passCode;
  }

  _verificationFailed(Exception e) {
    logger.severe(e);
  }
}

import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../component/phone_field.dart';
import '../../style/style.dart';
import 'apple_sign_in_button.dart';
import 'facebook_sign_in_button.dart';
import 'google_sign_in_button.dart';
import 'sms_login_button.dart';
import 'twitter_sign_in_button.dart';

class LoginScreen extends HookConsumerWidget {
  static String name = 'login';
  static String path = '/login';

  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.microtask(() async {
        // 通知許可
        if (Platform.isIOS) {
          await FirebaseMessaging.instance
              .requestPermission(alert: true, announcement: true, badge: true);
        } else {
          await Permission.notification.request();
        }
      });

      return null;
    }, []);

    return GestureDetector(
      // フォーカスを外す
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).canvasColor,
          centerTitle: true,
          elevation: 0.0,
          title: const Text('MIALK', style: TextStyles.appBarTitle),
        ),
        body: SingleChildScrollView(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  VerticalSpacer.standard,
                  // 電話番号
                  PhoneField(useSavedPhoneNumber: true),
                  VerticalSpacer.standard,
                  // ログイン
                  SmsLoginButton(),
                  SizedBox(height: 50.0),
                  Text(
                    '外部アカウントでログイン',
                    style: TextStyles.fieldTitleTextStyle,
                  ),
                  // Sign in with Google
                  GoogleSignInButton(),
                  // Sign in with Apple
                  AppleSignInButton(),
                  // Sign in with Facebook
                  FacebookSignInButton(),
                  // Sign in with Twitter
                  TwitterSignInButton(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

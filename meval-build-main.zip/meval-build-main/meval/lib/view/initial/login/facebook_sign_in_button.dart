import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../const/message.dart';
import '../../../provider/authentication_type_provider.dart';
import '../../../provider/shared_strage_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../view_model/login_view_model.dart';
import '../../component/loading_service.dart';
import '../../component/phone_field.dart';
import 'login_functions.dart';

class FacebookSignInButton extends ConsumerWidget {
  const FacebookSignInButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);

    return SignInButton(
      Buttons.FacebookNew,
      onPressed: () async {
        // SMS認証以外は不要のため、SharedPreferencesから電話番号を削除
        await ref
            .read(sharedPreferencesProvider)
            .remove(SharedPreferenceConst.phoneNumber);
        // 電話番号プロバイダをリフレッシュ
        ref.invalidate(phoneNumberProvider);
        // 電話番号バリデーション成否プロバイダをリフレッシュ
        ref.invalidate(phoneNumberValidProvider);

        // 認証タイプ:Facebook
        ref
            .read(authenticationTypeProvider.notifier)
            .update((_) => AuthenticationType.facebook);

        await _login(ref, navigator);
      },
    );
  }

  Future<void> _login(WidgetRef ref, NavigatorState navigator) async {
    try {
      // loading
      await ref.read(loadingServiceProvider.notifier).wrap(
            // ログイン処理
            ref.read(loginViewModelProvider.notifier).facebookSignIn(),
          );
    } on Exception catch (e) {
      logger.severe(e);
      showErrorToast(DisplayedErrorMessage.loginError);
      rethrow;
    }

    final user = ref.read(loginViewModelProvider);
    if (user == null) {
      // 途中でキャンセルした場合など、ユーザが存在しない場合
      return;
    }

    // ログイン成功時の処理（画面遷移）
    await onSuccessLogin(ref: ref, navigator: navigator);
  }
}

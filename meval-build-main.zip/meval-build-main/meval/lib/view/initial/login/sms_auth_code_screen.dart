import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../component/loading_service.dart';
import '../../style/style.dart';

class SmsAuthCodeScreen extends StatelessWidget {
  final String phoneNumber;

  const SmsAuthCodeScreen({
    Key? key,
    required this.phoneNumber,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        centerTitle: true,
        elevation: 0.0,
        title: const Text(
          'SMS認証',
          style: TextStyle(
            fontSize: 18,
            color: Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 32),
            const Icon(Icons.phone_iphone, size: 48),
            const SizedBox(height: 16),
            Text(
              '$phoneNumber へ確認コードを送信しました。',
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 4),
            const Text(
              'SMSの確認コードを入力してください。',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 32),
            const SmsAuthForm(),
          ],
        ),
      ),
    );
  }
}

class SmsAuthForm extends HookConsumerWidget {
  static const pinCount = 6;
  final space = '\u200B';

  const SmsAuthForm({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controllerListController = useState<List<TextEditingController>>(
        List.generate(pinCount, (index) => TextEditingController()));
    final focusNodeListController = useState<List<FocusNode>>(
        List.generate(pinCount, (index) => FocusNode()));

    final passCodeState = useState('');

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const SizedBox(width: 2),
              ...List.generate(
                pinCount,
                (index) => _buildTextField(
                  controllerListController.value,
                  focusNodeListController.value,
                  index,
                ),
              ),
              const SizedBox(width: 2),
            ],
          ),
          VerticalSpacer.standard,
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () async {
                // loading
                ref.read(loadingServiceProvider.notifier).present();

                final passCode = getPassCode(controllerListController.value);
                passCodeState.value = passCode;
                clearAll(controllerListController.value);
                Navigator.pop(context, passCode);
              },
              child: const Text(
                '認証する',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(List<TextEditingController> controllerList,
      List<FocusNode> focusNodeList, int index) {
    return ConstrainedBox(
      constraints: BoxConstraints.tight(const Size(40, 40)),
      child: TextField(
        controller: controllerList[index],
        keyboardType: TextInputType.number,
        autofocus: index == 0,
        focusNode: focusNodeList[index],
        textAlign: TextAlign.center,
        textAlignVertical: TextAlignVertical.center,
        onChanged: (str) =>
            _onChanged(controllerList, focusNodeList, str, index),
        onTap: () => _onTap(controllerList, index),
        style: const TextStyle(fontSize: 32),
        showCursor: false,
      ),
    );
  }

  void _onChanged(List<TextEditingController> controllerList,
      List<FocusNode> focusNodeList, String str, int index) {
    if (str.length == 1 && str != space) {
      for (final controller in controllerList) {
        controller.text = space;
      }

      if (int.tryParse(str) == null) {
        return;
      }

      controllerList[index].value = TextEditingValue(
        text: space + str,
        selection: const TextSelection.collapsed(offset: 2),
      );

      if (index == pinCount - 1) {
        focusNodeList[index].unfocus();
        return;
      }

      focusNodeList[index + 1].requestFocus();
      return;
    }

    if (str.length == pinCount) {
      str.split('').asMap().forEach((index, value) {
        controllerList[index].value = TextEditingValue(
            text: space + value,
            selection: const TextSelection.collapsed(offset: 2));
      });

      focusNodeList[index].unfocus();
      return;
    }

    if (str.length >= 2) {
      if (int.tryParse(str.substring(str.length - 1, str.length)) == null) {
        controllerList[index].value = TextEditingValue(
          text: space,
          selection: const TextSelection.collapsed(offset: 1),
        );
        return;
      }

      if (str.length > 2) {
        final newStr = space + str.substring(str.length - 1, str.length);

        controllerList[index].value = TextEditingValue(
          text: newStr,
          selection: const TextSelection.collapsed(offset: 2),
        );
      }

      if (index < pinCount - 1) {
        focusNodeList[index + 1].requestFocus();
      } else if (index == pinCount - 1) {
        focusNodeList[index].unfocus();
      }

      return;
    }

    if (str.length == 1 && str == space && index != 0) {
      focusNodeList[index - 1].requestFocus();
      return;
    }

    if (str.isEmpty) {
      controllerList[index].value = TextEditingValue(
          text: space, selection: const TextSelection.collapsed(offset: 1));

      if (index != 0) {
        focusNodeList[index - 1].requestFocus();
      }
    }
  }

  void _onTap(List<TextEditingController> controllerList, int index) {
    controllerList[index].selection =
        TextSelection.collapsed(offset: controllerList[index].text.length);
  }

  void clearAll(List<TextEditingController> controllerList) {
    for (final e in controllerList) {
      e.clear();
    }
  }

  String getPassCode(List<TextEditingController> controllerList) =>
      controllerList.fold<String>(
        '',
        (pre, e) {
          if (e.text.length < 2) {
            return pre;
          }
          return pre + e.text.substring(1, 2);
        },
      );
}

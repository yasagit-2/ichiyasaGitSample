import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/shared_strage_provider.dart';
import '../../../view_model/member_view_model.dart';
import '../../content/content_root_screen.dart';
import '../tos/root_tos_screen.dart';

Future<void> onSuccessLogin({
  required WidgetRef ref,
  required NavigatorState navigator,
  String? phoneNumber,
}) async {
  // 会員情報
  final currentMember =
      await ref.read(memberViewModelProvider.notifier).getCurrentMember();

  if (phoneNumber != null) {
    // 電話番号をデバイス内に保存
    await ref
        .read(sharedPreferencesProvider)
        .setString(SharedPreferenceConst.phoneNumber, phoneNumber);
  } else {
    // 電話番号を削除
    await ref
        .read(sharedPreferencesProvider)
        .remove(SharedPreferenceConst.phoneNumber);
  }

  if (currentMember == null) {
    // 会員登録未済時の処理
    await _pushRegisterScreen(navigator);
  } else {
    // 会員登録済みの場合の処理
    await _pushRootScreen(navigator);
  }
}

/// [RootTosScreen]へ画面遷移します。
Future<void> _pushRegisterScreen(NavigatorState navigatorState) async {
  navigatorState.context.go(RootTosScreen.path);
}

/// [ContentRootScreen]へ画面遷移します。
Future<void> _pushRootScreen(NavigatorState navigatorState) async {
  navigatorState.context.go(ContentRootScreen.path);
}

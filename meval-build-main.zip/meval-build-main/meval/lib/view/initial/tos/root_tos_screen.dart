import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:meval/provider/settings_provider.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../../provider/app_version_provider.dart';
import '../../../view_model/login_view_model.dart';
import '../../component/cancel_to_top_button.dart';
import '../../component/loading_service.dart';
import '../../style/style.dart';
import '../login/login_screen.dart';
import '../register/register_screen.dart';
import 'privacy_policy_screen.dart';
import 'tos_screen.dart';

// 規約同意プロバイダ
final isAgreeTosProvider = StateProvider.autoDispose<bool>((ref) => false);

// プライバシーポリシー同意プロバイダ
final isAgreePrivacyPolicyProvider =
    StateProvider.autoDispose<bool>((ref) => false);

// 全規約同意プロバイダ
final agreeProvider = Provider.autoDispose<bool>((ref) =>
    ref.watch(isAgreeTosProvider) && ref.watch(isAgreePrivacyPolicyProvider));

/// Terms of Service
class RootTosScreen extends HookConsumerWidget {
  static String path = '/rootTos';

  const RootTosScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      // loading解除
      Future.microtask(
          () => ref.read(loadingServiceProvider.notifier).dismiss());
      return null;
    }, []);

    // 認証状態(Watcher)
    final authWatcher = ref.watch(authStateChangesProvider);

    if (authWatcher is AsyncLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (authWatcher is AsyncError || authWatcher.value == null) {
      // ログイン画面へ
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.go(LoginScreen.path);
      });
    }

    // メンテナンス
    final maintenanceAsyncValue = ref.watch(maintenanceStreamProvider);
    if (maintenanceAsyncValue is! AsyncData ||
        maintenanceAsyncValue.value == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final maintenance = maintenanceAsyncValue.value!;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // メンテナンスチェック
      await maintenanceCheck(context, ref, maintenance);
      if (maintenance.isMaintenance) {
        return;
      }

      // バージョンチェック
      await appVersionCheck(context, ref, maintenance);
    });

    final isAgree = ref.watch(agreeProvider);
    // 設定情報
    final settingWatcher = ref.watch(settingsStreamProvider);

    // プライバシーポリシーのURLを取得
    final privacyPolicyUrl = settingWatcher.value?.privacyPolicyUrl ?? "";

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).canvasColor,
          centerTitle: true,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          title: const Text('利用規約', style: TextStyles.appBarTitle),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                children: [
                  Checkbox(
                      value: ref.watch(isAgreeTosProvider),
                      onChanged: (value) => ref
                          .watch(isAgreeTosProvider.notifier)
                          .update((_) => value!)),
                  SelectableText.rich(
                    const TextSpan(children: [
                      TextSpan(
                        text: '利用規約',
                        style: TextStyle(
                          color: Colors.blue,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      TextSpan(text: 'に同意します。'),
                    ]),
                    onTap: () => _pushTosScreen(context),
                  ),
                ],
              ),
              Row(
                children: [
                  Checkbox(
                      value: ref.watch(isAgreePrivacyPolicyProvider),
                      onChanged: (value) => ref
                          .watch(isAgreePrivacyPolicyProvider.notifier)
                          .update((_) => value!)),
                  SelectableText.rich(
                    const TextSpan(children: [
                      TextSpan(
                        text: 'プライバシーポリシー',
                        style: TextStyle(
                          color: Colors.blue,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      TextSpan(text: 'に同意します。'),
                    ]),
                    onTap: () => launchUrlString(privacyPolicyUrl,
                        mode: LaunchMode.externalApplication),
                  ),
                ],
              ),
              VerticalSpacer.standard,
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    onPressed: isAgree ? () => _agree(context) : null,
                    child:
                        const Text('同意する', style: TextStyles.buttonTextStyle)),
              ),
              VerticalSpacer.standard,
              const CancelToTopButton(buttonTitle: '同意せずにトップへ戻る'),
            ],
          ),
        ),
      ),
    );
  }

  /// 全ての規約に同意した場合の処理を行います。
  /// [RegisterScreen]へ遷移します。
  _agree(BuildContext context) {
    context.goNamed(RegisterScreen.name);
  }

  /// [TosScreen]へ遷移します。
  _pushTosScreen(BuildContext context) {
    context.goNamed(TosScreen.registerName);
  }

  /// [PrivacyPolicyScreen]へ遷移します。
  _pushPrivacyPolicyScreen(BuildContext context) {
    context.goNamed(PrivacyPolicyScreen.registerName);
  }
}

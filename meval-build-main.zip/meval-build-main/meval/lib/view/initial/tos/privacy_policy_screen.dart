import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../../style/style.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  static String path = 'privacyPolicy';
  static String registerName = 'registerPrivacyPolicy';
  static String contentName = 'contentPrivacyPolicy';

  const PrivacyPolicyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        centerTitle: true,
        elevation: 0.0,
        title: const Text('プライバシーポリシー', style: TextStyles.appBarTitle),
      ),
      body: FutureBuilder(
          future: rootBundle.loadString("assets/tos/privacy_policy.md"),
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            if (snapshot.hasData) {
              return Markdown(data: snapshot.data!);
            }

            return const Center(
              child: CircularProgressIndicator(),
            );
          }),
    );
  }
}

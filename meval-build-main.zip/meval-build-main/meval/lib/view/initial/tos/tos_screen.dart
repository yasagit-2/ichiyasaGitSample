import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../../style/style.dart';

class TosScreen extends StatelessWidget {
  static String path = 'tos';
  static String registerName = 'registerTos';
  static String contentName = 'contentTos';

  const TosScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        centerTitle: true,
        elevation: 0.0,
        title: const Text('利用規約', style: TextStyles.appBarTitle),
      ),
      body: FutureBuilder(
          future: rootBundle.loadString("assets/tos/terms_of_service.md"),
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            if (snapshot.hasData) {
              return Markdown(data: snapshot.data!);
            }

            return const Center(
              child: CircularProgressIndicator(),
            );
          }),
    );
  }
}

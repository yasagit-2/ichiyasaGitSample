import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lottie/lottie.dart';

import '../../const/constant.dart';
import '../../foundation/constants.dart';
import '../../provider/app_version_provider.dart';
import '../../provider/authentication_type_provider.dart';
import '../../provider/event_provider.dart';
import '../../provider/location_provider.dart';
import '../../provider/notification_provider.dart';
import '../../provider/screen_type_provider.dart';
import '../../provider/settings_provider.dart';
import '../../provider/steps_provider.dart';
import '../../provider/summary_provider.dart';
import '../../util/logger.dart';
import '../../util/analytics_util.dart';
import '../../view_model/login_view_model.dart';
import '../../view_model/member_view_model.dart';
import '../component/loading_service.dart';
import '../initial/login/login_screen.dart';
import 'fade_indexed_stack.dart';
import 'home/home_screen.dart';
import 'my_page/my_page_screen.dart';
import 'record/record_screen.dart';
import 'search/search_screen.dart';
import 'spend/spend_screen.dart';

class ContentRootScreen extends HookConsumerWidget {
  static String path = '/contentRoot';
  static String name = 'contentRoot';

  const ContentRootScreen({Key? key}) : super(key: key);

  static const List<Widget> _screenList = <Widget>[
    HomeScreen(),
    SearchScreen(),
    RecordScreen(),
    SpendScreen(),
    MyPageScreen(),
  ];

  static const _destinations = [
    NavigationDestination(icon: FaIcon(FontAwesomeIcons.home), label: 'ホーム'),
    NavigationDestination(
        icon: FaIcon(FontAwesomeIcons.searchLocation), label: '探索'),
    NavigationDestination(
        icon: FaIcon(FontAwesomeIcons.fileSignature), label: '記録'),
    NavigationDestination(icon: FaIcon(FontAwesomeIcons.coins), label: 'つかう'),
    NavigationDestination(icon: Icon(Icons.person), label: 'マイページ'),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    logger.fine('ContentRootScreen');
    if (Constants.flavor != Flavor.robo) {
      useEffect(() {
        Future.microtask(() async {
          // 位置情報使用許可
          final isPermitToUseLocation =
              await ref.watch(locationProvider).checkPermission();
          logger.fine('isPermitToUseLocation=$isPermitToUseLocation');

          // 位置情報使用許可の状態を更新
          ref
              .watch(permissionProvider.notifier)
              .update((_) => isPermitToUseLocation);

          // デバイス情報更新
          await ref.watch(memberViewModelProvider.notifier).updateDeviceInfo();

          // 歩数プロバイダをリフレッシュし、歩数へのアクセス許可を求める
          ref.invalidate(stepsOfTodayProvider);

          // loading解除
          ref.read(loadingServiceProvider.notifier).dismiss();
        });

        // ステータスバーの文字色を設定
        SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle.dark.copyWith(
            // Android
            statusBarColor: Colors.white,
            // iOS
            statusBarBrightness: Brightness.light,
          ),
        );

        return null;
      }, []);

      // 認証済みカレントユーザのリロード
      currentUserReloadForBuild(context, ref);

      // 会員
      final memberAsyncValue = ref.watch(memberStreamProvider);

      // アプリケーション設定
      final settingsAsyncValue = ref.watch(settingsStreamProvider);
      // 投稿アイコン設定
      final postIconsAsyncValue = ref.watch(postIconsStreamProvider);

      final totalCheckedInParentBasesAsyncValue =
          ref.watch(totalCheckedInParentBasesStreamProvider);
      final totalCheckedInSubBasesAsyncValue =
          ref.watch(totalCheckedInSubBasesStreamProvider);
      final totalCompletedTitlesAsyncValue =
          ref.watch(totalCompletedTitlesStreamProvider);
      final totalMemberAsyncValue = ref.watch(totalMemberStreamProvider);
      final notificationsAsyncValue = ref.watch(notificationsStreamProvider);
      final eventsAsyncValue = ref.watch(eventStreamProvider);

      // メンテナンス
      final maintenanceAsyncValue = ref.watch(maintenanceStreamProvider);

      // 各種プロバイダのロードを待つ
      if (settingsAsyncValue is! AsyncData ||
          postIconsAsyncValue is! AsyncData ||
          memberAsyncValue is! AsyncData ||
          maintenanceAsyncValue is! AsyncData ||
          totalCheckedInParentBasesAsyncValue is! AsyncData ||
          totalCheckedInSubBasesAsyncValue is! AsyncData ||
          totalCompletedTitlesAsyncValue is! AsyncData ||
          totalMemberAsyncValue is! AsyncData ||
          notificationsAsyncValue is! AsyncData ||
          eventsAsyncValue is! AsyncData ||
          settingsAsyncValue.value == null ||
          maintenanceAsyncValue.value == null) {
        return Scaffold(body: Center(child: Lottie.asset(Const.lottieLoading)));
      }

      final setting = settingsAsyncValue.value!;
      final member = memberAsyncValue.value;
      final maintenance = maintenanceAsyncValue.value!;

      if (member == null) {
        // 会員が存在しない場合、ログアウトしてログイン画面へ
        _goToLogin(context, ref);

        return const Scaffold(
          backgroundColor: Colors.black,
        );
      }

      // ログインイベント出力
      AnalyticsUtil.login(ref, member);

      // 投稿アイコン設定（投稿アイコン設定は省略可能、nullの可能性あり）
      final postIcons = postIconsAsyncValue.value;

      WidgetsBinding.instance.addPostFrameCallback((_) async {
        // アプリケーション設定プロバイダを更新
        ref.watch(settingsStateProvider.notifier).update((_) => setting);
        // 投稿アイコン設定プロバイダを更新
        ref.watch(postIconsStateProvider.notifier).update((_) => postIcons);
        // 認証タイププロバイダを会員情報の認証タイプにて更新
        ref
            .watch(authenticationTypeProvider.notifier)
            .update((_) => member.authenticationProvider);

        // メンテナンスチェック
        await maintenanceCheck(context, ref, maintenance);
        if (maintenance.isMaintenance) {
          return;
        }

        // バージョンチェック
        await appVersionCheck(context, ref, maintenance);
      });
    }
    final screenType = ref.watch(screenTypeProvider);

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: FadeIndexedStack(
          index: screenType.index,
          children: _screenList,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: screenType.index,
          destinations: _destinations,
          onDestinationSelected: (index) {
            ref
                .watch(screenTypeProvider.notifier)
                .update((_) => ScreenType.values[index]);
          },
        ),
      ),
    );
  }

  /// ログアウトしてログイン画面へ遷移します。
  void _goToLogin(BuildContext context, WidgetRef ref) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await showOkAlertDialog(
        context: context,
        title: '再ログインしてください',
        message: '会員情報を確認できないため、ログイン画面へ戻ります',
      );

      refreshStateForLogout(ref);
      await ref.watch(loginViewModelProvider.notifier).logout();
      context.go(LoginScreen.path);
    });
  }
}

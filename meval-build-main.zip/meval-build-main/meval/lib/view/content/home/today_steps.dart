import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/screen_type_provider.dart';
import '../../../provider/steps_provider.dart';
import '../../style/style.dart';

class TodaySteps extends ConsumerWidget {
  const TodaySteps({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    int? steps;
    bool isLoading = true;

    final stepsAsyncValue = ref.watch(stepsOfTodayProvider);
    if (stepsAsyncValue is AsyncData) {
      isLoading = false;
      steps = stepsAsyncValue.value;
    }

    String? formattedSteps;
    if (steps != null) {
      // 3桁ごとのカンマ区切りフォーマット
      formattedSteps = Const.numberFormatter.format(steps);
    }

    return Material(
      color: AppColors.mainColor,
      borderRadius: BorderRadius.circular(10.0),
      elevation: 8.0,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: InkWell(
          splashColor: Colors.blueGrey,
          onTap: () {
            // 画面タイプを記録画面へ変更
            ref
                .read(screenTypeProvider.notifier)
                .update((_) => ScreenType.record);
            // 記録画面のタブタイプをウォークタブへ変更
            ref
                .read(recordTabTypeProvider.notifier)
                .update((_) => RecordTabType.walk);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            textBaseline: TextBaseline.alphabetic,
            children: [
              HorizontalSpacer.smallish,
              const FaIcon(
                FontAwesomeIcons.walking,
                size: 36.0,
                color: Colors.white,
              ),
              const Expanded(child: SizedBox()),
              isLoading
                  ? const SizedBox(
                      height: 58.0,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )
                  : _stepsWidget(formattedSteps),
            ],
          ),
        ),
      ),
    );
  }

  /// 歩数表示のためのWidgetを構築します。
  /// [formattedSteps]=nullの場合、歩数を表示できない旨のメッセージを表示します。
  Widget _stepsWidget(String? formattedSteps) {
    if (formattedSteps == null) {
      return const SizedBox(
        height: 58.0,
        child: Align(
          alignment: Alignment.center,
          child: Text(
            '（歩数を表示できません）',
            style: TextStyle(
              fontSize: 20.0,
              color: Colors.white,
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        Text(
          formattedSteps,
          style: const TextStyle(
            fontSize: 36.0,
            color: Colors.white,
          ),
        ),
        const SizedBox(width: 8.0),
        const Text(
          '歩',
          style: TextStyle(
            fontSize: 32.0,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}

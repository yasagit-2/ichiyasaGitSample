import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../const/constant.dart';
import '../../../../model/data/event.dart';
import '../../../../provider/event_provider.dart';
import '../../../../provider/screen_type_provider.dart';
import '../../../style/style.dart';
import '../../record/tab/event/event_map_screen.dart';

class SlideEvent extends ConsumerWidget {
  const SlideEvent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // イベント
    final eventsAsyncValue = ref.watch(eventStreamProvider);
    if (eventsAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final events = eventsAsyncValue.value;
    if (events == null || events.isEmpty) {
      // イベントなし
      return const SizedBox();
    }

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        return Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Text(
                  'イベント',
                  style: TextStyle(fontSize: 24.0),
                ),
                const Expanded(child: SizedBox()),
                InkWell(
                  splashColor: AppColors.splashColor,
                  child: const Text(
                    '一覧',
                    style: TextStyle(fontSize: 20.0, color: Colors.blueAccent),
                  ),
                  onTap: () {
                    // 画面タイプを記録画面へ変更
                    ref
                        .read(screenTypeProvider.notifier)
                        .update((_) => ScreenType.record);
                    // 記録画面のタブタイプをイベントタブへ変更
                    ref
                        .read(recordTabTypeProvider.notifier)
                        .update((_) => RecordTabType.event);
                  },
                ),
                HorizontalSpacer.standard,
              ],
            ),
            SizedBox(
              height: 110.0,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: events.length < Const.slideLimit
                    ? events.length
                    : Const.slideLimit,
                itemBuilder: (context, index) {
                  // イベント
                  final event = events[index];

                  return SizedBox(
                    width: 150.0,
                    child: Card(
                      color: Colors.white,
                      elevation: 8.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        side: const BorderSide(
                          color: Colors.grey,
                          width: 0.5,
                        ),
                      ),
                      child: InkWell(
                        splashColor: AppColors.splashColor,
                        onTap: () {
                          // イベントマップへ
                          context.goNamed(EventMapScreen.nameFromTop,
                              extra: event.id);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // イベント画像
                                _eventImage(event),
                                // イベントタイトル
                                _eventTitle(event, now),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  /// イベント画像のWidgetを生成します。
  Widget _eventImage(Event event) {
    final imageUrl = event.imageUrl;
    if (imageUrl == null) {
      // イベント画像なし
      return const SizedBox();
    }

    return CachedNetworkImage(
      height: 60.0,
      imageUrl: imageUrl,
    );
  }

  /// イベントタイトルのWidgetを生成します。
  Widget _eventTitle(Event event, DateTime now) {
    final isEnd = now.compareTo(event.effectivePeriodEnd) > 0;

    final imageUrl = event.imageUrl;
    if (imageUrl == null) {
      if (isEnd) {
        // イベント期間終了
        return RichText(
          overflow: TextOverflow.ellipsis,
          maxLines: 4,
          textAlign: TextAlign.center,
          text: TextSpan(
            children: [
              const TextSpan(
                text: '※終了\n',
                style: TextStyle(color: Colors.red, fontFamily: regularFont),
              ),
              TextSpan(
                text: event.title,
                style: const TextStyle(
                    color: Colors.black, fontFamily: regularFont),
              ),
            ],
          ),
        );
      }
      return Text(
        event.title,
        overflow: TextOverflow.ellipsis,
        maxLines: 3,
      );
    }

    if (isEnd) {
      return RichText(
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        text: TextSpan(
          children: [
            const TextSpan(
              text: '※終了 ',
              style: TextStyle(
                  color: Colors.red, fontSize: 12.0, fontFamily: regularFont),
            ),
            TextSpan(
              text: event.title,
              style: const TextStyle(
                  color: Colors.black, fontSize: 12.0, fontFamily: regularFont),
            ),
          ],
        ),
      );
    }

    return Text(
      event.title,
      overflow: TextOverflow.ellipsis,
      maxLines: 1,
      style: const TextStyle(fontSize: 12.0),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/summary_provider.dart';
import '../../style/style.dart';

class Rank extends ConsumerWidget {
  const Rank({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 会員数
    final totalMemberAsyncValue = ref.watch(totalMemberStreamProvider);
    // ランキング
    final rankStreamAsyncValue = ref.watch(rankStreamProvider);

    if (rankStreamAsyncValue is AsyncError) {
      // ランキングは会員登録時にCloud Functionsが生成する。
      // これにより、会員登録直後は当該会員のrankingsコレクションのドキュメントが存在しない状態となる。
      // Firestoreのセキュリティルールは、自身のランキングのみ参照許可を与えているため、
      // ドキュメントが存在しない状態での参照はセキュリティルールに弾かれて異常が発生する。
      // そのため、ランキングストリームプロバイダで異常が発生した場合は、
      // ランキングの生成を待ちプロバイダをリフレッシュして再取得を行う。
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await Future.delayed(Duration(seconds: Const.timeoutSec));
        ref.invalidate(rankStreamProvider);
      });
    }

    bool isLoading = true;
    if (totalMemberAsyncValue is AsyncData &&
        rankStreamAsyncValue is AsyncData) {
      isLoading = false;
    }

    String totalMember = '';
    if (!isLoading && totalMemberAsyncValue.value! != 0) {
      totalMember = totalMemberAsyncValue.value.toString();
    }

    // 一つもサブ拠点へチェックインしていない場合、順位には「?」を表示
    String ranking = '?';
    if (!isLoading && rankStreamAsyncValue.value! != 0) {
      ranking = rankStreamAsyncValue.value.toString();
    }

    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              ranking,
              style: TextStyle(
                fontSize: 36.0,
                color: AppColors.mainColor,
              ),
            ),
            Text(
              ' 位',
              style: TextStyle(
                fontSize: 24.0,
                color: AppColors.mainColor,
              ),
            ),
            Text(
              ' / ',
              style: TextStyle(
                fontSize: 24.0,
                color: AppColors.mainColor,
              ),
            ),
            Text(
              totalMember,
              style: TextStyle(
                fontSize: 24.0,
                color: AppColors.mainColor,
              ),
            ),
            Text(
              ' 人中',
              style: TextStyle(
                fontSize: 18.0,
                color: AppColors.mainColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../provider/event_provider.dart';
import '../../../provider/notification_provider.dart';
import '../../../provider/steps_provider.dart';
import '../../style/style.dart';
import 'event/slide_event.dart';
import 'notification/slide_notification.dart';
import 'summary.dart';
import 'today_steps.dart';
import 'user_information.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          backgroundColor: Theme.of(context).canvasColor,
          automaticallyImplyLeading: false,
          elevation: 0.0,
        ),
      ),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          CupertinoSliverRefreshControl(
            onRefresh: () async {
              // 歩数プロバイダをリフレッシュし歩数を再取得
              ref.invalidate(stepsOfTodayProvider);
              // お知らせリストストリームプロバイダをリフレッシュしお知らせを再取得
              ref.invalidate(notificationsStreamProvider);
              // イベントリストストリームプロバイダをリフレッシュしイベントを再取得
              ref.invalidate(eventStreamProvider);
            },
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: const [
                    // ユーザ情報
                    UserInformation(),
                    VerticalSpacer.separator,
                    // 概要
                    Summary(),
                    VerticalSpacer.separator,
                    // 歩数
                    TodaySteps(),
                    VerticalSpacer.separator,
                    // お知らせ
                    SlideNotification(),
                    VerticalSpacer.separator,
                    // イベント
                    SlideEvent(),
                  ],
                ),
              ),
              childCount: 1,
            ),
          ),
        ],
      ),
    );
  }
}

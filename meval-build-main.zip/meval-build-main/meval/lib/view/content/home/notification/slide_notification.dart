import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../const/constant.dart';
import '../../../../provider/notification_provider.dart';
import '../../../style/style.dart';
import 'notification_content_screen.dart';
import 'notification_list_screen.dart';

class SlideNotification extends ConsumerWidget {
  const SlideNotification({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // お知らせリスト
    final notificationsAsyncValue = ref.watch(notificationsStreamProvider);
    if (notificationsAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final notifications = notificationsAsyncValue.value;
    if (notifications == null || notifications.isEmpty) {
      // お知らせなし
      return const SizedBox();
    }

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        // お知らせ表示期間
        final displayNotifications = notifications.where((memberNotification) {
          return memberNotification.effectivePeriodBegin.compareTo(now) <= 0 &&
              now.compareTo(memberNotification.effectivePeriodEnd) <= 0;
        }).toList();

        if (displayNotifications.isEmpty) {
          // 表示すべきお知らせが存在しない
          return const SizedBox();
        }

        return Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Text(
                  'お知らせ',
                  style: TextStyle(fontSize: 24.0),
                ),
                const Expanded(child: SizedBox()),
                InkWell(
                  splashColor: AppColors.splashColor,
                  onTap: () {
                    // お知らせ一覧へ
                    context.goNamed(NotificationListScreen.name);
                  },
                  child: const Text(
                    '一覧',
                    style: TextStyle(fontSize: 20.0, color: Colors.blueAccent),
                  ),
                ),
                HorizontalSpacer.standard,
              ],
            ),
            SizedBox(
              height: 100.0,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: displayNotifications.length < Const.slideLimit
                    ? displayNotifications.length
                    : Const.slideLimit,
                itemBuilder: (context, index) {
                  final notification = displayNotifications[index];
                  return SizedBox(
                    width: 150.0,
                    child: Card(
                      color: Colors.white,
                      elevation: 8.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        side: const BorderSide(
                          color: Colors.grey,
                          width: 0.5,
                        ),
                      ),
                      child: InkWell(
                        splashColor: AppColors.splashColor,
                        onTap: () {
                          final contentUrl = notification.contentUrl;
                          if (contentUrl != null) {
                            // お知らせコンテンツへ
                            context.goNamed(
                                NotificationContentScreen.nameFromTop,
                                extra: notification);
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                            // お知らせタイトル
                            child: Text(
                              notification.title,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 3,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

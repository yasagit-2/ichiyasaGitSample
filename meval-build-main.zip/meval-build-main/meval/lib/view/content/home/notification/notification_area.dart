import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../const/constant.dart';
import '../../../../model/data/member_notification.dart';
import '../../../../provider/notification_provider.dart';
import '../../../style/style.dart';
import '../../content_root_screen.dart';
import 'notification_content_screen.dart';

class NotificationArea extends ConsumerWidget {
  const NotificationArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // お知らせリスト
    final notificationsAsyncValue = ref.watch(notificationsStreamProvider);
    ref.listen(notificationsStreamProvider, (previous, next) {
      if (next is AsyncData) {
        if (next.value == null || next.value!.isEmpty) {
          // 一覧表示すべきお知らせ存在しない場合、コンテンツルートへ戻る
          // （お知らせ一覧表示中にお知らせが削除されるケースを考慮したもの）
          context.goNamed(ContentRootScreen.name);
        }
      }
    });

    if (notificationsAsyncValue is! AsyncData) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final notifications = notificationsAsyncValue.value;
    if (notifications == null || notifications.isEmpty) {
      return const SizedBox();
    }

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        // お知らせ表示期間
        final displayNotifications = notifications.where((memberNotification) {
          return memberNotification.effectivePeriodBegin.compareTo(now) <= 0 &&
              now.compareTo(memberNotification.effectivePeriodEnd) <= 0;
        }).toList();

        if (displayNotifications.isEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            // 表示すべきお知らせが存在しない場合、コンテンツルートへ
            context.goNamed(ContentRootScreen.name);
          });
        }

        return ListView.separated(
          itemCount: displayNotifications.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (BuildContext context, int index) {
            return const SizedBox(height: 5.0);
          },
          itemBuilder: (BuildContext context, int index) {
            final notification = displayNotifications[index];
            return _listArea(context, notification);
          },
        );
      },
    );
  }

  /// お知らせリスト1件分の表示Widgetを構築します。
  Widget _listArea(BuildContext context, MemberNotification notification) {
    // お知らせ表示期間
    final effectivePeriod =
        '${Const.dateFormat.format(notification.effectivePeriodBegin)} 〜';

    return SizedBox(
      width: double.infinity,
      height: 85,
      child: Material(
        elevation: 8.0,
        child: InkWell(
          splashColor: AppColors.splashColor,
          onTap: () {
            // お知らせコンテンツへ
            final contentUrl = notification.contentUrl;
            if (contentUrl != null) {
              context.goNamed(NotificationContentScreen.nameFromList,
                  extra: notification);
            }
          },
          child: Container(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(
                  top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // お知らせ表示期間
                        Text(effectivePeriod),
                        // お知らせタイトル
                        Text(
                          notification.title,
                          style: const TextStyle(fontSize: 18.0),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ],
                    ),
                  ),
                  notification.contentUrl == null
                      ? const SizedBox()
                      : const Icon(Icons.navigate_next),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

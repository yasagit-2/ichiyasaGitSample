import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../view_model/member_view_model.dart';
import '../../style/style.dart';

class UserInformation extends ConsumerWidget {
  const UserInformation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final memberAsyncValue = ref.watch(memberStreamProvider);
    if (memberAsyncValue is! AsyncData || memberAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final member = memberAsyncValue.value!;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // ホーム画面でのID表示を非表示にする
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   children: [
        //     SelectableText('ID : ${member.id}'),
        //   ],
        // ),
        // VerticalSpacer.smallish,
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Flexible(
              child: Text(
                member.nickname,
                style: TextStyles.userNameTextStyle,
                // maxLines: 2,
              ),
            ),
            const Text('さん'),
          ],
        ),
      ],
    );
  }
}

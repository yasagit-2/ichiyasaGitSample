import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../provider/summary_provider.dart';

class AchievedTitles extends ConsumerWidget {
  const AchievedTitles({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 獲得済み称号総数
    final totalCompletedTitlesAsyncValue =
        ref.watch(totalCompletedTitlesStreamProvider);

    bool isLoading = true;
    if (totalCompletedTitlesAsyncValue is AsyncData) {
      isLoading = false;
    }

    String achievedTitles = '';
    if (!isLoading) {
      // チェックイン済み親拠点総数
      achievedTitles = totalCompletedTitlesAsyncValue.value!.toString();
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        const SizedBox(width: 32.0),
        const Expanded(
          flex: 2,
          child: Text(
            '称号',
            style: TextStyle(
              fontSize: 24.0,
              color: Colors.white,
            ),
          ),
        ),
        Expanded(
          flex: 3,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                achievedTitles,
                style: const TextStyle(
                  height: 1.3,
                  fontSize: 36.0,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 12.0),
              const Text(
                '制覇',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8.0),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/screen_type_provider.dart';
import '../../style/style.dart';
import 'achieved_bases.dart';
import 'achieved_sub_bases.dart';
import 'achieved_titles.dart';
import 'rank.dart';

class Summary extends ConsumerWidget {
  const Summary({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      onTap: () {
        // 記録画面へ
        ref.watch(screenTypeProvider.notifier).update((_) => ScreenType.record);
        // 拠点タブへ
        ref
            .watch(recordTabTypeProvider.notifier)
            .update((_) => RecordTabType.base);
      },
      child: Stack(
        children: [
          const Center(
            child: SizedBox(
              height: 130.0,
              width: 130.0,
              child: Image(image: AssetImage(Const.logo)),
            ),
          ),
          Material(
            color: AppColors.mainColor.withOpacity(0.8),
            borderRadius: BorderRadius.circular(10.0),
            elevation: 8.0,
            child: Column(
              children: const [
                // 拠点
                AchievedBases(),
                // サブ拠点
                AchievedSubBases(),
                // 称号
                AchievedTitles(),
                // 順位
                Rank(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

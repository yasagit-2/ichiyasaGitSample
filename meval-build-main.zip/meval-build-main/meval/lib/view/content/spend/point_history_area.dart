import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../model/data/point.dart';
import '../../../provider/spend_provider.dart';
import '../../style/style.dart';
import 'completed_base_area.dart';
import 'completed_coupon_area.dart';
import 'completed_event_area.dart';
import 'completed_title_area.dart';

class PointHistoryArea extends ConsumerWidget {
  const PointHistoryArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ポイント獲得履歴のリスト
    final pointHistoriesAsyncValue = ref.watch(pointHistoriesStreamProvider);

    if (pointHistoriesAsyncValue is! AsyncData ||
        pointHistoriesAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final pointHistories = pointHistoriesAsyncValue.value!;

    return ListView.separated(
      itemCount: pointHistories.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (BuildContext context, int index) => const Divider(
        color: Colors.grey,
      ),
      itemBuilder: (BuildContext context, int index) {
        // ポイント獲得履歴
        final pointHistory = pointHistories[index];
        // ポイント獲得履歴の登録日時
        final createdAt = pointHistory.createdAt;

        return SizedBox(
          width: double.infinity,
          height: 75,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ポイント獲得アクティビティごとのアイコン生成
              SizedBox(
                width: 20.0,
                child: _iconSelect(pointHistory),
              ),
              HorizontalSpacer.standard,
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  createdAt == null
                      ? const SizedBox()
                      : Text(Const.dateAndTimeFormat.format(createdAt)),
                  // ポイント獲得アクティビティ
                  _activitySelect(pointHistory),
                ],
              ),
              const Expanded(child: SizedBox()),
              // 獲得ポイント
              pointHistory.completedCouponRef == null
                  ? _point(pointHistory, true)
                  : _point(pointHistory, false),
            ],
          ),
        );
      },
    );
  }

  /// ポイント獲得アクティビティごとのアイコンWidgetを生成し返却します。
  Widget _iconSelect(PointHistory postHistory) {
    final color = Colors.lightBlue.shade900;
    if (postHistory.completedParentBaseRef != null) {
      // 拠点制覇
      return FaIcon(FontAwesomeIcons.fortAwesome, color: color);
    } else if (postHistory.completedTitleRef != null) {
      // 称号獲得
      return FaIcon(FontAwesomeIcons.trophy, color: color);
    } else if (postHistory.answeredQuestionnaireRef != null) {
      // アンケート回答
      return FaIcon(FontAwesomeIcons.solidListAlt, color: color);
    } else if (postHistory.completedWalkRef != null) {
      // ウォーク達成
      return FaIcon(FontAwesomeIcons.walking, color: color);
    } else if (postHistory.completedEventRef != null) {
      // イベント達成
      return FaIcon(FontAwesomeIcons.stamp, color: color);
    } else if (postHistory.completedCouponRef != null) {
      // クーポン獲得
      return FaIcon(FontAwesomeIcons.ticketAlt, color: color);
    } else {
      throw UnsupportedError('ポイント履歴には、その履歴の元となったアクティビティが必ず一つだけ存在します。');
    }
  }

  /// ポイント獲得アクティビティごとの表示文言Widgetを生成し返却します。
  Widget _activitySelect(PointHistory postHistory) {
    const style = TextStyle(fontSize: 18.0);

    // 拠点制覇情報のリファレンス
    final completedParentBaseRef = postHistory.completedParentBaseRef;
    // 称号獲得情報のリファレンス
    final completedTitleRef = postHistory.completedTitleRef;
    // アンケート回答情報のリファレンス
    final answeredQuestionnaireRef = postHistory.answeredQuestionnaireRef;
    // ウォーク達成情報のリファレンス
    final completedWalkRef = postHistory.completedWalkRef;
    // イベント達成情報のリファレンス
    final completedEventRef = postHistory.completedEventRef;
    // クーポン獲得情報のリファレンス
    final completedCouponRef = postHistory.completedCouponRef;

    if (completedParentBaseRef != null) {
      // 拠点制覇
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('拠点COMPLETE', style: style),
          // 拠点名
          CompletedBaseArea(completedBaseId: completedParentBaseRef.id),
        ],
      );
    } else if (completedTitleRef != null) {
      // 称号獲得
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('称号獲得', style: style),
          // 称号名
          CompletedTitleArea(completedTitleId: completedTitleRef.id),
        ],
      );
    } else if (answeredQuestionnaireRef != null) {
      // アンケート回答
      return const Text('アンケート回答', style: style);
    } else if (completedWalkRef != null) {
      // ウォーク達成
      return const Text('ウォーク達成', style: style);
    } else if (completedEventRef != null) {
      // イベント達成
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('イベント達成', style: style),
          // イベントタイトル
          CompletedEventArea(completedEventId: completedEventRef.id),
        ],
      );
    } else if (completedCouponRef != null) {
      // クーポン獲得
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('クーポン交換', style: style),
          // クーポン名称
          CompletedCouponArea(completedCouponId: completedCouponRef.id),
        ],
      );
    } else {
      throw UnsupportedError('ポイント履歴には、その履歴の元となったアクティビティが必ず一つだけ存在します。');
    }
  }

  /// ポイント数のWidgetを生成し返却します。
  Widget _point(PointHistory postHistory, bool isPositive) {
    TextStyle pointStyle = TextStyle(
      fontSize: 32.0,
      color: Colors.lightBlue.shade900,
    );

    final textStyle = TextStyle(
      fontSize: 16.0,
      height: 0.8,
      color: Colors.lightBlue.shade900,
    );

    if (postHistory.point == 0) {
      // 0pt獲得用の表示

      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text('0', style: pointStyle),
          Text('pt', style: textStyle),
        ],
      );
    }

    Widget displayPoint;
    if (isPositive) {
      displayPoint = Text(
        '+ ${Const.numberFormatter.format(postHistory.point)}',
        style: pointStyle,
      );
    } else {
      displayPoint = Text(
        Const.numberFormatter.format(postHistory.point),
        style: pointStyle,
      );
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        SizedBox(
          width: 80.0,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: displayPoint,
          ),
        ),
        Text('pt', style: textStyle),
      ],
    );
  }
}

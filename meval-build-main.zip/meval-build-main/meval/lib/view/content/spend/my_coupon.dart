import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'my_coupon_list_screen.dart';

class MyCoupon extends StatelessWidget {
  const MyCoupon({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: SelectableText.rich(
        const TextSpan(
          text: 'マイクーポン',
          style: TextStyle(
            fontSize: 18.0,
            color: Colors.blue,
            decoration: TextDecoration.underline,
          ),
        ),
        // 自分のクーポン一覧へ
        onTap: () => context.goNamed(MyCouponListScreen.name),
      ),
    );
  }
}

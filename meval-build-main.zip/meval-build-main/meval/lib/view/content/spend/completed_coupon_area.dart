import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/completed_coupon.dart';
import '../../../provider/search_map_provider.dart';

class CompletedCouponArea extends ConsumerWidget {
  // 獲得済みクーポンID
  final String completedCouponId;

  const CompletedCouponArea({Key? key, required this.completedCouponId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      future:
          ref.watch(couponHistoryByIdStreamProvider(completedCouponId).future),
      builder: (BuildContext context, AsyncSnapshot<CouponHistory?> snapshot) {
        final couponHistory = snapshot.data;
        if (!snapshot.hasData || couponHistory == null) {
          return const SizedBox();
        }

        // クーポン名称
        return SizedBox(
          width: 200,
          child: Text(
            couponHistory.name,
            style: const TextStyle(fontSize: 14.0),
            overflow: TextOverflow.ellipsis,
          ),
        );
      },
    );
  }
}

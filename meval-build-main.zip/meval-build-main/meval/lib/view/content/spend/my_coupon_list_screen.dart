import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../style/style.dart';
import 'merchant_coupon_area.dart';

class MyCouponListScreen extends StatelessWidget {
  static String path = 'myCouponList';
  static String name = 'myCouponList';

  const MyCouponListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        centerTitle: true,
        title: const Text('自分のクーポン', style: TextStyles.appBarTitle),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: [
            CupertinoSliverRefreshControl(
              onRefresh: () async {},
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => const MerchantCouponArea(),
                childCount: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/event_participation_history.dart';
import '../../../provider/spend_provider.dart';

class CompletedEventArea extends ConsumerWidget {
  // 達成済みイベントID
  final String completedEventId;

  const CompletedEventArea({Key? key, required this.completedEventId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      future: ref.watch(completedEventProvider(completedEventId).future),
      builder:
          (BuildContext context, AsyncSnapshot<ParticipatedEvent?> snapshot) {
        final participatedEvent = snapshot.data;
        if (!snapshot.hasData || participatedEvent == null) {
          return const SizedBox();
        }

        // イベントタイトル
        return SizedBox(
          width: 200,
          child: Text(
            participatedEvent.title,
            style: const TextStyle(fontSize: 14.0),
            overflow: TextOverflow.ellipsis,
          ),
        );
      },
    );
  }
}

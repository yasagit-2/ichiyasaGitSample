import 'package:flutter/material.dart';

import '../../style/style.dart';
import 'my_coupon.dart';
import 'point_balance.dart';
import 'point_history.dart';

class SpendScreen extends StatelessWidget {
  const SpendScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          backgroundColor: Theme.of(context).canvasColor,
          automaticallyImplyLeading: false,
          elevation: 0.0,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const [
            // ポイント残高
            PointBalance(),
            VerticalSpacer.standard,
            // ポイント履歴
            PointHistory(),
            VerticalSpacer.standard,
            // マイクーポン
            MyCoupon(),
          ],
        ),
      ),
    );
  }
}

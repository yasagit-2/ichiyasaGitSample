import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../model/data/merchant.dart';
import '../../../provider/map_controller_provider.dart';
import '../../../provider/menu_button_provider.dart';
import '../../../provider/screen_type_provider.dart';
import '../../../provider/spend_provider.dart';
import '../../../util/image_processing.dart';
import '../../component/coupon_list_screen.dart';
import '../../component/image_view.dart';
import '../search/search_map.dart';

/// クーポンを保持している対象加盟店リスト
class MerchantCouponArea extends ConsumerWidget {
  const MerchantCouponArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      future: getMerchants(ref),
      builder: (BuildContext context, AsyncSnapshot<MerchantsData> snapshot) {
        if (!snapshot.hasData || snapshot.data == null) {
          return const SizedBox();
        }

        final merchants = snapshot.data!.merchants;

        return ListView.separated(
          itemCount: merchants.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (BuildContext context, int index) {
            return const SizedBox(height: 5.0);
          },
          itemBuilder: (BuildContext context, int index) {
            final merchant = merchants[index];

            return SizedBox(
              width: double.infinity,
              height: 80,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  // 加盟店画像
                  createNetworkImage(
                    navigator: Navigator.of(context),
                    imageUrl: merchant.imageUrl,
                    onTap: () async {
                      // 画面を探索画面へ
                      ref
                          .read(screenTypeProvider.notifier)
                          .update((_) => ScreenType.search);
                      // 探索画面のメニューボタンを加盟店ボタンへ
                      ref
                          .read(selectedMenuButtonProvider.notifier)
                          .update((_) => MenuButtonSelection.merchant);

                      final geopoint = merchant.position.geopoint;

                      context.pop();

                      // マップの中心位置を当該加盟店の位置情報へ変更
                      await moveCamera(
                          ref, LatLng(geopoint.latitude, geopoint.longitude));

                      ref
                          .read(merchantBottomSheetOpenProvider.notifier)
                          .update((_) => merchant);
                    },
                    // 画像拡大表示
                    onLongPress: (imageProvider) =>
                        context.pushNamed(ImageView.name, extra: imageProvider),
                  ),
                  Expanded(
                    child: Material(
                      elevation: 8.0,
                      child: InkWell(
                        onTap: () {
                          // クーポンリスト画面へ
                          context.goNamed(CouponListScreen.nameFromSpend,
                              extra: merchant.id);
                        },
                        child: Container(
                          alignment: Alignment.centerLeft,
                          color: Theme.of(context).canvasColor,
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Text(
                                    merchant.name,
                                    style: const TextStyle(fontSize: 18.0),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                  ),
                                ),
                                const Icon(Icons.navigate_next),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  /// 現在保持中のクーポン（有効期限内）に該当する加盟店のリストを返却します。
  Future<MerchantsData> getMerchants(WidgetRef ref) async {
    final now = await NTP.now();
    final merchants =
        await ref.watch(merchantsWithCouponsFutureProvider(now).future);

    return MerchantsData(now: now, merchants: merchants);
  }
}

class MerchantsData {
  DateTime now;
  List<Merchant> merchants;

  MerchantsData({required this.now, required this.merchants});
}

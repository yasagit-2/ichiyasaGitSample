import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'point_history_list_screen.dart';

/// ポイント履歴
class PointHistory extends StatelessWidget {
  const PointHistory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: SelectableText.rich(
        const TextSpan(
          text: 'ポイント履歴',
          style: TextStyle(
            fontSize: 18.0,
            color: Colors.blue,
            decoration: TextDecoration.underline,
          ),
        ),
        // ポイント履歴一覧へ
        onTap: () => context.goNamed(PointHistoryListScreen.name),
      ),
    );
  }
}

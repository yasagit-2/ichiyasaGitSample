import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/completed_title.dart';
import '../../../provider/spend_provider.dart';

class CompletedTitleArea extends ConsumerWidget {
  // 獲得済み称号ID
  final String completedTitleId;

  const CompletedTitleArea({Key? key, required this.completedTitleId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      // 称号獲得情報取得
      future: ref.watch(completedTitleProvider(completedTitleId).future),
      builder: (BuildContext context, AsyncSnapshot<TitleHistory?> snapshot) {
        final completedTitleBase = snapshot.data;
        if (!snapshot.hasData || completedTitleBase == null) {
          return const SizedBox();
        }

        // 称号名
        return SizedBox(
          width: 200,
          child: Text(
            completedTitleBase.name,
            style: const TextStyle(fontSize: 14.0),
            overflow: TextOverflow.ellipsis,
          ),
        );
      },
    );
  }
}

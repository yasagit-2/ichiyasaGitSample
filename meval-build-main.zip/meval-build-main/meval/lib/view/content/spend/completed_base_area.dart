import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/completed_base.dart';
import '../../../provider/spend_provider.dart';

class CompletedBaseArea extends ConsumerWidget {
  // 制覇済み拠点ID
  final String completedBaseId;

  const CompletedBaseArea({Key? key, required this.completedBaseId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      // 拠点制覇情報取得
      future: ref.watch(completedBaseProvider(completedBaseId).future),
      builder:
          (BuildContext context, AsyncSnapshot<CompletedParentBase?> snapshot) {
        final completedParentBase = snapshot.data;
        if (!snapshot.hasData || completedParentBase == null) {
          return const SizedBox();
        }

        // 拠点名
        return SizedBox(
          width: 200,
          child: Text(
            completedParentBase.name,
            style: const TextStyle(fontSize: 14.0),
            overflow: TextOverflow.ellipsis,
          ),
        );
      },
    );
  }
}

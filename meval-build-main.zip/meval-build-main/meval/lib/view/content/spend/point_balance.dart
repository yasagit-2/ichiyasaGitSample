import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../provider/screen_type_provider.dart';
import '../../../provider/spend_provider.dart';

/// ポイント残高
class PointBalance extends ConsumerWidget {
  const PointBalance({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final screenType = ref.watch(screenTypeProvider);
    if (screenType != ScreenType.spend) return const SizedBox();

    final pointAsyncValue = ref.watch(pointStreamProvider);
    if (pointAsyncValue is! AsyncData || pointAsyncValue.value == null) {
      return const SizedBox();
    }

    // ポイント
    final point = pointAsyncValue.value!;

    return Column(
      children: [
        const ListTile(
          leading: FaIcon(
            FontAwesomeIcons.coins,
            color: Colors.amber,
          ),
          title: Text(
            'ポイント残高',
            style: TextStyle(
              fontSize: 22.0,
            ),
          ),
          horizontalTitleGap: 0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            // ポイント
            Text(
              Const.numberFormatter.format(point),
              style:
                  TextStyle(fontSize: 48.0, color: Colors.lightBlue.shade900),
            ),
            const SizedBox(width: 8.0),
            Text(
              'pt',
              style:
                  TextStyle(fontSize: 24.0, color: Colors.lightBlue.shade900),
            ),
          ],
        ),
      ],
    );
  }
}

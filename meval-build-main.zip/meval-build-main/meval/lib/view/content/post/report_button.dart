import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../const/constant.dart';
import '../../../provider/settings_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../util/analytics_util.dart';
import '../../../view_model/post_view_model.dart';
import '../../../view_model/search_map_view_model.dart';
import '../../component/loading_service.dart';
import '../content_root_screen.dart';
import '../search/button/post_edit_button.dart';
import 'post_confirm_image.dart';
import 'post_confirm_screen.dart';
import 'post_message_field.dart';

// 投稿メッセージバリデーションプロバイダ
final _reportValidationProvider = Provider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('_reportValidationProvider dispose.');
  });

  // メッセージ
  final message = ref.watch(postMessageProvider);

  // 行政報告可否（行政報告可否プロバイダ=true AND メッセージ記載あり AND メッセージの最大文字数OK）
  return ref.watch(isAvailableReportProvider) &&
      message.isNotEmpty &&
      message.characters.length <= TextFieldConst.postMaxLength;
});

// 行政報告ボタン
class ReportButton extends ConsumerWidget {
  // 会員ID
  final String memberId;

  // 投稿日時
  final DateTime reportedAt;

  const ReportButton(
      {Key? key, required this.memberId, required this.reportedAt})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final setting = ref.watch(settingsStateProvider);
    if (setting == null) {
      return const SizedBox();
    }

    final navigator = Navigator.of(context);

    // 行政報告可否
    final isAvailableReport = ref.watch(_reportValidationProvider);

    return SizedBox(
      width: 200.0,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.grey,
        ),
        onPressed: isAvailableReport
            ? () async {
                // フォーカスを外す
                FocusScope.of(context).unfocus();

                final now = await NTP.now();

                // 画面表示中の最終行政報告日時の変化を考慮しボタン押下のタイミングで再確認
                ref.watch(isAvailableReportProvider.notifier).update((_) =>
                    now.difference(reportedAt).inHours >=
                    setting.reportIntervalLimitHour);

                if (!ref.watch(isAvailableReportProvider)) {
                  await showOkAlertDialog(
                    context: context,
                    title: '行政報告は1日1回まで送信できます',
                  );
                  return;
                }

                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '行政報告を送信しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                await ref
                    .watch(loadingServiceProvider.notifier)
                    .wrap(_report(ref, navigator));
              }
            : null,
        child: const Text('行政報告', style: TextStyle(fontSize: 14.0)),
      ),
    );
  }

  /// 行政報告を行います。
  Future<void> _report(WidgetRef ref, NavigatorState navigator) async {
    final message = ref.read(postMessageProvider);
    final postingPreparationMarker =
        ref.read(searchMapViewModelProvider).postingPreparationMarker;

    if (message.isEmpty || postingPreparationMarker.isEmpty) {
      // 投稿確認画面表示中にsettingsが更新されると、マップのリビルドが行われる。
      // その際、投稿準備マーカーがクリアされるため、ここで再確認を行う。

      showErrorToast('行政報告できません。再実行してください。');
      // 投稿編集ボタン表示解除
      ref.read(postEditButtonVisibilityProvider.notifier).update((_) => false);
      navigator.context.goNamed(ContentRootScreen.name);
      return;
    }

    final imageFile = ref.read(postConfirmImageProvider);

    // 行政報告送信
    final report = await ref.read(postViewModelProvider.notifier).report(
        memberId,
        reportedAt,
        message,
        postingPreparationMarker.first.position,
        imageFile);

    // 行政報告イベント出力
    await AnalyticsUtil.report(ref, report);

    // 投稿編集ボタン表示解除
    ref.read(postEditButtonVisibilityProvider.notifier).update((_) => false);

    showCreateToast('行政報告を送信しました');

    // 行政報告はマップ上に表示しないため、行政報告情報の取得は不要

    navigator.context.goNamed(ContentRootScreen.name);
  }
}

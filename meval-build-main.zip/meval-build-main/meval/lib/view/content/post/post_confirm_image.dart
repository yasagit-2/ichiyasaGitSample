import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../util/logger.dart';
import '../../component/image_view.dart';

// 投稿画像プロバイダ
final postConfirmImageProvider = StateProvider.autoDispose<File?>((ref) {
  ref.onDispose(() {
    logger.fine('_postImageProvider dispose.');
  });

  return null;
});

class PostConfirmImage extends ConsumerWidget {
  const PostConfirmImage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final postImage = ref.watch(postConfirmImageProvider);

    if (postImage != null) {
      final image = Image.file(postImage);

      return Column(
        children: [
          DottedBorder(
            color: Colors.grey,
            borderType: BorderType.RRect,
            radius: const Radius.circular(5),
            padding: const EdgeInsets.all(6),
            strokeWidth: 3,
            dashPattern: const [15.0, 6.0],
            child: Ink.image(
              height: 200,
              image: image.image,
              child: InkWell(
                onTap: () async => await _pickImage(ref),
                onLongPress: () {
                  // 画像拡大表示
                  context.pushNamed(ImageView.name, extra: image.image);
                },
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () => ref.refresh(postConfirmImageProvider),
            child: const Text('画像をクリア'),
          ),
        ],
      );
    }

    return DottedBorder(
      color: Colors.grey,
      borderType: BorderType.RRect,
      radius: const Radius.circular(5),
      padding: const EdgeInsets.all(6),
      strokeWidth: 3,
      dashPattern: const [15.0, 6.0],
      child: InkWell(
        onTap: () async => await _pickImage(ref),
        child: SizedBox(
          width: double.infinity,
          height: 50.0,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text('画像なし'),
                Text('※タップで画像選択'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// ギャラリーから画像を読み込みます。
  Future<void> _pickImage(WidgetRef ref) async {
    final picker = ImagePicker();
    final image =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 20);
    if (image != null) {
      ref
          .read(postConfirmImageProvider.notifier)
          .update((_) => File(image.path));
    }
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../const/constant.dart';
import '../../../../model/data/admin_alert.dart';
import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';
import '../../content_root_screen.dart';
import '../common/network_content_image.dart';

class AdminAlertScreen extends ConsumerWidget {
  static String path = 'adminAlert';
  static String name = 'adminAlert';

  final AdminAlert adminAlert;

  const AdminAlertScreen({Key? key, required this.adminAlert})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);
    final adminAlertAsyncValue =
        ref.watch(adminAlertByIdStreamProvider(adminAlert.id));
    ref.listen(adminAlertByIdStreamProvider(adminAlert.id), (previous, next) {
      if (next is AsyncData) {
        if (next.value == null) {
          // 行政投稿（注意）が存在しない場合、コンテンツルートへ戻る
          // （行政投稿（注意）参照中に当該の行政投稿（注意）が削除されるケースを考慮したもの）
          navigator.context.goNamed(ContentRootScreen.name);
        }
      }
    });

    if (adminAlertAsyncValue is! AsyncData ||
        adminAlertAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final streamedAdminAlert = adminAlertAsyncValue.value!;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          elevation: 0.0,
          backgroundColor: Theme.of(context).canvasColor,
          title: const Text('事業者投稿', style: TextStyles.appBarTitle),
          leading: IconButton(
            onPressed: () => context.pop(),
            icon: const Icon(Icons.close),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 行政投稿（注意）画像
              NetworkContentImage(imageUrl: streamedAdminAlert.imageUrl),
              VerticalSpacer.smallish,
              Row(
                children: [
                  const Text('注意：〜'),
                  Text(Const.dateFormat.format(streamedAdminAlert.dueDate)),
                ],
              ),
              VerticalSpacer.smallish,
              SelectableText(streamedAdminAlert.message),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../util/logger.dart';
import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';
import '../../content_root_screen.dart';

// アンケート選択プロバイダ（選択肢IDを保持）
final selectedChoiceIdProvider = StateProvider.autoDispose<String>((ref) => '');

class AdminQuestionnaireChoice extends HookConsumerWidget {
  // アンケートID
  final String adminQuestionnaireId;

  const AdminQuestionnaireChoice({Key? key, required this.adminQuestionnaireId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // true:アンケート回答済み（ラジオボタン無効化）、false:アンケート回答未済（ラジオボタン有効化）
    final isAnswered = useState(true);

    // アンケート選択肢
    final choiceAsyncValue = ref.watch(
        choiceByAdminQuestionnaireIdStreamProvider(adminQuestionnaireId));
    ref.listen(choiceByAdminQuestionnaireIdStreamProvider(adminQuestionnaireId),
        (previous, next) {
      if (next is AsyncData) {
        if (next.value == null || next.value!.isEmpty) {
          // アンケートの選択肢が存在しない場合、コンテンツルートへ戻る
          // （アンケート参照中に当該のアンケートの選択肢が削除されるケースを考慮したもの）
          context.goNamed(ContentRootScreen.name);
        }
      }
    });

    // アンケート回答履歴
    final questionnaireHistoryAsyncValue =
        ref.watch(questionnaireHistoryByIdStreamProvider(adminQuestionnaireId));

    if (choiceAsyncValue is AsyncLoading ||
        questionnaireHistoryAsyncValue is AsyncLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (choiceAsyncValue is AsyncError) {
      final error = choiceAsyncValue as AsyncError;
      logger.severe(error.error);
      logger.severe(error.stackTrace);
      return const SizedBox();
    }
    if (questionnaireHistoryAsyncValue is AsyncError) {
      final error = questionnaireHistoryAsyncValue as AsyncError;
      logger.severe(error.error);
      logger.severe(error.stackTrace);
      return const SizedBox();
    }

    // アンケート回答履歴
    final questionnaireHistory = questionnaireHistoryAsyncValue.value;
    if (questionnaireHistory != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // アンケート回答履歴の選択肢IDで状態を更新
        ref
            .watch(selectedChoiceIdProvider.notifier)
            .update((_) => questionnaireHistory.choiceId);

        isAnswered.value = true;
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        isAnswered.value = false;
      });
    }

    // 選択肢リスト
    final choices = choiceAsyncValue.value!;

    final radioListTiles = <Widget>[];
    for (final choice in choices) {
      final radioListTile = Card(
        child: RadioListTile(
          value: choice.id,
          groupValue: ref.watch(selectedChoiceIdProvider),
          title: Text(choice.choice),
          secondary: Text(
            choice.answer.toString(),
            style: const TextStyle(fontSize: 18.0),
          ),
          onChanged: isAnswered.value
              ? null
              : (String? value) {
                  if (value != null) {
                    // 選択肢を更新
                    ref
                        .watch(selectedChoiceIdProvider.notifier)
                        .update((_) => value);
                  }
                },
        ),
      );

      radioListTiles.add(radioListTile);
    }

    return Column(
      children: [
        isAnswered.value
            ? const Text(
                'アンケートに回答済みです',
                style: TextStyle(color: Colors.red),
              )
            : const SizedBox(),
        VerticalSpacer.smallish,
        ListView(shrinkWrap: true, children: radioListTiles),
      ],
    );
  }
}

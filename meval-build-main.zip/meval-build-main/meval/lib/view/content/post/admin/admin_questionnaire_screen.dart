import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../const/constant.dart';
import '../../../../model/data/admin_questionnaire.dart';
import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';
import '../../content_root_screen.dart';
import '../common/network_content_image.dart';
import 'admin_questionnaire_button.dart';
import 'admin_questionnaire_choice.dart';

class AdminQuestionnaireScreen extends ConsumerWidget {
  static String path = 'adminQuestionnaire';
  static String name = 'adminQuestionnaire';

  final AdminQuestionnaire adminQuestionnaire;

  const AdminQuestionnaireScreen({Key? key, required this.adminQuestionnaire})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adminQuestionnaireAsyncValue =
        ref.watch(adminQuestionnaireByIdStreamProvider(adminQuestionnaire.id));
    ref.listen(adminQuestionnaireByIdStreamProvider(adminQuestionnaire.id),
        (previous, next) {
      if (next is AsyncData) {
        if (next.value == null) {
          // 行政投稿（アンケート）が存在しない場合、コンテンツルートへ戻る
          // （行政投稿（アンケート）参照中に当該の行政投稿（アンケート）が削除されるケースを考慮したもの）
          context.goNamed(ContentRootScreen.name);
        }
      }
    });

    if (adminQuestionnaireAsyncValue is! AsyncData ||
        adminQuestionnaireAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final streamedAdminQuestionnaire = adminQuestionnaireAsyncValue.value!;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          elevation: 0.0,
          backgroundColor: Theme.of(context).canvasColor,
          title: const Text('事業者投稿', style: TextStyles.appBarTitle),
          leading: IconButton(
            onPressed: () => context.pop(),
            icon: const Icon(Icons.close),
          ),
        ),
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 行政投稿（アンケート）画像
                NetworkContentImage(
                    imageUrl: streamedAdminQuestionnaire.imageUrl),
                VerticalSpacer.smallish,
                Row(
                  children: [
                    const Text('アンケート：〜'),
                    Text(Const.dateFormat.format(adminQuestionnaire.dueDate)),
                  ],
                ),
                VerticalSpacer.smallish,
                SelectableText(adminQuestionnaire.message),
                VerticalSpacer.standard,
                // アンケートの選択肢
                AdminQuestionnaireChoice(
                    adminQuestionnaireId: adminQuestionnaire.id),
                // アンケート回答ボタン
                AdminQuestionnaireButton(
                    adminQuestionnaireId: adminQuestionnaire.id),
                VerticalSpacer.standard,
                const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'アンケートには1度だけ回答できます',
                    style: TextStyle(fontSize: 14.0),
                  ),
                ),
                VerticalSpacer.standard,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../view_model/post_view_model.dart';
import '../../../component/loading_service.dart';
import '../../../style/style.dart';
import 'admin_questionnaire_choice.dart';

class AdminQuestionnaireButton extends ConsumerWidget {
  // アンケートID
  final String adminQuestionnaireId;

  const AdminQuestionnaireButton({Key? key, required this.adminQuestionnaireId})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 選択肢ID
    final selectedChoiceId = ref.watch(selectedChoiceIdProvider);

    // true:アンケート回答ボタン活性化
    bool isVisible = selectedChoiceId.isNotEmpty;

    // アンケート回答履歴
    final questionnaireHistoryAsyncValue =
        ref.watch(questionnaireHistoryByIdStreamProvider(adminQuestionnaireId));
    if (questionnaireHistoryAsyncValue is! AsyncData) {
      isVisible = false;
    }

    if (questionnaireHistoryAsyncValue.value != null) {
      // アンケート回答済み（アンケート回答履歴が存在する）
      isVisible = false;
    }

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isVisible
            ? () async {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: 'アンケートに回答しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                // アンケート回答
                await ref
                    .watch(loadingServiceProvider.notifier)
                    .wrap(_answerQuestionnaire(ref, selectedChoiceId));
              }
            : null,
        child: const Text(
          'アンケートに回答する',
          style: TextStyles.buttonTextStyle,
        ),
      ),
    );
  }

  /// アンケート[adminQuestionnaireId]に対し、選択肢[selectedQuestionnaireId]にて回答します。
  Future<void> _answerQuestionnaire(
      WidgetRef ref, String selectedChoiceId) async {
    return await ref
        .read(postViewModelProvider.notifier)
        .answerQuestionnaire(adminQuestionnaireId, selectedChoiceId);
  }
}

import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../const/constant.dart';
import '../../../model/data/post.dart';
import '../../../provider/settings_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../util/analytics_util.dart';
import '../../../view_model/member_view_model.dart';
import '../../../view_model/post_view_model.dart';
import '../../component/loading_service.dart';
import '../../style/style.dart';
import '../content_root_screen.dart';
import 'comment/comment_display_area.dart';
import 'comment/comment_field.dart';
import 'common/network_content_image.dart';
import 'contributor.dart';
import 'like_area.dart';

// コメント可否プロバイダ
final isAvailableCommentProvider =
    StateProvider.autoDispose<bool>((ref) => false);

// 投稿表示
class PostDisplayScreen extends ConsumerWidget {
  static String path = 'postDisplay';
  static String name = 'postDisplay';

  const PostDisplayScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ログイン中の会員
    final member = ref.watch(memberViewModelProvider);
    final postMemberAsyncValue = ref.watch(postMemberProvider);
    // コメント日時
    final memberCommentedAtAsyncValue =
        ref.watch(memberCommentedAtStreamProvider);

    final navigator = Navigator.of(context);
    final postAsyncValue = ref.watch(postByIdStreamProvider);
    ref.listen(postByIdStreamProvider, (previous, next) {
      if (next is AsyncData) {
        if (next.value == null) {
          // 投稿が存在しない場合、コンテンツルートへ戻る
          // （投稿参照中に当該の投稿が削除されるケースを考慮したもの）
          navigator.context.goNamed(ContentRootScreen.name);
        }
      }
    });

    // アプリケーション設定
    final setting = ref.watch(settingsStateProvider);

    if (member == null ||
        postMemberAsyncValue is! AsyncData ||
        memberCommentedAtAsyncValue is! AsyncData ||
        postAsyncValue is! AsyncData ||
        setting == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // 投稿者
    final postMember = postMemberAsyncValue.value;
    // 投稿
    final post = postAsyncValue.value;

    // コメント日時
    final commentedAt = memberCommentedAtAsyncValue.value;

    if (postMember == null || post == null || commentedAt == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // 通報
    final postingAlertExistsAsyncValue =
        ref.watch(postingAlertExistsStreamProvider(post.id));
    if (postingAlertExistsAsyncValue is! AsyncData ||
        postingAlertExistsAsyncValue.value == null) {
      logger.info(postingAlertExistsAsyncValue);
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // true：通報可能（自身の通報が存在しなければ通報可能）
    final isReportable = !postingAlertExistsAsyncValue.value!;

    // 自身の投稿か否か
    final isOwnPost = post.memberRef.id == member.id;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final now = await NTP.now();

      // コメント可否を更新（コメント間隔制限（minute）以上経過）
      ref.watch(isAvailableCommentProvider.notifier).update((_) =>
          now.difference(commentedAt).inMinutes >=
          setting.commentIntervalLimitMinute);
    });

    // 投稿表示イベント出力
    AnalyticsUtil.viewPost(ref, post);

    return WillPopScope(
      onWillPop: () async => false,
      child: GestureDetector(
        // フォーカスを外す
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            elevation: 0.0,
            backgroundColor: Theme.of(context).canvasColor,
            title: const Text('投稿', style: TextStyles.appBarTitle),
            leading: IconButton(
              onPressed: () => context.pop(),
              icon: const Icon(Icons.close),
            ),
            actions: [
              isOwnPost
                  // 投稿削除
                  ? IconButton(
                      onPressed: () async {
                        final result = await _showOkCancelAlertDialog(
                            navigator, 'この投稿を削除しますか？');
                        if (result == OkCancelResult.cancel) {
                          return;
                        }

                        // 投稿削除
                        await _deletePost(ref, post);
                      },
                      icon: Image.asset(
                        Const.trash,
                      ),
                    )
                  // 通報
                  : isReportable
                      ? IconButton(
                          onPressed: () async {
                            final result = await _showOkCancelAlertDialog(
                                navigator, 'この投稿を通報しますか？');
                            if (result == OkCancelResult.cancel) {
                              return;
                            }

                            // 通報
                            await _alertPost(ref, post);

                            // コンテンツルートへ
                            navigator.context.goNamed(ContentRootScreen.name);
                          },
                          icon: Image.asset(
                            Const.alert,
                          ),
                        )
                      : IconButton(
                          onPressed: () {},
                          icon: Image.asset(
                            Const.alert,
                            color: Colors.grey,
                          ),
                        ),
            ],
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 投稿画像
                  NetworkContentImage(imageUrl: post.imageUrl),
                  VerticalSpacer.smallish,
                  // 投稿メッセージ
                  SelectableText(post.message),
                  VerticalSpacer.smallish,
                  // 投稿者/投稿時刻
                  Contributor(
                    member: postMember,
                    createdAt: (post.createdAt == null) ? null : post.createdAt,
                  ),
                  // いいね
                  LikeArea(post: post, isOwnPost: isOwnPost),
                  const Divider(thickness: 2),
                  // コメント表示領域
                  CommentDisplayArea(postId: post.id),
                  // コメントフィールド
                  CommentField(post: post, isOwnPost: isOwnPost),
                  isOwnPost
                      ? const SizedBox()
                      : Align(
                          alignment: Alignment.center,
                          child: Column(
                            children: const [
                              Text(
                                'コメントには時間間隔の制限があります',
                                style: TextStyle(fontSize: 14.0),
                              ),
                              Text(
                                '連続で送信することはできません',
                                style: TextStyle(fontSize: 14.0),
                              ),
                            ],
                          ),
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// 確認ダイアログを表示します。
  Future<OkCancelResult> _showOkCancelAlertDialog(
      NavigatorState navigator, String title) async {
    return await showOkCancelAlertDialog(
      context: navigator.context,
      title: title,
      isDestructiveAction: true,
    );
  }

  /// 投稿を削除します。
  Future<void> _deletePost(WidgetRef ref, Post post) async {
    await ref
        .watch(loadingServiceProvider.notifier)
        .wrap(ref.read(postViewModelProvider.notifier).deletePost(post));

    showDeleteToast('投稿を削除しました');
  }

  /// 投稿を通報します。
  Future<void> _alertPost(WidgetRef ref, Post post) async {
    await ref
        .watch(loadingServiceProvider.notifier)
        .wrap(ref.read(postViewModelProvider.notifier).alertPost(post));

    showDeleteToast('投稿を通報しました');
  }
}

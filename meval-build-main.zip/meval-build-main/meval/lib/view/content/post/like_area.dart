import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/post.dart';
import '../../../util/logger.dart';
import '../../../view_model/post_view_model.dart';
import '../../component/loading_service.dart';

class LikeArea extends ConsumerWidget {
  final Post post;
  final bool isOwnPost;

  const LikeArea({Key? key, required this.post, required this.isOwnPost})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final likeAsyncValue = ref.watch(likeStreamProvider(post.id));

    if (likeAsyncValue is AsyncLoading) {
      return const SizedBox();
    }

    if (likeAsyncValue is AsyncError) {
      return printError(likeAsyncValue as AsyncError);
    }

    final like = likeAsyncValue.value;

    return Row(
      children: [
        IconButton(
          onPressed: isOwnPost
              // 自身の投稿はいいね押下不可
              ? null
              : () async {
                  if (like == null) {
                    // いいね
                    await ref
                        .watch(loadingServiceProvider.notifier)
                        .wrap(_like(ref, post.id));
                  } else {
                    // いいね削除
                    await ref
                        .watch(loadingServiceProvider.notifier)
                        .wrap(_deleteLike(ref, like.id, post.id));
                  }
                },
          icon: like == null
              ? const Icon(Icons.favorite_border)
              : const Icon(Icons.favorite),
        ),
        Text(post.likeCount.toString()),
        const Text('いいね'),
      ],
    );
  }

  Future<void> _like(WidgetRef ref, String postId) async {
    return await ref.read(postViewModelProvider.notifier).like(postId);
  }

  Future<void> _deleteLike(WidgetRef ref, String likeId, String postId) async {
    return await ref
        .read(postViewModelProvider.notifier)
        .deleteLike(likeId, postId);
  }

  /// エラーログを出力します。
  Widget printError(AsyncError asyncError) {
    logger.severe(asyncError.error);
    logger.severe(asyncError.stackTrace);
    return const SizedBox();
  }
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../util/logger.dart';
import '../../../component/image_view.dart';

class NetworkContentImage extends HookConsumerWidget {
  final String? imageUrl;

  const NetworkContentImage({Key? key, this.imageUrl}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (imageUrl == null) return const SizedBox();

    return DottedBorder(
      color: Colors.grey,
      borderType: BorderType.RRect,
      radius: const Radius.circular(5),
      padding: const EdgeInsets.all(6),
      child: Material(
        child: CachedNetworkImage(
          height: 200.0,
          imageUrl: imageUrl!,
          imageBuilder: (context, imageProvider) {
            return Ink.image(
              fit: BoxFit.fitHeight,
              image: imageProvider,
              child: InkWell(
                onTap: () {
                  // フォーカスを外す
                  FocusScope.of(context).unfocus();

                  // 画像拡大表示
                  context.pushNamed(ImageView.name, extra: imageProvider);
                },
              ),
            );
          },
          placeholder: (_, __) => const Center(
            child: SizedBox(
              width: 80.0,
              height: 80.0,
              child: CircularProgressIndicator(),
            ),
          ),
          errorWidget: (_, url, error) {
            logger.severe('error=$error, url=$url');

            return _errorImage();
          },
        ),
      ),
    );
  }

  /// エラー表示用のWidgetを生成します。
  Widget _errorImage() {
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(Icons.broken_image, size: 30.0),
          Text(
            '（画像を表示できません）',
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                decoration: TextDecoration.none),
          ),
        ],
      ),
    );
  }
}

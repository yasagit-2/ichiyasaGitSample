import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';
import 'comment_list.dart';
import 'comment_list_screen.dart';

class CommentDisplayArea extends ConsumerWidget {
  // 投稿ID
  final String postId;

  const CommentDisplayArea({Key? key, required this.postId}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // コメント
    final commentListAsyncValue = ref.watch(commentListStreamProvider);

    if (commentListAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final commentList = commentListAsyncValue.value;
    if (commentList == null || commentList.isEmpty) {
      return const SizedBox();
    }

    return SizedBox(
      height: commentList.length >= 3 ? 200.0 : 150.0,
      child: Scrollbar(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                InkWell(
                  splashColor: AppColors.splashColor,
                  // コメント一覧へ
                  onTap: () => context.goNamed(CommentListScreen.name),
                  child: const Text(
                    'コメント一覧',
                    style: TextStyle(fontSize: 16.0, color: Colors.blueAccent),
                  ),
                ),
                HorizontalSpacer.smallish,
              ],
            ),
            Expanded(
              child: CommentList(comments: commentList),
            ),
            const Divider(thickness: 2),
            VerticalSpacer.smallish,
          ],
        ),
      ),
    );
  }
}

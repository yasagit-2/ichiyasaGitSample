import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';
import 'comment_list.dart';

class CommentListScreen extends ConsumerWidget {
  static String path = 'commentList';
  static String name = 'commentList';

  const CommentListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // コメント
    final commentListAsyncValue = ref.watch(commentListStreamProvider);
    if (commentListAsyncValue is! AsyncData) {
      return const Scaffold();
    }

    final commentList = commentListAsyncValue.value;
    if (commentList == null || commentList.isEmpty) {
      return const Scaffold();
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0.0,
        backgroundColor: Theme.of(context).canvasColor,
        title: const Text('コメント一覧', style: TextStyles.appBarTitle),
        leading: IconButton(
          onPressed: () => context.pop(),
          icon: const Icon(Icons.close),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: CommentList(comments: commentList),
        ),
      ),
    );
  }
}

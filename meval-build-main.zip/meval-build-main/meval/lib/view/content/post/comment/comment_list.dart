import 'package:flutter/material.dart';

import '../../../../model/data/comment.dart';
import '../../../style/style.dart';
import 'comment_text.dart';

class CommentList extends StatelessWidget {
  final List<Comment> comments;

  const CommentList({Key? key, required this.comments}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      shrinkWrap: true,
      itemCount: comments.length,
      itemBuilder: (BuildContext context, int index) {
        // コメント
        return CommentText(comment: comments[index]);
      },
      separatorBuilder: (BuildContext context, int index) =>
          VerticalSpacer.smallish,
    );
  }
}

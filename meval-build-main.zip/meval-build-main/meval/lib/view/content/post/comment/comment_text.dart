import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../const/constant.dart';
import '../../../../model/data/comment.dart';
import '../../../../view_model/post_view_model.dart';
import '../../../style/style.dart';

class CommentText extends HookConsumerWidget {
  // コメント
  final Comment comment;

  final int min = 1;
  final int max = 100;

  const CommentText({Key? key, required this.comment}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final maxLines = useState(min);

    return FutureBuilder(
      future: ref
          .watch(postViewModelProvider.notifier)
          .getMemberNickname(comment.memberRef.id),
      builder: (BuildContext context, AsyncSnapshot<String?> snapshot) {
        String nickname = '';
        if (snapshot.hasData && snapshot.data != null) {
          nickname = snapshot.data!;
        }

        return GestureDetector(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // コメント本文
              Text(
                comment.message,
                maxLines: maxLines.value,
                overflow: TextOverflow.ellipsis,
              ),
              // コメントした会員のニックネーム
              Row(
                children: [
                  const Text('投稿者：'),
                  Flexible(
                    child: SelectableText(
                      nickname,
                    ),
                  ),
                ],
              ),
              HorizontalSpacer.smallish,
              // コメント日時
              (comment.createdAt == null)
                  ? const SizedBox()
                  : Text(Const.dateAndTimeFormat.format(comment.createdAt!)),
            ],
          ),
          onTap: () {
            // コメント表示行数の変更
            (maxLines.value == min)
                ? maxLines.value = max
                : maxLines.value = min;
          },
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../provider/settings_provider.dart';
import '../../../view_model/member_view_model.dart';
import '../../style/style.dart';
import 'post_button.dart';
import 'post_confirm_image.dart';
import 'post_message_field.dart';
import 'report_button.dart';

// 投稿可否プロバイダ
final isAvailablePostProvider = StateProvider.autoDispose<bool>((ref) => false);

// 行政報告可否プロバイダ
final isAvailableReportProvider =
    StateProvider.autoDispose<bool>((ref) => false);

// 投稿確認
class PostConfirmScreen extends ConsumerWidget {
  static String path = 'postConfirm';
  static String name = 'postConfirm';

  const PostConfirmScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 会員ID
    final memberId = ref.watch(memberIdProvider);
    // 投稿日時
    final postedAtAsyncValue = ref.watch(memberPostedAtStreamProvider);
    // 行政報告日時
    final reportedAtAsyncValue = ref.watch(memberReportedAtStreamProvider);

    if (memberId == null) {
      return const SizedBox();
    }

    final setting = ref.watch(settingsStateProvider);

    if (postedAtAsyncValue is! AsyncData ||
        reportedAtAsyncValue is! AsyncData ||
        setting == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final postedAt = postedAtAsyncValue.value!;
    final reportedAt = reportedAtAsyncValue.value!;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final now = await NTP.now();

      // 投稿可否を更新（投稿間隔制限（hour）以上経過）
      ref.watch(isAvailablePostProvider.notifier).update((_) =>
          now.difference(postedAt).inHours >= setting.postIntervalLimitHour);

      // 行政報告可否を更新（行政報告間隔制限（hour）以上経過）
      ref.watch(isAvailableReportProvider.notifier).update((_) =>
          now.difference(reportedAt).inHours >=
          setting.reportIntervalLimitHour);
    });

    return WillPopScope(
      onWillPop: () async => false,
      child: GestureDetector(
        // フォーカスを外す
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            elevation: 0.0,
            backgroundColor: Theme.of(context).canvasColor,
            title: const Text('投稿確認', style: TextStyles.appBarTitle),
            leading: IconButton(
              onPressed: () => context.pop(),
              icon: const Icon(Icons.close),
            ),
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // 投稿画像
                  const PostConfirmImage(),
                  VerticalSpacer.standard,
                  // 投稿メッセージ
                  const PostMessageField(),
                  VerticalSpacer.standard,
                  // 投稿
                  PostButton(memberId: memberId, postedAt: postedAt),
                  VerticalSpacer.standard,
                  // 行政報告を表示しないよう変更
                  //ReportButton(memberId: memberId, reportedAt: reportedAt),
                  VerticalSpacer.smallish,
                  Column(
                    children: const [
                      Text(
                        '投稿には時間間隔の制限があります',
                        style: TextStyle(fontSize: 14.0),
                      ),
                      Text(
                        '連続で送信することはできません',
                        style: TextStyle(fontSize: 14.0),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../util/logger.dart';

// 投稿メッセージプロバイダ
final postMessageProvider = StateProvider.autoDispose<String>((ref) {
  ref.onDispose(() {
    logger.fine('postMessageProvider dispose.');
  });
  return '';
});

class PostMessageField extends HookConsumerWidget {
  const PostMessageField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final focusNode = useFocusNode();
    final messageController = useTextEditingController();

    return TextField(
      controller: messageController,
      focusNode: focusNode,
      maxLines: 5,
      maxLength: TextFieldConst.postMaxLength,
      decoration: InputDecoration(
        hintText: '例）道路が陥没しています。\n（50文字以内）\n\n※タップで文章入力',
        hintMaxLines: 5,
        border: const OutlineInputBorder(),
        // クリアボタン
        suffixIcon: SizedBox(
          width: 50,
          height: 150,
          child: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(
              onPressed: () {
                messageController.clear();
                ref.invalidate(postMessageProvider);
              },
              icon: const Icon(Icons.clear, size: 20.0),
            ),
          ),
        ),
      ),
      keyboardType: TextInputType.multiline,
      onChanged: (value) {
        ref.watch(postMessageProvider.notifier).update((_) => value);
      },
    );
  }
}

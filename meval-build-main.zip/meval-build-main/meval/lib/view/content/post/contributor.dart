import 'package:flutter/material.dart';

import '../../../const/constant.dart';
import '../../../model/data/member.dart';

/// 投稿者/投稿時刻
class Contributor extends StatelessWidget {
  final Member? member;

  final DateTime? createdAt;

  const Contributor({Key? key, required this.member, required this.createdAt})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('投稿者：'),
            (member == null)
                ? const Text('Unknown User')
                : Flexible(
                    child: SelectableText(
                      member!.nickname,
                    ),
                  ),
          ],
        ),
        (createdAt == null)
            ? const SizedBox()
            : SelectableText(Const.dateAndTimeFormat.format(createdAt!)),
      ],
    );
  }
}

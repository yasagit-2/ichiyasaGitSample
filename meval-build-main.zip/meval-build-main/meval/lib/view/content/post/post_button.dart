import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../const/constant.dart';
import '../../../provider/settings_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../util/analytics_util.dart';
import '../../../view_model/post_view_model.dart';
import '../../../view_model/search_map_view_model.dart';
import '../../component/loading_service.dart';
import '../content_root_screen.dart';
import '../search/button/post_edit_button.dart';
import 'post_confirm_image.dart';
import 'post_confirm_screen.dart';
import 'post_message_field.dart';

// 投稿メッセージバリデーションプロバイダ
final _postValidationProvider = Provider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('_postValidationProvider dispose.');
  });

  // メッセージ
  final message = ref.watch(postMessageProvider);

  // 投稿可否（投稿可否プロバイダ=true AND メッセージ記載あり AND メッセージの最大文字数OK）
  return ref.watch(isAvailablePostProvider) &&
      message.isNotEmpty &&
      message.characters.length <= TextFieldConst.postMaxLength;
});

// 投稿ボタン
class PostButton extends ConsumerWidget {
  // 会員ID
  final String memberId;

  // 投稿日時
  final DateTime postedAt;

  const PostButton({Key? key, required this.memberId, required this.postedAt})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final setting = ref.watch(settingsStateProvider);
    if (setting == null) {
      return const SizedBox();
    }

    final navigator = Navigator.of(context);

    // 投稿可否
    final isAvailablePost = ref.watch(_postValidationProvider);

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isAvailablePost
            ? () async {
                // フォーカスを外す
                FocusScope.of(context).unfocus();

                final now = await NTP.now();

                // 画面表示中の最終投稿日時の変化を考慮しボタン押下のタイミングで再確認
                ref.watch(isAvailablePostProvider.notifier).update((_) {
                  return now.difference(postedAt).inHours >=
                      setting.postIntervalLimitHour;
                });

                if (!ref.watch(isAvailablePostProvider)) {
                  await showOkAlertDialog(
                    context: context,
                    message: '投稿は1日1回まで送信できます',
                  );
                  return;
                }

                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: '投稿を送信しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                await ref
                    .watch(loadingServiceProvider.notifier)
                    .wrap(_post(context, ref, navigator));
              }
            : null,
        child: const Text('投稿'),
      ),
    );
  }

  /// 投稿を行います。
  /// 投稿が正常終了した場合、拠点情報を再取得します。
  Future<void> _post(
      BuildContext context, WidgetRef ref, NavigatorState navigator) async {
    final message = ref.read(postMessageProvider);
    final postingPreparationMarker =
        ref.read(searchMapViewModelProvider).postingPreparationMarker;

    if (message.isEmpty || postingPreparationMarker.isEmpty) {
      // 投稿確認画面表示中にsettingsが更新されると、マップのリビルドが行われる。
      // その際、投稿準備マーカーがクリアされるため、ここで再確認を行う。

      showErrorToast('投稿できません。再実行してください。');
      // 投稿編集ボタン表示解除
      ref.read(postEditButtonVisibilityProvider.notifier).update((_) => false);
      navigator.context.goNamed(ContentRootScreen.name);
      return;
    }

    final imageFile = ref.read(postConfirmImageProvider);

    // 投稿送信
    final post = await ref.read(postViewModelProvider.notifier).post(memberId,
        postedAt, message, postingPreparationMarker.first.position, imageFile);

    // 投稿イベント出力
    await AnalyticsUtil.post(ref, post);

    // 投稿編集ボタン表示解除
    ref.read(postEditButtonVisibilityProvider.notifier).update((_) => false);

    showCreateToast('投稿を送信しました');

    navigator.context.goNamed(ContentRootScreen.name);
  }
}

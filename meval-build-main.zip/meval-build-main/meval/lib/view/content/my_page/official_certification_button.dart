import 'package:flutter/material.dart';

import '../../../util/show_toast.dart';
import '../../style/style.dart';

class OfficialCertificationButton extends StatelessWidget {
  const OfficialCertificationButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text('※公的認証後は生年月を変更することはできません'),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              // TODO 公的認証
              showErrorToast('公的認証は現在未実装です');
            },
            child: const Text('公的認証', style: TextStyles.buttonTextStyle),
          ),
        ),
      ],
    );
  }
}

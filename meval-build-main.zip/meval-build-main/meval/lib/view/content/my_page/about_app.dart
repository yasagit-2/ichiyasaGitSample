import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:settings_ui/settings_ui.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../../const/constant.dart';
import '../../../provider/package_info_provider.dart';
import '../../../provider/settings_provider.dart';
import '../../initial/tos/privacy_policy_screen.dart';
import '../../initial/tos/tos_screen.dart';
import '../../style/style.dart';

class AboutApp extends ConsumerWidget {
  static String path = 'aboutApp';
  static String name = 'aboutApp';

  const AboutApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final packageInfo = ref.watch(packageInfoProvider);

    // 設定情報
    final settingWatcher = ref.watch(settingsStreamProvider);

    // プライバシーポリシーのURLを取得
    final privacyPolicyUrl = settingWatcher.value?.privacyPolicyUrl ?? "";

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        title: const Text('アプリについて', style: TextStyles.appBarTitle),
      ),
      body: SettingsList(
        sections: [
          SettingsSection(
            tiles: [
              SettingsTile(
                leading: const Icon(Icons.manage_accounts),
                title: const Text('バージョン'),
                value: Text(packageInfo.version),
                onPressed: (context) {},
              ),
            ],
          ),
          SettingsSection(
            tiles: [
              SettingsTile.navigation(
                leading: const FaIcon(FontAwesomeIcons.handshake),
                title: const Text('利用規約'),
                onPressed: (context) {
                  // 利用規約へ
                  context.goNamed(TosScreen.contentName);
                },
              ),
              SettingsTile.navigation(
                leading: const FaIcon(FontAwesomeIcons.userShield),
                title: const Text('プライバシーポリシー'),
                onPressed: (context) => launchUrlString(privacyPolicyUrl,
                    mode: LaunchMode.externalApplication),
              ),
              SettingsTile.navigation(
                leading: const FaIcon(FontAwesomeIcons.idCard),
                title: const Text('ライセンス'),
                onPressed: (context) {
                  _showLicense(context, packageInfo.version);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// ライセンスを表示します。
  _showLicense(BuildContext context, String version) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) => Theme(
          data: ThemeData(
            cardColor: Colors.white,
            appBarTheme: AppBarTheme(
              centerTitle: true,
              backgroundColor: Theme.of(context).canvasColor,
              elevation: 0.0,
              iconTheme: const IconThemeData(
                color: Colors.black,
              ),
              titleTextStyle: const TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),
            ),
          ),
          child: LicensePage(
            applicationVersion: version,
            applicationIcon: Image.asset(Const.logo, height: 64.0, width: 64.0),
          ),
        ),
      ),
    );
  }
}

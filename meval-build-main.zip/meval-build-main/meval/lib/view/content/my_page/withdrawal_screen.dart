import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../util/show_toast.dart';
import '../../../view_model/member_view_model.dart';
import '../../component/loading_service.dart';
import '../../style/style.dart';

class WithdrawalScreen extends ConsumerWidget {
  static String path = 'withdrawal';
  static String name = 'withdrawal';

  const WithdrawalScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 退会申請
    final withdrawalAsyncValue = ref.watch(withdrawalStreamProvider);
    if (withdrawalAsyncValue is! AsyncData) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final withdrawal = withdrawalAsyncValue.value;

    // true：退会申請中
    final isWithdrawal = withdrawal != null;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        centerTitle: true,
        title: const Text('退会申請', style: TextStyles.appBarTitle),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '退会申請を行うと、猶予期間後に会員情報（ポイント含む）が全て削除されます。\n\n'
                '退会申請後、猶予期間中は退会申請を取り消す事ができます。\n\n'
                '猶予期間後に削除された会員情報（ポイント含む）は元に戻りません。',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18.0),
              ),
              SizedBox(
                width: double.infinity,
                child: isWithdrawal
                    ? ElevatedButton(
                        onPressed: () async {
                          // 退会申請キャンセル
                          await ref.watch(loadingServiceProvider.notifier).wrap(
                              ref
                                  .watch(memberViewModelProvider.notifier)
                                  .cancelWithdrawal());

                          showCreateToast('退会申請を取り消しました');
                        },
                        child: const Text('退会申請を取り消す'),
                      )
                    : ElevatedButton(
                        onPressed: () async {
                          final result = await showOkCancelAlertDialog(
                            context: context,
                            title: '退会申請を行いますか？',
                            isDestructiveAction: true,
                          );

                          if (result == OkCancelResult.cancel) {
                            return;
                          }

                          // 退会申請
                          await ref.watch(loadingServiceProvider.notifier).wrap(
                              ref
                                  .watch(memberViewModelProvider.notifier)
                                  .createWithdrawal());

                          showCreateToast('退会申請を行いました');
                        },
                        child: const Text('退会申請'),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

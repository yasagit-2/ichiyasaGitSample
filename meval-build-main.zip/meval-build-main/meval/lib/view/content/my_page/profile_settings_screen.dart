import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../provider/authentication_type_provider.dart';
import '../../../view_model/member_view_model.dart';
import '../../initial/register/gender_selection.dart';
import '../../initial/register/mailaddress_field.dart';
import '../../initial/register/month_of_birth_selection.dart';
import '../../initial/register/name_field.dart';
import '../../initial/register/nickname_field.dart';
import '../../initial/register/prefecture_selection.dart';
import '../../style/style.dart';
import 'auth_phone_field.dart';
import 'profile_update_button.dart';

class ProfileSettingsScreen extends ConsumerWidget {
  static String path = 'profile';
  static String name = 'profile';

  const ProfileSettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final member = ref.watch(memberViewModelProvider)!;

    // 認証タイプ
    final authenticationType = ref.read(authenticationTypeProvider);

    // 電話番号フィールドの表示
    final isDisplayPhoneField = authenticationType == AuthenticationType.sms;

    return GestureDetector(
      // フォーカスを外す
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Theme.of(context).canvasColor,
          elevation: 0.0,
          title: const Text('プロフィール設定', style: TextStyles.appBarTitle),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // 電話番号
                // （電話番号は変更不可。2022/09現在、運用対処として整理。）
                isDisplayPhoneField
                    ? Column(
                        children: const [
                          AuthPhoneField(),
                          VerticalSpacer.standard,
                        ],
                      )
                    : const SizedBox(),
                // ニックネーム
                NicknameField(nickname: member.nickname),
                // 性別
                GenderSelection(gender: member.gender),
                VerticalSpacer.smallish,
                // 生年月
                MonthOfBirthSelection(monthOfBirth: member.monthOfBirth),
                VerticalSpacer.smallish,
                // 居住地
                PrefectureSelection(prefecture: member.prefecture),
                VerticalSpacer.standard,
                // 氏名
                nameField(name: member.name),
                VerticalSpacer.standard,
                // メールアドレス
                mailAddressField(mailAddress: member.mailAddress),
                VerticalSpacer.standard,
                // プロフィール更新ボタン
                const ProfileUpdateButton(),
                VerticalSpacer.standard,
                // 公的認証ボタン
                // （公的認証は現状非表示。）
                // const OfficialCertificationButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

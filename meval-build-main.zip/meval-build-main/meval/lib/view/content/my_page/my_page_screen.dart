import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:settings_ui/settings_ui.dart';

import '../../../const/constant.dart';
import '../../../provider/authentication_type_provider.dart';
import '../../../provider/settings_provider.dart';
import '../../../provider/shared_strage_provider.dart';
import '../../../view_model/login_view_model.dart';
import '../../../view_model/member_view_model.dart';
import '../../initial/login/login_screen.dart';
import '../../style/style.dart';
import 'about_app.dart';
import 'help_screen.dart';
import 'profile_settings_screen.dart';
import 'withdrawal_screen.dart';

// チュートリアル表示プロバイダ
final displayedTutorialProvider = StateProvider.autoDispose((ref) =>
    ref
        .watch(sharedPreferencesProvider)
        .getBool(SharedPreferenceConst.displayedTutorialSearchScreen) ??
    false);

class MyPageScreen extends HookConsumerWidget {
  const MyPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ログイン中の会員
    final memberAsyncValue = ref.watch(memberStreamProvider);
    if (memberAsyncValue is! AsyncData || memberAsyncValue.value == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final member = memberAsyncValue.value!;

    // プッシュ通知有効化
    final pushNotificationEnabled = useState(ref
            .watch(sharedPreferencesProvider)
            .getBool(SharedPreferenceConst.pushNotificationEnabled) ??
        false);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        centerTitle: true,
        title: const Text('マイページ', style: TextStyles.appBarTitle),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 会員ID
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SelectableText('ID : ${member.id}'),
              ],
            ),
            VerticalSpacer.smallish,
            // マイページコンテンツ
            _myPageContents(ref, pushNotificationEnabled),
          ],
        ),
      ),
    );
  }
}

/// マイページのコンテンツWidgetを生成します。
Widget _myPageContents(
    WidgetRef ref, ValueNotifier<bool> pushNotificationEnabled) {
  return SettingsList(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    sections: [
      SettingsSection(
        tiles: [
          SettingsTile.navigation(
            leading: const Icon(Icons.manage_accounts),
            title: const Text('プロフィール'),
            onPressed: (context) {
              // プロフィールへ
              context.goNamed(ProfileSettingsScreen.name);
            },
          ),
          SettingsTile.navigation(
            leading: const Icon(Icons.notifications),
            title: const Text('プッシュ通知設定'),
            onPressed: (context) {
              AppSettings.openNotificationSettings(asAnotherTask: true);
            },
          ),
          SettingsTile.switchTile(
            initialValue: !ref.watch(displayedTutorialProvider),
            onToggle: (value) async {
              ref
                  .read(displayedTutorialProvider.notifier)
                  .update((_) => !value);
              await ref.read(sharedPreferencesProvider).setBool(
                  SharedPreferenceConst.displayedTutorialSearchScreen, !value);
            },
            leading: const Icon(Icons.description),
            title: const Text('チュートリアルを表示'),
          ),
        ],
      ),
      SettingsSection(
        tiles: [
          SettingsTile.navigation(
            leading: const Icon(Icons.info),
            title: const Text('アプリについて'),
            onPressed: (context) {
              // アプリについてへ
              context.goNamed(AboutApp.name);
            },
          ),
          SettingsTile.navigation(
            leading: const Icon(Icons.help),
            title: const Text('ヘルプ'),
            // ヘルプページへ
            onPressed: (context) => context.goNamed(HelpScreen.name),
          ),
        ],
      ),
      SettingsSection(
        tiles: [
          SettingsTile(
            leading: const Icon(Icons.logout),
            title: const Text('ログアウト'),
            onPressed: (context) async {
              final result = await showOkCancelAlertDialog(
                context: context,
                title: 'ログアウトしますか？',
                isDestructiveAction: true,
              );

              if (result == OkCancelResult.cancel) {
                return;
              }

              await ref.watch(mapIconProvider.future);
              final navigatorState = Navigator.of(context);
              return _logout(ref, navigatorState);
            },
          ),
        ],
      ),
      SettingsSection(
        tiles: [
          SettingsTile.navigation(
            leading: Image.asset(Const.withdrawal, height: 28.0),
            title: const Text('退会'),
            onPressed: (context) async {
              // 退会申請へ
              context.goNamed(WithdrawalScreen.name);
            },
          ),
        ],
      ),
    ],
  );
}

/// ログアウトし、履歴を破棄した上で、[LoginScreen]へ戻ります。
Future<void> _logout(WidgetRef ref, NavigatorState navigatorState) async {
  // 状態をリフレッシュ
  refreshStateForLogout(ref);
  // ログアウト
  await ref.watch(loginViewModelProvider.notifier).logout();
  // ログイン画面へ
  navigatorState.context.go(LoginScreen.path);
}

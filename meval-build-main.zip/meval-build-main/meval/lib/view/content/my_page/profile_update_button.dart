import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../const/constant.dart';
import '../../../view_model/member_view_model.dart';
import '../../component/loading_service.dart';
import '../../initial/register/gender_selection.dart';
import '../../initial/register/mailaddress_field.dart';
import '../../initial/register/month_of_birth_selection.dart';
import '../../initial/register/name_field.dart';
import '../../initial/register/nickname_field.dart';
import '../../initial/register/prefecture_selection.dart';
import '../../style/style.dart';

final profileUpdateValidationProvider = Provider.autoDispose((ref) {
  // ログイン中の会員
  final member = ref.watch(memberViewModelProvider);
  if (member == null) return false;

  final nickname = ref.watch(nicknameProvider);
  final gender = ref.watch(genderProvider);
  final monthOfBirth = ref.watch(monthOfBirthProvider);
  final prefecture = ref.watch(prefectureProvider);
  final name = ref.watch(nameProvider);
  final mailAddress = ref.watch(mailAddressProvider);

  if (member.nickname == nickname &&
      member.gender == gender &&
      member.monthOfBirth == monthOfBirth &&
      member.prefecture == prefecture &&
      member.name == name &&
      member.mailAddress == mailAddress) {
    // 変更がない場合
    return false;
  }

  if (nickname.isNotEmpty &&
      // ニックネームの最大文字数
      nickname.characters.length <= TextFieldConst.nicknameMaxLength &&
      gender.isNotEmpty &&
      monthOfBirth.compareTo(Const.initialDate) != 0 &&
      prefecture.isNotEmpty &&
      name.isNotEmpty &&
      name.characters.length <= TextFieldConst.nicknameMaxLength &&
      mailAddress.isNotEmpty &&
      mailAddress.characters.length <= TextFieldConst.mailAddressMaxLength &&
      EmailValidator.validate(mailAddress)) {
    return true;
  }

  return false;
});

class ProfileUpdateButton extends ConsumerWidget {
  const ProfileUpdateButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isValid = ref.watch(profileUpdateValidationProvider);

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isValid
            ? () async {
                final result = await showOkCancelAlertDialog(
                  context: context,
                  title: 'プロフィールを更新しますか？',
                  isDestructiveAction: true,
                );

                if (result == OkCancelResult.cancel) {
                  return;
                }

                await _updateMember(ref, context);

                // フォーカスを外す
                FocusScope.of(context).unfocus();
              }
            : null,
        child: const Text('更新', style: TextStyles.buttonTextStyle),
      ),
    );
  }

  /// 会員情報を更新します。
  Future<void> _updateMember(WidgetRef ref, BuildContext context) async {
    final nickname = ref.read(nicknameProvider);
    final gender = ref.read(genderProvider);
    final monthOfBirth = ref.read(monthOfBirthProvider);
    final prefecture = ref.read(prefectureProvider);
    final name = ref.read(nameProvider);
    final mailAddress = ref.read(mailAddressProvider);

    await ref.read(loadingServiceProvider.notifier).wrap(ref
        .read(memberViewModelProvider.notifier)
        .updateMember(
            nickname: nickname,
            gender: gender,
            monthOfBirth: monthOfBirth,
            prefecture: prefecture,
            name: name,
            mailAddress: mailAddress));

    await showOkAlertDialog(
      context: context,
      title: 'プロフィールを更新しました',
    );
  }
}

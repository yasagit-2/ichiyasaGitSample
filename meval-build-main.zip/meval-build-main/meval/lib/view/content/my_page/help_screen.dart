import 'dart:io';

import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../provider/settings_provider.dart';
import '../../../util/logger.dart';
import '../../style/style.dart';

/// ヘルプ画面
///
/// 2022/9/23 時点の webview_flutter ^3.0.4 には、以下で報告されているissueが存在します。
/// 現時点でアプリの動作には影響が無さそうですが、コンソールにはエラーが出力されます。
/// * https://github.com/apache/cordova-ios/issues/1103
class HelpScreen extends ConsumerStatefulWidget {
  static String path = 'help';
  static String name = 'help';

  const HelpScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends ConsumerState<HelpScreen> {
  late WebViewController _webViewController;

  bool _isLoading = true;

  // タイトル
  String _title = '';
  double _downloadPercentage = 0.0;

  bool _canGoBack = false;
  bool _canGoForward = false;

  @override
  void initState() {
    super.initState();
    // 仮想ディスプレイの有効化
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  void dispose() {
    logger.fine('dispose.');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsStateProvider);
    if (settings == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        centerTitle: true,
        title: Text(
          _title,
          style: const TextStyle(
              fontSize: 20.0, fontFamily: titleFont, color: Colors.black),
        ),
      ),
      body: Column(
        children: [
          _isLoading
              ? LinearProgressIndicator(
                  value: _downloadPercentage,
                  minHeight: 7.0,
                )
              : const SizedBox(),
          Expanded(
            child: Scrollbar(
              trackVisibility: true,
              child: WebView(
                initialUrl: settings.helpPageUrl,
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (controller) {
                  _webViewController = controller;
                },
                onPageFinished: (String url) async {
                  // タイトル設定（Webページのタイトルを取得）
                  final title = await _webViewController.getTitle();
                  if (title != null) _title = title;

                  _canGoBack = await _webViewController.canGoBack();
                  _canGoForward = await _webViewController.canGoForward();

                  if (_isLoading) _toggleLoading();
                },
                onProgress: (progress) => _calculateProgress(progress),
                onWebResourceError: (error) async {
                  if (error.errorCode == -999 &&
                      error.domain == 'NSURLErrorDomain') {
                    logger.warning(
                      'errorCode=${error.errorCode}, domain=${error.domain}, description=${error.description}, errorType=${error.errorType}, failingUrl=${error.failingUrl}',
                    );

                    // キャンセルイベントを無視（以下参照）
                    // https://github.com/flutter/flutter/issues/112433#issuecomment-1273114647
                    return;
                  }

                  logger.severe(
                    'errorCode=${error.errorCode}, domain=${error.domain}, description=${error.description}, errorType=${error.errorType}, failingUrl=${error.failingUrl}',
                  );
                  await showOkAlertDialog(
                    context: context,
                    title: 'ヘルプページを表示できません',
                  );

                  context.pop();
                },
              ),
            ),
          ),
        ],
      ),
      persistentFooterAlignment: AlignmentDirectional.center,
      persistentFooterButtons: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: _canGoBack ? _webViewController.goBack : null,
            ),
            IconButton(
              icon: const Icon(Icons.arrow_forward),
              onPressed: _canGoForward ? _webViewController.goForward : null,
            ),
          ],
        ),
      ],
    );
  }

  /// ローディングの切り替えを行います。
  void _toggleLoading() {
    setState(() => _isLoading = !_isLoading);
  }

  /// 進捗計算を行います。
  void _calculateProgress(int progress) {
    setState(() => _downloadPercentage = (progress / 100));
  }
}

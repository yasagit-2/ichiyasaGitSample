import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../provider/screen_type_provider.dart';
import 'tab/base/base_screen.dart';
import 'tab/event/event_screen.dart';
import 'tab/walk/walk_screen.dart';

/// 記録画面
/// タブを構成します。各タブのコンテンツとして、[BaseScreen]、[EventScreen]、および[WalkScreen]を利用します。
class RecordScreen extends ConsumerWidget {
  static const _tabs = [
    _TabInfo(
      recordTabType: RecordTabType.base,
      label: '拠点',
      widget: BaseScreen(),
      icon: FaIcon(FontAwesomeIcons.fortAwesome),
    ),
    _TabInfo(
      recordTabType: RecordTabType.event,
      label: 'イベント',
      widget: EventScreen(),
      icon: FaIcon(FontAwesomeIcons.calendarCheck),
    ),
    _TabInfo(
      recordTabType: RecordTabType.walk,
      label: 'ウォーク',
      widget: WalkScreen(),
      icon: FaIcon(FontAwesomeIcons.walking),
    ),
  ];

  const RecordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: _tabs.length,
      child: Builder(builder: (context) {
        final tabType = ref.watch(recordTabTypeProvider);
        final tabInfo = _tabs.firstWhere((tab) => tab.recordTabType == tabType);
        final index = _tabs.indexOf(tabInfo);

        // プロバイダのタブタイプへ移動
        final tabController = DefaultTabController.of(context)!;
        tabController.animateTo(index);

        tabController.addListener(() {
          if (!tabController.indexIsChanging) {
            // タブが変化した際に状態を更新
            ref
                .read(recordTabTypeProvider.notifier)
                .update((_) => RecordTabType.values[tabController.index]);
          }
        });
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).canvasColor,
            automaticallyImplyLeading: false,
            elevation: 0.0,
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: Ink(
                height: 38.0,
                child: TabBar(
                  unselectedLabelColor: Colors.black,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicator: BoxDecoration(
                    color: Colors.blueGrey,
                    borderRadius: BorderRadius.circular(50),
                    // color: Colors.blueGrey,
                  ),
                  tabs: _tabs.map((tab) {
                    return Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          tab.icon,
                          const SizedBox(width: 8.0),
                          Text(tab.label,
                              style: const TextStyle(fontSize: 14.0)),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          body: TabBarView(
            children: _tabs.map((tab) => tab.widget).toList(),
          ),
        );
      }),
    );
  }
}

/// タブの情報を保持するクラスです。
class _TabInfo {
  // タブタイプ
  final RecordTabType recordTabType;

  // タブのラベル
  final String label;

  // タブ選択時に表示するWidget
  final Widget widget;

  // タブのアイコン
  final Widget icon;

  const _TabInfo({
    required this.recordTabType,
    required this.label,
    required this.widget,
    required this.icon,
  });
}

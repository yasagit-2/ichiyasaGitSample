import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../const/constant.dart';

class CalendarHeader extends StatelessWidget {
  final DateTime focusedDay;
  final VoidCallback onLeftArrowTap;
  final VoidCallback onRightArrowTap;
  final VoidCallback onTodayButtonTap;
  final ValueChanged<CalendarFormat> onFormatChanged;
  final bool clearButtonVisible;
  final CalendarFormat calendarFormat;
  final Map<CalendarFormat, String> availableCalendarFormats;

  const CalendarHeader({
    Key? key,
    required this.focusedDay,
    required this.onLeftArrowTap,
    required this.onRightArrowTap,
    required this.onTodayButtonTap,
    required this.clearButtonVisible,
    required this.onFormatChanged,
    required this.calendarFormat,
    required this.availableCalendarFormats,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final headerText = Const.yearMonthFormat.format(focusedDay);

    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: onLeftArrowTap,
        ),
        SizedBox(
          width: 120.0,
          child: Text(
            headerText,
            style: const TextStyle(fontSize: 18.0),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.calendar_today, size: 20.0),
          visualDensity: VisualDensity.compact,
          onPressed: onTodayButtonTap,
        ),
        const Spacer(),
        InkWell(
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10.0, vertical: 2.0),
            decoration: BoxDecoration(
              color: Colors.deepOrange[400],
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: Text(
              availableCalendarFormats[_nextFormat()]!,
              style: const TextStyle(color: Colors.white, fontSize: 15.0),
            ),
          ),
          onTap: () => onFormatChanged(_nextFormat()),
        ),
        const Spacer(),
        IconButton(
          icon: const Icon(Icons.chevron_right),
          onPressed: onRightArrowTap,
        ),
      ],
    );
  }

  CalendarFormat _nextFormat() {
    final formats = availableCalendarFormats.keys.toList();
    int id = formats.indexOf(calendarFormat);
    id = (id + 1) % formats.length;

    return formats[id];
  }
}

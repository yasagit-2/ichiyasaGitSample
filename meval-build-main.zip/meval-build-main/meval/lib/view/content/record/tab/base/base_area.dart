import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../model/data/base.dart';
import '../../../../../model/data/check_in.dart';
import '../../../../../model/data/completed_base.dart';
import '../../../../../model/data/title.dart' as app;
import '../../../../../provider/map_controller_provider.dart';
import '../../../../../provider/menu_button_provider.dart';
import '../../../../../provider/record_provider.dart';
import '../../../../../provider/screen_type_provider.dart';
import '../../../../../util/image_processing.dart';
import '../../../../../util/logger.dart';
import '../../../../component/image_view.dart';
import '../../../../component/loading_service.dart';
import '../../../../style/style.dart';
import '../../../search/search_map.dart';

/// 拠点領域
///
/// 制覇未済の拠点について、進捗状況を表示します。
/// 拠点の公開ステータスが「公開済み」ではない場合は表示しません。
class BaseArea extends ConsumerWidget {
  // 称号
  final app.Title title;

  const BaseArea({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 称号に紐づく親拠点
    final parentBasesAsyncValue =
        ref.watch(parentBasesByTitleIdStreamProvider(title.id));

    // 称号に紐づく拠点制覇情報
    final completedBasesAsyncValue =
        ref.watch(completedBasesByTitleIdStreamProvider(title.id));

    // チェックイン情報（親拠点、サブ拠点のチェックイン情報）
    final checkedInAsyncValue = ref.watch(checkedInStreamProvider);

    if (parentBasesAsyncValue is! AsyncData ||
        completedBasesAsyncValue is! AsyncData ||
        checkedInAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    // 親拠点
    final parentBases = parentBasesAsyncValue.value;
    if (parentBases == null || parentBases.isEmpty) {
      return const SizedBox();
    }

    // 制覇済み拠点
    final completedBases = completedBasesAsyncValue.value;

    // 親拠点から制覇済み拠点を除外
    final excludedParentBases =
        _excludeCompletedBases(parentBases, completedBases);

    // チェックインリスト
    final checkedInList = checkedInAsyncValue.value;

    final navigator = Navigator.of(context);

    return ListView.separated(
      itemCount: excludedParentBases.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      separatorBuilder: (BuildContext context, int index) {
        return VerticalSpacer.separator;
      },
      itemBuilder: (BuildContext context, int index) {
        // 表示対象の拠点（親拠点）
        final parentBase = excludedParentBases[index];

        // 親拠点IDに紐づくサブ拠点
        final subBasesAsyncValue =
            ref.watch(subBasesByParentBaseIdStreamProvider(parentBase.id));
        if (subBasesAsyncValue is AsyncLoading) {
          return const SizedBox();
        }
        if (subBasesAsyncValue is AsyncError) {
          final error = subBasesAsyncValue as AsyncError;
          logger.severe(error.error);
          logger.severe(error.stackTrace);
          return const SizedBox();
        }

        // true:親拠点チェックイン済み
        final isCheckedInParent = _isCheckedIn(parentBase, checkedInList);

        // 当該親拠点に紐づくサブ拠点のリスト
        final subBaseList = subBasesAsyncValue.value!;
        // チェックイン済みサブ拠点のリスト
        final checkedInSubBaseList = subBaseList
            .where((subBase) => _isCheckedIn(subBase, checkedInList))
            .toList();

        // サブ拠点のチェックイン率
        final checkedInRate = _calcCheckedInRateOfSubBase(
            parentBase, subBaseList, checkedInSubBaseList, isCheckedInParent);

        return SizedBox(
          width: double.infinity,
          height: 80,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // 拠点画像
              _baseImage(ref, navigator, parentBase, isCheckedInParent),
              Expanded(
                child: Material(
                  elevation: 8.0,
                  color: _baseListColor(isCheckedInParent),
                  child: InkWell(
                    // 拠点制覇済みの場合はタップ不可
                    onTap: _onTap(ref, context, parentBase,
                        checkedInSubBaseList, checkedInRate),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: SizedBox(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // 拠点名
                                  _baseName(parentBase, isCheckedInParent),
                                  VerticalSpacer.smallish,
                                  // プログレスインジケータ
                                  _progressIndicator(checkedInRate),
                                ],
                              ),
                            ),
                          ),
                        ),
                        HorizontalSpacer.smallish,
                        // チェックイン数
                        _checkinRatio(parentBase, checkedInSubBaseList),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// 親拠点[parentBases]から制覇済み拠点[completedBases]を除外します。
  List<Base> _excludeCompletedBases(
      List<Base> parentBases, List<CompletedParentBase>? completedBases) {
    if (completedBases == null || completedBases.isEmpty) {
      return parentBases;
    }

    // 制覇済み拠点（親拠点）の拠点IDリスト
    final completedBaseIdList =
        completedBases.map((completedBase) => completedBase.id);

    return parentBases
        .where((parentBase) => !completedBaseIdList.contains(parentBase.id))
        .toList();
  }

  /// チェックイン情報[checkedInList]を確認し、[base]がチェックイン済みである場合、trueを返却します。
  bool _isCheckedIn(Base base, List<CheckIn>? checkedInList) {
    if (checkedInList == null || checkedInList.isEmpty) {
      return false;
    }

    // チェックイン済み拠点IDのリスト
    final checkedInBaseIdList =
        checkedInList.map((checkIn) => checkIn.baseRef.id).toList();

    return checkedInBaseIdList.contains(base.id) ? true : false;
  }

  /// 親拠点[parentBase]の拠点画像Widgetを生成します。
  Widget _baseImage(WidgetRef ref, NavigatorState navigator, Base parentBase,
      bool isCheckedInParent) {
    if (!isCheckedInParent) {
      // チェックイン未済拠点は画像表示なし

      return const SizedBox(
        width: 80.0,
        height: 80.0,
        child: Icon(Icons.lock_open, size: 36.0),
      );
    }

    // 拠点画像
    return createNetworkImage(
      navigator: navigator,
      imageUrl: parentBase.imageUrl,
      onTap: () async {
        // 画面を探索画面へ
        ref.read(screenTypeProvider.notifier).update((_) => ScreenType.search);
        // 探索画面のメニューボタンを拠点ボタンへ
        ref
            .read(selectedMenuButtonProvider.notifier)
            .update((_) => MenuButtonSelection.base);

        final geopoint = parentBase.position.geopoint;

        // マップの中心位置を当該拠点の位置情報へ変更
        await moveCamera(ref, LatLng(geopoint.latitude, geopoint.longitude));

        ref
            .read(baseBottomSheetOpenProvider.notifier)
            .update((_) => parentBase);
      },
      // 画像拡大表示
      onLongPress: (imageProvider) =>
          navigator.context.pushNamed(ImageView.name, extra: imageProvider),
    );
  }

  /// 拠点リストの色を返却します。
  Color _baseListColor(bool isCheckedInParent) {
    return isCheckedInParent
        // チェックイン済み
        ? Colors.lightBlue.shade700
        // チェックイン未済
        : Colors.lightBlue.shade200;
  }

  /// 親拠点[parentBase]に所属するチェックイン済みサブ拠点[checkedInSubBaseList]のチェックイン率を算出します。
  ///
  /// [parentBase]がチェックイン未済（[isCheckedInParent]=false）の場合、0.0を返却します。
  /// [parentBase]がチェックイン済み、かつ[parentBase]がサブ拠点を持たない場合（サブ拠点を持たないチェックイン済み拠点の場合）、1.0を返却します。
  double _calcCheckedInRateOfSubBase(Base parentBase, List<Base> subBaseList,
      List<Base> checkedInSubBaseList, bool isCheckedInParent) {
    if (!isCheckedInParent) {
      // 親拠点にチェックインしていない場合
      return 0.0;
    }

    if (subBaseList.isEmpty || parentBase.subBaseCount == 0) {
      // サブ拠点を持たないチェックイン済み親拠点の場合、およびsubBaseCountが0の場合はCOMPLETE
      return 1.0;
    }

    // サブ拠点チェックイン率
    return checkedInSubBaseList.length / parentBase.subBaseCount;
  }

  /// 拠点タップ時の[GestureTapCallback]を返却します。
  /// サブ拠点のチェックイン率[checkedInRate]=1.0の場合(COMPLETEの場合)、タップ可能とします。
  /// COMPLETEしていない場合、タップ不可です。
  GestureTapCallback? _onTap(
    WidgetRef ref,
    BuildContext context,
    // 親拠点
    Base parentBase,
    // チェックイン済みサブ拠点のリスト
    List<Base> checkedInSubBaseList,
    // サブ拠点のチェックイン率
    double checkedInRate,
  ) {
    if (checkedInRate != 1.0) {
      // 未COMPLETE、タップ不可
      return null;
    }

    return () async {
      final result = await showOkCancelAlertDialog(
        context: context,
        title: '拠点をCOMPLETEしますか？',
        isDestructiveAction: true,
      );

      if (result == OkCancelResult.cancel) {
        return;
      }

      // 拠点制覇情報の保存
      await ref.read(loadingServiceProvider.notifier).wrap(
          saveCompletedBases(ref, title, parentBase, checkedInSubBaseList));

      await showOkAlertDialog(
        context: context,
        title: parentBase.name,
        message: '拠点をCOMPLETEしました！',
      );
    };
  }

  /// 親拠点[parentBase]の拠点名を表示するWidgetを生成します。
  /// チェックイン未済の場合、拠点名は表示しません。
  Widget _baseName(Base parentBase, bool isCheckedInParent) {
    const textStyle = TextStyle(color: Colors.white, fontSize: 18.0);
    return isCheckedInParent
        ? Text(parentBase.name,
            style: textStyle, overflow: TextOverflow.ellipsis)
        : const Text('？？？？？', style: textStyle);
  }

  /// サブ拠点のチェックイン率[checkedInRate]に応じたプログレスインジケータを生成します。
  /// [checkedInRate]=1.0の場合、"COMPLETE"を表示します。
  Widget _progressIndicator(double checkedInRate) {
    return Stack(
      children: [
        LinearProgressIndicator(
          backgroundColor: Colors.white,
          color: Colors.blue.shade900,
          value: checkedInRate,
          minHeight: 30,
        ),
        Align(
          alignment: Alignment.center,
          child: checkedInRate == 1.0
              ? const Text(
                  'COMPLETE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                  ),
                )
              : const SizedBox(),
        ),
      ],
    );
  }

  /// チェックイン数のWidgetを生成します。
  /// "チェックイン済みサブ拠点数/親拠点に紐づくサブ拠点数"の表示Widgetを構成します。
  Widget _checkinRatio(Base parentBase, List<Base> checkedInSubBaseList) {
    const textStyle = TextStyle(fontSize: 36.0, color: Colors.white);
    return Row(
      children: [
        Text(checkedInSubBaseList.length.toString(), style: textStyle),
        const Text('/', style: textStyle),
        Text(parentBase.subBaseCount.toString(), style: textStyle),
        HorizontalSpacer.smallish,
      ],
    );
  }
}

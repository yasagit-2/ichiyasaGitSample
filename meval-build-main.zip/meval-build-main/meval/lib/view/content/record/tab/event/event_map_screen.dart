import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/collection.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../const/message.dart';
import '../../../../../model/data/event.dart';
import '../../../../../model/data/event_participation_history.dart';
import '../../../../../model/data/map_position.dart';
import '../../../../../provider/data/event_marker_data.dart';
import '../../../../../provider/event_provider.dart';
import '../../../../../provider/location_provider.dart';
import '../../../../../util/logger.dart';
import '../../../../../util/show_toast.dart';
import '../../../../component/loading_service.dart';
import '../../../../style/style.dart';
import 'qr_code_screen.dart';
import 'stamp_rally_screen.dart';

class EventMapScreen extends ConsumerWidget {
  static String pathFromTop = 'eventMapFromTop';
  static String pathFromRecord = 'eventMapFromRecord';
  static String nameFromTop = 'eventMapFromTop';
  static String nameFromRecord = 'eventMapFromRecord';

  // イベントID
  final String eventId;

  const EventMapScreen({Key? key, required this.eventId}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    logger.fine('EventMapScreen');

    WidgetsBinding.instance.addPostFrameCallback((_) {
      // loading
      ref.read(loadingServiceProvider.notifier).present();
    });

    final navigator = Navigator.of(context);

    // イベント
    final eventAsyncValue = ref.watch(eventByIdStreamProvider(eventId));
    // イベントスポット
    final eventSpotsAsyncValue = ref.watch(eventSpotsStreamProvider(eventId));

    // 参加イベント
    final participatedEventAsyncValue =
        ref.watch(participatedEventByEventIdStreamProvider(eventId));
    // スタンプ獲得済みのイベントスポット
    final completedSpotsAsyncValue =
        ref.watch(completedSpotsByEventIdStreamProvider(eventId));

    if (eventAsyncValue is! AsyncData ||
        eventSpotsAsyncValue is! AsyncData ||
        participatedEventAsyncValue is! AsyncData ||
        completedSpotsAsyncValue is! AsyncData) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // ローディング解除
        ref.read(loadingServiceProvider.notifier).dismiss();
      });
      return const Scaffold();
    }

    final event = eventAsyncValue.value;
    final eventSpots = eventSpotsAsyncValue.value;

    // 参加イベント
    final participatedEvent = participatedEventAsyncValue.value;
    // スタンプ獲得済みのイベントスポット
    final completedSpots = completedSpotsAsyncValue.value;

    if (event == null ||
        eventSpots == null ||
        eventSpots.isEmpty ||
        completedSpots == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        // ローディング解除
        ref.read(loadingServiceProvider.notifier).dismiss();

        // eventsコレクションを定義する場合、必ず一つ以上のイベントスポットを設定する設計。
        // そのため、このケースは発生しない想定。（もし発生したら、それはバグです。）
        await showOkAlertDialog(message: 'イベントスポットがありません', context: context);
        context.pop();
      });
      return const Scaffold();
    }

    // true：イベント達成地点数分のスタンプを獲得済み（深い意味は無いが念のため、イベント達成地点数"以上"で判定）
    final isCompleteSpotCount =
        event.completeSpotCount <= completedSpots.length;

    return FutureBuilder(
      future: _createBuilderData(ref, navigator, event, eventSpots),
      builder: (BuildContext context, AsyncSnapshot<_BuilderData> snapshot) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // ローディング解除
          ref.read(loadingServiceProvider.notifier).dismiss();
        });

        Set<Marker> markers = {};
        Set<Circle> circles = {};
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          final builderData = snapshot.data!;
          markers = builderData.markers.asSet();
          now = builderData.now;

          // サークル生成
          circles = _createEventCircles(
              event, eventSpots, participatedEvent, completedSpots, now);
        }

        // イベント期間中
        final isEventDuring = event.effectivePeriodBegin.compareTo(now) <= 0 &&
            now.compareTo(event.effectivePeriodEnd) <= 0;

        return Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(40.0),
            child: AppBar(
              centerTitle: true,
              backgroundColor: Theme.of(context).canvasColor,
              elevation: 0.0,
              title: _eventTitle(event, now),
              leading: IconButton(
                onPressed: () {
                  // イベントリストストリームプロバイダをリフレッシュしイベントを再取得
                  ref.invalidate(eventStreamProvider);

                  context.pop();
                },
                icon: const Icon(Icons.close, size: 24.0),
              ),
              actions: [
                FittedBox(
                  fit: BoxFit.none,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 12.0),
                    child: IconButton(
                      onPressed: () {
                        if (GoRouter.of(context).location == pathFromTop) {
                          //  スタンプラリー画面へ（FromTop）
                          context.pushNamed(StampRallyScreen.nameFromTop,
                              extra: event.id);
                        } else {
                          //  スタンプラリー画面へ（FromRecord）
                          context.pushNamed(StampRallyScreen.nameFromRecord,
                              extra: event.id);
                        }
                      },
                      icon: Image.asset(Const.stamp),
                      iconSize: 36.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
          body: SafeArea(
            child: Stack(
              children: [
                // イベントマップ（Google Map）
                _eventMap(ref, event, participatedEvent, markers, circles),
                // イベント期間中、かつイベント達成地点数分のスタンプを獲得未済の場合、QRコード読み込み可能
                isEventDuring && !isCompleteSpotCount
                    ? Padding(
                        padding: const EdgeInsets.only(top: 60, left: 10),
                        child: FloatingActionButton(
                          heroTag: 'qrCodeCamera',
                          backgroundColor: AppColors.mainColor,
                          onPressed: () async {
                            if (event.isUseLocation) {
                              // 位置情報使用許可
                              final isPermitToUseLocation = await ref
                                  .watch(locationProvider)
                                  .checkPermission();

                              // 位置情報使用許可が得られない場合
                              if (!isPermitToUseLocation) {
                                await showOkAlertDialog(
                                    context: context,
                                    title: '位置情報を利用できません',
                                    message: 'スタンプ獲得のためには位置情報の利用を許可してください');
                                return;
                              }
                            }

                            // QRコード読み込みへ
                            context.pushNamed(QrCodeScreen.name,
                                extra: event.id);
                          },
                          shape: const CircleBorder(
                            side: BorderSide(
                              color: Colors.blue,
                            ),
                          ),
                          child: const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 28.0,
                          ),
                        ),
                      )
                    : const SizedBox(),
              ],
            ),
          ),
        );
      },
    );
  }

  /// AppBarのタイトルWidgetを生成します。
  Widget _eventTitle(Event event, DateTime now) {
    // true：イベント期間終了
    final isEnd = now.compareTo(event.effectivePeriodEnd) > 0;

    if (isEnd) {
      // イベント期間終了
      return RichText(
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        textAlign: TextAlign.center,
        text: TextSpan(
          children: [
            const TextSpan(
              text: '※終了 ',
              style: TextStyle(
                  fontSize: 18.0, fontFamily: titleFont, color: Colors.red),
            ),
            TextSpan(
              text: event.title,
              style: const TextStyle(
                  fontSize: 18.0, fontFamily: titleFont, color: Colors.black),
            ),
          ],
        ),
      );
    }

    return Text(
      event.title,
      style: const TextStyle(
          fontSize: 18.0, fontFamily: titleFont, color: Colors.black),
    );
  }

  /// イベントマップを生成します。
  Widget _eventMap(
      WidgetRef ref,
      Event event,
      ParticipatedEvent? participatedEvent,
      Set<Marker> markers,
      Set<Circle> circles) {
    return GoogleMap(
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
      zoomControlsEnabled: true,
      mapToolbarEnabled: false,
      initialCameraPosition: const CameraPosition(
        target: MapConst.initialLocation,
        zoom: MapConst.initialZoom,
      ),
      onMapCreated: (GoogleMapController controller) async {
        if (event.isUseLocation &&
            (participatedEvent == null || !participatedEvent.isComplete)) {
          await requestPermission(ref);

          final locationPermission = await Geolocator.checkPermission();
          if (locationPermission != LocationPermission.whileInUse) {
            showErrorToast(DisplayedErrorMessage.currentLocationError);
          }
        }

        // イベントの中心位置へ移動
        await _moveCameraToNewPosition(controller, event.position);

        ref
            .watch(eventMapControllerProvider.notifier)
            .update((_) => controller);
      },
      onCameraIdle: () async {
        if (event.isUseLocation) {
          await requestPermission(ref);
        }
      },
      markers: markers,
      circles: circles,
    );
  }

  /// イベントサークルを生成します。
  Set<Circle> _createEventCircles(
      Event event,
      List<EventSpot> eventSpots,
      ParticipatedEvent? participatedEvent,
      List<CompletedSpot> completedSpots,
      DateTime now) {
    // true：イベント期間終了
    final isEnd = now.compareTo(event.effectivePeriodEnd) > 0;
    if (isEnd) {
      // イベント期間が終了している場合はサークルを生成しない
      return {};
    }

    if (!event.isUseLocation) {
      // イベントに位置情報を利用しない場合はサークルを生成しない
      return {};
    }

    if (participatedEvent != null && participatedEvent.isComplete) {
      // 達成済みイベントの場合はサークル生成しない
      return {};
    }

    // スタンプ獲得済みのイベントスポットIDリスト
    final completedSpotIdList = completedSpots
        .map((completedSpot) => completedSpot.eventSpotId)
        .toList();

    return eventSpots
        .map(
          (eventSpot) {
            if (completedSpotIdList.contains(eventSpot.id)) {
              // スタンプ獲得済みのためサークル生成しない
              return null;
            }

            final geopoint = eventSpot.position.geopoint;
            return Circle(
              circleId: CircleId(eventSpot.id),
              center: LatLng(geopoint.latitude, geopoint.longitude),
              radius: event.qrCodeRadius,
              fillColor: Colors.deepOrange.shade300.withOpacity(0.3),
              strokeWidth: 0,
            );
          },
        )
        .whereType<Circle>()
        .toSet();
  }

  /// [position]へMapを移動します。
  Future<void> _moveCameraToNewPosition(
      GoogleMapController controller, MapPosition position) async {
    final geopoint = position.geopoint;

    final target = LatLng(geopoint.latitude, geopoint.longitude);
    await controller.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: target,
          zoom: await controller.getZoomLevel(),
        ),
      ),
    );
  }

  /// FutureBuilderの構築に必要な情報として、
  /// イベントマーカーの生成および現在時刻（NTP）の取得を行います。
  Future<_BuilderData> _createBuilderData(WidgetRef ref,
      NavigatorState navigator, Event event, List<EventSpot> eventSpots) async {
    // イベントマーカー
    final markers = await ref.watch(eventMarkersProvider(EventMarkerData(
            navigator: navigator, event: event, eventSpots: eventSpots))
        .future);

    return _BuilderData(markers: markers, now: await NTP.now());
  }
}

class _BuilderData {
  final KtSet<Marker> markers;
  final DateTime now;

  _BuilderData({
    required this.markers,
    required this.now,
  });
}

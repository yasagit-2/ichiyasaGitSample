import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../model/data/event.dart';
import '../../../../../util/image_processing.dart';
import '../../../../component/image_view.dart';
import 'event_map_screen.dart';

class EventArea extends ConsumerWidget {
  // イベント
  final Event event;

  const EventArea({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        return SizedBox(
          width: double.infinity,
          height: 80,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // イベント画像
              _eventImage(ref, Navigator.of(context), event, now),
              // イベント内容
              _eventContent(context, event, now),
            ],
          ),
        );
      },
    );
  }

  /// イベント[event]の画像Widgetを生成します。
  Widget _eventImage(
      WidgetRef ref, NavigatorState navigator, Event event, DateTime now) {
    if (now.compareTo(event.effectivePeriodBegin) < 0) {
      // イベント期間開始前

      return SizedBox(
        width: 80.0,
        height: 80.0,
        child: Icon(
          Icons.warning,
          size: 56.0,
          color: Colors.deepOrange.shade500.withOpacity(0.2),
        ),
      );
    }

    if (event.imageUrl == null) {
      // 画像表示なし

      return SizedBox(
        width: 80.0,
        height: 80.0,
        child: IconButton(
          onPressed: () {
            // イベントマップへ
            navigator.context
                .goNamed(EventMapScreen.nameFromRecord, extra: event.id);
          },
          icon: const Icon(Icons.broken_image, size: 36.0),
        ),
      );
    }

    // イベント画像
    return createNetworkImage(
      navigator: navigator,
      imageUrl: event.imageUrl,
      onTap: () {
        // イベントマップへ
        navigator.context
            .goNamed(EventMapScreen.nameFromRecord, extra: event.id);
      },
      // 画像拡大表示
      onLongPress: (imageProvider) =>
          navigator.context.pushNamed(ImageView.name, extra: imageProvider),
    );
  }

  /// イベント[event]の期間およびタイトルを表示するWidgetを生成します。
  Widget _eventContent(BuildContext context, Event event, DateTime now) {
    // イベント期間
    final eventPeriodText = Text(
      '${Const.dateAndTimeFormat.format(event.effectivePeriodBegin)} 〜 ${Const.dateAndTimeFormat.format(event.effectivePeriodEnd)}',
      style: const TextStyle(color: Colors.white),
      maxLines: 1,
    );

    final isEnd = now.compareTo(event.effectivePeriodEnd) > 0;

    Widget eventPeriodWidget;
    if (isEnd) {
      // イベント期間終了
      eventPeriodWidget = Row(
        children: [
          const Text('※終了', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 5.0),
          eventPeriodText,
        ],
      );
    } else {
      eventPeriodWidget = eventPeriodText;
    }

    return Expanded(
      child: Material(
        elevation: 8.0,
        color: isEnd ? Colors.deepOrange.shade200 : Colors.deepOrange.shade600,
        child: InkWell(
          onTap: () {
            // イベントマップへ
            context.goNamed(EventMapScreen.nameFromRecord, extra: event.id);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: SizedBox(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // イベント期間
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: eventPeriodWidget,
                        ),
                        // イベントタイトル
                        Text(
                          event.title,
                          style: const TextStyle(color: Colors.white),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/collection.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../model/data/completed_walk.dart';
import '../../../../../provider/settings_provider.dart';
import '../../../../../provider/steps_provider.dart';
import '../../../../../util/datetime_util.dart';
import '../../../../component/loading_service.dart';
import '../../../../style/style.dart';

/// 歩数表示
class StepsDisplay extends ConsumerWidget {
  const StepsDisplay({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 選択日
    final selectedDay = ref.watch(selectedDayProvider);
    final week = _Week(day: selectedDay);

    final steps = ref.watch(stepsProvider);

    // 週間の歩数
    final stepsOfWeek = _sumStepsOfWeek(steps, week.beginningOfWeek);

    // 週間規定歩数
    final targetStepPerWeek = ref.watch(targetStepPerWeekProvider);
    // 週間規定歩数達成ポイント
    final stepAchievedPoint = ref.watch(stepAchievedPointProvider);

    return CustomScrollView(
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      slivers: [
        CupertinoSliverRefreshControl(
          onRefresh: () async {
            // 歩数再取得
            await getSteps(ref: ref, now: await NTP.now());
          },
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              return FutureBuilder(
                future: NTP.now(),
                builder:
                    (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
                  DateTime now = DateTime.now();

                  if (snapshot.hasData && snapshot.data != null) {
                    // NTPを利用
                    now = snapshot.data!;
                  }

                  // 週番号（YYYYWww）を選択日の週初（日曜日）から算出
                  final weeksNumAsStandardForm =
                      createWeeksNumAsStandardForm(week.beginningOfWeek);
                  // ウォーク達成履歴
                  final walkHistoryAsyncValue = ref
                      .watch(walkHistoryStreamProvider(weeksNumAsStandardForm));

                  bool isLoading = true;
                  if (walkHistoryAsyncValue is AsyncData) {
                    isLoading = false;
                  }

                  // ウォーク達成履歴
                  final walkHistory = walkHistoryAsyncValue.value;

                  // 規定歩数達成判定（true:達成）
                  final isAchieved = isAchievedPrescribedSteps(
                      selectedDay, stepsOfWeek, now, targetStepPerWeek);

                  // true:ウォークCOMPLETE可能
                  // ウォーク達成履歴が存在しない、かつ規定歩数達成
                  final isCompletable = walkHistory == null && isAchieved;

                  return Column(
                    children: [
                      // 選択日の歩数
                      ListTile(
                        leading: const FaIcon(
                          FontAwesomeIcons.calendarAlt,
                        ),
                        title: Text(
                          Const.dateFormat.format(selectedDay),
                          style: const TextStyle(
                            fontSize: 24.0,
                          ),
                        ),
                        horizontalTitleGap: 0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.baseline,
                        textBaseline: TextBaseline.alphabetic,
                        children: [
                          Text(
                            Const.numberFormatter
                                .format(_getEventsForDay(steps, selectedDay)),
                            style: TextStyle(
                                fontSize: 48.0,
                                color: Colors.lightBlue.shade900),
                          ),
                          const SizedBox(width: 8.0),
                          Text(
                            '歩',
                            style: TextStyle(
                                fontSize: 24.0,
                                color: Colors.lightBlue.shade900),
                          ),
                        ],
                      ),

                      // 週間歩数
                      ListTile(
                        leading: const FaIcon(
                          FontAwesomeIcons.calendarWeek,
                        ),
                        title: Text(
                          '${Const.monthDateFormat.format(week.beginningOfWeek)} 〜 ${Const.monthDateFormat.format(week.endingOfWeek)}',
                          style: const TextStyle(
                            fontSize: 24.0,
                          ),
                        ),
                        horizontalTitleGap: 0,
                      ),

                      VerticalSpacer.smallish,
                      Center(
                        child: isLoading
                            ? const CircularProgressIndicator()
                            : ElevatedButton(
                                onPressed: isCompletable
                                    ? () async {
                                        final result =
                                            await showOkCancelAlertDialog(
                                          context: context,
                                          title: 'ウォークCOMPLETEしますか？',
                                          isDestructiveAction: true,
                                        );

                                        if (result == OkCancelResult.cancel) {
                                          return;
                                        }

                                        // ウォーク達成情報の保存
                                        await ref
                                            .watch(
                                              loadingServiceProvider.notifier,
                                            )
                                            .wrap(
                                              saveCompletedWalks(
                                                ref,
                                                stepsOfWeek,
                                                stepAchievedPoint,
                                                now,
                                              ),
                                            );

                                        await showOkAlertDialog(
                                          context: context,
                                          title: 'ウォークCOMPLETEしました！',
                                        );
                                      }
                                    : null,
                                style: ElevatedButton.styleFrom(
                                  elevation: 24.0,
                                  backgroundColor: Colors.lightBlue.shade900,
                                  shadowColor: Colors.grey.shade900,
                                  minimumSize: const Size(200, 200),
                                  shape: CircleBorder(
                                    side: BorderSide(
                                      color: Colors.lightBlue.shade900,
                                      width: 1,
                                      style: BorderStyle.solid,
                                    ),
                                  ),
                                ),
                                child: Column(
                                  children: [
                                    _complete(walkHistory),
                                    // 週間の歩数
                                    Text(
                                      Const.numberFormatter.format(stepsOfWeek),
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 42.0),
                                    ),
                                    const SizedBox(
                                      width: 150,
                                      child: Divider(
                                        thickness: 1.0,
                                        color: Colors.white,
                                      ),
                                    ),
                                    // 週間規定歩数
                                    Text(
                                      Const.numberFormatter
                                          .format(targetStepPerWeek),
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 42.0),
                                    ),
                                  ],
                                ),
                              ),
                      )
                    ],
                  );
                },
              );
            },
            childCount: 1,
          ),
        ),
      ],
    );
  }

  /// [startDate]を週の開始日として、1週間の合計歩数を取得します。
  int _sumStepsOfWeek(KtLinkedMap<int, StepData> steps, DateTime startDate) {
    var sum = 0;
    for (int i = 0; i < DateTime.daysPerWeek; i++) {
      final target = startDate.add(Duration(days: i));
      sum += _getEventsForDay(steps, target);
    }

    return sum;
  }

  /// [day]のイベント（歩数）を取得します。
  /// [day]に該当する歩数が存在しない場合、0を返却します。
  int _getEventsForDay(KtLinkedMap<int, StepData> steps, DateTime day) {
    if (steps.size == 0) {
      return 0;
    }

    final step =
        steps[DateTime(day.year, day.month, day.day).millisecondsSinceEpoch];

    return step == null || step.steps == null ? 0 : step.steps!;
  }

  /// 規定歩数の達成を判定します。true:規定歩数達成
  bool isAchievedPrescribedSteps(
      DateTime day, int steps, DateTime now, int targetStepPerWeek) {
    return _isThisWeek(day, now) && steps >= targetStepPerWeek;
  }

  /// [day]が今週か否かを判定します。
  bool _isThisWeek(DateTime day, DateTime now) {
    // 現在の週
    final week = _Week(day: now);

    if (day.compareTo(week.beginningOfWeek) >= 0 &&
        week.endingOfWeek.compareTo(day) >= 0) {
      return true;
    }

    return false;
  }

  /// 「COMPLETE」文字列のWidgetを返却します。
  Widget _complete(WalkHistory? walkHistory) {
    if (walkHistory == null) {
      return const SizedBox();
    }

    return Column(
      children: [
        Text(
          'COMPLETE',
          style: TextStyle(color: Colors.red.shade500),
        ),
        // VerticalSpacer.smallish,
      ],
    );
  }
}

/// 週初/週末を保持します。
class _Week {
  // 週初（日曜日の00:00:00.000000）
  late final DateTime beginningOfWeek;

  // 週末（土曜日の23:59:59.999999）
  late final DateTime endingOfWeek;

  /// コンストラクタ
  /// [day]が含まれる週初/週末を算出します。
  _Week({required DateTime day}) {
    // 日曜日
    final sunday = (DateTime.sunday == day.weekday)
        ? day
        : day.subtract(Duration(days: day.weekday));
    // 土曜日
    final saturday = sunday.add(const Duration(days: DateTime.saturday));

    // 週初（日曜日の00:00:00.000000）
    beginningOfWeek = DateTime(sunday.year, sunday.month, sunday.day);
    // 週末（土曜日の23:59:59.999999）
    endingOfWeek = DateTime(
        saturday.year, saturday.month, saturday.day, 23, 59, 59, 999, 999);
  }
}

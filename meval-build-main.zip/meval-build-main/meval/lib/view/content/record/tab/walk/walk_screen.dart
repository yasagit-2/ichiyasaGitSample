import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'steps_calendar.dart';
import 'steps_display.dart';

class WalkScreen extends ConsumerStatefulWidget {
  const WalkScreen({Key? key}) : super(key: key);

  @override
  WalkScreenState createState() => WalkScreenState();
}

class WalkScreenState extends ConsumerState<WalkScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 8.0, left: 8.0, right: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            // カレンダー
            StepsCalendar(),

            Divider(
              thickness: 1.0,
              color: Colors.grey,
            ),

            // 歩数表示
            Expanded(child: StepsDisplay()),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../model/data/base.dart';
import '../../../../../model/data/completed_base.dart';
import '../../../../../model/data/title.dart' as app;
import '../../../../../provider/map_controller_provider.dart';
import '../../../../../provider/menu_button_provider.dart';
import '../../../../../provider/record_provider.dart';
import '../../../../../provider/screen_type_provider.dart';
import '../../../../../util/image_processing.dart';
import '../../../../component/image_view.dart';
import '../../../../style/style.dart';
import '../../../search/search_map.dart';

/// 拠点制覇領域
///
/// 制覇済み拠点の情報は、当該拠点の公開ステータスに関わらず必ず表示します。
/// （記録画面は履歴表示を目的としているため、拠点が削除されたり非公開になったとしても必ず表示する必要があります。）
class BaseCompletedArea extends ConsumerWidget {
  // 称号
  final app.Title title;

  const BaseCompletedArea({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 称号に紐づく拠点制覇情報
    final completedBasesAsyncValue =
        ref.watch(completedBasesByTitleIdStreamProvider(title.id));

    if (completedBasesAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final completedBases = completedBasesAsyncValue.value;
    if (completedBases == null || completedBases.isEmpty) {
      return const SizedBox();
    }

    // 制覇済み拠点の情報は必ず表示する。
    return ListView.separated(
      itemCount: completedBases.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      separatorBuilder: (BuildContext context, int index) {
        return VerticalSpacer.separator;
      },
      itemBuilder: (BuildContext context, int index) {
        final completedBase = completedBases[index];

        // 拠点情報を取得（拠点が非公開である場合や、拠点自体が削除された場合は存在しない）
        // 拠点情報を取得できない場合は、拠点制覇情報のみでWidgetを構築する（この場合、拠点画像等は表示不可）
        final baseAsyncValue =
            ref.watch(baseByIdStreamProvider(completedBase.id));
        if (baseAsyncValue is! AsyncData) {
          return const SizedBox();
        }

        final base = baseAsyncValue.value;

        final navigator = Navigator.of(context);

        return SizedBox(
          width: double.infinity,
          height: 80,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // 拠点画像
              _baseImage(ref, navigator, base, completedBase),
              Expanded(
                child: Material(
                  elevation: 8.0,
                  color: Colors.grey.shade500,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: SizedBox(
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // 拠点名（履歴の拠点のものを利用）
                                Text(
                                  completedBase.name,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 18.0),
                                  overflow: TextOverflow.ellipsis,
                                ),
                                VerticalSpacer.smallish,
                                // プログレスインジケータ(COMPLETE)
                                _progressIndicator(),
                              ],
                            ),
                          ),
                        ),
                      ),
                      HorizontalSpacer.smallish,
                      // サブ拠点のチェックイン数（拠点制覇済みであるため固定）
                      _checkinRatio(completedBase),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// 拠点画像のWidgetを生成します。
  Widget _baseImage(WidgetRef ref, NavigatorState navigator, Base? base,
      CompletedParentBase completedBase) {
    // 拠点画像
    return createNetworkImage(
      navigator: navigator,
      // 拠点が存在しない場合は、エラー用のアイコン表示（履歴に画像情報は持たない）
      imageUrl: base?.imageUrl,
      onTap: () async {
        // 画面を探索画面へ
        ref.read(screenTypeProvider.notifier).update((_) => ScreenType.search);
        // 探索画面のメニューボタンを拠点ボタンへ
        ref
            .read(selectedMenuButtonProvider.notifier)
            .update((_) => MenuButtonSelection.base);

        // 位置情報（履歴の拠点のものを利用）
        final geopoint = completedBase.position.geopoint;

        // マップの中心位置を当該拠点の位置情報へ変更
        await moveCamera(ref, LatLng(geopoint.latitude, geopoint.longitude));

        ref.read(baseBottomSheetOpenProvider.notifier).update((_) => base);
      },
      // 画像拡大表示
      onLongPress: (imageProvider) =>
          navigator.context.pushNamed(ImageView.name, extra: imageProvider),
    );
  }

  /// プログレスインジケータ(COMPLETE)を生成します。
  Widget _progressIndicator() {
    return Stack(
      children: [
        LinearProgressIndicator(
          backgroundColor: Colors.white,
          color: Colors.grey.shade600,
          value: 1.0,
          minHeight: 30,
        ),
        const Align(
          alignment: Alignment.center,
          child: Text(
            'COMPLETE',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18.0,
            ),
          ),
        ),
      ],
    );
  }

  /// チェックイン数のWidgetを生成します。
  /// 拠点制覇情報[completedBase]のサブ拠点数を利用し、"サブ拠点数/サブ拠点数"の表示Widgetを構成します。
  /// 拠点制覇済みであることから、3/3 のように分母および分子には同一の数字（どちらもサブ拠点数）を表示します。
  Widget _checkinRatio(CompletedParentBase completedBase) {
    const textStyle = TextStyle(fontSize: 36.0, color: Colors.white);
    return Row(
      children: [
        Text(completedBase.subBaseCount.toString(), style: textStyle),
        const Text('/', style: textStyle),
        Text(completedBase.subBaseCount.toString(), style: textStyle),
        HorizontalSpacer.smallish,
      ],
    );
  }
}

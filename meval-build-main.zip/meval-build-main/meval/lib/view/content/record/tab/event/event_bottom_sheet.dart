import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../model/data/event.dart';
import '../../../../../provider/data/event_spot_data.dart';
import '../../../../../provider/event_provider.dart';
import '../../../../component/bottom_sheet_content.dart';
import '../../../../style/style.dart';

class EventBottomSheet extends ConsumerWidget {
  // イベント
  final Event event;

  // イベントスポット
  final EventSpot eventSpot;

  const EventBottomSheet(
      {Key? key, required this.event, required this.eventSpot})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);
    final eventSpotData =
        EventSpotData(eventId: event.id, eventSpotId: eventSpot.id);

    // イベントスポット
    final eventSpotAsyncValue = ref.watch(
      eventSpotByIdStreamProvider(eventSpotData),
    );
    ref.listen(eventSpotByIdStreamProvider(eventSpotData), (previous, next) {
      if (next is AsyncData) {
        if (next.value == null) {
          navigator.pop();
        }
      }
    });

    if (eventSpotAsyncValue is! AsyncData ||
        eventSpotAsyncValue.value == null) {
      return const SizedBox(
        height: 350,
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final streamedEventSpot = eventSpotAsyncValue.value!;

    return SizedBox(
      height: 350.0,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CupertinoButton(
                onPressed: () => navigator.pop(),
                child: const Icon(CupertinoIcons.xmark, size: 20.0),
              ),
            ],
          ),
          const Divider(
            height: 0,
            thickness: 1,
          ),
          VerticalSpacer.smallish,
          BottomSheetContent(
            imageUrl: streamedEventSpot.imageUrl,
            name: streamedEventSpot.name,
          ),
        ],
      ),
    );
  }
}

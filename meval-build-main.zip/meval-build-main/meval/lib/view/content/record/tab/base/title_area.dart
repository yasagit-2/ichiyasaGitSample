import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../model/data/completed_title.dart';
import '../../../../../model/data/title.dart' as app;
import '../../../../../provider/record_provider.dart';
import '../../../../style/style.dart';

/// 称号領域
class TitleArea extends ConsumerWidget {
  // 称号
  final app.Title title;

  const TitleArea({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 称号IDに紐づく称号獲得情報
    final completedTitleAsyncValue =
        ref.watch(completedTitleByIdStreamProvider(title.id));

    if (completedTitleAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    // 称号獲得情報
    final completedTitle = completedTitleAsyncValue.value;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Material(
        elevation: 8.0,
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.grey.withOpacity(0.8),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.lightBlue.shade500,
                Colors.lightBlue.shade800,
                Colors.lightBlue.shade900,
                Colors.lightBlue.shade800,
                Colors.lightBlue.shade500,
              ],
            ),
            borderRadius: BorderRadius.circular(10),
            // color: Colors.grey.withOpacity(0.8),
          ),
          // 称号
          child: _title(completedTitle),
        ),
      ),
    );
  }

  /// 称号Widgetを構築します。
  /// 称号獲得情報が存在する（[completedTitle] != null）の場合、称号の名称を表示します。
  /// 称号獲得情報しない場合、称号の名称は表示しません。
  Widget _title(TitleHistory? completedTitle) {
    const textStyle = TextStyle(color: Colors.white, fontSize: 20.0);

    final isCompletedTitle = completedTitle != null;

    return Row(
      children: [
        HorizontalSpacer.smallish,
        isCompletedTitle
            ? const Icon(Icons.emoji_events,
                size: 36.0, color: Color(0xffffd700))
            : const Icon(Icons.emoji_events, size: 36.0),
        HorizontalSpacer.standard,
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Center(
            child: isCompletedTitle
                ? Text(
                    title.name,
                    style: textStyle,
                  )
                : Text(
                    title.name,
                    style: textStyle,
                  ),
          ),
        ),
      ],
    );
  }
}

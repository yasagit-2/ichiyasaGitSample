import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../../const/constant.dart';
import '../../../../../model/data/event.dart';
import '../../../../../provider/event_provider.dart';
import '../../../../../util/logger.dart';
import '../../../../../util/show_toast.dart';
import '../../../../../view_model/member_view_model.dart';
import '../../../../component/loading_service.dart';
import '../../../../style/style.dart';

/// スタンプラリー画面
class StampRallyScreen extends ConsumerWidget {
  static String pathFromTop = 'eventRallyFromTop';
  static String pathFromRecord = 'eventRallyFromRecord';
  static String pathFromQrCode = 'eventRallyFromQrCode';
  static String nameFromTop = 'eventRallyFromTop';
  static String nameFromRecord = 'eventRallyFromRecord';
  static String nameFromQrCode = 'eventRallyFromQrCode';

  // イベントID
  final String eventId;

  const StampRallyScreen({Key? key, required this.eventId}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // イベント
    final eventAsyncValue = ref.watch(eventByIdStreamProvider(eventId));
    // 参加イベント
    final participatedEventAsyncValue =
        ref.watch(participatedEventByEventIdStreamProvider(eventId));
    // イベント達成地点数
    final completedSpotCountAsyncValue =
        ref.watch(completedSpotCountByEventIdStreamProvider(eventId));

    // ログイン中会員のID
    final memberId = ref.watch(memberIdProvider);

    if (eventAsyncValue is! AsyncData ||
        eventAsyncValue.value == null ||
        participatedEventAsyncValue is! AsyncData ||
        completedSpotCountAsyncValue is! AsyncData ||
        memberId == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // イベント
    final event = eventAsyncValue.value!;
    // 参加イベント
    final participatedEvent = participatedEventAsyncValue.value;
    // イベント達成地点数
    final completedSpotCount = completedSpotCountAsyncValue.value!;

    logger.fine('participatedEvent=$participatedEvent');

    // イベント達成済み（交換済み）
    final isCompleted =
        participatedEvent != null && participatedEvent.isComplete;

    // 交換可能
    final isExchangeable =
        !isCompleted && event.completeSpotCount == completedSpotCount;

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        return Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).canvasColor,
            centerTitle: true,
            elevation: 0.0,
            title: _eventTitle(event, now),
          ),
          body: SingleChildScrollView(
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  // 交換種別ごとのWidget
                  _exchange(ref, context, memberId, event, isCompleted,
                      isExchangeable),
                  const Divider(
                    thickness: 2.0,
                    color: Colors.grey,
                  ),
                  // スタンプグリッド
                  _stampGrid(event, completedSpotCount),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// AppBarのタイトルWidgetを生成します。
  Widget _eventTitle(Event event, DateTime now) {
    // true：イベント期間終了
    final isEnd = now.compareTo(event.effectivePeriodEnd) > 0;

    if (isEnd) {
      // イベント期間終了
      return RichText(
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        textAlign: TextAlign.center,
        text: TextSpan(
          children: [
            const TextSpan(
              text: '※終了 ',
              style: TextStyle(
                  fontSize: 18.0, fontFamily: titleFont, color: Colors.red),
            ),
            TextSpan(
              text: event.title,
              style: const TextStyle(
                  fontSize: 18.0, fontFamily: titleFont, color: Colors.black),
            ),
          ],
        ),
      );
    }

    return Text(
      event.title,
      style: const TextStyle(
          fontSize: 20.0, fontFamily: titleFont, color: Colors.black),
    );
  }

  /// 交換種別のWidgetを生成します。
  Widget _exchange(WidgetRef ref, BuildContext context, String memberId,
      Event event, bool isCompleted, bool isExchangeable) {
    // 交換対象種別
    final exchangeType = intToExchangeType(event.exchangeType);

    TextStyle textStyle;
    if (isExchangeable) {
      textStyle = const TextStyle(color: Colors.white);
    } else {
      textStyle = const TextStyle(color: Colors.grey);
    }

    return SizedBox(
      width: 300,
      height: 60,
      child: Material(
        color: isExchangeable
            ? Colors.deepOrange
            : Colors.deepOrange.shade800.withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          // イベント未完了、かつ交換可能である場合タップ可能
          onTap: !isCompleted && isExchangeable
              ? () async {
                  final result = await showOkCancelAlertDialog(
                    context: context,
                    title: exchangeType == ExchangeType.point
                        ? 'ポイント交換を行いますか？'
                        : 'チケット交換を行いますか？',
                    isDestructiveAction: true,
                  );

                  if (result == OkCancelResult.cancel) {
                    return;
                  }

                  // 参加イベントを達成状態として更新（loading）
                  await ref
                      .read(loadingServiceProvider.notifier)
                      .wrap(completeEvent(ref, memberId, event));

                  exchangeType == ExchangeType.point
                      ? showCreateToast('ポイント交換が完了しました')
                      : showCreateToast('チケット交換が完了しました');
                }
              : null,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  exchangeType == ExchangeType.point
                      // ポイント
                      ? const FaIcon(FontAwesomeIcons.coins,
                          size: 36.0, color: Colors.white)
                      // チケット
                      : const Icon(Icons.style,
                          size: 36.0, color: Colors.white),
                  HorizontalSpacer.smallish,
                  Column(
                    children: [
                      exchangeType == ExchangeType.point
                          ? Text('ポイント交換', style: textStyle)
                          : Text('チケット交換', style: textStyle),
                      isCompleted
                          ? Text('COMPLETE（交換済み）', style: textStyle)
                          : Text('※交換を押すと使用済みとなります', style: textStyle),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// スタンプのGridを生成します。
  Widget _stampGrid(Event event, int completedSpotCount) {
    // イベント達成地点数（定義）
    final completeSpotCount = event.completeSpotCount;

    return GridView.builder(
      shrinkWrap: true,
      itemCount: completeSpotCount,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        // Girdの横に配置するWidget数（固定）
        crossAxisCount: 3,
      ),
      itemBuilder: (BuildContext context, int index) {
        if (index < completedSpotCount) {
          // スタンプ獲得済み
          return _createCompletedStamp(index + 1);
        }

        // ブランクスタンプ
        return _createBlankStamp();
      },
    );
  }

  /// 獲得済みスタンプのWidgetを生成します。
  Widget _createCompletedStamp(int stampNumber) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.deepOrange,
            ),
          ),
          Center(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  stampNumber.toString(),
                  style: const TextStyle(fontSize: 64.0, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 獲得未済を表すブランクスタンプWidgetを生成します。
  Widget _createBlankStamp() {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.deepOrange, width: 2.0),
        ),
      ),
    );
  }
}

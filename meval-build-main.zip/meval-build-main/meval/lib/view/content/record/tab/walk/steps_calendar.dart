import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../provider/steps_provider.dart';
import 'calendar_header.dart';

class StepsCalendar extends HookConsumerWidget {
  const StepsCalendar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final focusedDay = useState<DateTime?>(null);

    useEffect(() {
      Future.microtask(() async {
        final now = await NTP.now();
        focusedDay.value = now;

        // 歩数取得
        await getSteps(ref: ref, now: now);
      });

      return () {};
    }, []);

    // 1週表示をデフォルト
    final calendarFormat = useState(CalendarFormat.week);
    final pageController = useState(PageController());

    return FutureBuilder(
      future: NTP.now(),
      builder: (BuildContext context, AsyncSnapshot<DateTime> snapshot) {
        DateTime now = DateTime.now();

        if (snapshot.hasData && snapshot.data != null) {
          // NTPを利用
          now = snapshot.data!;
        }

        return Column(
          children: [
            CalendarHeader(
              focusedDay: focusedDay.value == null ? now : focusedDay.value!,
              clearButtonVisible: false,
              onTodayButtonTap: () {
                focusedDay.value = now;
                ref.watch(selectedDayProvider.notifier).update((_) => now);
              },
              onLeftArrowTap: () {
                pageController.value.previousPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                );
              },
              onRightArrowTap: () {
                pageController.value.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                );
              },
              onFormatChanged: (format) {
                if (format != calendarFormat.value) {
                  calendarFormat.value = format;
                }
              },
              calendarFormat: calendarFormat.value,
              availableCalendarFormats: const {
                CalendarFormat.month: 'Month',
                CalendarFormat.twoWeeks: '2 weeks',
                CalendarFormat.week: 'Week',
              },
            ),
            TableCalendar(
              locale: 'ja_JP',
              // カレンダー表示期間(first)
              firstDay: now.subtract(const Duration(days: 365)),
              // カレンダー表示期間(last)
              lastDay: now.add(const Duration(days: 365)),
              focusedDay: focusedDay.value == null ? now : focusedDay.value!,
              headerVisible: false,
              calendarStyle: CalendarStyle(
                // 選択日のデコレーション
                selectedDecoration: BoxDecoration(
                  color: Colors.deepOrange.shade400,
                  shape: BoxShape.circle,
                ),
                // "本日"のデコレーション
                todayDecoration: BoxDecoration(
                  color: Colors.deepOrange.shade200,
                  shape: BoxShape.circle,
                ),
                outsideDaysVisible: false,
                markerDecoration: const BoxDecoration(
                  color: Colors.blueAccent,
                  shape: BoxShape.circle,
                ),
              ),
              daysOfWeekStyle: DaysOfWeekStyle(
                // 曜日の平日スタイル
                weekdayStyle: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade700,
                ),
                // 曜日の週末スタイル
                weekendStyle: TextStyle(
                  fontSize: 13,
                  color: Colors.red.shade500,
                ),
              ),
              onCalendarCreated: (controller) {
                WidgetsBinding.instance.addPostFrameCallback(
                    (_) => pageController.value = controller);
              },
              // 日付選択
              onDaySelected: (selected, focused) async {
                ref.watch(selectedDayProvider.notifier).update((_) => selected);
                focusedDay.value = focused;

                // 歩数取得
                await getSteps(ref: ref, now: now, referenceDate: focused);
              },
              onPageChanged: (focused) async {
                ref.watch(selectedDayProvider.notifier).update((_) => focused);
                focusedDay.value = focused;

                // 歩数取得
                await getSteps(ref: ref, now: now, referenceDate: focused);
              },
              selectedDayPredicate: (day) {
                return isSameDayFromMillisSinceEpoch(
                    ref.watch(selectedDayProvider).millisecondsSinceEpoch,
                    day.millisecondsSinceEpoch);
              },
              calendarFormat: calendarFormat.value,
              onFormatChanged: (format) {
                if (format != calendarFormat.value) {
                  calendarFormat.value = format;
                }
              },
              // イベントのロード
              eventLoader: (DateTime day) {
                return _getEventsForDay(ref, day, now);
              },
            ),
          ],
        );
      },
    );
  }

  /// [day]のイベント（歩数）を取得します。
  /// [day]に該当する歩数が存在しない場合、空のリストを返却します。
  List<StepData> _getEventsForDay(WidgetRef ref, DateTime day, DateTime now) {
    // 歩数
    final steps = ref.watch(stepsProvider);
    if (steps.size == 0) {
      return [];
    }

    if (DateTime(now.year, now.month, now.day, 23, 59, 59, 999, 999)
            .compareTo(day) <
        0) {
      // 未来日のイベント（歩数）を取得する必要はない（存在しない）ため空のListを返却
      return [];
    }

    final stepData =
        steps[DateTime(day.year, day.month, day.day).millisecondsSinceEpoch];

    return stepData == null || stepData.steps == null ? [] : [stepData];
  }
}

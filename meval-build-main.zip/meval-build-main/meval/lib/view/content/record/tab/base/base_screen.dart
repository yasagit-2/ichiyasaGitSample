import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../provider/record_provider.dart';
import '../../../../style/style.dart';
import 'base_area.dart';
import 'base_completed_area.dart';
import 'title_area.dart';

class BaseScreen extends ConsumerStatefulWidget {
  const BaseScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<BaseScreen> createState() => _BaseScreenState();
}

class _BaseScreenState extends ConsumerState<BaseScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    // 全ての称号
    final titlesAsyncValue = ref.watch(allTitlesStreamProvider);
    if (titlesAsyncValue is! AsyncData || titlesAsyncValue.value == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final titles = titlesAsyncValue.value!;

    return CustomScrollView(
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      slivers: [
        CupertinoSliverRefreshControl(
          onRefresh: () async {
            // 全称号ストリームプロバイダをリフレッシュし称号を再取得
            ref.invalidate(allTitlesStreamProvider);
          },
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            childCount: 1,
            (context, index) {
              return Padding(
                padding: const EdgeInsets.all(16.0),
                child: ListView.builder(
                  itemCount: titles.length,
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    final title = titles[index];

                    return Column(
                      children: [
                        // 称号
                        TitleArea(title: title),
                        // 制覇済み拠点
                        BaseCompletedArea(title: title),
                        VerticalSpacer.separator,
                        // 制覇未済拠点
                        BaseArea(title: title),
                      ],
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

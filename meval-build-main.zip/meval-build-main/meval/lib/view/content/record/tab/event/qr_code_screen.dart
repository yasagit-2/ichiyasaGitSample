import 'package:adaptive_dialog/adaptive_dialog.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../../../../model/data/event.dart';
import '../../../../../model/data/event_participation_history.dart';
import '../../../../../provider/data/within_range_data.dart';
import '../../../../../provider/event_provider.dart';
import '../../../../../provider/location_provider.dart';
import '../../../../../util/logger.dart';
import '../../../../../util/show_toast.dart';
import '../../../../../view_model/member_view_model.dart';
import '../../../../component/loading_service.dart';
import '../../../../style/style.dart';
import 'stamp_rally_screen.dart';

final mobileScannerControllerProvider = Provider.autoDispose(
  (ref) {
    ref.onDispose(() {
      logger.fine('mobileScannerControllerProvider dispose.');
    });

    return MobileScannerController();
  },
);

class QrCodeScreen extends HookConsumerWidget {
  static String path = 'qrCode';
  static String name = 'qrCode';

  // イベントID
  final String eventId;

  const QrCodeScreen({Key? key, required this.eventId}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(mobileScannerControllerProvider);
    final isStarted = useState<bool>(true);
    final qrCodeState = useState<String>('');
    final torchState = useState<TorchState>(controller.torchState.value);

    // イベント
    final eventAsyncValue = ref.watch(eventByIdStreamProvider(eventId));
    // イベントスポット
    final eventSpotsAsyncValue = ref.watch(eventSpotsStreamProvider(eventId));
    // イベント達成地点
    final completedSpotsAsyncValue =
        ref.watch(completedSpotsByEventIdStreamProvider(eventId));

    // ログイン中会員のID
    final memberId = ref.watch(memberIdProvider);

    if (eventAsyncValue is! AsyncData ||
        eventSpotsAsyncValue is! AsyncData ||
        completedSpotsAsyncValue is! AsyncData ||
        memberId == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // イベント
    final event = eventAsyncValue.value!;
    // イベントスポット
    final eventSpots = eventSpotsAsyncValue.value!;
    // イベント達成地点
    final completedSpots = completedSpotsAsyncValue.value!;

    // [定義]QRコード識別子（イベントID_イベントスポットID）のリスト
    final qrCodeIdList =
        eventSpots.map((eventSpot) => '${eventId}_${eventSpot.id}').toList();

    // [履歴]達成地点ID（QRコード識別子）リスト
    final completedSpotIdList =
        completedSpots.map((completedSpot) => completedSpot.id).toList();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        centerTitle: true,
        elevation: 0.0,
        title: Text(event.title, style: TextStyles.appBarTitle),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            MobileScanner(
              controller: controller,
              fit: BoxFit.contain,
              onDetect: (Barcode barcode, _) async {
                final rawValue = barcode.rawValue;
                if (rawValue == null ||
                    qrCodeState.value == rawValue ||
                    !qrCodeIdList.contains(rawValue)) {
                  // 既にStateに保持しているコードは処理しない
                  // QRコード識別子に該当しないコードは処理しない
                  return;
                }

                try {
                  return await _onDetect(
                      ref: ref,
                      context: context,
                      controller: controller,
                      qrCodeState: qrCodeState,
                      torchState: torchState,
                      event: event,
                      completedSpotIdList: completedSpotIdList,
                      completedSpots: completedSpots,
                      eventSpots: eventSpots,
                      rawValue: rawValue,
                      memberId: memberId);
                } on Exception {
                  context.pop();
                  rethrow;
                }
              },
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // フラッシュライト
                  IconButton(
                    iconSize: 32.0,
                    color: Colors.white,
                    onPressed: () async {
                      await controller.toggleTorch();
                      torchState.value = controller.torchState.value;
                    },
                    icon: torchState.value == TorchState.on
                        ? const Icon(
                            Icons.flash_on,
                            color: Colors.yellow,
                          )
                        : const Icon(
                            Icons.flash_off,
                            color: Colors.grey,
                          ),
                  ),

                  // スキャナ開始/停止
                  IconButton(
                    color: Colors.white,
                    icon: isStarted.value
                        ? const Icon(Icons.stop)
                        : const Icon(Icons.play_arrow),
                    iconSize: 32.0,
                    onPressed: () {
                      isStarted.value ? controller.stop() : controller.start();
                      isStarted.value = !isStarted.value;
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// QRコードの読み取り結果に応じた処理を行います。
  /// スタンプ獲得済みの場合、メッセージを表示し終了します。
  /// スタンプ獲得未済の場合、かつQRコード識別子が当該イベントのイベントスポットに該当する場合、スタンプ獲得処理を実行しイベントラリー画面へ遷移します。
  _onDetect({
    required WidgetRef ref,
    required BuildContext context,
    required MobileScannerController controller,
    required ValueNotifier<String> qrCodeState,
    required ValueNotifier<TorchState> torchState,
    required Event event,
    // [履歴]達成地点ID（QRコード識別子）リスト
    required List<String> completedSpotIdList,
    // イベント達成地点
    required List<CompletedSpot> completedSpots,
    // イベントスポット
    required List<EventSpot> eventSpots,
    // QRコードの読み取り結果（QRコード識別子）
    required String rawValue,
    // 会員ID
    required String memberId,
  }) async {
    if (completedSpotIdList.contains(rawValue)) {
      // スタンプ獲得済み

      // スキャナをストップ
      await _stopScanner(controller, torchState);

      final completedSpot = completedSpots
          .firstWhere((completedSpot) => completedSpot.id == rawValue);

      await showOkAlertDialog(
        title: completedSpot.eventSpotName,
        message: 'スタンプ獲得済みです',
        context: context,
      );

      qrCodeState.value = '';
      await controller.start();
    } else {
      // スタンプ獲得未済

      qrCodeState.value = rawValue;

      // QRコード識別子（イベントID_イベントスポットID）
      // （呼び出し元にてQRコード識別子の形式を確認済みのため、ここでは必ずアンダースコアで文字列を2分割可能）
      final qrCodeId = rawValue.split('_');

      // イベントID
      final qrCodeEventId = qrCodeId[0];
      // スポットID
      final qrCodeSpotId = qrCodeId[1];

      logger.fine('qrCodeEventId=$qrCodeEventId, qrCodeSpotId=$qrCodeSpotId');

      final completeTargetEventSpot = eventSpots
          .firstWhereOrNull((eventSpot) => eventSpot.id == qrCodeSpotId);

      // 対象のイベントスポットが存在しないため処理しない
      if (completeTargetEventSpot == null) return;

      // スキャナをストップ
      await _stopScanner(controller, torchState);

      // 位置情報の確認
      if (event.isUseLocation) {
        // 位置情報使用許可
        final isPermitToUseLocation =
            await ref.watch(locationProvider).checkPermission();

        // 位置情報使用許可が得られない場合
        if (!isPermitToUseLocation) {
          await showOkAlertDialog(
              context: context,
              title: '位置情報を利用できません',
              message: 'スタンプ獲得のためには位置情報の利用を許可してください');

          qrCodeState.value = '';
          await controller.start();
          return;
        }

        // リフレッシュ（疑似ロケーションを考慮）
        ref.invalidate(currentLocationProvider);
        await requestPermission(ref);

        final geopoint = completeTargetEventSpot.position.geopoint;
        final isWithinRange = await withinRangeAvailability(
            ref,
            WithinRangeData(
              location: LatLng(geopoint.latitude, geopoint.longitude),
              radius: event.qrCodeRadius,
            ));

        if (!isWithinRange) {
          await showOkAlertDialog(
            context: context,
            title: completeTargetEventSpot.name,
            message: 'イベントスポットから ${event.qrCodeRadius.toInt()} メートル以内に近づいてください',
          );

          qrCodeState.value = '';
          await controller.start();
          return;
        }
      }

      final result = await showOkCancelAlertDialog(
        title: completeTargetEventSpot.name,
        message: 'スタンプを獲得しますか？',
        context: context,
      );

      if (result == OkCancelResult.cancel) {
        qrCodeState.value = '';
        await controller.start();
        return;
      }

      //  スタンプ取得（loading）
      await ref.read(loadingServiceProvider.notifier).wrap(completeSpot(
          ref, memberId, event, completeTargetEventSpot, rawValue));

      showCreateToast('${completeTargetEventSpot.name} のスタンプを獲得しました');

      // スタンプラリーへ
      context.replaceNamed(StampRallyScreen.nameFromQrCode, extra: event.id);
    }
  }

  /// フラッシュライトをOFFにし、スキャナをstopします。
  Future<void> _stopScanner(MobileScannerController controller,
      ValueNotifier<TorchState> torchState) async {
    if (controller.torchState.value == TorchState.on) {
      await controller.toggleTorch();
      torchState.value = controller.torchState.value;
    }

    return await controller.stop();
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../provider/event_provider.dart';
import 'event_area.dart';

/// 記録画面（イベント）
class EventScreen extends ConsumerStatefulWidget {
  const EventScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<EventScreen> createState() => _EventScreenState();
}

class _EventScreenState extends ConsumerState<EventScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    // イベント
    final eventsAsyncValue = ref.watch(eventStreamProvider);
    if (eventsAsyncValue is! AsyncData) {
      return const Center(child: CircularProgressIndicator());
    }

    final events = eventsAsyncValue.value;
    if (events == null || events.isEmpty) {
      // イベントなし
      return _noEvents();
    }

    return CustomScrollView(
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      slivers: [
        CupertinoSliverRefreshControl(
          onRefresh: () async {
            // イベントリストストリームプロバイダをリフレッシュしイベントを再取得
            ref.invalidate(eventStreamProvider);
          },
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) => Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView.separated(
                itemCount: events.length,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (BuildContext context, int index) =>
                    const Divider(color: Colors.grey),
                itemBuilder: (BuildContext context, int index) {
                  final event = events[index];
                  return EventArea(event: event);
                },
              ),
            ),
            childCount: 1,
          ),
        ),
      ],
    );
  }

  /// イベントが存在しない場合のWidgetを生成します。
  Widget _noEvents() {
    return const Center(
      child: Text(
        '（現在イベントはありません）',
        style: TextStyle(fontSize: 18.0),
      ),
    );
  }
}

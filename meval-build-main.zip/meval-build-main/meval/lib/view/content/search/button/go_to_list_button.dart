import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../provider/menu_button_provider.dart';
import '../../../../provider/screen_type_provider.dart';
import '../../../style/style.dart';
import '../list_screen/base_list_area.dart';
import '../list_screen/base_list_screen.dart';
import '../list_screen/merchant_list_area.dart';
import '../list_screen/merchant_list_screen.dart';
import '../list_screen/post_list_screen.dart';
import '../list_screen/post_tab/admin_alert_list_area.dart';
import '../list_screen/post_tab/own_post_list_area.dart';

// 一覧ボタン表示プロバイダ（現在の表示状態）
final _listButtonVisibleStateProvider =
    StateProvider.autoDispose<bool>((ref) => false);

// 一覧ボタン表示プロバイダ（拠点/加盟店/投稿の変化に応じた表示状態）
final _listButtonVisibleProvider =
    FutureProvider.autoDispose<bool>((ref) async {
  final selectedMenuButton = ref.watch(selectedMenuButtonProvider);
  if (selectedMenuButton == MenuButtonSelection.unselected) {
    // [unselected]の場合は表示しない
    return false;
  }

  final isVisibleBases = await ref.watch(_basesVisibleProvider.future);
  final isVisibleMerchants = await ref.watch(_merchantsVisibleProvider.future);
  final isVisiblePosts = await ref.watch(_postsVisibleProvider.future);

  return isVisibleBases || isVisibleMerchants || isVisiblePosts;
});

// 拠点一覧表示プロバイダ
final _basesVisibleProvider = FutureProvider.autoDispose<bool>((ref) async {
  final screenType = ref.watch(screenTypeProvider);
  final selectedMenuButton = ref.watch(selectedMenuButtonProvider);
  if (screenType != ScreenType.search ||
      selectedMenuButton != MenuButtonSelection.base) {
    return false;
  }

  final mainBases = await ref.watch(mainBasesProvider.future);

  if (selectedMenuButton == MenuButtonSelection.base && mainBases.isNotEmpty) {
    // 一覧表示すべき拠点が存在する
    return true;
  }

  return false;
});

// 加盟店一覧表示プロバイダ
final _merchantsVisibleProvider = FutureProvider.autoDispose<bool>((ref) async {
  final screenType = ref.watch(screenTypeProvider);
  final selectedMenuButton = ref.watch(selectedMenuButtonProvider);
  if (screenType != ScreenType.search ||
      selectedMenuButton != MenuButtonSelection.merchant) {
    return false;
  }

  final merchants = await ref.watch(merchantsProvider.future);

  if (selectedMenuButton == MenuButtonSelection.merchant &&
      merchants.isNotEmpty) {
    // 一覧表示すべき加盟店が存在する
    return true;
  }

  return false;
});

// 投稿一覧表示プロバイダ
final _postsVisibleProvider = FutureProvider.autoDispose<bool>((ref) async {
  final screenType = ref.watch(screenTypeProvider);
  final selectedMenuButton = ref.watch(selectedMenuButtonProvider);
  if (screenType != ScreenType.search ||
      selectedMenuButton != MenuButtonSelection.post) {
    return false;
  }

  final posts = await ref.watch(postsProvider.future);
  final adminAlerts = await ref.watch(adminAlertsProvider.future);
  final adminQuestionnaires =
      await ref.watch(adminQuestionnairesProvider.future);

  if (selectedMenuButton == MenuButtonSelection.post &&
      (posts.isNotEmpty ||
          adminAlerts.isNotEmpty ||
          adminQuestionnaires.isNotEmpty)) {
    // 一覧表示すべき投稿が存在する
    return true;
  }

  return false;
});

class GoToListButton extends ConsumerWidget {
  const GoToListButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isVisibleState = ref.watch(_listButtonVisibleStateProvider);

    final selectedMenuButton = ref.watch(selectedMenuButtonProvider);
    final navigator = Navigator.of(context);

    return FutureBuilder(
      future: ref.watch(_listButtonVisibleProvider.future),
      builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
        if (!snapshot.hasData || snapshot.data == null) {
          return const SizedBox();
        }

        final isVisible = snapshot.data!;
        if (isVisible != isVisibleState) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            ref
                .watch(_listButtonVisibleStateProvider.notifier)
                .update((_) => isVisible);
          });
        }

        return isVisibleState
            ? Positioned(
                top: 125,
                left: 10,
                child: FloatingActionButton(
                  heroTag: 'goToList',
                  backgroundColor: AppColors.mainColor,
                  shape: const CircleBorder(
                    side: BorderSide(
                      color: Colors.blue,
                    ),
                  ),
                  child: const Icon(FontAwesomeIcons.angleRight,
                      size: ButtonStyles.menuButtonSize),
                  onPressed: () =>
                      _goToListScreen(navigator, selectedMenuButton),
                ),
              )
            : const SizedBox();
      },
    );
  }

  /// [selectedMenuButton]に応じて、それぞれ該当する一覧画面へ遷移します。
  void _goToListScreen(
      NavigatorState navigator, MenuButtonSelection selectedMenuButton) {
    switch (selectedMenuButton) {
      case MenuButtonSelection.base:
        // 拠点一覧画面へ
        navigator.context.goNamed(BaseListScreen.name);
        break;
      case MenuButtonSelection.post:
        // 投稿リスト（自分の投稿/行政の投稿）画面へ
        navigator.context.goNamed(PostListScreen.name);
        break;
      case MenuButtonSelection.merchant:
        // 加盟店一覧画面へ
        navigator.context.goNamed(MerchantListScreen.name);
        break;
      default:
        return;
    }
  }
}

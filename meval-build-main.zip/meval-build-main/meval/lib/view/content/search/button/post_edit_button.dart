import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../const/constant.dart';
import '../../../../util/logger.dart';
import '../../../../view_model/search_map_view_model.dart';
import '../../post/post_confirm_screen.dart';

// 投稿編集ボタン可視性プロバイダ
final postEditButtonVisibilityProvider =
    StateProvider.autoDispose((ref) => false);

class PostEditButton extends ConsumerWidget {
  const PostEditButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final buttonVisibility = ref.watch(postEditButtonVisibilityProvider);

    return Positioned(
      bottom: 10,
      right: 10,
      child: buttonVisibility
          ? FloatingActionButton(
              key: Tutorial.postEditButtonKey,
              heroTag: 'postEdit',
              shape: const CircleBorder(
                side: BorderSide(
                  width: 3.0,
                  color: Colors.deepOrange,
                ),
              ),
              backgroundColor: Colors.white70,
              elevation: 0.0,
              child: const FaIcon(
                FontAwesomeIcons.pencilAlt,
                size: 30.0,
                color: Colors.deepOrangeAccent,
              ),
              onPressed: () {
                final mapInformation = ref.watch(searchMapViewModelProvider);
                logger.fine(
                    'postingPreparationMarker=${mapInformation.postingPreparationMarker}');
                context.goNamed(PostConfirmScreen.name);
              },
            )
          : const SizedBox(),
    );
  }
}

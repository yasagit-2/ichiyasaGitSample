import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../provider/menu_button_provider.dart';
import '../../../style/style.dart';
import 'post_edit_button.dart';

class BaseButton extends HookConsumerWidget {
  const BaseButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isSelected =
        ref.watch(selectedMenuButtonProvider) == MenuButtonSelection.base;

    return FloatingActionButton(
      heroTag: 'base',
      shape: isSelected
          ? const CircleBorder(
              side: BorderSide(
                color: Colors.black,
              ),
            )
          : const CircleBorder(
              side: BorderSide(
                color: Colors.black54,
              ),
            ),
      backgroundColor: isSelected ? Colors.black : Colors.black38,
      onPressed: () async {
        // ON/OFF切り替え
        ref.watch(selectedMenuButtonProvider.notifier).update((state) =>
            state == MenuButtonSelection.base
                ? MenuButtonSelection.unselected
                : MenuButtonSelection.base);

        // メニューボタン（SpeedDial）を閉じる
        ref.watch(openCloseDialProvider).value = false;

        if (ref.watch(selectedMenuButtonProvider) == MenuButtonSelection.base) {
          // 投稿編集ボタン非表示
          ref
              .watch(postEditButtonVisibilityProvider.notifier)
              .update((_) => false);
        }
      },
      child: const Icon(Icons.bookmark, size: ButtonStyles.menuButtonSize),
    );
  }
}

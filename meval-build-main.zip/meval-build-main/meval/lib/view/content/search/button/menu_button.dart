import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../const/constant.dart';
import '../../../../provider/menu_button_provider.dart';
import '../../../component/loading_service.dart';
import '../../../style/style.dart';
import 'base_button.dart';
import 'merchant_button.dart';
import 'post_display_button.dart';

class MenuButton extends HookConsumerWidget {
  const MenuButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // ローディング中はボタン表示しない
    final isLoading = ref.watch(loadingServiceProvider);
    if (isLoading) return const SizedBox();

    final isOpen = useState(false);

    IconData icon;
    IconThemeData? iconThemeData;
    switch (ref.watch(selectedMenuButtonProvider)) {
      case MenuButtonSelection.base:
        icon = Icons.bookmark;
        iconThemeData = const IconThemeData(size: ButtonStyles.menuButtonSize);
        break;
      case MenuButtonSelection.post:
        icon = Icons.waving_hand;
        iconThemeData = const IconThemeData(size: ButtonStyles.menuButtonSize);
        break;
      case MenuButtonSelection.merchant:
        icon = Icons.home;
        iconThemeData = const IconThemeData(size: ButtonStyles.menuButtonSize);
        break;
      default:
        icon = FontAwesomeIcons.bars;
        break;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 60, left: 10),
      child: SpeedDial(
        key: Tutorial.menuButtonKey,
        icon: icon,
        iconTheme: isOpen.value ? null : iconThemeData,
        activeIcon: Icons.close,
        backgroundColor: AppColors.mainColor,
        shape: const CircleBorder(
          side: BorderSide(
            color: Colors.blue,
          ),
        ),
        direction: SpeedDialDirection.right,
        childrenButtonSize: const Size(65.0, 65.0),
        onOpen: () => isOpen.value = true,
        onClose: () => isOpen.value = false,
        openCloseDial: ref.watch(openCloseDialProvider),
        children: [
          SpeedDialChild(
            key: Tutorial.menuBaseButtonKey,
            label: '拠点',
            child: const BaseButton(),
          ),
          SpeedDialChild(
            key: Tutorial.menuPostButtonKey,
            label: '投稿',
            child: const PostDisplayButton(),
          ),
          SpeedDialChild(
            key: Tutorial.menuMerchantButtonKey,
            label: '加盟店',
            child: const MerchantButton(),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:meval/util/analytics_util.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import '../../../model/data/admin_alert.dart';
import '../../../model/data/admin_questionnaire.dart';
import '../../../model/data/base.dart';
import '../../../model/data/merchant.dart';
import '../../../model/data/post.dart';
import '../../../provider/location_provider.dart';
import '../../../util/show_toast.dart';
import '../../../view_model/post_view_model.dart';
import '../post/admin/admin_alert_screen.dart';
import '../post/admin/admin_questionnaire_screen.dart';
import '../post/post_display_screen.dart';
import 'base_bottom_sheet.dart';
import 'merchant_bottom_sheet.dart';

/// 拠点情報表示のためのコールバックです。
/// [base]の情報を表示します。
/// 「チェックイン」タップ時に[checkIn]を呼び出します。
void showBaseInformation(WidgetRef ref, NavigatorState navigator, Base base,
    AsyncCallback checkIn, bool isAvailCheckIn) {
  // ボトムシートオープン前に現在の位置情報をリフレッシュ（疑似ロケーションを考慮）
  ref.invalidate(currentLocationProvider);

  // 拠点表示イベント出力
  AnalyticsUtil.viewBase(ref, base);

  showCupertinoModalBottomSheet(
    expand: false,
    context: navigator.context,
    builder: (context) {
      return BaseBottomSheet(
        base: base,
        checkIn: checkIn,
        isAvailCheckIn: isAvailCheckIn,
      );
    },
  );
}

/// 加盟店情報表示のためのコールバックです。
/// [merchant]の情報を表示します。
void showMerchantInformation(NavigatorState navigator, Merchant merchant) {
  showCupertinoModalBottomSheet(
    context: navigator.context,
    builder: (context) {
      return MerchantBottomSheet(merchant: merchant);
    },
  );
}

/// 拠点に対するチェックイン成功時のコールバックです。
/// チェックイン時のメッセージを表示します。
void onSuccessOfCheckInToBase(String baseName) {
  showCreateToast('$baseName を開放しました');
}

/// サブ拠点に対するチェックイン成功時のコールバックです。
/// チェックイン時のメッセージを表示します。
Future<void> onSuccessOfCheckInToSubBase(String baseName) async {
  showCreateToast('サブ拠点 $baseName をチェックしました');
}

/// 投稿アイコン押下時のコールバックです。
/// [PostDisplayScreen]へ遷移します。
Future<void> onTapPost(Ref ref, NavigatorState navigator, Post post) async {
  // 対象の投稿へ状態を更新
  ref.read(postViewModelProvider.notifier).update(post);

  navigator.context.goNamed(PostDisplayScreen.name);
}

/// 行政投稿アラートアイコン押下時のコールバックです。
Future<void> onTapAdminAlert(
    Ref ref, NavigatorState navigator, AdminAlert adminAlert) async {
  navigator.context.goNamed(AdminAlertScreen.name, extra: adminAlert);
}

/// 行政投稿アンケートアイコン押下時のコールバックです。
Future<void> onTapAdminQuestionnaire(Ref ref, NavigatorState navigator,
    AdminQuestionnaire adminQuestionnaire) async {
  navigator.context
      .goNamed(AdminQuestionnaireScreen.name, extra: adminQuestionnaire);
}

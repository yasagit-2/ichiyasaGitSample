import 'package:flutter/cupertino.dart';

import 'own_post_list_area.dart';

class OwnPostListTab extends StatelessWidget {
  const OwnPostListTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          CupertinoSliverRefreshControl(
            onRefresh: () async {},
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => const OwnPostListArea(),
              childCount: 1,
            ),
          ),
        ],
      ),
    );
  }
}

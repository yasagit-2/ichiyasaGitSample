import 'package:flutter/cupertino.dart';

import 'admin_alert_list_area.dart';

class AdminAlertListTab extends StatelessWidget {
  const AdminAlertListTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          CupertinoSliverRefreshControl(
            onRefresh: () async {},
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => const AdminAlertListArea(),
              childCount: 1,
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../model/data/merchant.dart';
import '../../../../provider/search_map_provider.dart';
import '../../../../util/logger.dart';
import '../../content_root_screen.dart';
import '../search_map.dart';
import 'list_area.dart';

// 加盟店リストプロバイダ
final merchantsProvider =
    FutureProvider.autoDispose<List<Merchant>>((ref) async {
  ref.onDispose(() {
    logger.fine('merchantsProvider dispose.');
  });

  final merchantDocList = await ref.watch(merchantStreamProvider.future);

  return (await Future.wait(
    merchantDocList.map(
      (documentSnapshot) => merchantRef(id: documentSnapshot.id).get(),
    ),
  ))
      .map((merchantDocumentSnapshot) => merchantDocumentSnapshot.data)
      .whereType<Merchant>()
      .toList()
    // 加盟店ID順でソート
    ..sort((a, b) {
      return a.id.compareTo(b.id);
    });
});

class MerchantListArea extends ConsumerWidget {
  const MerchantListArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);

    final merchantsAsyncValue = ref.watch(merchantsProvider);
    ref.listen(merchantsProvider, (previous, next) {
      if (next is AsyncData) {
        if (next.value == null || next.value!.isEmpty) {
          // 一覧表示すべき加盟店が存在しない場合、コンテンツルートへ戻る
          // （加盟店一覧表示中に加盟店が削除されるケースを考慮したもの）
          navigator.context.goNamed(ContentRootScreen.name);
        }
      }
    });

    if (merchantsAsyncValue is AsyncLoading) {
      return const SizedBox();
    }
    if (merchantsAsyncValue is AsyncError) {
      final error = merchantsAsyncValue as AsyncError;
      logger.severe(error.error);
      logger.severe(error.stackTrace);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigator.context.goNamed(ContentRootScreen.name);
      });

      return const SizedBox();
    }

    final merchants = merchantsAsyncValue.value;
    if (merchants == null || merchants.isEmpty) {
      return const SizedBox();
    }

    return ListView.separated(
      itemCount: merchants.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(height: 5.0);
      },
      itemBuilder: (BuildContext context, int index) {
        final merchant = merchants[index];
        return ListArea(
          mapPositionMixin: merchant,
          content: merchant.name,
          isGreyOut: false,
          onTap: () => ref
              .read(merchantBottomSheetOpenProvider.notifier)
              .update((_) => merchant),
        );
      },
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../style/style.dart';
import 'base_list_area.dart';

class BaseListScreen extends StatelessWidget {
  static String path = 'baseList';
  static String name = 'baseList';

  const BaseListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).canvasColor,
        elevation: 0.0,
        centerTitle: true,
        title: const Text('拠点一覧', style: TextStyles.appBarTitle),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: [
            CupertinoSliverRefreshControl(
              onRefresh: () async {},
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => const BaseListArea(),
                childCount: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

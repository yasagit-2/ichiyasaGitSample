import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../../model/data/post.dart';
import '../../../../../provider/search_map_provider.dart';
import '../../../../../util/logger.dart';
import '../../../../../view_model/member_view_model.dart';
import '../list_area.dart';

// 自分の投稿リストプロバイダ
final postsProvider = FutureProvider.autoDispose<List<Post>>((ref) async {
  ref.onDispose(() {
    logger.fine('postsProvider dispose.');
  });

  // ログイン中の会員
  final member = ref.watch(memberViewModelProvider)!;

  final postDocList = await ref.watch(postStreamProvider.future);

  return (await Future.wait(
    postDocList.map(
      (documentSnapshot) => postRef(id: documentSnapshot.id).get(),
    ),
  ))
      .map((postDocumentSnapshot) => postDocumentSnapshot.data)
      .whereType<Post>()
      // 自身の投稿のみにフィルタ
      .where((post) => post.memberRef.id == member.id)
      .toList()
    // 投稿日時で降順ソート
    ..sort((a, b) {
      if (a.createdAt == null || b.createdAt == null) {
        return -1;
      }
      return b.createdAt!.compareTo(a.createdAt!);
    });
});

class OwnPostListArea extends ConsumerWidget {
  const OwnPostListArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final postsAsyncValue = ref.watch(postsProvider);

    if (postsAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final posts = postsAsyncValue.value;
    if (posts == null || posts.isEmpty) {
      return const SizedBox();
    }

    return ListView.separated(
      itemCount: posts.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(height: 5.0);
      },
      itemBuilder: (BuildContext context, int index) {
        final post = posts[index];
        return ListArea(
          mapPositionMixin: post,
          content: post.message,
          isGreyOut: false,
        );
      },
    );
  }
}

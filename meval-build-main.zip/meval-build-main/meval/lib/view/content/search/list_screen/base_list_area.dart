import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../model/data/base.dart';
import '../../../../model/data/check_in.dart';
import '../../../../provider/search_map_provider.dart';
import '../../../../util/logger.dart';
import '../../../../view_model/search_map_view_model.dart';
import '../../content_root_screen.dart';
import '../search_map.dart';
import 'list_area.dart';

// メイン拠点リストプロバイダ（サブ拠点は含まない）
final mainBasesProvider = FutureProvider.autoDispose<List<Base>>((ref) async {
  ref.onDispose(() {
    logger.fine('mainBasesProvider dispose.');
  });

  final now = await NTP.now();
  final baseDocList = await ref.watch(baseStreamProvider.future);

  return (await Future.wait(
    baseDocList.map(
      (documentSnapshot) => baseRef(id: documentSnapshot.id).get(),
    ),
  ))
      .map((baseDocumentSnapshot) => baseDocumentSnapshot.data)
      .whereType<Base>()
      // サブ拠点、および拠点表示条件判定の結果非表示の拠点を除外
      .where((base) {
    // 拠点表示条件判定
    final judgeResult = judgeDisplayCondition(base, now);

    return base.parentRef == null && judgeResult;
  }).toList()
    // 拠点ID順でソート
    ..sort((a, b) {
      return a.id.compareTo(b.id);
    });
});

class BaseListArea extends ConsumerWidget {
  const BaseListArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);

    final mainBasesAsyncValue = ref.watch(mainBasesProvider);
    ref.listen(mainBasesProvider, (previous, next) {
      if (next is AsyncData) {
        if (next.value == null || next.value!.isEmpty) {
          // 一覧表示すべき拠点が存在しない場合、コンテンツルートへ戻る
          // （拠点一覧表示中に拠点が削除されるケースを考慮したもの）
          navigator.context.goNamed(ContentRootScreen.name);
        }
      }
    });

    if (mainBasesAsyncValue is AsyncLoading) {
      return const SizedBox();
    }
    if (mainBasesAsyncValue is AsyncError) {
      final error = mainBasesAsyncValue as AsyncError;
      logger.severe(error.error);
      logger.severe(error.stackTrace);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigator.context.goNamed(ContentRootScreen.name);
      });

      return const SizedBox();
    }

    final bases = mainBasesAsyncValue.value;
    if (bases == null || bases.isEmpty) {
      return const SizedBox();
    }

    return ListView.separated(
      itemCount: bases.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(height: 5.0);
      },
      itemBuilder: (BuildContext context, int index) {
        final base = bases[index];

        return FutureBuilder(
          future: ref.watch(checkInByBaseIdStreamProvider(base.id).future),
          builder: (BuildContext context, AsyncSnapshot<CheckIn?> snapshot) {
            bool isGreyOut = false;
            if (snapshot.hasData && snapshot.data != null) {
              // 拠点チェックイン済みのためグレーアウト
              isGreyOut = true;
            }
            return ListArea(
              mapPositionMixin: base,
              content: base.name,
              isGreyOut: isGreyOut,
              onTap: () => ref
                  .read(baseBottomSheetOpenProvider.notifier)
                  .update((_) => base),
            );
          },
        );
      },
    );
  }
}

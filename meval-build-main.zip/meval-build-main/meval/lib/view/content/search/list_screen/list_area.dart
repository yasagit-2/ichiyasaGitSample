import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../model/data/map_position_mixin.dart';
import '../../../../provider/map_controller_provider.dart';
import '../../../../util/image_processing.dart';
import '../../../component/image_view.dart';

class ListArea extends ConsumerWidget {
  final MapPositionMixin mapPositionMixin;

  // リスト表示するコンテンツ文字列
  final String content;

  // true:リストエリアをグレーアウト
  final bool isGreyOut;

  final VoidCallback? onTap;

  const ListArea({
    Key? key,
    required this.mapPositionMixin,
    required this.content,
    required this.isGreyOut,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);

    return SizedBox(
      width: double.infinity,
      height: 80,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          // 投稿画像
          createNetworkImage(
            navigator: navigator,
            imageUrl: mapPositionMixin.imageUrl,
            // 画像拡大表示
            onLongPress: (imageProvider) =>
                context.pushNamed(ImageView.name, extra: imageProvider),
          ),
          Expanded(
            child: Material(
              elevation: 8.0,
              child: InkWell(
                onTap: () async {
                  // 位置情報
                  final geopoint = mapPositionMixin.position.geopoint;

                  // マップの中心位置を当該投稿の位置情報へ変更
                  await moveCamera(
                      ref, LatLng(geopoint.latitude, geopoint.longitude));

                  navigator.pop();

                  if (onTap != null) {
                    onTap!();
                  }
                },
                child: Container(
                  alignment: Alignment.centerLeft,
                  color:
                      isGreyOut ? Colors.grey : Theme.of(context).canvasColor,
                  child: Padding(
                    padding: const EdgeInsets.only(
                        top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Text(
                            content,
                            style: isGreyOut
                                ? const TextStyle(
                                    fontSize: 18.0,
                                    color: Colors.black54,
                                  )
                                : const TextStyle(fontSize: 18.0),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                          ),
                        ),
                        const Icon(Icons.navigate_next),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

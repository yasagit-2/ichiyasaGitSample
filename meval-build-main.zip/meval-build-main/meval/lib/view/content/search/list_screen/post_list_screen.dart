import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../provider/screen_type_provider.dart';
import 'post_tab/admin_alert_list_tab.dart';
import 'post_tab/own_post_list_tab.dart';

class PostListScreen extends ConsumerWidget {
  static String path = 'postList';
  static String name = 'postList';

  static const _postListTabs = [
    _PostListTabInfo(
      postListTabType: PostListTabType.ownPost,
      label: '自分の投稿',
      widget: OwnPostListTab(),
    ),
    _PostListTabInfo(
      postListTabType: PostListTabType.adminAlert,
      label: '事業者投稿',
      widget: AdminAlertListTab(),
    ),
  ];

  const PostListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: _postListTabs.length,
      child: Builder(
        builder: (context) {
          final postListTabType = ref.watch(postListTabTypeProvider);
          final postListTabInfo = _postListTabs
              .firstWhere((tab) => tab.postListTabType == postListTabType);
          final index = _postListTabs.indexOf(postListTabInfo);

          // プロバイダのタブタイプへ移動
          final tabController = DefaultTabController.of(context)!;
          tabController.animateTo(index);

          tabController.addListener(() {
            if (!tabController.indexIsChanging) {
              // タブが変化した際に状態を更新
              ref
                  .read(postListTabTypeProvider.notifier)
                  .update((_) => PostListTabType.values[tabController.index]);
            }
          });

          return Scaffold(
            appBar: AppBar(
              backgroundColor: Theme.of(context).canvasColor,
              elevation: 0.0,
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(28.0),
                child: Ink(
                  height: 38.0,
                  child: TabBar(
                    unselectedLabelColor: Colors.black,
                    indicatorSize: TabBarIndicatorSize.tab,
                    indicator: BoxDecoration(
                      color: Colors.blueGrey,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    tabs: _postListTabs.map((tab) {
                      return Tab(
                        child: Text(tab.label,
                            style: const TextStyle(fontSize: 18.0)),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
            body: TabBarView(
              children: _postListTabs.map((tab) => tab.widget).toList(),
            ),
          );
        },
      ),
    );
  }
}

/// タブの情報を保持するクラスです。
class _PostListTabInfo {
  // タブタイプ
  final PostListTabType postListTabType;

  // タブのラベル
  final String label;

  // タブ選択時に表示するWidget
  final Widget widget;

  const _PostListTabInfo({
    required this.postListTabType,
    required this.label,
    required this.widget,
  });
}

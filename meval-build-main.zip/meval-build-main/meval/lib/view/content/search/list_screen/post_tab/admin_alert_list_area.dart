import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../../../../../model/data/admin_alert.dart';
import '../../../../../model/data/admin_post_mixin.dart';
import '../../../../../model/data/admin_questionnaire.dart';
import '../../../../../model/data/map_position_mixin.dart';
import '../../../../../provider/search_map_provider.dart';
import '../../../../../util/logger.dart';
import '../list_area.dart';

// 行政投稿アラートリストプロバイダ
final adminAlertsProvider =
    FutureProvider.autoDispose<List<AdminPostMixin>>((ref) async {
  ref.onDispose(() {
    logger.fine('adminAlertsProvider dispose.');
  });

  final now = await NTP.now();
  final adminAlertDocList = await ref.watch(adminAlertStreamProvider.future);

  return (await Future.wait(
    adminAlertDocList.map(
      (documentSnapshot) => adminAlertRef(id: documentSnapshot.id).get(),
    ),
  ))
      .map((adminAlertDocumentSnapshot) => adminAlertDocumentSnapshot.data)
      .whereType<AdminPostMixin>()
      // 期限にてフィルタ
      .where((adminAlert) => now.compareTo(adminAlert.dueDate) <= 0)
      .toList();
});

// 行政投稿アンケートリストプロバイダ
final adminQuestionnairesProvider =
    FutureProvider.autoDispose<List<AdminPostMixin>>((ref) async {
  ref.onDispose(() {
    logger.fine('adminQuestionnairesProvider dispose.');
  });

  final now = await NTP.now();
  final adminQuestionnaireDocList =
      await ref.watch(adminQuestionnaireStreamProvider.future);

  return (await Future.wait(
    adminQuestionnaireDocList.map(
      (documentSnapshot) =>
          adminQuestionnaireRef(id: documentSnapshot.id).get(),
    ),
  ))
      .map((adminQuestionnaireDocumentSnapshot) =>
          adminQuestionnaireDocumentSnapshot.data)
      .whereType<AdminPostMixin>()
      // 期限にてフィルタ
      .where((adminQuestionnaire) =>
          now.compareTo(adminQuestionnaire.dueDate) <= 0)
      .toList();
});

class AdminAlertListArea extends ConsumerWidget {
  const AdminAlertListArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adminAlertsAsyncValue = ref.watch(adminAlertsProvider);
    final adminQuestionnairesAsyncValue =
        ref.watch(adminQuestionnairesProvider);

    if (adminAlertsAsyncValue is! AsyncData ||
        adminQuestionnairesAsyncValue is! AsyncData) {
      return const SizedBox();
    }

    final adminAlerts = adminAlertsAsyncValue.value;
    final adminQuestionnaires = adminQuestionnairesAsyncValue.value;
    if (adminAlerts == null || adminQuestionnaires == null) {
      return const SizedBox();
    }

    // 行政投稿（行政投稿アラート + 行政投稿アンケート）
    final adminPosts = [...adminAlerts, ...adminQuestionnaires];
    adminPosts.sort((a, b) {
      if (a.createdAt == null || b.createdAt == null) {
        return -1;
      }
      return b.createdAt!.compareTo(a.createdAt!);
    });

    return ListView.separated(
      itemCount: adminPosts.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(height: 5.0);
      },
      itemBuilder: (BuildContext context, int index) {
        return ListArea(
          mapPositionMixin: adminPosts[index] as MapPositionMixin,
          content: adminPosts[index].message,
          isGreyOut: false,
        );
      },
    );
  }
}

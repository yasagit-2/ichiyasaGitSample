import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/base.dart';
import '../../../model/data/check_in.dart';
import '../../../provider/location_provider.dart';
import '../../../provider/search_map_provider.dart';
import '../../component/bottom_sheet_content.dart';
import '../../style/style.dart';

final baseBottomSheetDismiss = StateProvider.autoDispose<bool>((ref) => false);

class BaseBottomSheet extends ConsumerWidget {
  final Base base;
  final AsyncCallback checkIn;
  final bool isAvailCheckIn;

  const BaseBottomSheet({
    Key? key,
    required this.base,
    required this.checkIn,
    required this.isAvailCheckIn,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);
    if (ref.watch(baseBottomSheetDismiss)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigator.pop();
      });

      return const SizedBox();
    }

    final baseAsyncValue = ref.watch(baseByIdStreamProvider(base.id));
    final checkInAsyncValue = ref.watch(checkInByBaseIdStreamProvider(base.id));

    if (baseAsyncValue is! AsyncData || checkInAsyncValue is AsyncLoading) {
      return const SizedBox(
          height: 350, child: Center(child: CircularProgressIndicator()));
    }

    final streamedBase = baseAsyncValue.value;
    if (streamedBase == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        // 表示すべき拠点が存在しない場合、マップへ戻る
        // （拠点情報表示中に拠点が削除されるケースを考慮したもの）
        navigator.pop();
      });

      return const SizedBox();
    }

    CheckIn? streamedCheckIn;
    if (checkInAsyncValue is AsyncError) {
      final error = checkInAsyncValue.error;
      if (error is FirebaseException && error.code == 'permission-denied') {
        // チェックインが存在しない場合は、セキュリティルールによりpermission-deniedが発生する
        // permission-deniedの場合、未チェックインとして処理する
        streamedCheckIn = null;
      } else {
        return const SizedBox(
            height: 350, child: Center(child: CircularProgressIndicator()));
      }
    } else {
      streamedCheckIn = checkInAsyncValue.value;
    }

    bool isPossibleCheckin = isAvailCheckIn;

    if (streamedCheckIn != null) {
      // 拠点チェックイン済み
      // （拠点情報表示中に、同一ユーザにて当該拠点へ別端末からチェックインするようなケースを考慮）

      // チェックイン不可とする
      isPossibleCheckin = false;
    }

    final content = baseAsyncValue.value?.content;

    return FutureBuilder(
      future: ref.watch(currentLocationProvider.future),
      builder: (BuildContext context, AsyncSnapshot<Position?> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox(
              height: 350, child: Center(child: CircularProgressIndicator()));
        }

        if (!snapshot.hasData || snapshot.data == null) {
          // 位置情報が取得できない場合はチェックイン不可
          isPossibleCheckin = false;
        }

        if (snapshot.data != null && snapshot.data!.isMocked) {
          // 位置情報がモックされている場合はチェックイン不可
          isPossibleCheckin = false;
        }

        return SizedBox(
            height: content == null ? 350.0 : 500.0,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CupertinoButton(
                        onPressed: () => navigator.pop(),
                        child: const Icon(CupertinoIcons.xmark, size: 20.0),
                      ),
                      CupertinoButton(
                        onPressed: isPossibleCheckin
                            ? () async {
                                await checkIn();
                                navigator.pop();
                              }
                            : null,
                        child: const Text('チェックイン'),
                      ),
                    ],
                  ),
                  const Divider(
                    height: 0,
                    thickness: 1,
                  ),
                  VerticalSpacer.smallish,
                  BottomSheetContent(
                    imageUrl: streamedBase.imageUrl,
                    name: streamedBase.name,
                    content: streamedBase.content,
                  ),
                ],
              ),
            ));
      },
    );
  }
}

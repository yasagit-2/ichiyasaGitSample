import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../model/data/merchant.dart';
import '../../../provider/search_map_provider.dart';
import '../../component/bottom_sheet_content.dart';
import '../../component/coupon_list_screen.dart';
import '../../style/style.dart';

final merchantBottomSheetDismiss =
    StateProvider.autoDispose<bool>((ref) => false);

class MerchantBottomSheet extends ConsumerWidget {
  final Merchant merchant;

  const MerchantBottomSheet({Key? key, required this.merchant})
      : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final navigator = Navigator.of(context);
    if (ref.watch(merchantBottomSheetDismiss)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigator.pop();
      });

      return const SizedBox();
    }

    final merchantAsyncValue =
        ref.watch(merchantByIdStreamProvider(merchant.id));
    final tweetAsyncValue =
        ref.watch(tweetStreamProviderByMerchantId(merchant.id));

    final couponsAsyncValue =
        ref.watch(couponsByMerchantIdStreamProvider(merchant.id));
    final couponHistoriesAsyncValue =
        ref.watch(couponHistoriesByMerchantId(merchant.id));

    if (merchantAsyncValue is! AsyncData ||
        tweetAsyncValue is! AsyncData ||
        couponsAsyncValue is! AsyncData ||
        couponsAsyncValue.value == null ||
        couponHistoriesAsyncValue is! AsyncData ||
        couponHistoriesAsyncValue.value == null) {
      return const SizedBox(
          height: 350, child: Center(child: CircularProgressIndicator()));
    }

    final streamedMerchant = merchantAsyncValue.value;
    if (streamedMerchant == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // 表示すべき加盟店が存在しない場合、マップへ戻る
        // （加盟店情報表示中に拠点が削除されるケースを考慮したもの）
        navigator.pop();
      });

      return const SizedBox();
    }

    final tweet = tweetAsyncValue.value;
    final coupons = couponsAsyncValue.value!;
    final couponHistories = couponHistoriesAsyncValue.value!;
    final content = merchantAsyncValue.value!.content;

    return SizedBox(
        height: content == null ? 380.0 : 500.0,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CupertinoButton(
                    child: const Icon(CupertinoIcons.xmark, size: 20.0),
                    onPressed: () => navigator.pop(),
                  ),
                  coupons.isEmpty && couponHistories.isEmpty
                      ? const SizedBox()
                      : CupertinoButton(
                          child: const Text('クーポン'),
                          onPressed: () {
                            // クーポンリスト画面へ
                            context.goNamed(CouponListScreen.nameFromSearch,
                                extra: merchant.id);
                          },
                        ),
                ],
              ),
              const Divider(
                height: 0,
                thickness: 1,
              ),
              VerticalSpacer.smallish,
              BottomSheetContent(
                imageUrl: streamedMerchant.imageUrl,
                name: streamedMerchant.name,
                tweet: tweet,
                merchantsUrl: streamedMerchant.merchantsUrl,
                content: streamedMerchant.content,
              ),
            ],
          ),
        ));
  }
}

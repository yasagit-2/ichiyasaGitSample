import 'package:flutter/material.dart';

import 'button/go_to_list_button.dart';
import 'button/menu_button.dart';
import 'button/post_edit_button.dart';
import 'search_map.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          backgroundColor: Theme.of(context).canvasColor,
          automaticallyImplyLeading: false,
          elevation: 0.0,
        ),
      ),
      body: Stack(
        children: const [
          // 探索マップ
          SearchMap(),
          // メニューボタン
          MenuButton(),
          // 一覧ボタン
          GoToListButton(),
          // 投稿編集ボタン
          PostEditButton(),
        ],
      ),
    );
  }
}

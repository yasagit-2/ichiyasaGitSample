import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/collection.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../const/constant.dart';
import '../../../const/message.dart';
import '../../../model/data/base.dart';
import '../../../model/data/merchant.dart';
import '../../../provider/location_provider.dart';
import '../../../provider/map_controller_provider.dart';
import '../../../provider/menu_button_provider.dart';
import '../../../provider/screen_type_provider.dart';
import '../../../provider/search_map_provider.dart';
import '../../../provider/settings_provider.dart';
import '../../../provider/shared_strage_provider.dart';
import '../../../util/logger.dart';
import '../../../util/show_toast.dart';
import '../../../view_model/login_view_model.dart';
import '../../../view_model/member_view_model.dart';
import '../../../view_model/search_map_view_model.dart';
import '../../component/loading_service.dart';
import '../my_page/my_page_screen.dart';
import 'base_bottom_sheet.dart';
import 'button/post_edit_button.dart';
import 'merchant_bottom_sheet.dart';
import 'search_screen_callbacks.dart';

// マーカープロバイダ
final markersProvider = Provider.autoDispose<KtSet<Marker>>((ref) {
  ref.onDispose(() {
    logger.fine('markersProvider dispose.');
  });

  final mapInformation = ref.watch(searchMapViewModelProvider);
  final menuButtonSelection = ref.watch(selectedMenuButtonProvider);

  Set<Marker> markers = {};
  // 拠点ボタン有効
  if (menuButtonSelection == MenuButtonSelection.base) {
    markers.addAll(mapInformation.baseMarkers);
  }
  // 投稿表示ボタン有効
  if (menuButtonSelection == MenuButtonSelection.post) {
    markers.addAll(mapInformation.postMarkers);
    markers.addAll(mapInformation.adminAlertMarkers);
    markers.addAll(mapInformation.adminQuestionnaireMarkers);
  }
  // 加盟店ボタン有効
  if (menuButtonSelection == MenuButtonSelection.merchant) {
    markers.addAll(mapInformation.merchantMarkers);
  }

  // 投稿編集ボタン表示中(LongTapにより、投稿準備マーカー表示)
  if (ref.watch(postEditButtonVisibilityProvider)) {
    markers.addAll(mapInformation.postingPreparationMarker);
  }

  logger.fine('markers=$markers');

  return markers.toImmutableSet();
});

// サークルプロバイダ
final circleProvider = Provider.autoDispose<KtSet<Circle>>((ref) {
  Set<Circle> circles = {};
  final mapInformation = ref.watch(searchMapViewModelProvider);

  final isBaseButtonEnabled =
      ref.watch(selectedMenuButtonProvider) == MenuButtonSelection.base;
  if (isBaseButtonEnabled) {
    circles.addAll(mapInformation.baseCircles);
  }

  return circles.toImmutableSet();
});

// 拠点ボトムシートオープンプロバイダ
final baseBottomSheetOpenProvider = StateProvider<Base?>((ref) => null);

// 加盟店ボトムシートオープンプロバイダ
final merchantBottomSheetOpenProvider = StateProvider<Merchant?>((ref) => null);

class SearchMap extends HookConsumerWidget {
  static final List<TargetFocus> targets = createTargetFocus();

  const SearchMap({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    logger.fine('SearchMap');

    // マップアイコンのロード
    final mapIconAsyncValue = ref.watch(mapIconProvider);

    // チェックイン時にマーカーを再生成するため、チェックイン情報を監視
    final checkInAsyncValue = ref.watch(checkInStreamProvider);
    // 拠点制覇時にマーカーを再生成するため、拠点制覇情報（親拠点）を監視
    final completedParentBasesAsyncValue =
        ref.watch(completedParentBasesStreamProvider);

    // デバイスに保存されている最終の位置情報
    final lastKnownLocationAsyncValue = ref.watch(lastKnownLocationProvider);

    if (mapIconAsyncValue is AsyncLoading ||
        lastKnownLocationAsyncValue is AsyncLoading ||
        checkInAsyncValue is AsyncLoading ||
        completedParentBasesAsyncValue is AsyncLoading) {
      if (ref.watch(screenTypeProvider) == ScreenType.search) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ref.watch(loadingServiceProvider.notifier).present();
        });
      }
      return const SizedBox();
    }

    final centerLocation = ref.watch(centerLocationProvider);
    final completer = Completer<GoogleMapController>();
    CameraPosition cameraPosition = CameraPosition(
        target: LatLng(centerLocation.latitude, centerLocation.longitude));

    // メニューボタン
    final menuButtonSelection = ref.watch(selectedMenuButtonProvider);

    final navigator = Navigator.of(context);

    useEffect(() {
      Future.microtask(() async {
        await ref.watch(mapIconProvider.future);
        final firebaseUser = await ref.watch(authStateChangesProvider.future);
        if (firebaseUser != null) {
          // マーカー生成
          await _createMarkers(ref, navigator);
        }

        if (ref.watch(screenTypeProvider) == ScreenType.search) {
          final sharedPreferences = ref.read(sharedPreferencesProvider);
          final isDisplayedTutorial = sharedPreferences.getBool(
                  SharedPreferenceConst.displayedTutorialSearchScreen) ??
              false;

          if (isDisplayedTutorial) {
            // 探索画面の初回表示以外はチュートリアルを表示しない
            return;
          }

          // チュートリアル表示済み状態へ更新
          await sharedPreferences.setBool(
              SharedPreferenceConst.displayedTutorialSearchScreen, true);
          ref.read(displayedTutorialProvider.notifier).update((_) => true);

          // 拠点ボトムシートを閉じる
          ref.read(baseBottomSheetDismiss.notifier).update((_) => true);
          // 加盟店ボトムシートを閉じる
          ref.read(merchantBottomSheetDismiss.notifier).update((_) => true);

          ref.invalidate(selectedMenuButtonProvider);

          String identify = '';
          final tutorialCoachMark = TutorialCoachMark(
            targets: targets,
            paddingFocus: 10,
            opacityShadow: 0.8,
            onClickOverlay: (target) {
              final targetIdentify = target.identify as String;

              if (identify == targetIdentify) {
                return;
              }

              // メニューボタン（SpeedDial）をオープン
              ref.read(openCloseDialProvider).value = true;

              identify = targetIdentify;
              switch (identify) {
                case Tutorial.menuButtonId:
                  ref
                      .read(selectedMenuButtonProvider.notifier)
                      .update((_) => MenuButtonSelection.base);
                  break;
                case Tutorial.menuBaseButtonId:
                  ref
                      .read(selectedMenuButtonProvider.notifier)
                      .update((_) => MenuButtonSelection.post);
                  break;
                case Tutorial.menuPostButtonId:
                  // メニューボタン（SpeedDial）をクローズ
                  ref.read(openCloseDialProvider).value = false;
                  ref
                      .read(postEditButtonVisibilityProvider.notifier)
                      .update((_) => true);
                  break;
                case Tutorial.postEditButtonId:
                  // メニューボタン（SpeedDial）をオープン
                  ref.read(openCloseDialProvider).value = true;
                  ref
                      .read(postEditButtonVisibilityProvider.notifier)
                      .update((_) => false);
                  ref
                      .read(selectedMenuButtonProvider.notifier)
                      .update((_) => MenuButtonSelection.merchant);
                  break;
                case Tutorial.menuMerchantButtonId:
                  ref.invalidate(selectedMenuButtonProvider);
                  // メニューボタン（SpeedDial）をクローズ
                  ref.read(openCloseDialProvider).value = false;
                  break;
              }
            },
            onFinish: () {
              ref.invalidate(selectedMenuButtonProvider);
              // メニューボタン（SpeedDial）をクローズ
              ref.read(openCloseDialProvider).value = false;

              ref.invalidate(baseBottomSheetDismiss);
              ref.invalidate(merchantBottomSheetDismiss);
            },
            onSkip: () {
              ref.invalidate(selectedMenuButtonProvider);
              // メニューボタン（SpeedDial）をクローズ
              ref.read(openCloseDialProvider).value = false;
            },
          );

          tutorialCoachMark.show(context: context, rootOverlay: true);
        }
      });

      return null;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final base = ref.watch(baseBottomSheetOpenProvider);
      final memberId = ref.watch(memberIdProvider);
      if (base != null && memberId != null) {
        ref.watch(baseBottomSheetOpenProvider.notifier).update((_) => null);

        // チェックイン可否判定
        final isAvailCheckIn = await ref
            .watch(searchMapViewModelProvider.notifier)
            .baseCheckInAvailability(base);

        // 拠点ボトムシート表示
        showBaseInformation(
          ref,
          navigator,
          base,
          () async => await ref.watch(loadingServiceProvider.notifier).wrap(
                ref.watch(searchMapViewModelProvider.notifier).checkIn(
                      base,
                      memberId,
                      () => onSuccessOfCheckInToBase(base.name),
                    ),
              ),
          isAvailCheckIn,
        );
      }

      final merchant = ref.watch(merchantBottomSheetOpenProvider);
      if (merchant != null) {
        ref.watch(merchantBottomSheetOpenProvider.notifier).update((_) => null);

        // 加盟店ボトムシート表示
        showMerchantInformation(navigator, merchant);
      }
    });

    return SafeArea(
      child: GoogleMap(
        myLocationEnabled: true,
        myLocationButtonEnabled:
            // 投稿表示モード=OFFの場合のみ表示
            menuButtonSelection != MenuButtonSelection.post,
        zoomControlsEnabled:
            // 投稿表示モード=OFFの場合のみ表示
            menuButtonSelection != MenuButtonSelection.post,
        mapToolbarEnabled: false,
        initialCameraPosition: const CameraPosition(
          target: MapConst.initialLocation,
          zoom: MapConst.initialZoom,
        ),
        onMapCreated: (GoogleMapController controller) async {
          if (ref.watch(permissionProvider)) {
            final currentPosition =
                await ref.watch(currentLocationProvider.future);
            if (currentPosition != null) {
              if (currentPosition.isMocked) {
                // 位置情報がモックされている
                showErrorToast(DisplayedErrorMessage.locationError);
              }

              // 現在の位置情報の場所へ移動
              await _moveCameraToNewPosition(controller, currentPosition);

              // 地図の中心を現在の位置情報へ更新
              ref.watch(centerLocationProvider.notifier).update((_) =>
                  LatLng(currentPosition.latitude, currentPosition.longitude));
            }
          }

          completer.complete(controller);
          ref
              .watch(googleMapControllerProvider.notifier)
              .update((_) => controller);

          // ローディング解除
          ref.read(loadingServiceProvider.notifier).dismiss();
        },
        onCameraIdle: () async {
          await requestPermission(ref);

          final centerLocation = LatLng(
              cameraPosition.target.latitude, cameraPosition.target.longitude);

          // 地図の中心をCameraPositionの位置へ更新
          ref
              .watch(centerLocationProvider.notifier)
              .update((_) => centerLocation);
        },
        onCameraMove: (position) {
          cameraPosition = position;
        },
        onLongPress: (LatLng location) {
          // 投稿表示モード=OFFの場合は何もしない
          if (menuButtonSelection != MenuButtonSelection.post) return;

          // 投稿準備マーカーを追加
          ref
              .watch(searchMapViewModelProvider.notifier)
              .addPostingPreparationMarker(location);

          // 投稿編集ボタン表示
          ref
              .watch(postEditButtonVisibilityProvider.notifier)
              .update((_) => true);
        },
        onTap: (LatLng location) {
          // 投稿表示モード=OFFの場合は何もしない
          if (menuButtonSelection != MenuButtonSelection.post) return;

          // 投稿編集ボタン表示解除
          ref
              .watch(postEditButtonVisibilityProvider.notifier)
              .update((_) => false);
        },
        markers: ref.watch(markersProvider).asSet(),
        circles: ref.watch(circleProvider).asSet(),
      ),
    );
  }

  /// [position]へMapを移動します。
  Future<void> _moveCameraToNewPosition(
      GoogleMapController controller, Position position) async {
    final target = LatLng(position.latitude, position.longitude);

    double zoomLevel = MapConst.initialZoom;
    try {
      zoomLevel = await controller.getZoomLevel();
    } on Exception catch (e) {
      logger.warning(e);
    }

    await controller.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: target,
          zoom: zoomLevel,
        ),
      ),
    );
  }

  /// 地図上に表示するマーカーを生成します。
  Future<void> _createMarkers(
    WidgetRef ref,
    NavigatorState navigator,
  ) async {
    // 拠点マーカー
    await _createBaseMarkers(ref, navigator);
    // 加盟店マーカー
    await _createMerchantMarkers(ref, navigator);
    // 投稿マーカー（投稿/行政投稿アラート/行政投稿アンケート）
    await _createPostAndAdminMarkers(ref, navigator);
  }

  /// 拠点マーカーを生成します。
  Future<void> _createBaseMarkers(
    WidgetRef ref,
    NavigatorState navigator,
  ) async {
    // 拠点表示ボタンがOFFの場合は処理しない
    if (ref.watch(selectedMenuButtonProvider) != MenuButtonSelection.base) {
      return;
    }

    final baseDocSnapshots = await ref.watch(baseStreamProvider.future);

    // 拠点マーカー生成
    return await ref
        .watch(searchMapViewModelProvider.notifier)
        .createBaseMarkers(
          baseDocSnapshots,
          (baseName) => onSuccessOfCheckInToBase(baseName),
          onSuccessOfCheckInToSubBase,
          (base, checkIn, isAvailCheckIn) => showBaseInformation(
            ref,
            navigator,
            base,
            checkIn,
            isAvailCheckIn,
          ),
        );
  }

  /// 加盟店マーカーを生成します。
  Future<void> _createMerchantMarkers(
    WidgetRef ref,
    NavigatorState navigator,
  ) async {
    // 加盟店表示ボタンがOFFの場合は処理しない
    if (ref.watch(selectedMenuButtonProvider) != MenuButtonSelection.merchant) {
      return;
    }

    final merchantDocSnapshots = await ref.watch(merchantStreamProvider.future);

    // 加盟店IDリスト
    final merchantIdList = merchantDocSnapshots
        .map((documentSnapshot) => documentSnapshot.id)
        .toList();

    // つぶやきストリームプロバイダ
    final tweets = await ref.watch(
        tweetStreamProviderByMerchantIdList(merchantIdList.toImmutableList())
            .future);

    // 加盟店マーカー生成
    return ref.watch(searchMapViewModelProvider.notifier).createMerchantMarkers(
          merchantDocSnapshots,
          tweets,
          (merchant) => showMerchantInformation(navigator, merchant),
        );
  }

  /// 投稿マーカー（投稿/行政投稿アラート/行政投稿アンケート）を生成します。
  Future<void> _createPostAndAdminMarkers(
      WidgetRef ref, NavigatorState navigator) async {
    // 投稿
    final postDocSnapshots = await _getPostDocSnapshots(ref);
    // 行政投稿アラート
    final adminAlertDocSnapshots = await _getAdminAlertDocSnapshots(ref);
    // 行政投稿アンケート
    final adminQuestionnaireDocSnapshots =
        await _getAdminQuestionnaireDocSnapshots(ref);

    // 投稿マーカー（投稿/行政投稿アラート/行政投稿アンケート）生成
    return ref
        .watch(searchMapViewModelProvider.notifier)
        .createPostAndAdminMarkers(
          postDocSnapshots,
          adminAlertDocSnapshots,
          adminQuestionnaireDocSnapshots,
          navigator,
          onTapPost,
          onTapAdminAlert,
          onTapAdminQuestionnaire,
        );
  }

  /// 投稿のDocumentSnapshotを返却します。
  Future<List<DocumentSnapshot>?> _getPostDocSnapshots(WidgetRef ref) async {
    // 投稿表示ボタンがOFFの場合は処理しない
    if (ref.watch(selectedMenuButtonProvider) != MenuButtonSelection.post) {
      return null;
    }

    return await ref.watch(postStreamProvider.future);
  }

  /// 行政投稿アラートのDocumentSnapshotを返却します。
  Future<List<DocumentSnapshot>?> _getAdminAlertDocSnapshots(
      WidgetRef ref) async {
    // 投稿表示ボタンがOFFの場合は処理しない
    if (ref.watch(selectedMenuButtonProvider) != MenuButtonSelection.post) {
      return null;
    }

    return await ref.watch(adminAlertStreamProvider.future);
  }

  /// 行政投稿アンケートのDocumentSnapshotを返却します。
  Future<List<DocumentSnapshot>?> _getAdminQuestionnaireDocSnapshots(
      WidgetRef ref) async {
    // 投稿表示ボタンがOFFの場合は処理しない
    if (ref.watch(selectedMenuButtonProvider) != MenuButtonSelection.post) {
      return null;
    }

    return await ref.watch(adminQuestionnaireStreamProvider.future);
  }

  static List<TargetFocus> createTargetFocus() {
    List<TargetFocus> targets = [];
    targets.add(
      TargetFocus(
        identify: Tutorial.menuButtonId,
        keyTarget: Tutorial.menuButtonKey,
        enableOverlayTab: true,
        enableTargetTab: false,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                    child: Text(
                      "メニューボタン",
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                  ),
                  Text(
                    'タップしてメニューを表示します。',
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );

    targets.add(
      TargetFocus(
        identify: Tutorial.menuBaseButtonId,
        keyTarget: Tutorial.menuBaseButtonKey,
        enableOverlayTab: true,
        enableTargetTab: false,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                    child: Text(
                      "拠点メニュー",
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                  ),
                  Text(
                    '拠点やサブ拠点を表示します。',
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );

    targets.add(
      TargetFocus(
        identify: Tutorial.menuPostButtonId,
        keyTarget: Tutorial.menuPostButtonKey,
        enableOverlayTab: true,
        enableTargetTab: false,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                    child: Text(
                      "投稿メニュー",
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                  ),
                  Text(
                    '会員の投稿や行政からの投稿を表示します。',
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );

    targets.add(
      TargetFocus(
        identify: Tutorial.postEditButtonId,
        keyTarget: Tutorial.postEditButtonKey,
        enableOverlayTab: true,
        enableTargetTab: false,
        contents: [
          TargetContent(
            align: ContentAlign.top,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                    child: Text(
                      "投稿編集ボタン",
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                  ),
                  Text(
                    '投稿メニューにて地図上の特定の場所をロングタップすると投稿編集ボタンが表示されます。投稿編集ボタンをタップして、ロングタップした箇所に投稿を行うことができます。',
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );

    targets.add(
      TargetFocus(
        identify: Tutorial.menuMerchantButtonId,
        keyTarget: Tutorial.menuMerchantButtonKey,
        enableOverlayTab: true,
        enableTargetTab: false,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                    child: Text(
                      "加盟店メニュー",
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                  ),
                  Text(
                    '加盟店や加盟店のクーポンを表示します。',
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );

    return targets;
  }
}

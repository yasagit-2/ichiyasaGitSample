/// 利用者が参照する異常系メッセージ
class DisplayedErrorMessage {
  static const smsLoginError = 'ログインに失敗しました\n正しい確認コードを入力してください';
  static const smsLoginTooManyRequests =
      'ログインに多数失敗したため\n一時的に無効化しました\nしばらく時間をおいてから\n再ログインしてください';
  static const loginError = 'ログインに失敗しました';
  static const networkError = '通信異常が発生しました\n通信環境を確認してください';
  static const userNotFound = '会員情報を確認できません\n再ログインしてください';
  static const userDisabled = 'このユーザは利用できません';
  static const timeout = 'タイムアウトが発生しました\n通信環境を確認してください';
  static const cannotOpenStoreUrl = 'ストアのURLをオープンできません';
  static const locationError = '正しい位置情報を使用できません';
  static const currentLocationError = '位置情報を取得できません\nアプリの設定を確認してください';
  static const usedCoupon = '有効期限が切れています\nこのクーポンは使用できません';
}

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';

class Const {
  static const phoneNumberRegex = r'^0[0-9]{10}$';

  /// エポック
  static final epoch = DateTime.fromMillisecondsSinceEpoch(0);

  /// 年月日初期値
  static final initialDate = DateTime(1899, 12, 31);

  /// 生年月の初期値
  static final monthOfBirthInitialDate = DateTime(1980, 1, 1);

  /// 生年月の最小値
  static final monthOfBirthMinimumDate = DateTime(1900, 1, 1);

  /// 年月フォーマット
  static final yearMonthFormat = DateFormat('yyyy年 M月', 'ja');

  /// 日付フォーマット
  static final dateFormat = DateFormat('yyyy年 M月 d日', 'ja');

  /// 月日フォーマット
  static final monthDateFormat = DateFormat('M月 d日', 'ja');

  /// 年月日時刻フォーマット
  static final dateAndTimeFormat = DateFormat('yyyy/M/d HH:mm', 'ja');

  /// 時刻フォーマット（時分）
  static final hourMinuteFormat = DateFormat('HH:mm');

  /// 3桁ごとにカンマ区切りのフォーマット
  static final numberFormatter = NumberFormat("#,###");

  /// 性別
  static const genderList = [
    '男性',
    '女性',
    'その他',
    '回答しない',
  ];

  /// Alertアイコン
  static const String alert = 'assets/images/icon/alert.png';

  /// Trashアイコン
  static const String trash = 'assets/images/icon/trash.png';

  /// Stampアイコン
  static const String stamp = 'assets/images/icon/stamp.png';

  /// 退会アイコン
  static const String withdrawal = 'assets/images/icon/withdrawal.png';

  /// MeValロゴ画像
  static const String logo = 'assets/images/icon/logo_home.png';

  /// Loading（lottie）
  static const String lottieLoading = 'assets/lottie/927-triangle-loading.json';

  /// デフォルト規定歩数
  static int defaultPrescribedSteps = 35000;

  /// 1日のミリ秒
  static int millisPerDay = 86400000;

  /// タイムアウト（秒）
  static int timeoutSec = 10;

  /// スライド表示するWidgetの最大数（お知らせ、イベント）
  static int slideLimit = 5;
}

class TextFieldConst {
  // ニックネームの最大文字数
  static const int nicknameMaxLength = 20;

  // メールアドレスの最大文字数
  static const int mailAddressMaxLength = 100;

  // 投稿および行政報告の最大文字数
  static const int postMaxLength = 50;

  // コメントの最大文字数
  static const int commentMaxLength = 50;
}

class SharedPreferenceConst {
  /// 電話番号
  static const String phoneNumber = 'phoneNumber';

  /// push通知
  static const String pushNotificationEnabled = 'pushNotificationEnabled';

  /// 初回起動（true：初回起動）
  static const String firstRun = 'firstRun';

  /// 探索画面チュートリアル（true：表示済み）
  static const String displayedTutorialSearchScreen =
      'displayedTutorialSearchScreen';
}

class Env {
  // [Twitter]APIキー
  static const String twitterApiKey = 'TWITTER_API_KEY';

  // [Twitter]APIシークレット
  static const String twitterApiSecret = 'TWITTER_API_SECRET';

  // [Twitter]コールバックURL
  static const String twitterCallbackUrl = 'TWITTER_CALLBACK_URL';

  // [Apple]コールバックURL
  static const String appleCallbackUrl = 'APPLE_CALLBACK_URL';
}

class MapConst {
  /// Map初期表示の位置情報
  static const LatLng initialLocation =
      LatLng(35.68142790469979, 139.76712479782196);

  /// Map初期表示のズームレベル
  static const double initialZoom = 14.4746;

  /// 拠点/投稿/加盟店収集半径(km)
  static const double collectionRadius = 10.0;

  /// チェックイン可能距離(m)
  static const double checkInRadius = 200.0;

  /// 加盟店単位のつぶやき（InfoWindow）表示時間（秒）
  static const int infoWindowDisplaySeconds = 5;

  /// マップ停止中（マップ表示したまま操作しない状態）につぶやきを表示するタイマー継続時間制限（分）
  static const int infoWindowTimerMinutes = 5;
}

class MapImage {
  // アイコンサイズ（Height）
  static const int iconHeight = 100;

  // アイコンサイズ（Width）
  static const int iconWidth = 100;

  /// 拠点
  static const String base = 'assets/images/map/base.png';

  /// 拠点(チェックイン)
  static const String baseCheckedIn = 'assets/images/map/base_checked_in.png';

  /// サブ拠点
  static const String subBase = 'assets/images/map/sub_base.png';

  /// 加盟店
  static const String merchant = 'assets/images/map/merchant.png';

  /// 加盟店（つぶやき）
  static const String merchantTweet = 'assets/images/map/merchant_tweet.png';

  /// 投稿
  static const String post = 'assets/images/map/post.png';

  /// 行政投稿アラート
  static const String adminAlert = 'assets/images/map/admin_alert.png';

  /// 行政投稿アンケート
  static const String adminQuestionnaire =
      'assets/images/map/admin_questionnaire.png';

  /// イベント
  static const String event = 'assets/images/map/event.png';

  /// イベント達成
  static const String completeEvent = 'assets/images/map/complete_event.png';
}

/// チュートリアル
class Tutorial {
  /// メニューボタン
  static const menuButtonId = 'menuButton';
  static final menuButtonKey = GlobalKey();

  /// 拠点ボタン
  static const menuBaseButtonId = 'menuBaseButton';
  static final menuBaseButtonKey = GlobalKey();

  /// 投稿ボタン
  static const menuPostButtonId = 'menuPostButton';
  static final menuPostButtonKey = GlobalKey();

  /// 加盟店ボタン
  static const menuMerchantButtonId = 'menuMerchantButton';
  static final menuMerchantButtonKey = GlobalKey();

  /// 投稿編集ボタン
  static const postEditButtonId = 'postEditButton';
  static final postEditButtonKey = GlobalKey();
}

/// 公開ステータス
enum PublishStatus {
  // 未公開
  unpublished,
  // 公開済み
  published,
  // 非公開
  private,
}

/// 公開ステータス[publishStatus]を定義値(int)へ変換します。
int publishStatusToInt(PublishStatus publishStatus) {
  switch (publishStatus) {
    // 未公開
    case PublishStatus.unpublished:
      return 0;
    // 公開済み
    case PublishStatus.published:
      return 1;
    // 非公開
    case PublishStatus.private:
      return 9;
    default:
      return 0;
  }
}

/// 投稿の可視性
enum VisibleStatus {
  // 表示
  visible,
  // 非表示
  nonVisible,
}

/// 投稿の可視性[visibleStatus]を定義値(int)へ変換します。
int visibleStatusToInt(VisibleStatus visibleStatus) {
  switch (visibleStatus) {
    // 表示
    case VisibleStatus.visible:
      return 0;
    // 非表示
    case VisibleStatus.nonVisible:
      return 1;
    default:
      return 0;
  }
}

/// 交換対象種別
enum ExchangeType {
  // ポイント
  point,
  // チケット
  ticket,
}

/// 交換対象種別[exchangeType]を定義値(int)へ変換します。
int exchangeTypeToInt(ExchangeType exchangeType) {
  switch (exchangeType) {
    // ポイント
    case ExchangeType.point:
      return 0;
    // チケット
    case ExchangeType.ticket:
      return 1;
    default:
      return 0;
  }
}

/// [exchangeType]を[ExchangeType]へ変換します。
ExchangeType intToExchangeType(int exchangeType) {
  switch (exchangeType) {
    // ポイント
    case 0:
      return ExchangeType.point;
    case 1:
      return ExchangeType.ticket;
    default:
      return ExchangeType.point;
  }
}

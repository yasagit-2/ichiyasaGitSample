import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:google_maps_flutter_android/google_maps_flutter_android.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'const/constant.dart';
import 'const/message.dart';
import 'firebase_options.dart';
import 'localization/japanese_cupertino_localizations.dart';
import 'provider/device_info_provider.dart';
import 'provider/geoflutterfire_provider.dart';
import 'provider/package_info_provider.dart';
import 'provider/routing_provider.dart';
import 'provider/shared_strage_provider.dart';
import 'util/logger.dart';
import 'util/show_toast.dart';
import 'view/component/loading_service.dart';
import 'view/component/phone_field.dart';
import 'view/style/style.dart';
import 'view_model/login_view_model.dart';
import 'view_model/member_view_model.dart';

void main() async {
  // await runZonedGuarded<Future<void>>(() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // [Crashlytics]catchされたException/Error
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;

  final container = ProviderContainer();
  PlatformDispatcher.instance.onError = (error, stack) {
    logger.severe('error=$error');
    logger.severe('stack=$stack');
    logger.severe('runtimeType=${error.runtimeType}');

    Future.microtask(
      () async {
        if (error is FirebaseAuthException) {
          if (error.code == 'user-not-found') {
            // Authenticationにユーザが存在しない
            // Firebase Authenticationのユーザが削除されるレアケースの考慮（不具合課題検討票 No.40 参照）
            showErrorToast(DisplayedErrorMessage.userNotFound);
            // Crashlytics
            await FirebaseCrashlytics.instance
                .recordError(error, stack, fatal: true);
            return;
          } else if (error.code == 'user-disabled') {
            // Authenticationのユーザが無効化されている
            // Web管理画面からユーザを無効化した場合の考慮
            showErrorToast(DisplayedErrorMessage.userDisabled);
            // Crashlytics
            await FirebaseCrashlytics.instance
                .recordError(error, stack, fatal: true);
            return;
          } else if (error.code == 'no-current-user') {
            // ログアウト処理が実行された後、
            // 非同期にて処理中のFirebaseアクセスにより発生するする可能性があるため、
            // このケースはエラメッセージを出力しない
            return;
          } else if (error.code == 'too-many-requests') {
            showErrorToast(DisplayedErrorMessage.smsLoginTooManyRequests);
            // Crashlytics
            await FirebaseCrashlytics.instance
                .recordError(error, stack, fatal: true);
            return;
          } else {
            // その他の異常は通信異常として捉える
            showErrorToast(DisplayedErrorMessage.networkError);
            // Crashlytics
            await FirebaseCrashlytics.instance
                .recordError(error, stack, fatal: true);
            return;
          }
        }

        // 認証状態確認
        final firebaseUser =
            await container.read(authStateChangesProvider.future);
        if (firebaseUser == null) {
          // ログアウト済みの場合は、エラーメッセージを表示しない
          await FirebaseCrashlytics.instance
              .recordError(error, stack, fatal: true);
          return;
        }

        if (error is SocketException ||
            error is FirebaseException ||
            error is PlatformException) {
          showErrorToast(DisplayedErrorMessage.networkError);
          // Crashlytics
          await FirebaseCrashlytics.instance
              .recordError(error, stack, fatal: true);
          return;
        }

        if (error is TimeoutException) {
          showErrorToast(DisplayedErrorMessage.timeout);
          // Crashlytics
          await FirebaseCrashlytics.instance
              .recordError(error, stack, fatal: true);
          return;
        }

        // Crashlytics
        await FirebaseCrashlytics.instance
            .recordError(error, stack, fatal: true);
        return;
      },
    );

    return true;
  };

  // FirebaseUserのログイン状態が確定するまで待機
  await FirebaseAuth.instance.userChanges().first;

  final sharedPreferences = await SharedPreferences.getInstance();

  final geoflutterfire = GeoFlutterFire();
  // パッケージ情報
  final packageInfo = await PackageInfo.fromPlatform();
  // デバイス情報
  final baseDeviceInfo = await DeviceInfoPlugin().deviceInfo;

  await dotenv.load(fileName: ".env");

  if (sharedPreferences.getBool(SharedPreferenceConst.firstRun) ?? true) {
    // iOSでは、ユーザ情報がiOSのキーチェーンに保存されるため、アプリを削除してもユーザ情報が残存する
    // そのため、初回起動時はFirebaseからのログアウト処理を実行する
    await container.read(loginViewModelProvider.notifier).logout();
    await sharedPreferences.setBool(SharedPreferenceConst.firstRun, false);

    await sharedPreferences.remove(SharedPreferenceConst.phoneNumber);
    container.invalidate(phoneNumberProvider);
    container.invalidate(phoneNumberValidProvider);
    container.invalidate(memberViewModelProvider);
    container.invalidate(loginViewModelProvider);
  }

  // フォアグラウンド通知の有効化（iOS）
  // https://firebase.flutter.dev/docs/messaging/notifications/#ios-configuration
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );

  // フォアグラウンド通知の有効化（Android）
  // https://firebase.flutter.dev/docs/messaging/notifications/#android-configuration
  const AndroidNotificationChannel channel = AndroidNotificationChannel(
    'high_importance_channel',
    'High Importance Notifications',
    description: 'This channel is used for important notifications.',
    importance: Importance.max,
  );
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  final token = await FirebaseMessaging.instance.getToken();
  logger.fine('token=$token');

  FirebaseMessaging.onMessage.listen(
    (RemoteMessage message) {
      final notification = message.notification;
      final android = message.notification?.android;

      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              channelDescription: channel.description,
              icon: 'ic_notification',
              enableVibration: true,
            ),
          ),
        );
      }
    },
  );

  // 全配信用のトピック購読登録(FCM)
  // https://dev.classmethod.jp/articles/flutter_fcm_push1/
  //"/topics/all"
  await FirebaseMessaging.instance.subscribeToTopic('all');

  final GoogleMapsFlutterPlatform mapsImplementation =
      GoogleMapsFlutterPlatform.instance;
  if (mapsImplementation is GoogleMapsFlutterAndroid) {
    mapsImplementation.useAndroidViewSurface = true;
  }

  runApp(ProviderScope(
    overrides: [
      sharedPreferencesProvider.overrideWithValue(sharedPreferences),
      geoflutterfireProvider.overrideWithValue(geoflutterfire),
      packageInfoProvider.overrideWithValue(packageInfo),
      baseDeviceInfoProvider.overrideWithValue(baseDeviceInfo),
    ],
    child: const MyApp(),
  ));
}

class MyApp extends ConsumerWidget {
  static const localeJa = Locale('ja', 'JP');
  static const localeEn = Locale("en", "US");

  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routingProvider);

    return StyledToast(
      locale: localeJa,
      child: MaterialApp.router(
        routeInformationProvider: router.routeInformationProvider,
        routeInformationParser: router.routeInformationParser,
        routerDelegate: router.routerDelegate,
        title: 'MeVal',
        debugShowCheckedModeBanner: false,
        theme: lightTheme,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          JapaneseCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          localeEn,
          localeJa,
        ],
        builder: (context, child) {
          return Stack(
            children: [
              if (child != null) child,
              Consumer(builder: (context, ref, child) {
                final isLoading = ref.watch(loadingServiceProvider);
                if (isLoading) {
                  return ColoredBox(
                    color: Colors.black54,
                    child: Center(
                      child: SpinKitFadingCircle(
                        color: AppColors.mainColor,
                        size: 100,
                      ),
                    ),
                  );
                }
                return const SizedBox();
              }),
            ],
          );
        },
      ),
    );
  }
}

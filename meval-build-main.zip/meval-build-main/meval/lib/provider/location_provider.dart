import 'dart:async';

import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:ntp/ntp.dart';

import '../const/constant.dart';
import '../const/message.dart';
import '../util/logger.dart';
import '../util/show_toast.dart';
import 'data/within_range_data.dart';
import 'settings_provider.dart';

/// LocationProviderのインスタンスを提供するプロバイダ
final locationProvider = Provider<LocationProvider>((ref) {
  ref.onDispose(() {
    logger.fine('locationProvider dispose.');
  });
  return LocationProvider();
});

/// 位置情報使用許可プロバイダ
final permissionProvider = StateProvider<bool>((ref) {
  ref.onDispose(() {
    logger.fine('permissionProvider dispose.');
  });
  return false;
});

/// 現在の位置情報を提供するプロバイダ
final currentLocationProvider = FutureProvider<Position?>((ref) async {
  logger.fine('currentLocationProvider');

  ref.onDispose(() {
    logger.fine('currentLocationProvider dispose.');
  });

  final locationPermission = await Geolocator.checkPermission();
  if (locationPermission != LocationPermission.whileInUse) {
    return null;
  }

  return await ref.watch(locationProvider).getCurrentLocation();
});

/// デバイスに保存されている最終の位置情報を提供するプロバイダ
/// 最終の位置情報を取得できない場合、および位置情報の使用許可が得られない場合は[MapConst.initialLocation]の[Position]を返却します。
final lastKnownLocationProvider = FutureProvider<Position>((ref) async {
  ref.onDispose(() {
    logger.fine('lastKnownLocationProvider dispose.');
  });

  final initialPosition = Position(
      longitude: MapConst.initialLocation.longitude,
      latitude: MapConst.initialLocation.latitude,
      timestamp: await NTP.now(),
      accuracy: 0.0,
      altitude: 0.0,
      heading: 0.0,
      speed: 0.0,
      speedAccuracy: 0.0);

  // 位置情報使用許可が得られない場合
  if (!ref.watch(permissionProvider)) return initialPosition;

  final position = await ref.watch(locationProvider).getLastKnownLocation();
  if (position == null) return initialPosition;

  return position;
});

/// 現在位置と[location]からチェックイン可否を判断します
/// 位置情報使用許可が得られていない場合および位置情報がモックされている場合はfalseを返却します。
Future<bool> checkInAvailability(Ref ref, LatLng location) async {
  final permission = ref.read(permissionProvider);
  if (!permission) return false;

  final currentLocation = await ref.read(currentLocationProvider.future);
  if (currentLocation == null) return false;

  if (currentLocation.isMocked) {
    // 位置情報がモックされている場合
    return false;
  }

  final distance = Geolocator.distanceBetween(currentLocation.latitude,
      currentLocation.longitude, location.latitude, location.longitude);

  // チェックイン可能距離(m)
  final checkInRadius = ref.read(checkInRadiusProvider);

  // チェックイン可能距離(m)を超える場合はチェックイン不可
  if (checkInRadius < distance) return false;

  return true;
}

/// 現在位置と位置情報から距離を判断します。
/// true：現在位置が距離の半径内である場合、false：現在位置が距離の半径外である場合
/// 位置情報使用許可が得られていない場合および位置情報がモックされている場合はfalseを返却します。
Future<bool> withinRangeAvailability(
    WidgetRef ref, WithinRangeData withinRangeData) async {
  final permission = ref.read(permissionProvider);
  if (!permission) return false;

  final currentLocation = await ref.read(currentLocationProvider.future);
  if (currentLocation == null) return false;

  if (currentLocation.isMocked) {
    // 位置情報がモックされている場合
    showErrorToast(DisplayedErrorMessage.locationError);
    return false;
  }

  final location = withinRangeData.location;
  final distance = Geolocator.distanceBetween(currentLocation.latitude,
      currentLocation.longitude, location.latitude, location.longitude);

  // 距離の半径(meter)
  final radius = withinRangeData.radius;

  // 距離の半径(meter)を超える場合は不可
  if (radius < distance) return false;

  return true;
}

Future<void> requestPermission(WidgetRef ref) async {
  LocationPermission locationPermission = await Geolocator.checkPermission();
  if (locationPermission == LocationPermission.denied) {
    try {
      locationPermission = await Geolocator.requestPermission();
    } on PermissionRequestInProgressException catch (e) {
      logger.warning(e);
    }
  }

  if (locationPermission == LocationPermission.whileInUse) {
    ref.read(permissionProvider.notifier).update((_) => true);
    ref.invalidate(currentLocationProvider);
  }
}

class LocationProvider {
  final StreamController<Position> _locationController =
      StreamController<Position>();

  Stream<Position> get locationStream => _locationController.stream;

  /// 現在の位置情報を取得します。
  Future<Position?> getCurrentLocation() async {
    final locationPermission = await Geolocator.checkPermission();
    if (locationPermission != LocationPermission.whileInUse) {
      return null;
    }

    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
      );
    } on LocationServiceDisabledException catch (e) {
      logger.warning(e);
      showErrorToast(DisplayedErrorMessage.currentLocationError);
      return null;
    } on TimeoutException catch (e) {
      logger.warning(e);
      showErrorToast(DisplayedErrorMessage.currentLocationError);
      return null;
    }
  }

  /// デバイスに保存されている最終の位置情報を取得します。
  Future<Position?> getLastKnownLocation() async {
    return await Geolocator.getLastKnownPosition();
  }

  /// 継続的に位置情報を取得します。
  /// 位置情報が100メートル以上変化すると、Streamにより新しい位置情報を取得します。
  Future<void> getContinuousLocation() async {
    Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100,
      ),
    ).listen((Position position) {
      _locationController.add(position);
    });
  }

  /// 位置情報へアクセスするための許可をユーザに求めます。
  Future<bool> checkPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      logger.severe('位置情報へのアクセスが拒否されました。チェックイン機能を利用できません。');
      return false;
    }

    LocationPermission locationPermission = await Geolocator.checkPermission();
    if (locationPermission == LocationPermission.denied) {
      try {
        // 再度パーミッションリクエスト
        locationPermission = await Geolocator.requestPermission();
      } on PermissionRequestInProgressException catch (e) {
        logger.warning(e);
      }

      if (locationPermission == LocationPermission.denied) {
        logger.severe('位置情報へのアクセスが拒否されました。チェックイン機能を利用できません。');
        return false;
      }
    }

    if (locationPermission == LocationPermission.deniedForever) {
      logger.severe('位置情報へのアクセスが拒否されました。チェックイン機能を利用できません。');
      return false;
    }

    return true;
  }
}

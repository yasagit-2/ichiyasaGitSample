import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';

final packageInfoProvider = Provider<PackageInfo>(
  (_) => throw UnimplementedError('アプリケーション起動時にmainで生成したインスタンスを使用'),
);

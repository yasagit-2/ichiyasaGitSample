// メニューボタン選択プロバイダ
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

// メニューボタンプロバイダ
final selectedMenuButtonProvider =
    StateProvider<MenuButtonSelection>((ref) => MenuButtonSelection.base);

/// メニューボタン
enum MenuButtonSelection {
  unselected,
  base,
  post,
  merchant,
}

// メニューボタン開閉プロバイダ
final openCloseDialProvider =
    Provider.autoDispose<ValueNotifier<bool>>((ref) => ValueNotifier(false));

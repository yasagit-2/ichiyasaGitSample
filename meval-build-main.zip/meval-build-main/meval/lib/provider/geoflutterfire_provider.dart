import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

// Geoflutterfireのインスタンスをて依拠するプロバイダ
final geoflutterfireProvider = Provider<GeoFlutterFire>(
  (_) => throw UnimplementedError('アプリケーション起動時にmainで生成したインスタンスを使用'),
);

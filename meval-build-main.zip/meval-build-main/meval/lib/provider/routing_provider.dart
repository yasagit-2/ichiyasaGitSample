import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../initial_screen.dart';
import '../model/data/admin_alert.dart';
import '../model/data/admin_questionnaire.dart';
import '../model/data/member_notification.dart';
import '../view/component/coupon_list_screen.dart';
import '../view/component/image_view.dart';
import '../view/content/content_root_screen.dart';
import '../view/content/home/notification/notification_content_screen.dart';
import '../view/content/home/notification/notification_list_screen.dart';
import '../view/content/my_page/about_app.dart';
import '../view/content/my_page/help_screen.dart';
import '../view/content/my_page/profile_settings_screen.dart';
import '../view/content/my_page/withdrawal_screen.dart';
import '../view/content/post/admin/admin_alert_screen.dart';
import '../view/content/post/admin/admin_questionnaire_screen.dart';
import '../view/content/post/comment/comment_list_screen.dart';
import '../view/content/post/post_confirm_screen.dart';
import '../view/content/post/post_display_screen.dart';
import '../view/content/record/tab/event/event_map_screen.dart';
import '../view/content/record/tab/event/qr_code_screen.dart';
import '../view/content/record/tab/event/stamp_rally_screen.dart';
import '../view/content/search/list_screen/base_list_screen.dart';
import '../view/content/search/list_screen/merchant_list_screen.dart';
import '../view/content/search/list_screen/post_list_screen.dart';
import '../view/content/spend/my_coupon_list_screen.dart';
import '../view/content/spend/point_history_list_screen.dart';
import '../view/initial/login/login_screen.dart';
import '../view/initial/login/robo_login_screen.dart';
import '../view/initial/register/register_screen.dart';
import '../view/initial/tos/privacy_policy_screen.dart';
import '../view/initial/tos/root_tos_screen.dart';
import '../view/initial/tos/tos_screen.dart';

// 宣言的ルーティングプロバイダ
final routingProvider = Provider(
  (ref) => GoRouter(
    initialLocation: InitialScreen.path,
    routes: [
      // Initial
      GoRoute(
        path: InitialScreen.path,
        name: InitialScreen.name,
        builder: (context, state) => const InitialScreen(),
      ),
      // ログイン
      GoRoute(
        path: LoginScreen.path,
        name: LoginScreen.name,
        builder: (context, state) => const LoginScreen(),
      ),
      // roboテストログイン
      GoRoute(
        path: RoboLoginScreen.path,
        name: RoboLoginScreen.name,
        builder: (context, state) => const RoboLoginScreen(),
      ),
      // 利用規約ルート
      GoRoute(
        path: RootTosScreen.path,
        builder: (context, state) => const RootTosScreen(),
        routes: [
          // 利用規約
          GoRoute(
            path: TosScreen.path,
            name: TosScreen.registerName,
            builder: (context, state) => const TosScreen(),
          ),
          // プライバシーポリシー
          GoRoute(
            path: PrivacyPolicyScreen.path,
            name: PrivacyPolicyScreen.registerName,
            builder: (context, state) => const PrivacyPolicyScreen(),
          ),
          // 会員登録
          GoRoute(
            path: RegisterScreen.path,
            name: RegisterScreen.name,
            builder: (context, state) => const RegisterScreen(),
          ),
        ],
      ),
      // コンテンツルート
      GoRoute(
        path: ContentRootScreen.path,
        name: ContentRootScreen.name,
        builder: (context, state) => const ContentRootScreen(),
        routes: [
          // お知らせコンテンツ
          GoRoute(
            path: NotificationContentScreen.pathFromTop,
            name: NotificationContentScreen.nameFromTop,
            builder: (context, state) => NotificationContentScreen(
              notification: state.extra! as MemberNotification,
            ),
          ),
          // イベントマップ
          GoRoute(
            path: EventMapScreen.pathFromTop,
            name: EventMapScreen.nameFromTop,
            builder: (context, state) => EventMapScreen(
              eventId: state.extra! as String,
            ),
            routes: [
              // スタンプラリー
              GoRoute(
                path: StampRallyScreen.pathFromTop,
                name: StampRallyScreen.nameFromTop,
                builder: (context, state) => StampRallyScreen(
                  eventId: state.extra! as String,
                ),
              ),
              // QRコード
              GoRoute(
                path: QrCodeScreen.path,
                name: QrCodeScreen.name,
                builder: (context, state) => QrCodeScreen(
                  eventId: state.extra! as String,
                ),
                routes: [
                  // スタンプラリー
                  GoRoute(
                    path: StampRallyScreen.pathFromQrCode,
                    name: StampRallyScreen.nameFromQrCode,
                    builder: (context, state) => StampRallyScreen(
                      eventId: state.extra! as String,
                    ),
                  ),
                ],
              ),
            ],
          ),

          // [ホーム]お知らせ一覧
          GoRoute(
            path: NotificationListScreen.path,
            name: NotificationListScreen.name,
            builder: (context, state) => const NotificationListScreen(),
            routes: [
              // お知らせコンテンツ
              GoRoute(
                path: NotificationContentScreen.pathFromList,
                name: NotificationContentScreen.nameFromList,
                builder: (context, state) => NotificationContentScreen(
                  notification: state.extra! as MemberNotification,
                ),
              ),
            ],
          ),

          // [探索]拠点一覧
          GoRoute(
            path: BaseListScreen.path,
            name: BaseListScreen.name,
            builder: (context, state) => const BaseListScreen(),
          ),
          // [探索]投稿リスト（自分の投稿/行政の投稿）
          GoRoute(
            path: PostListScreen.path,
            name: PostListScreen.name,
            builder: (context, state) => const PostListScreen(),
          ),
          // [探索]加盟店一覧
          GoRoute(
            path: MerchantListScreen.path,
            name: MerchantListScreen.name,
            builder: (context, state) => const MerchantListScreen(),
          ),
          // [探索]投稿表示
          GoRoute(
            path: PostDisplayScreen.path,
            name: PostDisplayScreen.name,
            builder: (context, state) => const PostDisplayScreen(),
            routes: [
              // [探索]コメント一覧
              GoRoute(
                path: CommentListScreen.path,
                name: CommentListScreen.name,
                builder: (context, state) => const CommentListScreen(),
              ),
            ],
          ),
          // [探索]投稿確認
          GoRoute(
            path: PostConfirmScreen.path,
            name: PostConfirmScreen.name,
            builder: (context, state) => const PostConfirmScreen(),
          ),
          // [探索]画像表示
          GoRoute(
            path: ImageView.path,
            name: ImageView.name,
            builder: (context, state) => ImageView(
              imageProvider: state.extra! as ImageProvider,
            ),
          ),
          // [探索]行政投稿（注意）
          GoRoute(
            path: AdminAlertScreen.path,
            name: AdminAlertScreen.name,
            builder: (context, state) => AdminAlertScreen(
              adminAlert: state.extra! as AdminAlert,
            ),
          ),
          // [探索]行政投稿（アンケート）
          GoRoute(
            path: AdminQuestionnaireScreen.path,
            name: AdminQuestionnaireScreen.name,
            builder: (context, state) => AdminQuestionnaireScreen(
              adminQuestionnaire: state.extra! as AdminQuestionnaire,
            ),
          ),
          // [探索]クーポン一覧
          GoRoute(
            path: CouponListScreen.pathFromSearch,
            name: CouponListScreen.nameFromSearch,
            builder: (context, state) => CouponListScreen(
              merchantId: state.extra! as String,
            ),
          ),

          // [記録]イベントマップ
          GoRoute(
            path: EventMapScreen.pathFromRecord,
            name: EventMapScreen.nameFromRecord,
            builder: (context, state) => EventMapScreen(
              eventId: state.extra! as String,
            ),
            routes: [
              // [記録]スタンプラリー
              GoRoute(
                path: StampRallyScreen.pathFromRecord,
                name: StampRallyScreen.nameFromRecord,
                builder: (context, state) => StampRallyScreen(
                  eventId: state.extra! as String,
                ),
              ),
            ],
          ),

          // [つかう]ポイント履歴
          GoRoute(
            path: PointHistoryListScreen.path,
            name: PointHistoryListScreen.name,
            builder: (context, state) => const PointHistoryListScreen(),
          ),
          // [つかう]自分のクーポン
          GoRoute(
            path: MyCouponListScreen.path,
            name: MyCouponListScreen.name,
            builder: (context, state) => const MyCouponListScreen(),
            routes: [
              // [つかう]クーポン一覧
              GoRoute(
                path: CouponListScreen.pathFromSpend,
                name: CouponListScreen.nameFromSpend,
                builder: (context, state) => CouponListScreen(
                  merchantId: state.extra! as String,
                ),
              ),
            ],
          ),

          // [マイページ]プロフィール
          GoRoute(
            path: ProfileSettingsScreen.path,
            name: ProfileSettingsScreen.name,
            builder: (context, state) => const ProfileSettingsScreen(),
          ),
          // [マイページ]アプリについて
          GoRoute(
            path: AboutApp.path,
            name: AboutApp.name,
            builder: (context, state) => const AboutApp(),
            routes: [
              // [マイページ]利用規約
              GoRoute(
                path: TosScreen.path,
                name: TosScreen.contentName,
                builder: (context, state) => const TosScreen(),
              ),
              // [マイページ]プライバシーポリシー
              GoRoute(
                path: PrivacyPolicyScreen.path,
                name: PrivacyPolicyScreen.contentName,
                builder: (context, state) => const PrivacyPolicyScreen(),
              ),
            ],
          ),
          // [マイページ]ヘルプ
          GoRoute(
            path: HelpScreen.path,
            name: HelpScreen.name,
            builder: (context, state) => const HelpScreen(),
          ),
          // [マイページ]退会
          GoRoute(
            path: WithdrawalScreen.path,
            name: WithdrawalScreen.name,
            builder: (context, state) => const WithdrawalScreen(),
          ),
        ],
      ),
    ],
  ),
);

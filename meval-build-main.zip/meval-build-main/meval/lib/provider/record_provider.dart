import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/base.dart';
import '../model/data/check_in.dart';
import '../model/data/completed_base.dart';
import '../model/data/completed_title.dart';
import '../model/data/title.dart';
import '../model/repository/record_repository.dart';
import '../util/logger.dart';
import '../view_model/member_view_model.dart';

// 全称号ストリームプロバイダ
final allTitlesStreamProvider = StreamProvider.autoDispose<List<Title>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('allTitlesStreamProvider dispose.');
    });

    return ref.watch(recordRepositoryProvider).getStreamTitles();
  },
);

// 称号に紐づく拠点制覇情報ストリームプロバイダ
final completedBasesByTitleIdStreamProvider = StreamProvider.family
    .autoDispose<List<CompletedParentBase>, String>((ref, String titleId) {
  ref.onDispose(() {
    logger.fine('completedBasesByTitleIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(recordRepositoryProvider)
      .getCompletedBasesByTitleId(memberId, titleId);
});

// 称号に紐づく親拠点ストリームプロバイダ
final parentBasesByTitleIdStreamProvider =
    StreamProvider.family.autoDispose((ref, String titleId) {
  ref.onDispose(() {
    logger.fine('parentBasesByTitleIdStreamProvider dispose.');
  });

  return ref.watch(recordRepositoryProvider).getParentBasesByTitleId(titleId);
});

// 拠点IDに紐づく拠点ストリームプロバイダ
final baseByIdStreamProvider =
    StreamProvider.family.autoDispose<Base?, String>((ref, String baseId) {
  ref.onDispose(() {
    logger.fine('baseByIdStreamProvider dispose.');
  });

  return ref.watch(recordRepositoryProvider).getBaseById(baseId);
});

// 親拠点IDに紐づくサブ拠点ストリームプロバイダ
final subBasesByParentBaseIdStreamProvider = StreamProvider.family
    .autoDispose<List<Base>, String>((ref, String parentBaseId) {
  ref.onDispose(() {
    logger.fine('subBasesByParentBaseIdStreamProvider dispose.');
  });

  return ref
      .watch(recordRepositoryProvider)
      .getSubBasesByParentBaseId(parentBaseId);
});

// チェックインストリームプロバイダ（ログイン中の会員のチェックイン情報を監視するプロバイダ）
final checkedInStreamProvider =
    StreamProvider.autoDispose<List<CheckIn>>((ref) {
  ref.onDispose(() {
    logger.fine('checkedInStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(recordRepositoryProvider).getCheckInByMemberId(memberId);
});

// 称号IDに紐づく称号獲得情報ストリームプロバイダ
final completedTitleByIdStreamProvider = StreamProvider.family
    .autoDispose<TitleHistory?, String>((ref, String titleId) {
  ref.onDispose(() {
    logger.fine('completedTitleByIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(recordRepositoryProvider)
      .getCompletedTitleById(memberId, titleId);
});

/// 拠点制覇情報、および称号獲得情報を保存します。
/// ログイン中の会員が存在しない場合、このメソッドは使用できません。
Future<void> saveCompletedBases(
    WidgetRef ref, Title title, Base parent, List<Base>? subBases) async {
  // 利用者が表示している記録画面の状況にて、その瞬間の情報を記録します。
  // この処理をCloud Functionsにて実行することも検討しましたが、
  // 利用者のCOMPLETEタップ後、かつ拠点制覇情報、および称号獲得情報が作り出される間に
  // 拠点/サブ拠点追加といった他のトランザクションが入り込んでしまうと、
  // 利用者から見た「拠点制覇/称号獲得した」という状況と矛盾してしまうことになるため、
  // 拠点制覇情報、および称号獲得情報はフロントエンドから作り込むようにしています。

  // ログイン中会員のID
  final memberId = ref.read(memberIdProvider);
  if (memberId == null) {
    throw UnsupportedError('この操作は許可されていません。');
  }

  return await ref
      .read(recordRepositoryProvider)
      .saveCompletedBases(memberId, title, parent, subBases);
}

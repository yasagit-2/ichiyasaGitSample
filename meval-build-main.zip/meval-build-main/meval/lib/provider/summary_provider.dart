import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/repository/home_repository.dart';
import '../util/logger.dart';
import '../view_model/member_view_model.dart';

// チェックイン済み親拠点総数ストリームプロバイダ
final totalCheckedInParentBasesStreamProvider =
    StreamProvider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('totalCheckedInParentBasesStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(homeRepositoryProvider)
      .getTotalCheckedInParentBases(memberId);
});

// チェックイン済みサブ拠点総数ストリームプロバイダ
final totalCheckedInSubBasesStreamProvider =
    StreamProvider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('totalCheckedInSubBasesStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(homeRepositoryProvider).getTotalCheckedInSubBases(memberId);
});

// 獲得済み称号総数ストリームプロバイダ
final totalCompletedTitlesStreamProvider =
    StreamProvider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('totalCompletedTitlesStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(homeRepositoryProvider).getTotalCompletedTitles(memberId);
});

// 会員数ストリームプロバイダ
final totalMemberStreamProvider = StreamProvider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('totalMemberStreamProvider dispose.');
  });

  return ref.watch(homeRepositoryProvider).getTotalMember();
});

// ランキングストリームプロバイダ
final rankStreamProvider = StreamProvider.autoDispose((ref) {
  ref.onDispose(() {
    logger.fine('rankStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(homeRepositoryProvider).getRank(memberId);
});

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'search_map_provider.dart';

/// GoogleMapControllerプロバイダ
final googleMapControllerProvider =
    StateProvider<GoogleMapController?>((ref) => null);

/// マップの中心位置を[position]へ移動します。
Future<void> moveCamera(WidgetRef ref, LatLng position) async {
  final googleMapController = ref.read(googleMapControllerProvider);
  if (googleMapController == null) {
    return;
  }

  ref.read(centerLocationProvider.notifier).update((_) => position);

  await googleMapController.moveCamera(
    CameraUpdate.newCameraPosition(
      CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: await googleMapController.getZoomLevel(),
      ),
    ),
  );
}

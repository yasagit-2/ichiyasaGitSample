import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/member_notification.dart';
import '../model/repository/home_repository.dart';
import '../util/logger.dart';

// お知らせリストストリームプロバイダ
final notificationsStreamProvider =
    StreamProvider.autoDispose<List<MemberNotification>>((ref) {
  ref.onDispose(() {
    logger.fine('notificationStreamProvider dispose.');
  });

  return ref.watch(homeRepositoryProvider).getMemberNotifications();
});

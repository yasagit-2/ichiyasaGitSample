import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

part 'within_range_data.freezed.dart';

@freezed
class WithinRangeData with _$WithinRangeData {
  const factory WithinRangeData({
    // 位置情報
    required LatLng location,
    // 距離の半径(meter)
    required double radius,
  }) = _WithinRangeData;
}

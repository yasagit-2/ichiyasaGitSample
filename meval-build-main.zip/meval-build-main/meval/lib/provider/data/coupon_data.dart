import 'package:freezed_annotation/freezed_annotation.dart';

part 'coupon_data.freezed.dart';

@freezed
class CouponData with _$CouponData {
  const factory CouponData({
    // 加盟店ID
    required String merchantId,
    // クーポンID
    required String couponId,
  }) = _CouponData;
}

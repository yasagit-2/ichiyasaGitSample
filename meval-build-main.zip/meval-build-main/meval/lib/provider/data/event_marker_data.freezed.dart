// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'event_marker_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$EventMarkerData {
  NavigatorState get navigator => throw _privateConstructorUsedError; // イベント
  Event get event => throw _privateConstructorUsedError; // イベントスポットリスト
  List<EventSpot> get eventSpots => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $EventMarkerDataCopyWith<EventMarkerData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventMarkerDataCopyWith<$Res> {
  factory $EventMarkerDataCopyWith(
          EventMarkerData value, $Res Function(EventMarkerData) then) =
      _$EventMarkerDataCopyWithImpl<$Res, EventMarkerData>;
  @useResult
  $Res call(
      {NavigatorState navigator, Event event, List<EventSpot> eventSpots});

  $EventCopyWith<$Res> get event;
}

/// @nodoc
class _$EventMarkerDataCopyWithImpl<$Res, $Val extends EventMarkerData>
    implements $EventMarkerDataCopyWith<$Res> {
  _$EventMarkerDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? navigator = null,
    Object? event = null,
    Object? eventSpots = null,
  }) {
    return _then(_value.copyWith(
      navigator: null == navigator
          ? _value.navigator
          : navigator // ignore: cast_nullable_to_non_nullable
              as NavigatorState,
      event: null == event
          ? _value.event
          : event // ignore: cast_nullable_to_non_nullable
              as Event,
      eventSpots: null == eventSpots
          ? _value.eventSpots
          : eventSpots // ignore: cast_nullable_to_non_nullable
              as List<EventSpot>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $EventCopyWith<$Res> get event {
    return $EventCopyWith<$Res>(_value.event, (value) {
      return _then(_value.copyWith(event: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_EventMarkerDataCopyWith<$Res>
    implements $EventMarkerDataCopyWith<$Res> {
  factory _$$_EventMarkerDataCopyWith(
          _$_EventMarkerData value, $Res Function(_$_EventMarkerData) then) =
      __$$_EventMarkerDataCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {NavigatorState navigator, Event event, List<EventSpot> eventSpots});

  @override
  $EventCopyWith<$Res> get event;
}

/// @nodoc
class __$$_EventMarkerDataCopyWithImpl<$Res>
    extends _$EventMarkerDataCopyWithImpl<$Res, _$_EventMarkerData>
    implements _$$_EventMarkerDataCopyWith<$Res> {
  __$$_EventMarkerDataCopyWithImpl(
      _$_EventMarkerData _value, $Res Function(_$_EventMarkerData) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? navigator = null,
    Object? event = null,
    Object? eventSpots = null,
  }) {
    return _then(_$_EventMarkerData(
      navigator: null == navigator
          ? _value.navigator
          : navigator // ignore: cast_nullable_to_non_nullable
              as NavigatorState,
      event: null == event
          ? _value.event
          : event // ignore: cast_nullable_to_non_nullable
              as Event,
      eventSpots: null == eventSpots
          ? _value._eventSpots
          : eventSpots // ignore: cast_nullable_to_non_nullable
              as List<EventSpot>,
    ));
  }
}

/// @nodoc

class _$_EventMarkerData implements _EventMarkerData {
  const _$_EventMarkerData(
      {required this.navigator,
      required this.event,
      required final List<EventSpot> eventSpots})
      : _eventSpots = eventSpots;

  @override
  final NavigatorState navigator;
// イベント
  @override
  final Event event;
// イベントスポットリスト
  final List<EventSpot> _eventSpots;
// イベントスポットリスト
  @override
  List<EventSpot> get eventSpots {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_eventSpots);
  }

  @override
  String toString() {
    return 'EventMarkerData(navigator: $navigator, event: $event, eventSpots: $eventSpots)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EventMarkerData &&
            (identical(other.navigator, navigator) ||
                other.navigator == navigator) &&
            (identical(other.event, event) || other.event == event) &&
            const DeepCollectionEquality()
                .equals(other._eventSpots, _eventSpots));
  }

  @override
  int get hashCode => Object.hash(runtimeType, navigator, event,
      const DeepCollectionEquality().hash(_eventSpots));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventMarkerDataCopyWith<_$_EventMarkerData> get copyWith =>
      __$$_EventMarkerDataCopyWithImpl<_$_EventMarkerData>(this, _$identity);
}

abstract class _EventMarkerData implements EventMarkerData {
  const factory _EventMarkerData(
      {required final NavigatorState navigator,
      required final Event event,
      required final List<EventSpot> eventSpots}) = _$_EventMarkerData;

  @override
  NavigatorState get navigator;
  @override // イベント
  Event get event;
  @override // イベントスポットリスト
  List<EventSpot> get eventSpots;
  @override
  @JsonKey(ignore: true)
  _$$_EventMarkerDataCopyWith<_$_EventMarkerData> get copyWith =>
      throw _privateConstructorUsedError;
}

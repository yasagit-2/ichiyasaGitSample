import 'package:freezed_annotation/freezed_annotation.dart';

part 'event_spot_data.freezed.dart';

@freezed
class EventSpotData with _$EventSpotData {
  const factory EventSpotData({
    // イベントID
    required String eventId,
    // イベントスポットID
    required String eventSpotId,
  }) = _EventSpotData;
}

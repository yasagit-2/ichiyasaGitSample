import 'package:freezed_annotation/freezed_annotation.dart';

part 'map_icon_data.freezed.dart';

@freezed
class MapIconData with _$MapIconData {
  const factory MapIconData({
    // アイコンのURL
    required String url,
    // アイコンのローカルパス
    required String localIconPath,
  }) = _MapIconData;
}

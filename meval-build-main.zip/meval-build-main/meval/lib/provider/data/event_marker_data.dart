import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../../../../model/data/event.dart';

part 'event_marker_data.freezed.dart';

@freezed
class EventMarkerData with _$EventMarkerData {
  const factory EventMarkerData({
    required NavigatorState navigator,
    // イベント
    required Event event,
    // イベントスポットリスト
    required List<EventSpot> eventSpots,
  }) = _EventMarkerData;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'event_spot_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$EventSpotData {
// イベントID
  String get eventId => throw _privateConstructorUsedError; // イベントスポットID
  String get eventSpotId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $EventSpotDataCopyWith<EventSpotData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EventSpotDataCopyWith<$Res> {
  factory $EventSpotDataCopyWith(
          EventSpotData value, $Res Function(EventSpotData) then) =
      _$EventSpotDataCopyWithImpl<$Res, EventSpotData>;
  @useResult
  $Res call({String eventId, String eventSpotId});
}

/// @nodoc
class _$EventSpotDataCopyWithImpl<$Res, $Val extends EventSpotData>
    implements $EventSpotDataCopyWith<$Res> {
  _$EventSpotDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? eventId = null,
    Object? eventSpotId = null,
  }) {
    return _then(_value.copyWith(
      eventId: null == eventId
          ? _value.eventId
          : eventId // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotId: null == eventSpotId
          ? _value.eventSpotId
          : eventSpotId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_EventSpotDataCopyWith<$Res>
    implements $EventSpotDataCopyWith<$Res> {
  factory _$$_EventSpotDataCopyWith(
          _$_EventSpotData value, $Res Function(_$_EventSpotData) then) =
      __$$_EventSpotDataCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String eventId, String eventSpotId});
}

/// @nodoc
class __$$_EventSpotDataCopyWithImpl<$Res>
    extends _$EventSpotDataCopyWithImpl<$Res, _$_EventSpotData>
    implements _$$_EventSpotDataCopyWith<$Res> {
  __$$_EventSpotDataCopyWithImpl(
      _$_EventSpotData _value, $Res Function(_$_EventSpotData) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? eventId = null,
    Object? eventSpotId = null,
  }) {
    return _then(_$_EventSpotData(
      eventId: null == eventId
          ? _value.eventId
          : eventId // ignore: cast_nullable_to_non_nullable
              as String,
      eventSpotId: null == eventSpotId
          ? _value.eventSpotId
          : eventSpotId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_EventSpotData implements _EventSpotData {
  const _$_EventSpotData({required this.eventId, required this.eventSpotId});

// イベントID
  @override
  final String eventId;
// イベントスポットID
  @override
  final String eventSpotId;

  @override
  String toString() {
    return 'EventSpotData(eventId: $eventId, eventSpotId: $eventSpotId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EventSpotData &&
            (identical(other.eventId, eventId) || other.eventId == eventId) &&
            (identical(other.eventSpotId, eventSpotId) ||
                other.eventSpotId == eventSpotId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, eventId, eventSpotId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EventSpotDataCopyWith<_$_EventSpotData> get copyWith =>
      __$$_EventSpotDataCopyWithImpl<_$_EventSpotData>(this, _$identity);
}

abstract class _EventSpotData implements EventSpotData {
  const factory _EventSpotData(
      {required final String eventId,
      required final String eventSpotId}) = _$_EventSpotData;

  @override // イベントID
  String get eventId;
  @override // イベントスポットID
  String get eventSpotId;
  @override
  @JsonKey(ignore: true)
  _$$_EventSpotDataCopyWith<_$_EventSpotData> get copyWith =>
      throw _privateConstructorUsedError;
}

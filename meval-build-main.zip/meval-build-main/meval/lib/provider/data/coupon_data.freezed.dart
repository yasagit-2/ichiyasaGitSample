// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'coupon_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CouponData {
// 加盟店ID
  String get merchantId => throw _privateConstructorUsedError; // クーポンID
  String get couponId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CouponDataCopyWith<CouponData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CouponDataCopyWith<$Res> {
  factory $CouponDataCopyWith(
          CouponData value, $Res Function(CouponData) then) =
      _$CouponDataCopyWithImpl<$Res, CouponData>;
  @useResult
  $Res call({String merchantId, String couponId});
}

/// @nodoc
class _$CouponDataCopyWithImpl<$Res, $Val extends CouponData>
    implements $CouponDataCopyWith<$Res> {
  _$CouponDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantId = null,
    Object? couponId = null,
  }) {
    return _then(_value.copyWith(
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      couponId: null == couponId
          ? _value.couponId
          : couponId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CouponDataCopyWith<$Res>
    implements $CouponDataCopyWith<$Res> {
  factory _$$_CouponDataCopyWith(
          _$_CouponData value, $Res Function(_$_CouponData) then) =
      __$$_CouponDataCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String merchantId, String couponId});
}

/// @nodoc
class __$$_CouponDataCopyWithImpl<$Res>
    extends _$CouponDataCopyWithImpl<$Res, _$_CouponData>
    implements _$$_CouponDataCopyWith<$Res> {
  __$$_CouponDataCopyWithImpl(
      _$_CouponData _value, $Res Function(_$_CouponData) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantId = null,
    Object? couponId = null,
  }) {
    return _then(_$_CouponData(
      merchantId: null == merchantId
          ? _value.merchantId
          : merchantId // ignore: cast_nullable_to_non_nullable
              as String,
      couponId: null == couponId
          ? _value.couponId
          : couponId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_CouponData implements _CouponData {
  const _$_CouponData({required this.merchantId, required this.couponId});

// 加盟店ID
  @override
  final String merchantId;
// クーポンID
  @override
  final String couponId;

  @override
  String toString() {
    return 'CouponData(merchantId: $merchantId, couponId: $couponId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CouponData &&
            (identical(other.merchantId, merchantId) ||
                other.merchantId == merchantId) &&
            (identical(other.couponId, couponId) ||
                other.couponId == couponId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, merchantId, couponId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CouponDataCopyWith<_$_CouponData> get copyWith =>
      __$$_CouponDataCopyWithImpl<_$_CouponData>(this, _$identity);
}

abstract class _CouponData implements CouponData {
  const factory _CouponData(
      {required final String merchantId,
      required final String couponId}) = _$_CouponData;

  @override // 加盟店ID
  String get merchantId;
  @override // クーポンID
  String get couponId;
  @override
  @JsonKey(ignore: true)
  _$$_CouponDataCopyWith<_$_CouponData> get copyWith =>
      throw _privateConstructorUsedError;
}

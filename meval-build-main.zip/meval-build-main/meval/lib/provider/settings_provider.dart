import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../const/constant.dart';
import '../model/data/map_icon.dart';
import '../model/data/setting.dart';
import '../util/image_processing.dart';
import '../util/logger.dart';

// アプリケーション設定プロバイダ
final settingsStateProvider =
    StateProvider.autoDispose<Setting?>((ref) => null);

// 投稿アイコン設定プロバイダ
final postIconsStateProvider =
    StateProvider.autoDispose<List<PostIcon>?>((ref) => null);

// マップアイコンプロバイダ
final mapIconProvider = FutureProvider.autoDispose<MapIcon>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('mapIconProvider dispose.');
    });

    // settingsのロードを待機
    await ref.watch(settingsStreamProvider.future);
    // postIconsのロードを待機
    await ref.watch(postIconsStreamProvider.future);

    final mapIcon = MapIcon(
      baseIcon: await ref.watch(_baseIconProvider.future),
      baseCheckedInIcon: await ref.watch(_baseCheckedInIconProvider.future),
      subBaseIcon: await ref.watch(_subBaseIconProvider.future),
      merchantIcon: await ref.watch(_merchantIconProvider.future),
      merchantTweetIcon: await ref.watch(_merchantTweetIconProvider.future),
      postIcon: await ref.watch(_postIconProvider.future),
      adminAlertIcon: await ref.watch(_adminAlertIconProvider.future),
      adminQuestionnaireIcon:
          await ref.watch(_adminQuestionnaireIconProvider.future),
      mapPostIcons: await ref.watch(_unitOfLikePostIconProvider.future),
    );

    return mapIcon;
  },
);

// チェックイン可能距離プロバイダ
final checkInRadiusProvider = Provider.autoDispose<double>(
  (ref) {
    ref.onDispose(() {
      logger.fine('checkInRadiusProvider dispose.');
    });

    final setting = ref.watch(settingsStateProvider);
    final checkInRadius =
        setting == null ? MapConst.checkInRadius : setting.checkInRadius;

    return checkInRadius;
  },
);

// 拠点/投稿/加盟店収集半径プロバイダ
final collectionRadiusProvider = Provider.autoDispose<double>(
  (ref) {
    ref.onDispose(() {
      logger.fine('collectionRadiusProvider dispose.');
    });

    final setting = ref.watch(settingsStateProvider);
    final collectionRadius =
        setting == null ? MapConst.collectionRadius : setting.collectionRadius;

    return collectionRadius;
  },
);

// 週間規定歩数プロバイダ
final targetStepPerWeekProvider = Provider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('targetStepPerWeekProvider dispose.');
  });

  final setting = ref.watch(settingsStateProvider);
  final targetStepPerWeek = setting == null
      ? Const.defaultPrescribedSteps
      : setting.targetStepPerWeek;

  return targetStepPerWeek;
});

// 週間規定歩数達成ポイントプロバイダ
final stepAchievedPointProvider = Provider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('stepAchievedPointProvider dispose.');
  });

  final setting = ref.watch(settingsStateProvider);
  final stepAchievedPoint = setting == null ? 0 : setting.stepAchievedPoint;

  return stepAchievedPoint;
});

// アプリケーション設定ストリームプロバイダ
final settingsStreamProvider = StreamProvider.autoDispose<Setting?>(
  (ref) {
    ref.onDispose(() {
      logger.fine('settingsStreamProvider dispose.');
    });

    return settingRef(id: settingDocumentId)
        .snapshots()
        .map((settingDocumentSnapshot) => settingDocumentSnapshot.data);
  },
);

// 投稿アイコン設定ストリームプロバイダ
final postIconsStreamProvider = StreamProvider.autoDispose<List<PostIcon>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('postIconsStreamProvider dispose.');
    });

    return settingRef(id: settingDocumentId).postIcons.snapshots().map(
        (postIconQuerySnapshot) => postIconQuerySnapshot.docs
            .map((postIconQueryDocSnapshot) => postIconQueryDocSnapshot.data)
            .toList());
  },
);

// 拠点アイコンプロバイダ
final _baseIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_baseIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.baseIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.base, height: 150, width: 150);

    return icon;
  },
);

// チェックイン済み拠点アイコンプロバイダ
final _baseCheckedInIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_baseCheckedInIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.baseCheckedInIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.baseCheckedIn, height: 150, width: 150);

    return icon;
  },
);

// サブ拠点アイコンプロバイダ
final _subBaseIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_subBaseIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.subBaseIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.subBase,
        height: MapImage.iconHeight,
        width: MapImage.iconWidth);

    return icon;
  },
);

// 加盟店アイコンプロバイダ
final _merchantIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_merchantIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.merchantIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.merchant, height: 150, width: 150);

    return icon;
  },
);

// 加盟店つぶやきアイコンプロバイダ
final _merchantTweetIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_merchantTweetIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.merchantTweetIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.merchantTweet, height: 150, width: 150);

    return icon;
  },
);

// 投稿アイコンプロバイダ
final _postIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_postIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.postIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.post, height: 150, width: 150);

    return icon;
  },
);

// いいね数単位の投稿アイコンプロバイダ
final _unitOfLikePostIconProvider =
    FutureProvider.autoDispose<List<MapPostIcon>>((ref) async {
  ref.onDispose(() {
    logger.fine('_unitOfLikePostIconProvider dispose.');
  });

  final postIcons = ref.watch(postIconsStateProvider);

  final mapPostIcons = <MapPostIcon>[];
  if (postIcons != null) {
    for (final postIcon in postIcons) {
      BitmapDescriptor? icon;
      icon = await createBitmapDescriptorFromNetwork(
          url: postIcon.unitOfLikePostIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);

      // ネットワーク画像からアイコン生成できない場合、投稿アイコンプロバイダを利用
      final postIconBitmapDescriptor =
          await ref.watch(_postIconProvider.future);
      icon ??= postIconBitmapDescriptor;

      mapPostIcons.add(
        MapPostIcon(unitOfLikePostIcon: icon, likeCount: postIcon.likeCount),
      );
    }
  }

  // いいね数で昇順ソート
  mapPostIcons.sort((a, b) => a.likeCount.compareTo(b.likeCount));

  return mapPostIcons;
});

// 行政投稿アラートアイコンプロバイダ
final _adminAlertIconProvider = FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_adminAlertIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.adminAlertIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.adminAlert,
        height: MapImage.iconHeight,
        width: MapImage.iconWidth);

    return icon;
  },
);

// 行政投稿アンケートアイコンプロバイダ
final _adminQuestionnaireIconProvider =
    FutureProvider.autoDispose<BitmapDescriptor>(
  (ref) async {
    ref.onDispose(() {
      logger.fine('_adminQuestionnaireIconProvider dispose.');
    });

    BitmapDescriptor? icon;
    final setting = ref.watch(settingsStateProvider);
    if (setting != null) {
      icon = await createBitmapDescriptorFromNetwork(
          url: setting.adminQuestionnaireIconUrl,
          height: MapImage.iconHeight,
          width: MapImage.iconWidth);
    }

    // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
    icon ??= await createBitmapDescriptorFromLocal(
        path: MapImage.adminQuestionnaire, height: 100, width: 100);

    return icon;
  },
);

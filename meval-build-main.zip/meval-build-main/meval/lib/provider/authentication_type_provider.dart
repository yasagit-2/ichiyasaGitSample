import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../util/logger.dart';
import '../view/component/phone_field.dart';
import '../view/initial/login/login_screen.dart';
import '../view_model/login_view_model.dart';
import '../view_model/member_view_model.dart';
import 'menu_button_provider.dart';
import 'screen_type_provider.dart';

// 認証タイププロバイダ
final authenticationTypeProvider =
    StateProvider<AuthenticationType>((ref) => AuthenticationType.sms);

enum AuthenticationType {
  sms,
  google,
  apple,
  facebook,
  twitter,
}

/// プロバイダをリフレッシュします。
/// ログアウト時に呼び出すことを想定します。
void refreshStateForLogout(WidgetRef ref) {
  // 画面タイププロバイダをリフレッシュ
  ref.invalidate(screenTypeProvider);
  // メニューボタンプロバイダをリフレッシュ
  ref.invalidate(selectedMenuButtonProvider);
  // 記録画面のタブタイププロバイダをリフレッシュ
  ref.invalidate(recordTabTypeProvider);

  // 電話番号プロバイダをリフレッシュ
  ref.invalidate(phoneNumberProvider);
  // 電話番号バリデーション成否プロバイダをリフレッシュ
  ref.invalidate(phoneNumberValidProvider);

  // MemberViewModelプロバイダをリフレッシュ
  ref.invalidate(memberViewModelProvider);
}

/// 認証済みのカレントユーザをリロードします。
void currentUserReloadForBuild(BuildContext context, WidgetRef ref) {
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    await _currentUserReload(context, ref);
  });
}

/// 認証済みのカレントユーザをリロードします。
Future<void> _currentUserReload(BuildContext context, WidgetRef ref) async {
  try {
    await ref.watch(loginViewModelProvider.notifier).currentUserReload();
  } on FirebaseAuthException catch (e) {
    logger.severe(e);

    if (e.code == 'user-not-found' || e.code == 'user-disabled') {
      // 1. Authenticationにユーザが存在しない
      //    Firebase Authenticationのユーザが削除されるレアケースの考慮（不具合課題検討票 No.40 参照）

      // 2. Authenticationのユーザが無効化されている
      //    Web管理画面からユーザを無効化した場合の考慮

      await _goToLoginScreen(context, ref);
    }

    rethrow;
  }
}

/// ログアウトしログインページへ遷移します。
Future<void> _goToLoginScreen(BuildContext context, WidgetRef ref) async {
  // ログアウトしログインページへ
  refreshStateForLogout(ref);
  await ref.watch(loginViewModelProvider.notifier).logout();
  context.go(LoginScreen.path);
}

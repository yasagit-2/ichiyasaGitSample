import 'dart:collection';
import 'dart:io';

import 'package:health/health.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/kt.dart';
import 'package:permission_handler/permission_handler.dart';

import '../const/constant.dart';
import '../model/data/completed_walk.dart';
import '../model/repository/record_repository.dart';
import '../util/logger.dart';
import '../view_model/member_view_model.dart';

// 歩数プロバイダ（本日のステップ数を返却するプロバイダ）
// 歩数が取得できない場合、nullを返却します。
final stepsOfTodayProvider = FutureProvider.autoDispose<int?>((ref) async {
  ref.onDispose(() {
    logger.fine('stepsOfTodayProvider dispose.');
  });

  const types = [HealthDataType.STEPS];
  const permissions = [HealthDataAccess.READ];

  final healthFactory = HealthFactory();

  // https://pub.dev/documentation/health/latest/health/HealthFactory/requestAuthorization.html
  // Caveat:
  //   As Apple HealthKit will not disclose if READ access has been granted for a data type
  //   due to privacy concern, this method will return true if the window asking for
  //   permission was showed to the user without errors if it is called on iOS with a READ
  //   or READ_WRITE access.
  final isRequestAuthorization =
      await healthFactory.requestAuthorization(types, permissions: permissions);

  if (Platform.isAndroid) {
    if (isRequestAuthorization) {
      final permissionStatus = await Permission.activityRecognition.request();
      logger.fine('permissionStatus=$permissionStatus');

      final isGranted =
          await Permission.activityRecognition.request().isGranted;
      if (!isGranted) {
        return null;
      }
    }
  }

  final now = DateTime.now();
  final startTime = DateTime(now.year, now.month, now.day);
  final endTime = DateTime(now.year, now.month, now.day, 23, 59, 59, 999, 999);

  int? steps = await healthFactory.getTotalStepsInInterval(startTime, endTime);

  return steps;
});

// 歩数プロバイダ（インターバル指定）
// 指定されたインターバル区間の中で1日単位の歩数を取得します。
final stepsInIntervalProvider = FutureProvider.family
    .autoDispose<KtLinkedMap<int, StepData>?, StepInterval>(
        (ref, StepInterval stepInterval) async {
  ref.onDispose(() {
    logger.fine('stepsInIntervalProvider dispose.');
  });

  final healthFactory = HealthFactory();

  final steps = LinkedHashMap<int, StepData>(
    equals: isSameDayFromMillisSinceEpoch,
    hashCode: getHashCode,
  );
  for (int start = stepInterval.startMillis;
      start <= stepInterval.endMillis;
      start += Const.millisPerDay) {
    final end = start + Const.millisPerDay - 1;

    final startDateTime = DateTime.fromMillisecondsSinceEpoch(start);
    final endDateTime = DateTime.fromMillisecondsSinceEpoch(end);
    int? intervalSteps =
        await healthFactory.getTotalStepsInInterval(startDateTime, endDateTime);

    // key:歩数の当該日、value:歩数データ
    steps[startDateTime.millisecondsSinceEpoch] =
        StepData(steps: intervalSteps);
  }

  return KtLinkedMap.from(steps);
});

// 歩数プロバイダ（key:day（UNIXエポックからの積算ミリ秒）、value:歩数データ）
final stepsProvider = StateProvider.autoDispose<KtLinkedMap<int, StepData>>(
    (ref) => KtLinkedMap.from({}));

// ウォーク達成履歴ストリームプロバイダ（指定された週番号（YYYYWww）のウォーク達成履歴を監視するプロバイダ）
final walkHistoryStreamProvider =
    StreamProvider.family.autoDispose<WalkHistory?, String>((ref, String id) {
  ref.onDispose(() {
    logger.fine('walkHistoryStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(recordRepositoryProvider).getWalkHistory(memberId, id);
});

// 選択中日付プロバイダ
final selectedDayProvider =
    StateProvider.autoDispose<DateTime>((ref) => DateTime.now());

/// [millisecondsSinceEpoch]からハッシュ値を算出します。
int getHashCode(int millisecondsSinceEpoch) {
  final key = DateTime.fromMillisecondsSinceEpoch(millisecondsSinceEpoch);
  return key.day * 1000000 + key.month * 10000 + key.year;
}

/// [a], [b]が同一日であるか否かを判定します。true:同一日
bool isSameDayFromMillisSinceEpoch(int? a, int? b) {
  if (a == null || b == null) {
    return false;
  }

  final dateTimeA = DateTime.fromMillisecondsSinceEpoch(a);
  final dateTimeB = DateTime.fromMillisecondsSinceEpoch(b);

  return dateTimeA.year == dateTimeB.year &&
      dateTimeA.month == dateTimeB.month &&
      dateTimeA.day == dateTimeB.day;
}

/// [referenceDate]を基準日として、1ヶ月前から現在日までの歩数を取得します。
/// [referenceDate]==nullの場合、選択日[selectedDayProvider]を基準日として利用します。
Future<void> getSteps(
    {required WidgetRef ref,
    required DateTime now,
    DateTime? referenceDate}) async {
  referenceDate ??= ref.watch(selectedDayProvider)!;

  // 歩数取得開始日時（[focused]を基準とした先月初）
  final startTimeToGetSteps =
      DateTime(referenceDate.year, referenceDate.month - 1);
  // 歩数取得終了日時（[focused]を基準とした翌月末）
  final endTimeToGetSteps =
      DateTime(referenceDate.year, referenceDate.month + 2)
          .add(const Duration(days: -1));

  if (startTimeToGetSteps.compareTo(now) > 0) {
    // 歩数取得開始日時が現在日時を超える場合、歩数は存在しないため歩数取得を実行しない
    return;
  }

  // 歩数取得終了日時（[focused]を基準とした翌月末）が現在日時を超える場合、
  // 現在日以降の歩数は存在しないことから、歩数取得の範囲を本日までとする
  final lastTimeToGetSteps = now.compareTo(endTimeToGetSteps) < 0
      ? DateTime(now.year, now.month, now.day, 23, 59, 59, 999, 999)
      : DateTime(endTimeToGetSteps.year, endTimeToGetSteps.month,
          endTimeToGetSteps.day, 23, 59, 59, 999, 999);

  ProviderContainer().listen(
    stepsInIntervalProvider(StepInterval(
        startMillis: startTimeToGetSteps.millisecondsSinceEpoch,
        endMillis: lastTimeToGetSteps.millisecondsSinceEpoch)),
    (previous, next) {
      if (next is AsyncData) {
        if (next.value is KtLinkedMap<int, StepData>) {
          final steps = next.value as KtLinkedMap<int, StepData>;
          // 状態を更新
          ref.watch(stepsProvider.notifier).update((_) => steps);
        }
      }
    },
  );
}

/// ウォーク達成情報を保存します。
Future<void> saveCompletedWalks(
    WidgetRef ref, int stepsOfWeek, int stepAchievedPoint, DateTime now) async {
  // ログイン中会員のID
  final memberId = ref.read(memberIdProvider);
  if (memberId == null) {
    throw UnsupportedError('この操作は許可されていません。');
  }

  return await ref
      .read(recordRepositoryProvider)
      .saveCompletedWalks(memberId, stepsOfWeek, stepAchievedPoint, now);
}

/// 歩数取得のための期間（開始/終了）をUNIXエポックからの積算ミリ秒で保持します。
class StepInterval {
  // 開始（ミリ秒）
  final int startMillis;

  // 終了（ミリ秒）
  final int endMillis;

  StepInterval({required this.startMillis, required this.endMillis});

  @override
  String toString() {
    return 'StepInterval{startMillis: $startMillis, endMillis: $endMillis}';
  }
}

/// 歩数を保持します。
class StepData {
  // 歩数
  final int? steps;

  StepData({this.steps});

  @override
  String toString() {
    return 'StepData{steps: $steps}';
  }
}

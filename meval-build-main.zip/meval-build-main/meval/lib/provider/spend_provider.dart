import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/completed_base.dart';
import '../model/data/completed_coupon.dart';
import '../model/data/completed_title.dart';
import '../model/data/event_participation_history.dart';
import '../model/data/merchant.dart';
import '../model/data/point.dart';
import '../model/repository/spend_repository.dart';
import '../util/logger.dart';
import '../view_model/member_view_model.dart';

// ポイントストリームプロバイダ
final pointStreamProvider = StreamProvider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('pointStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(spendRepositoryProvider).getPoint(memberId);
});

// ポイント獲得履歴ストリームプロバイダ
final pointHistoriesStreamProvider =
    StreamProvider.autoDispose<List<PointHistory>>((ref) {
  ref.onDispose(() {
    logger.fine('pointHistoriesStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(spendRepositoryProvider).getPointHistories(memberId);
});

// 拠点制覇情報プロバイダ
final completedBaseProvider = FutureProvider.family
    .autoDispose<CompletedParentBase?, String>((ref, String completedBaseId) {
  ref.onDispose(() {
    logger.fine('completedBaseProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return null;
  }

  return ref
      .watch(spendRepositoryProvider)
      .getCompletedBase(memberId, completedBaseId);
});

// 称号獲得情報プロバイダ
final completedTitleProvider = FutureProvider.family
    .autoDispose<TitleHistory?, String>((ref, String completedTitleId) {
  ref.onDispose(() {
    logger.fine('completedTitleProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return null;
  }

  return ref
      .watch(spendRepositoryProvider)
      .getCompletedTitle(memberId, completedTitleId);
});

// 達成イベントプロバイダ
final completedEventProvider = FutureProvider.family
    .autoDispose<ParticipatedEvent?, String>((ref, String completedEventId) {
  ref.onDispose(() {
    logger.fine('completedEventProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return null;
  }

  return ref
      .watch(spendRepositoryProvider)
      .getCompletedEvent(memberId, completedEventId);
});

// クーポン獲得/使用履歴ストリームプロバイダ
final couponHistoriesStreamProvider =
    StreamProvider.autoDispose<List<CouponHistory>>((ref) {
  ref.onDispose(() {
    logger.fine('couponHistoriesStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(spendRepositoryProvider).getCouponHistories(memberId);
});

// 加盟店IDリスト指定加盟店ストリームプロバイダ（パラメータで指定された加盟店IDに該当する加盟店を監視するプロバイダ）
final merchantsByIdsStreamProvider =
    StreamProvider.family.autoDispose((ref, List<String> merchantIds) {
  ref.onDispose(() {
    logger.fine('merchantsByIdsStreamProvider dispose.');
  });

  return ref.watch(spendRepositoryProvider).getMerchantsByIds(merchantIds);
});

// クーポン獲得/使用履歴に存在する加盟店リストプロバイダ
final merchantsWithCouponsFutureProvider = FutureProvider.family
    .autoDispose<List<Merchant>, DateTime>((ref, DateTime now) async {
  ref.onDispose(() {
    logger.fine('merchantsWithCouponsFutureProvider dispose.');
  });

  // クーポン獲得/使用履歴のリスト
  final couponHistories = await ref.watch(couponHistoriesStreamProvider.future);
  // 加盟店IDリスト
  final merchantIds = couponHistories
      // クーポンが有効期限内
      .where((couponHistory) => now.compareTo(couponHistory.dueDate) <= 0)
      .map((couponHistory) => couponHistory.merchantId)
      .toList();

  return await ref.watch(merchantsByIdsStreamProvider(merchantIds).future);
});

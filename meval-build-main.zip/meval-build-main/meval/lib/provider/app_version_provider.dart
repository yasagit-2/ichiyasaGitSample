import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:version/version.dart';

import '../const/message.dart';
import '../model/data/maintenance.dart';
import '../util/logger.dart';
import '../view/initial/login/login_screen.dart';
import '../view_model/login_view_model.dart';
import 'authentication_type_provider.dart';

// メンテナンスストリームプロバイダ
final maintenanceStreamProvider =
    StreamProvider.autoDispose<Maintenance?>((ref) {
  ref.onDispose(() {
    logger.fine('maintenanceStreamProvider dispose.');
  });

  return maintenanceRef(id: 'maintenance')
      .snapshots()
      .map((maintenanceDocSnap) => maintenanceDocSnap.data);
});

/// メンテナンス中か否かのチェックを行います。
/// メンテナンス中の場合、アプリケーションからは強制的にログアウトします。
Future<void> maintenanceCheck(
    BuildContext context, WidgetRef ref, Maintenance maintenance) async {
  // 認証状態確認
  final firebaseUser = await ref.watch(authStateChangesProvider.future);
  if (firebaseUser == null) {
    // ログアウト済みの場合はチェック不要
    return;
  }

  if (maintenance.isMaintenance) {
    // メンテナンス中
    await _showMaintenanceDialog(context, ref);
  }
}

/// アプリケーションのバージョンチェックを行います。
/// バージョンが更新されている場合、ダイアログメッセージを表示し、App StoreまたはPlay Storeを開きます。
/// アプリケーションからは強制的にログアウトします。
Future<void> appVersionCheck(
    BuildContext context, WidgetRef ref, Maintenance maintenance) async {
  // 認証状態確認
  final firebaseUser = await ref.watch(authStateChangesProvider.future);
  if (firebaseUser == null) {
    // ログアウト済みの場合はチェック不要
    return;
  }

  final packageInfo = await PackageInfo.fromPlatform();
  final currentVersion = Version.parse(packageInfo.version);

  final newVersion = Version.parse(maintenance.version);

  if (currentVersion == newVersion) {
    // バージョン差異無し
    return;
  }

  if (currentVersion < newVersion) {
    // バージョン更新（利用中のバージョン < Firestore上のバージョン）

    // バージョン更新時のダイアログメッセージ表示
    await _showUpdateDialog(context, ref, maintenance);
  } else {
    // 利用中のバージョン > Firestore上のバージョン
    // Firestoreのバージョン更新前に、新しいバージョンが利用された場合

    // メンテナンス中のダイアログメッセージ表示
    await _showMaintenanceDialog(context, ref);
  }
}

/// バージョン更新時のダイアログメッセージを表示します。
Future<void> _showUpdateDialog(
    BuildContext context, WidgetRef ref, Maintenance maintenance) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      const title = 'バージョン更新のお知らせ';
      const message = '新しいバージョンのアプリが利用可能です。ストアより更新版を入手してご利用下さい。';
      const btnLabel = '今すぐ更新';
      return CupertinoAlertDialog(
        title: const Text(title),
        content: const Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text(
              btnLabel,
              style: TextStyle(color: Colors.red),
            ),
            onPressed: () async {
              try {
                if (Platform.isIOS) {
                  // iOS
                  await _launchUrl(maintenance.appStoreUrl);
                } else {
                  // Android
                  await _launchUrl(maintenance.playStoreUrl);
                }
              } finally {
                // 状態をリフレッシュ
                refreshStateForLogout(ref);
                // ログアウト
                await ref.watch(loginViewModelProvider.notifier).logout();
                // ログイン画面へ
                context.go(LoginScreen.path);
              }
            },
          ),
        ],
      );
    },
  );
}

/// メンテナンス中のダイアログメッセージを表示します。
Future<void> _showMaintenanceDialog(BuildContext context, WidgetRef ref) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      const title = 'メンテナンス中';
      const message =
          '現在システムメンテナンス中のため一時サービスを停止しております。大変ご不便をおかけいたしますが、今しばらくお待ちください。';
      const btnLabel = 'OK';
      return CupertinoAlertDialog(
        title: const Text(title),
        content: const Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text(
              btnLabel,
              style: TextStyle(color: Colors.red),
            ),
            onPressed: () async {
              // 状態をリフレッシュ
              refreshStateForLogout(ref);
              // ログアウト
              await ref.watch(loginViewModelProvider.notifier).logout();
              // ログイン画面へ
              context.go(LoginScreen.path);
            },
          ),
        ],
      );
    },
  );
}

/// [url]へ遷移します。
Future<void> _launchUrl(String url) async {
  final uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } else {
    throw Exception('${DisplayedErrorMessage.cannotOpenStoreUrl}, url=$url');
  }
}

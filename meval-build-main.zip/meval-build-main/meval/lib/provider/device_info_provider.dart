import 'dart:io';

import 'package:apple_product_name/apple_product_name.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../model/data/device_info.dart';

final baseDeviceInfoProvider = Provider<BaseDeviceInfo>(
  (_) => throw UnimplementedError('アプリケーション起動時にmainで生成したインスタンスを使用'),
);

final appleProductNameProvider = Provider((ref) => AppleProductName());

final deviceInfoProvider = Provider<DeviceInfo>(
  (ref) {
    final baseDeviceInfo = ref.watch(baseDeviceInfoProvider);

    DeviceInfo deviceInfo;
    if (Platform.isIOS) {
      final iosInfo = baseDeviceInfo as IosDeviceInfo;
      final device =
          ref.watch(appleProductNameProvider).lookup(iosInfo.utsname.machine!);

      deviceInfo = DeviceInfo(
        os: Platform.operatingSystem,
        version: iosInfo.systemVersion!,
        device: device,
      );
    } else if (Platform.isAndroid) {
      final androidInfo = baseDeviceInfo as AndroidDeviceInfo;

      deviceInfo = DeviceInfo(
        os: Platform.operatingSystem,
        version: androidInfo.version.release!,
        device: androidInfo.device!,
      );
    } else {
      throw UnimplementedError('未サポートのでデバイスです。');
    }

    return deviceInfo;
  },
);

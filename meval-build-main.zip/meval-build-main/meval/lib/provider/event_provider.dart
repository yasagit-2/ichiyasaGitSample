import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/kt.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import '../const/constant.dart';
import '../model/data/event.dart';
import '../model/data/event_participation_history.dart';
import '../model/repository/record_repository.dart';
import '../util/image_processing.dart';
import '../util/logger.dart';
import '../view/content/record/tab/event/event_bottom_sheet.dart';
import '../view_model/member_view_model.dart';
import 'data/event_marker_data.dart';
import 'data/event_spot_data.dart';
import 'data/map_icon_data.dart';

// イベントリストストリームプロバイダ
final eventStreamProvider = StreamProvider.autoDispose<List<Event>>((ref) {
  ref.onDispose(() {
    logger.fine('eventStreamProvider dispose.');
  });

  return ref.watch(recordRepositoryProvider).getEvents();
});

// イベントMapのGoogleMapControllerプロバイダ
final eventMapControllerProvider =
    StateProvider.autoDispose<GoogleMapController?>((ref) {
  ref.onDispose(() {
    logger.fine('eventMapControllerProvider dispose.');
  });

  return null;
});

// ID指定のイベントストリームプロバイダ（eventIdのイベントを監視するプロバイダ）
final eventByIdStreamProvider =
    StreamProvider.family.autoDispose<Event?, String>((ref, String eventId) {
  ref.onDispose(() {
    logger.fine('eventByIdStreamProvider dispose.');
  });

  return ref.watch(recordRepositoryProvider).getEventById(eventId);
});

// ID指定のイベントスポットストリームプロバイダ（指定されたイベントスポットを監視するプロバイダ）
final eventSpotByIdStreamProvider = StreamProvider.family
    .autoDispose<EventSpot?, EventSpotData>((ref, EventSpotData eventSpot) {
  ref.onDispose(() {
    logger.fine('eventSpotByIdStreamProvider dispose.');
  });

  return ref
      .watch(recordRepositoryProvider)
      .getEventSpotById(eventSpot.eventId, eventSpot.eventSpotId);
});

// イベントスポットストリームプロバイダ（eventIdに所属するイベントスポットを監視するプロバイダ）
final eventSpotsStreamProvider = StreamProvider.family
    .autoDispose<List<EventSpot>, String>((ref, String eventId) {
  ref.onDispose(() {
    logger.fine('eventSpotsStreamProvider dispose.');
  });

  return ref.watch(recordRepositoryProvider).getEventSpots(eventId);
});

// ID指定の参加イベントストリームプロバイダ（eventIdの参加イベントを監視するプロバイダ）
final participatedEventByEventIdStreamProvider = StreamProvider.family
    .autoDispose<ParticipatedEvent?, String>((ref, String eventId) {
  ref.onDispose(() {
    logger.fine('participatedEventByEventIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(recordRepositoryProvider)
      .getParticipatedEventByEventId(memberId, eventId);
});

// ID指定のイベント達成地点数ストリームプロバイダ（eventIdのイベント達成地点数を監視するプロバイダ）
final completedSpotCountByEventIdStreamProvider =
    StreamProvider.family.autoDispose<int, String>((ref, String eventId) {
  ref.onDispose(() {
    logger.fine('completedSpotCountByEventIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(recordRepositoryProvider)
      .getCompletedSpotCountByEventId(memberId, eventId);
});

// ID指定の達成地点ストリームプロバイダ（eventIdのイベント達成地点を監視するプロバイダ）
final completedSpotsByEventIdStreamProvider = StreamProvider.family
    .autoDispose<List<CompletedSpot>, String>((ref, String eventId) {
  ref.onDispose(() {
    logger.fine('completedSpotsByEventIdStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .watch(recordRepositoryProvider)
      .getCompletedSpotByEventId(memberId, eventId);
});

// イベントマーカープロバイダ
final eventMarkersProvider = FutureProvider.family
    .autoDispose<KtSet<Marker>, EventMarkerData>(
        (ref, EventMarkerData eventMarkerData) async {
  ref.onDispose(() {
    logger.fine('eventMarkersProvider dispose.');
  });

  final event = eventMarkerData.event;
  final eventSpots = eventMarkerData.eventSpots;

  Set<Marker> eventMarkers = {};
  if (eventSpots.isEmpty) {
    return eventMarkers.toImmutableSet();
  }

  // スタンプ獲得済みのイベントスポット
  final completedSpots =
      await ref.watch(completedSpotsByEventIdStreamProvider(event.id).future);

  final completedSpotIdList =
      completedSpots.map((completedSpot) => completedSpot.eventSpotId).toList();

  // イベントマーカー生成
  final markerList = await Future.wait(
    eventMarkerData.eventSpots.map(
      (eventSpot) async {
        final eventSpotId = eventSpot.id;
        BitmapDescriptor icon;
        if (completedSpotIdList.contains(eventSpotId)) {
          // スタンプ獲得済みアイコン
          icon = await ref.watch(_iconProvider(MapIconData(
                  url: event.completeSpotIconUrl,
                  localIconPath: MapImage.completeEvent))
              .future);
        } else {
          // スタンプ獲得未済アイコン
          icon = await ref.watch(_iconProvider(MapIconData(
                  url: event.eventIconUrl, localIconPath: MapImage.event))
              .future);
        }

        final geopoint = eventSpot.position.geopoint;
        return Marker(
          markerId: MarkerId(eventSpot.id),
          position: LatLng(geopoint.latitude, geopoint.longitude),
          icon: icon,
          onTap: () => _showEventInformation(
              eventMarkerData.navigator, eventMarkerData.event, eventSpot),
        );
      },
    ),
  );

  eventMarkers.addAll(markerList);

  return eventMarkers.toImmutableSet();
});

// アイコンプロバイダ
final _iconProvider =
    FutureProvider.family.autoDispose((ref, MapIconData iconData) async {
  ref.onDispose(() {
    logger.fine('_iconProvider dispose.');
  });

  // ネットワークから画像を読み込みアイコン生成
  BitmapDescriptor? icon = await createBitmapDescriptorFromNetwork(
      url: iconData.url,
      height: MapImage.iconHeight,
      width: MapImage.iconWidth);

  // ネットワーク画像からアイコン生成できない場合、ローカル画像からアイコンを生成
  icon ??= await createBitmapDescriptorFromLocal(
      path: iconData.localIconPath, height: 150, width: 150);

  return icon;
});

/// イベントスポット情報表示のためのコールバックです。
/// [eventSpot]の情報を表示します。
void _showEventInformation(
    NavigatorState navigator, Event event, EventSpot eventSpot) {
  showCupertinoModalBottomSheet(
    context: navigator.context,
    builder: (context) {
      return EventBottomSheet(event: event, eventSpot: eventSpot);
    },
  );
}

/// 会員[memberId]のイベント参加履歴を保存します。
Future<void> completeSpot(WidgetRef ref, String memberId, Event event,
    EventSpot eventSpot, String qrCodeId) async {
  return ref
      .read(recordRepositoryProvider)
      .completeSpot(memberId, event, eventSpot, qrCodeId);
}

/// 会員[memberId]の参加イベント[event]を達成状態として更新します。
Future<void> completeEvent(WidgetRef ref, String memberId, Event event) async {
  return ref.read(recordRepositoryProvider).completeEvent(memberId, event);
}

import 'package:hooks_riverpod/hooks_riverpod.dart';

// 画面タイププロバイダ
final screenTypeProvider = StateProvider<ScreenType>((ref) => ScreenType.home);

// 画面タイプ
enum ScreenType {
  home,
  search,
  record,
  spend,
  myPage,
}

// 記録画面のタブタイププロバイダ
final recordTabTypeProvider =
    StateProvider<RecordTabType>((ref) => RecordTabType.base);

// 記録画面のタブタイプ
enum RecordTabType {
  base,
  event,
  walk,
}

// 投稿リストのタブタイププロバイダ
final postListTabTypeProvider =
    StateProvider<PostListTabType>((ref) => PostListTabType.ownPost);

// 投稿リストのタブタイプ
enum PostListTabType {
  // 自分の投稿リスト
  ownPost,
  // 行政の投稿リスト
  adminAlert,
}

// クーポンリストのタブタイププロバイダ
final couponListTabTypeProvider =
    StateProvider<CouponListTabType>((ref) => CouponListTabType.ownCoupon);

// クーポンリストのタブタイプ
enum CouponListTabType {
  // 自分のクーポン
  ownCoupon,
  // 交換可能クーポン
  replaceableCoupon,
}

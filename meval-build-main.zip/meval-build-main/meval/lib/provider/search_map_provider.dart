import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/collection.dart';

import '../const/constant.dart';
import '../model/data/base.dart';
import '../model/data/check_in.dart';
import '../model/data/completed_base.dart';
import '../model/data/completed_coupon.dart';
import '../model/data/merchant.dart';
import '../model/data/tweet.dart';
import '../model/repository/map_repository.dart';
import '../util/logger.dart';
import '../view_model/member_view_model.dart';
import 'data/coupon_data.dart';
import 'geoflutterfire_provider.dart';
import 'settings_provider.dart';

// 地図中心の位置情報プロバイダ
final centerLocationProvider = StateProvider<LatLng>(
  (ref) => LatLng(
    MapConst.initialLocation.latitude,
    MapConst.initialLocation.longitude,
  ),
);

// 拠点ストリームプロバイダ
final baseStreamProvider = StreamProvider.autoDispose<List<DocumentSnapshot>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('baseStreamProvider dispose.');
    });

    return ref.read(mapRepositoryProvider).getBasesByRange(
          ref.watch(geoflutterfireProvider),
          ref.watch(centerLocationProvider),
          ref.watch(collectionRadiusProvider),
        );
  },
);

// 拠点ストリームプロバイダ（パラメータで指定された拠点を監視するプロバイダ）
final baseByIdStreamProvider =
    StreamProvider.family.autoDispose<Base?, String>((ref, String baseId) {
  ref.onDispose(() {
    logger.fine('baseByIdStreamProvider dispose.');
  });

  return ref.read(mapRepositoryProvider).getBaseById(baseId);
});

// 加盟店ストリームプロバイダ
final merchantStreamProvider =
    StreamProvider.autoDispose<List<DocumentSnapshot>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('merchantStreamProvider dispose.');
    });

    return ref.read(mapRepositoryProvider).getMerchantsByRange(
          ref.watch(geoflutterfireProvider),
          ref.watch(centerLocationProvider),
          ref.watch(collectionRadiusProvider),
        );
  },
);

// 加盟店ストリームプロバイダ（パラメータで指定された加盟店を監視するプロバイダ）
final merchantByIdStreamProvider = StreamProvider.family
    .autoDispose<Merchant?, String>((ref, String merchantId) {
  ref.onDispose(() {
    logger.fine('merchantByIdStreamProvider dispose.');
  });

  return ref.read(mapRepositoryProvider).getMerchantById(merchantId);
});

// つぶやきストリームプロバイダ（加盟店IDリスト指定）
final tweetStreamProviderByMerchantIdList = StreamProvider.family
    .autoDispose<List<Tweet>, KtList<String>>(
        (ref, KtList<String> merchantIdList) {
  ref.onDispose(() {
    logger.fine('tweetStreamProviderByMerchantIdList dispose.');
  });

  return ref
      .read(mapRepositoryProvider)
      .getTweetsByMerchantIdList(merchantIdList.asList());
});

// つぶやきストリームプロバイダ（加盟店ID指定）
final tweetStreamProviderByMerchantId =
    StreamProvider.family.autoDispose<Tweet?, String>((ref, String merchantId) {
  ref.onDispose(() {
    logger.fine('tweetStreamProviderByMerchantId dispose.');
  });

  return ref.read(mapRepositoryProvider).getTweetsByMerchantId(merchantId);
});

// 行政投稿アラートストリームプロバイダ
final adminAlertStreamProvider =
    StreamProvider.autoDispose<List<DocumentSnapshot>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('adminAlertStreamProvider dispose.');
    });

    return ref.read(mapRepositoryProvider).getAdminAlertsByRange(
          ref.watch(geoflutterfireProvider),
          ref.watch(centerLocationProvider),
          ref.watch(collectionRadiusProvider),
        );
  },
);

// 行政投稿アンケートストリームプロバイダ
final adminQuestionnaireStreamProvider =
    StreamProvider.autoDispose<List<DocumentSnapshot>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('adminQuestionnaireStreamProvider dispose.');
    });

    return ref.read(mapRepositoryProvider).getAdminQuestionnairesByRange(
          ref.watch(geoflutterfireProvider),
          ref.watch(centerLocationProvider),
          ref.watch(collectionRadiusProvider),
        );
  },
);

// 投稿ストリームプロバイダ
final postStreamProvider = StreamProvider.autoDispose<List<DocumentSnapshot>>(
  (ref) {
    ref.onDispose(() {
      logger.fine('postStreamProvider dispose.');
    });

    return ref.read(mapRepositoryProvider).getPostsByRange(
          ref.watch(geoflutterfireProvider),
          ref.watch(centerLocationProvider),
          ref.watch(collectionRadiusProvider),
        );
  },
);

// チェックインストリームプロバイダ（ログイン中の会員のチェックイン情報を監視するプロバイダ）
final checkInStreamProvider = StreamProvider.autoDispose<List<CheckIn>>((ref) {
  ref.onDispose(() {
    logger.fine('checkInStreamProvider dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.read(mapRepositoryProvider).getCheckInByMemberIdStream(memberId);
});

// チェックインストリームプロバイダ（パラメータで指定されたチェックイン情報を監視するプロバイダ）
final checkInByBaseIdStreamProvider =
    StreamProvider.family.autoDispose<CheckIn?, String>((ref, String baseId) {
  ref.onDispose(() {
    logger.fine('checkInByBaseIdStreamProvider dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.read(mapRepositoryProvider).getCheckInByBaseId(baseId, memberId);
});

// 拠点制覇情報（親拠点）ストリームプロバイダ
final completedParentBasesStreamProvider =
    StreamProvider.autoDispose<List<CompletedParentBase>>((ref) {
  ref.onDispose(() {
    logger.fine('completedParentBasesStreamProvider dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.read(mapRepositoryProvider).getCompletedParentBases(memberId);
});

// クーポンリストストリームプロバイダ（パラメータ指定された加盟店のクーポンを監視するプロバイダ）
final couponsByMerchantIdStreamProvider =
    StreamProvider.family.autoDispose((ref, String merchantId) {
  ref.onDispose(() {
    logger.fine('couponsByMerchantIdStreamProvider dispose.');
  });

  return ref.read(mapRepositoryProvider).getCouponsByMerchantId(merchantId);
});

// クーポン獲得/使用履歴ストリームプロバイダ（パラメータ指定された獲得済みクーポンを監視するプロバイダ）
final couponHistoryByIdStreamProvider = StreamProvider.family
    .autoDispose<CouponHistory?, String>((ref, String couponId) {
  ref.onDispose(() {
    logger.fine('couponHistoryByIdStreamProvider dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .read(mapRepositoryProvider)
      .getCouponHistoryById(memberId, couponId);
});

// クーポン獲得/使用履歴ストリームプロバイダ（パラメータ指定された加盟店の獲得済みクーポンを監視するプロバイダ）
final couponHistoriesByMerchantId = StreamProvider.family
    .autoDispose<List<CouponHistory>, String>((ref, String merchantId) {
  ref.onDispose(() {
    logger.fine('couponHistoriesByMerchantId dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref
      .read(mapRepositoryProvider)
      .getCouponHistoriesByMerchantId(memberId, merchantId);
});

// クーポン獲得制限人数残りストリームプロバイダ
final couponExchangeLimitRemainStreamProvider = StreamProvider.family
    .autoDispose<int, CouponData>((ref, CouponData couponData) {
  ref.onDispose(() {
    logger.fine('couponExchangeLimitRemainStreamProvider dispose.');
  });

  return ref
      .read(mapRepositoryProvider)
      .getExchangeLimitRemain(couponData.merchantId, couponData.couponId);
});

// ポイント交換未済（バックエンド処理中）のクーポン獲得/使用履歴ストリームプロバイダ
final unusedPointCouponsStreamProvider =
    StreamProvider.autoDispose<List<CouponHistory>>((ref) {
  ref.onDispose(() {
    logger.fine('unusedPointCouponsStreamProvider dispose.');
  });

  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.read(mapRepositoryProvider).getUnusedPointCoupons(memberId);
});

// ポイントストリームプロバイダ
final pointStreamProvider = StreamProvider.autoDispose<int>((ref) {
  ref.onDispose(() {
    logger.fine('pointStreamProvider dispose.');
  });

  // ログイン中会員のID
  final memberId = ref.watch(memberIdProvider);
  if (memberId == null) {
    return const Stream.empty();
  }

  return ref.watch(mapRepositoryProvider).getPoint(memberId);
});

/// クーポン獲得/使用履歴を保存します。
Future<void> createCouponHistory(WidgetRef ref, Coupon coupon) async {
  // ログイン中会員のID
  final memberId = ref.read(memberIdProvider);
  if (memberId == null) {
    throw UnsupportedError('この操作は許可されていません。');
  }

  return ref.read(mapRepositoryProvider).createCouponHistory(memberId, coupon);
}

/// [couponHistory]のクーポンを使用済みとして更新します。
Future<void> useCoupon(WidgetRef ref, CouponHistory couponHistory) async {
  // ログイン中会員のID
  final memberId = ref.read(memberIdProvider);
  if (memberId == null) {
    throw UnsupportedError('この操作は許可されていません。');
  }

  return ref.read(mapRepositoryProvider).useCoupon(memberId, couponHistory);
}

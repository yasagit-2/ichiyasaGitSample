import 'package:enum_to_string/enum_to_string.dart';

enum Flavor { robo, dev }

class Constants {
  /// 環境 Flavor
  static Flavor get flavor =>
      EnumToString.fromString(
        Flavor.values,
        const String.fromEnvironment('FLAVOR'),
      ) ??
      Flavor.dev;
}

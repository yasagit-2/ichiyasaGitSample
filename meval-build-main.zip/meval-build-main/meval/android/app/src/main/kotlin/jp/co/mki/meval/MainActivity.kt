package com.example.meval_mki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

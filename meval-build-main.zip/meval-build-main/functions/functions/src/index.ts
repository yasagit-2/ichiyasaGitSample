import * as admin from 'firebase-admin';

admin.initializeApp();

const functions = {
  // scheduled
  deleteTweet: './functions/schedules/deleteTweet',
  deleteTriggerEvent: './functions/schedules/deleteTriggerEvent',
  deleteAdminAlert: './functions/schedules/deleteAdminAlert',
  deleteMemberNotification: './functions/schedules/deleteMemberNotification',
  deleteEvent: './functions/schedules/deleteEvent',
  deleteMember: './functions/schedules/deleteMember',
  deleteAuthentication: './functions/schedules/deleteAuthentication',

  // triggered
  deletePost: './functions/triggers/deletePost',
  createCompletedBase: './functions/triggers/createCompletedBase',
  createCompletedTitle: './functions/triggers/createCompletedTitle',
  createAnsweredQuestionnaire: './functions/triggers/createAnsweredQuestionnaire',
  createCompletedWalk: './functions/triggers/createCompletedWalk',
  createMember: './functions/triggers/createMember',
  createCheckIn: './functions/triggers/createCheckIn',
  updateParticipatedEvent: './functions/triggers/updateParticipatedEvent',
  deleteMemberRelation: './functions/triggers/deleteMemberRelation',
  deleteReport: './functions/triggers/deleteReport',
  createCouponHistory: './functions/triggers/createCouponHistory',

  // API
  signInWithApple:'./functions/api/signInWithApple',
};

const loadFunctions = (names: any) => {
  for (const name in names) {
    if (!process.env.FUNCTION_NAME || process.env.FUNCTION_NAME === name) {
      module.exports[name] = require(names[name]);
    }
  }
  console.log(`exports=${JSON.stringify(module.exports)}`);
};

loadFunctions(functions);

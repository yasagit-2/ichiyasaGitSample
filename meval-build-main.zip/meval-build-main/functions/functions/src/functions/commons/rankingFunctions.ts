import { firestore } from 'firebase-admin'
import FieldValue = firestore.FieldValue;
import Transaction = firestore.Transaction;
import DocumentSnapshot = firestore.DocumentSnapshot;

export const db = firestore();

const membersRef = db.collection('members');
const checkInsRef = db.collection('checkIns');
const summariesRef = db.collection('summaries');

/**
 * ランキング算出のためのインタフェースクラスです。
 */
interface Rank {
  /** 会員ID */
  memberId: string;
  /** チェックイン済みサブ拠点総数 */
  totalCheckedInSubBases: number;
  /** 順位 */
  rank: number;
}

/**
 * 会員のランキングを設定します。
 *
 * @param transaction トランザクション
 */
export async function setRanking(transaction: Transaction): Promise<void> {

  // ランキング算出処理
  const ranks = await createRank(transaction);

  const summaryDocRef = summariesRef.doc('mevalAppSummaries');

  // ランキング設定（rankingsコレクションにおける当該ユーザのドキュメント取得）
  const rankingDocSnapshots: DocumentSnapshot[] = [];
  for (const rank of ranks) {
    const rankingDocRef = summaryDocRef.collection('rankings').doc(rank.memberId);
    const rankingDocSnapshot = await transaction.get(rankingDocRef);
    rankingDocSnapshots.push(rankingDocSnapshot);
  }

  // ランキング設定
  for (const rankingDocSnapshot of rankingDocSnapshots) {
    const rankingDocRef = summaryDocRef.collection('rankings').doc(rankingDocSnapshot.id);
    const rank = ranks.find((rank) => rank.memberId === rankingDocSnapshot.id);
    if (!rank) break;

    if (!rankingDocSnapshot.exists) {
      // 当該ユーザのランキングドキュメントが存在しない場合は新規生成
      transaction.set(rankingDocRef, {
        rank: rank.rank,
        memberRef: membersRef.doc(rank.memberId),
        updatedAt: FieldValue.serverTimestamp(),
        createdAt: FieldValue.serverTimestamp(),
      });
    } else {
      transaction.update(rankingDocRef, {
        rank: rank.rank,
        memberRef: membersRef.doc(rank.memberId),
        updatedAt: FieldValue.serverTimestamp(),
      });
    }
  }
}

/**
 * チェックイン済みサブ拠点数を元に、全会員のランキングを算出します。
 *
 * @param transaction トランザクション
 * @return 全会員分のランキングオブジェクト
 */
async function createRank(transaction: Transaction): Promise<Rank[]> {
  const memberDocRefs = await membersRef.listDocuments();
  const memberIds = memberDocRefs.map((docRef) => docRef.id);
  console.log(`memberIds=${memberIds}`);

  const rankTarget: Rank[] = [];
  for (const memberId of memberIds) {
    const query = checkInsRef
      .where('memberRef', '==', membersRef.doc(memberId))
      .where('isParent', '==', false);
    const querySnapshot = await transaction.get(query);
    rankTarget.push({
      memberId: memberId,
      totalCheckedInSubBases: querySnapshot.size,
      rank: 0
    })
  }
  console.log(`rankTarget=${JSON.stringify(rankTarget)}`);

  // ランキング算出
  const ranked = calculateRank(rankTarget, (a: number, b: number) => b - a);
  console.log(`ranked=${JSON.stringify(ranked)}`);

  return ranked;
}

/**
 * 順位算出した新しい {@link Rank} オブジェクトを返却します。
 *
 * @remarks
 * {@link target} の {@link Rank#totalCheckedInSubBases} にて順位算出した新しいオブジェクトを返却します。
 * 算出した順位は、{@link Rank#rank} へ設定します。
 *
 * {@link Rank#totalCheckedInSubBases} が同一の値を持つ場合、同一の順位として算定し後続の順位をスキップします。
 * 例：{@link Rank#totalCheckedInSubBases} が [20, 10 ,20, 30] の値を持つ場合、[2, 4, 2, 1] の考え方で順位を算出します。（2位は同一順位、3位は存在しない。）
 *
 * チェックイン済みサブ拠点が一つも存在しない場合、順位算出の対象外としてrank=0を設定します。
 *
 * @param target 順位算出する対象オブジェクト
 * @param compareTo 比較に用いるFunction
 * @return ランキングオブジェクト
 */
function calculateRank(target: Rank[], compareTo: (a: number, b: number) => number): Rank[] {
  const ranking = target
    .map((rank, i) => [rank.totalCheckedInSubBases, i])
    .sort((a, b) => compareTo(a[0], b[0]))
    .reduce((a, x, i, s) => {
      a[x[1]] = i > 0 && compareTo(s[i - 1][0], x[0]) === 0 ? a[s[i - 1][1]] : i + 1;
      return a;
    }, []);

  return target.map((rank: Rank, index: number) => {
    if (rank.totalCheckedInSubBases === 0) {
      // チェックインしたサブ拠点が存在しない場合、順位算出対象外としてrank=0とする
      return {
        ...rank,
        rank: 0,
      };
    }

    return {
      ...rank,
      rank: ranking[index],
    };
  });
}

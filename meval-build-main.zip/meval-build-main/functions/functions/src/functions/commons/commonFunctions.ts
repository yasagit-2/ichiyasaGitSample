import { firestore } from 'firebase-admin'
import * as functions from 'firebase-functions';
import { EventContext } from 'firebase-functions';
import FieldValue = firestore.FieldValue;

export const timeZone = 'Asia/Tokyo';
export const region = functions.region('asia-northeast1');
export const db = firestore();

/**
 * 一つのイベントでFunctionが複数回呼び出される場合があるため、重複実行を防ぐための施策。
 * "triggerEvents"コレクションへ、ドキュメントID「イベントID+suffix」にて保存します。
 *
 * see...
 *   https://firebase.google.com/docs/functions/firestore-events#limitations
 *
 * @param eventID
 * @param suffix
 */
async function hasAlreadyTriggered(eventID: string, suffix: string): Promise<boolean> {
  const id = [eventID, suffix].join('_');

  return db.runTransaction(async transaction => {
      const triggerEventDocRef = db.collection('triggerEvents').doc(id);

      const doc = await transaction.get(triggerEventDocRef);
      if (doc.exists) {
        console.log(`EventID: ${id} has already triggered.`);
        return true;
      } else {
        transaction.set(triggerEventDocRef, {createdAt: FieldValue.serverTimestamp()});
        return false;
      }
    }
  )
}

export const triggerOnce = <T>(
  suffix: string,
  handler: (data: T, context: EventContext) => PromiseLike<any> | any
): ((data: T, context: EventContext) => PromiseLike<any> | any) => async (
  data,
  context
) => {
  if (await hasAlreadyTriggered(context.eventId, suffix)) {
    return undefined
  }
  return handler(data, context)
}

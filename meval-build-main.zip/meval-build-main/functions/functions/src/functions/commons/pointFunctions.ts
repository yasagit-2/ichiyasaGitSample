import { firestore } from 'firebase-admin'
import FieldValue = firestore.FieldValue;
import Transaction = firestore.Transaction;

export const db = firestore();

const pointsRef = db.collection('points');

/**
 * 現在のポイント（ポイント獲得前のポイント）を返却します。
 *
 * @remarks
 * {@link pointHistoryId} に該当するポイント獲得履歴が既に存在する場合、-1を返却します。
 *
 * @param transaction トランザクション
 * @param memberId 会員ID
 * @param pointHistoryId ポイント履歴ID
 * @return 獲得前のポイント（ポイント獲得履歴が既に存在する場合は-1）
 */
export async function getPointBeforeEarning(transaction: Transaction, memberId: string,
                                            pointHistoryId: string): Promise<number> {

  const pointDocRef = pointsRef.doc(memberId);
  const pointDocSnapshot = await transaction.get(pointDocRef);
  const pointData = pointDocSnapshot.data();

  const pointHistoryDocRef = pointDocRef.collection('pointHistories').doc(pointHistoryId);

  // ポイント履歴
  const pointHistoryDocSnapshot = await transaction.get(pointHistoryDocRef);
  const pointHistory = pointHistoryDocSnapshot.data();
  if (pointHistory) {
    // 既にポイント獲得履歴が存在するため終了
    console.log(
      `The process will be terminated because a history of points earned already exists. pointHistoryId=${pointHistoryId}`);
    return -1;
  }

  let pointBeforeEarning = 0;
  if (!pointData) {
    // ポイントデータの初期状態を作成
    // （ただし、pointsコレクションは、会員登録時に初期状態を生成するため必ず存在するはず）
    transaction.set(pointDocRef, {
      point: 0,
      updatedAt: FieldValue.serverTimestamp(),
      createdAt: FieldValue.serverTimestamp(),
    });
  } else {
    // 現在（更新前）のポイント数
    pointBeforeEarning = pointData.point;
  }

  return pointBeforeEarning;
}

/**
 * 会員のポイントを更新します。
 *
 * @remarks
 * 会員 {@link memberId} のポイントを {@link point} で更新します。
 * {@link isIncrementPoint === true} の場合、update処理を実行しません。
 *
 * @param transaction トランザクション
 * @param memberId 会員ID
 * @param point 付与ポイント
 * @param isIncrementPoint ポイント付与制限人数残り
 * @return 付与ポイント（ポイントのupdate処理を実行しない場合は0）
 */
export function updatePoint(transaction: Transaction, memberId: string, point: number, isIncrementPoint: boolean) {

  if (isIncrementPoint) {
    // ポイント付与
    transaction.update(pointsRef.doc(memberId), {
      point: FieldValue.increment(point),
      updatedAt: FieldValue.serverTimestamp(),
    });
  } else {
    // 0ポイント付与という履歴を残すため、付与ポイント数を0とする
    point = 0;
  }

  return point;
}

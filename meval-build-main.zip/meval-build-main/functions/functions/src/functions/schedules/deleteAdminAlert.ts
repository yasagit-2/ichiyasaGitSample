import * as admin from 'firebase-admin';
import { firestore } from 'firebase-admin';
import { DateTime } from 'luxon';
import { db, region, timeZone } from '../commons/commonFunctions';
import Timestamp = firestore.Timestamp;

// スケジューリング
const schedule = region.pubsub.schedule('0 1 * * *').timeZone(timeZone);

const adminAlertsRef = db.collection('adminAlerts');

/**
 * スケジューリング実行により、期限超過した行政投稿（注意）を削除します。
 */
module.exports.deleteAdminAlert =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {
      await db.runTransaction(async (transaction) => {

          // 表示期限を超過した行政投稿（注意）を削除対象とする（同一時刻(=)も削除対象）
          const query = adminAlertsRef
            .where('dueDate', '<=', Timestamp.fromMillis(DateTime.now().toMillis()));
          const querySnapshot = await transaction.get(query);

          for (const doc of querySnapshot.docs) {
            const adminAlert = doc.data();
            console.log('delete target=' + JSON.stringify(adminAlert));

            try {
              // 行政投稿（注意）画像の削除
              const imagePath = adminAlert.imagePath;
              if (imagePath) {
                console.log(`delete target imagePath=${imagePath}`);
                await admin.storage().bucket().file(imagePath).delete();
              }
            } catch (e) {
              // 行政投稿（注意）画像の削除に失敗したとしても、削除処理を継続する。
              console.log(JSON.stringify(e));
            }

            // 行政投稿（注意）削除
            transaction.delete(doc.ref);
          }

        }
      );
    }
  );

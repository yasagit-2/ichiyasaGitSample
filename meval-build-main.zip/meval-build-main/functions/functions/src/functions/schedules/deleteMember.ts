import * as admin from 'firebase-admin';
import { firestore } from 'firebase-admin';
import { db, region, timeZone } from '../commons/commonFunctions';
import { DateTime } from 'luxon';
import DocumentReference = firestore.DocumentReference;
import Timestamp = firestore.Timestamp;

// スケジューリング
const schedule = region.pubsub.schedule('0 2 * * *').timeZone(timeZone);

const settingsRef = db.collection('settings');

// 削除対象コレクション
const membersRef = db.collection('members');
const withdrawalsRef = db.collection('withdrawals');

/**
 * スケジューリング実行により、退会申請が行われかつ猶予日数を超過した会員情報（members）および退会申請（withdrawals）を削除します。
 * Firestore上の会員情報に加えて、Authenticationからも当該ユーザを削除します。
 *
 * @remarks
 * 会員に紐づく関連情報は、deleteMemberRelation にて削除します。
 * このFunction（{@link deleteMember}）では、まず会員情報（members）および退会申請（withdrawals）を削除することにより、
 * アプリケーションにログイン中の会員を強制的にログアウトさせることを意図しています。
 *
 * 会員情報（members）と会員に紐づく関連情報を同一DBトランザクションで削除する場合、
 * レアケースではあるものの削除処理と当該会員によるデータ生成処理が競合すると、
 * 削除しきれないゾンビデータが残ってしまう懸念があります。
 * そのため、会員情報（members）の削除（強制ログアウト）と、当該会員に紐づく関連情報の削除の処理を分離（FunctionおよびDBトランザクションを分離）しています。
 */
module.exports.deleteMember =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {

      const settingsDocRef = settingsRef.doc('mevalAppSettings');
      await db.runTransaction(async (transaction) => {

          // アプリケーション設定
          const settingsDocSnapshot = await transaction.get(settingsDocRef);
          const settings = settingsDocSnapshot.data();
          if (!settings || !settings.notificationRetentionDay) {
            console.log('アプリケーション設定が未設定です。');
            return;
          }

          // 会員削除猶予日数
          const memberDeletionGraceDay = settings.memberDeletionGraceDay;
          console.log(`memberDeletionGraceDay=${memberDeletionGraceDay}`);

          const now = DateTime.now();
          // 現在時刻から会員削除猶予日数を減算した日時（UNIXエポックからの積算ミリ秒）
          const dueDateTimeMillis = now.minus({days: memberDeletionGraceDay}).toMillis();
          console.log(`dueDateTimeMillis=${dueDateTimeMillis}`);

          // dueTimeMillis以下の登録日時の退会申請を検索
          const withdrawalsQuery = withdrawalsRef.where('createdAt', '<=', Timestamp.fromMillis(dueDateTimeMillis));
          const withdrawalsQuerySnap = await transaction.get(withdrawalsQuery);

          // 削除対象のDocumentReference
          const deleteTargetDocRefs: Array<DocumentReference> = [];

          for (const withdrawal of withdrawalsQuerySnap.docs) {
            console.log(`withdrawal=${JSON.stringify(withdrawal)}`);

            // 削除対象の会員
            const memberId = withdrawal.id;
            const memberDocRef = membersRef.doc(memberId);
            const memberDocSnap = await transaction.get(memberDocRef);
            const member = memberDocSnap.data();
            console.log(`delete target member=${JSON.stringify(member)}`);

            // 退会申請
            deleteTargetDocRefs.push(withdrawal.ref);

            // 会員
            deleteTargetDocRefs.push(memberDocRef);

            // Authenticationから当該ユーザを削除
            await admin.auth().deleteUser(memberId);
          }

          // 削除対象のドキュメント群を削除
          deleteTargetDocRefs.forEach((doc) => {
            transaction.delete(doc);
          });

        }
      );
    }
  );

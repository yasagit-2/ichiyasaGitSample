import { firestore } from 'firebase-admin';
import { DateTime } from 'luxon';
import { db, region, timeZone } from '../commons/commonFunctions';
import Timestamp = firestore.Timestamp;

// スケジューリング
const schedule = region.pubsub.schedule('*/10 * * * *').timeZone(timeZone);

const tweetsRef = db.collection('tweets');

/**
 * スケジューリング実行により、加盟店のつぶやきを削除します。
 */
module.exports.deleteTweet =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {
      await db.runTransaction(async (transaction) => {

          // 表示期限を超過したつぶやきを削除対象とする（同一時刻(=)も削除対象）
          const tweetQuery = tweetsRef
            .where('expiration', '<=', Timestamp.fromMillis(DateTime.now().toMillis()));
          const tweetQuerySnapshot = await transaction.get(tweetQuery);

          tweetQuerySnapshot.docs.forEach(doc => {
              console.log('delete target=' + JSON.stringify(doc.data()));
              // つぶやき削除
              transaction.delete(doc.ref);
            }
          );
        }
      );
    }
  );

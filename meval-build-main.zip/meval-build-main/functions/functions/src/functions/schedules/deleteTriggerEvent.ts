import { firestore } from 'firebase-admin';
import { DateTime } from 'luxon';
import { db, region, timeZone } from '../commons/commonFunctions';
import Timestamp = firestore.Timestamp;

// スケジューリング
const schedule = region.pubsub.schedule('0 1 * * *').timeZone(timeZone);

const triggerEventsRef = db.collection('triggerEvents');

/**
 * スケジューリング実行により、前日以前のtriggerEventを削除します。
 */
module.exports.deleteTriggerEvent =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {
      const now = DateTime.now().setZone(timeZone);
      const midnight = DateTime.fromObject({
        year: now.year,
        month: now.month,
        day: now.day,
      }, {zone: timeZone});

      await db.runTransaction(async (transaction) => {

          // 前日以前の全てのtriggerEventを削除対象とする
          const triggerEventQuery = triggerEventsRef
            .where('createdAt', '<', Timestamp.fromMillis(midnight.toMillis()));
          const tweetQuerySnapshot = await transaction.get(triggerEventQuery);

          tweetQuerySnapshot.docs.forEach(doc => {
              console.log('delete target=' + JSON.stringify(doc.data()));
              // triggerEvent削除
              transaction.delete(doc.ref);
            }
          );
        }
      );
    }
  );

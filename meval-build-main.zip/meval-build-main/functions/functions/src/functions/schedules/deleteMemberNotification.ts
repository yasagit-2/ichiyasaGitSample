import { db, region, timeZone } from '../commons/commonFunctions';
import { DateTime } from 'luxon';
import * as admin from 'firebase-admin';
import { firestore } from 'firebase-admin';
import Timestamp = firestore.Timestamp;

// スケジューリング
const schedule = region.pubsub.schedule('0 1 * * *').timeZone(timeZone);

const settingsRef = db.collection('settings');
const memberNotificationsRef = db.collection('memberNotifications');

/**
 * スケジューリング実行により、保存日数を超過したお知らせを削除します。
 */
module.exports.deleteMemberNotification =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {
      await db.runTransaction(async (transaction) => {

          const settingsDocRef = settingsRef.doc('mevalAppSettings');
          const settingsDocSnapshot = await transaction.get(settingsDocRef);
          const settings = settingsDocSnapshot.data();
          if (!settings || !settings.notificationRetentionDay) {
            console.log('アプリケーション設定が未設定です。');
            return;
          }

          // お知らせ保存日数
          const notificationRetentionDay = settings.notificationRetentionDay;
          console.log(`notificationRetentionDay=${notificationRetentionDay}`);

          const now = DateTime.now();
          // 現在時刻からお知らせ保存日数を減算した日時（UNIXエポックからの積算ミリ秒）
          const dueDateTimeMillis = now.minus({days: notificationRetentionDay}).toMillis();
          console.log(`dueDateTimeMillis=${dueDateTimeMillis}`);

          // dueTimeMillis以下の有効期限のお知らせを検索
          const query = memberNotificationsRef
            .where('effectivePeriodEnd', '<=', Timestamp.fromMillis(dueDateTimeMillis));
          const querySnapshot = await transaction.get(query);

          for (const doc of querySnapshot.docs) {
            const memberNotification = doc.data();
            console.log('delete target=' + JSON.stringify(memberNotification));

            if (memberNotification.contentUrl) {
              try {
                // お知らせのコンテンツディレクトリ削除
                await admin.storage().bucket()
                  .deleteFiles({prefix: `memberNotifications/${memberNotification.id}`});
              } catch (e) {
                // コンテンツディレクトリの削除に失敗したとしても、削除処理を継続する。
                console.log(JSON.stringify(e));
              }
            }

            // お知らせ削除
            transaction.delete(doc.ref);
          }
        }
      );
    }
  );

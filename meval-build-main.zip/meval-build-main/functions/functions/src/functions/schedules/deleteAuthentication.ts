import * as admin from 'firebase-admin';
import { db, region, timeZone } from '../commons/commonFunctions';
import { UserRecord } from 'firebase-admin/lib/auth';
import { DateTime } from 'luxon';

// スケジューリング
const schedule = region.pubsub.schedule('0 3 * * *').timeZone(timeZone);

const settingsRef = db.collection('settings');
const adminsRef = db.collection('admins');
const membersRef = db.collection('members');
const withdrawalsRef = db.collection('withdrawals');

/**
 * スケジューリング実行により、以下を削除します。
 *
 * - Firebase Authentication：membersコレクションに会員情報が保存されていないAuthenticationアカウント
 *   認証後に会員登録を完了せず離脱したユーザの情報は、Firestore上には残りませんが、Firebase Authentication上には残存することになります。
 *   そのため、会員登録を完了していないユーザ（Firestore上に会員情報が存在しないAuthentication）の情報を削除します。
 *   ただし即削除してしまうと、ちょうどそのタイミングで会員登録操作を実施しているユーザの情報も削除してしまうことになるため、
 *   Authenticationの最終ログイン日がsettingsコレクションの会員削除猶予日数（memberDeletionGraceDay）を経過している場合のみを対象とします。
 *
 * - members, withdrawalsコレクション：Authenticationが存在しない（Authenticationから削除されている）会員の会員情報および退会申請
 *   レアケースではあるものの、Authenticationの削除とユーザの会員登録が競合すると、
 *   Authenticationに存在しない会員情報がゾンビデータとしてFirestore上に残存してしまう可能性があります。
 *   そのため、Authenticationに存在しない会員情報（および）退会申請を削除します。
 *   （会員情報に紐づく関連情報は、deleteMemberRelation にて削除処理が行われるため、ここでは処理しません。）
 */
module.exports.deleteAuthentication =
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  schedule.onRun(async (_context) => {

      // Authenticationユーザ一覧
      const users = await fetchAllAuthUsers();

      const settingsDocRef = settingsRef.doc('mevalAppSettings');
      await db.runTransaction(async (transaction) => {

          const adminsQuerySnap = await transaction.get(adminsRef);
          const adminIds = adminsQuerySnap.docs.map((doc) => doc.id);

          // アプリケーションユーザ
          const appAuthUsers = users.filter((user) => {
            return !adminIds.includes(user.uid);
          });

          // アプリケーション設定
          const settingsDocSnapshot = await transaction.get(settingsDocRef);
          const settings = settingsDocSnapshot.data();
          if (!settings || !settings.notificationRetentionDay) {
            console.log('アプリケーション設定が未設定です。');
            return;
          }

          // 全会員の会員IDリスト
          const membersQuerySnap = await transaction.get(membersRef);
          const memberIds = membersQuerySnap.docs.map((doc) => doc.id);

          // 会員削除猶予日数
          const memberDeletionGraceDay = settings.memberDeletionGraceDay;
          console.log(`memberDeletionGraceDay=${memberDeletionGraceDay}`);

          const now = DateTime.now();
          // 現在時刻から会員削除猶予日数を減算した日時（UNIXエポックからの積算ミリ秒）
          const dueDateTimeMillis = now.minus({days: memberDeletionGraceDay}).toMillis();
          console.log(`dueDateTimeMillis=${dueDateTimeMillis}`);

          // 確認対象ユーザ
          const usersToBeVerified = appAuthUsers.filter((user) => {
            // 最終ログイン日時
            const lastSignInTime = user.metadata.lastSignInTime;
            if (!lastSignInTime) {
              return true;
            }

            // 最終ログイン日時（UNIXエポックからの積算ミリ秒）
            const lastSignInMillis = DateTime.fromRFC2822(lastSignInTime).toMillis();

            // 最終ログイン日時が古い（現在時刻から会員削除猶予日数を減算した日時未満）
            return lastSignInMillis < dueDateTimeMillis;
          });

          // membersコレクションに存在しないユーザ（削除対象ユーザ）
          const deleteTargetAuthUsers = usersToBeVerified.filter((user) => {
            return !memberIds.includes(user.uid);
          });

          for (const user of deleteTargetAuthUsers) {
            console.log(`delete target user=${JSON.stringify(user)}`);
            // Authenticationから当該ユーザを削除
            await admin.auth().deleteUser(user.uid);
          }

          // Authenticationに存在しない会員情報を削除
          const appAuthUserIds = appAuthUsers.map((appAuthUser) => appAuthUser.uid);
          const deleteTargetMemberIds = memberIds.filter((memberId) => !appAuthUserIds.includes(memberId));

          for (const memberId of deleteTargetMemberIds) {
            // 会員削除
            transaction.delete(membersRef.doc(memberId));
            // 退会申請削除
            transaction.delete(withdrawalsRef.doc(memberId));
          }
        }
      );
    }
  );

/**
 * Firebase Authentication の全てのユーザを取得します。
 */
async function fetchAllAuthUsers(): Promise<UserRecord[]> {
  const users: UserRecord[] = [];

  // ユーザ一覧の取得は1000件まで
  // https://firebase.google.com/docs/auth/admin/manage-users#list_all_users
  let listUsersResult = await admin.auth().listUsers(1000);
  users.push(...listUsersResult.users);

  // 1001件目以降はpageTokenを利用して取得
  while (listUsersResult.pageToken) {
    listUsersResult = await admin.auth().listUsers(1000, listUsersResult.pageToken);
    users.push(...listUsersResult.users);
  }

  return users;
}


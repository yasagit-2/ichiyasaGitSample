import { db, region, triggerOnce } from '../commons/commonFunctions';
import { EventContext } from 'firebase-functions';
import { firestore } from 'firebase-admin';
import { DateTime } from 'luxon';
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;
import FieldValue = firestore.FieldValue;
import Timestamp = firestore.Timestamp;

const pointsRef = db.collection('points');
const merchantsRef = db.collection('merchants');
const completedCouponsRef = db.collection('completedCoupons');

/**
 * クーポン獲得/使用履歴生成時に起動するFunctionです。
 *
 * @remarks
 * クーポン交換処理として、当該会員のポイントをクーポン交換に必要なポイント数で減算し、クーポン獲得制限人数の残りをデクリメントします。
 * また、クーポン交換処理の正常終了を示すためにisPointUsed=trueへ更新します。
 * ポイント履歴には、クーポン交換に伴うポイント消費を記録します。
 *
 * 以下に場合は、ポイント交換処理を行わずに当該の「クーポン獲得/使用履歴」を削除します。
 * - 交換に必要なポイントが不足している場合
 * - クーポン獲得制限人数の上限に達している場合
 * - 現在時刻がクーポン有効期限を超過している場合
 */
module.exports.createCouponHistory = region
  .firestore
  .document('completedCoupons/{memberId}/couponHistories/{couponId}')
  .onCreate(triggerOnce('createCouponHistory',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        const couponHistory = snapshot.data();
        console.log(`couponHistory=${JSON.stringify(couponHistory)}`);

        // 交換ポイント
        const exchangePoint = couponHistory.exchangePoint;
        console.log(`exchangePoint=${exchangePoint}`);
        // 加盟店ID
        const merchantId = couponHistory.merchantId;
        console.log(`merchantId=${merchantId}`);

        // クーポンID
        const couponId = snapshot.id;
        console.log(`couponId=${couponId}`);

        const memberId = couponHistory.memberRef.id;
        console.log(`memberId=${memberId}`);

        const pointDocRef = pointsRef.doc(memberId);
        const couponTransactionDocRef = merchantsRef.doc(merchantId)
          .collection('coupons').doc(couponId)
          .collection('couponTransactions').doc('couponTransaction');
        const couponHistoryDocRef = completedCouponsRef.doc(memberId).collection('couponHistories').doc(couponId);

        // ポイント履歴ID（会員ID_クーポンID）
        const pointHistoryId = `${memberId}_${couponId}`;
        const pointHistoryDocRef = pointDocRef.collection('pointHistories').doc(pointHistoryId);

        await db.runTransaction(async (transaction) => {

            const couponTransactionDocSnap = await transaction.get(couponTransactionDocRef);
            const couponTransaction = couponTransactionDocSnap.data();
            if (!couponTransaction || couponTransaction.exchangeLimitRemain <= 0) {
              // クーポン獲得制限に到達

              console.log('Coupon acquisition limit reached.');
              // 「クーポン獲得/使用履歴」を削除
              transaction.delete(couponHistoryDocRef);
              return;
            }

            const pointDocSnap = await transaction.get(pointDocRef);
            const pointData = pointDocSnap.data();
            if (!pointData) {
              console.log('point is not found.');
              // 「クーポン獲得/使用履歴」を削除
              transaction.delete(couponHistoryDocRef);
              return;
            }

            // 現在の所持ポイント
            const point = pointData.point;
            console.log(`point=${point}`);

            if (point < exchangePoint) {
              // 交換に必要なポイントが不足

              console.log('Points are missing.');
              // 「クーポン獲得/使用履歴」を削除
              transaction.delete(couponHistoryDocRef);
              return;
            }

            const couponHistoryDocSnap = await transaction.get(couponHistoryDocRef);
            const couponHistoryData = couponHistoryDocSnap.data();
            if (!couponHistoryData || couponHistoryData.isPointUsed) {
              console.log('couponHistory is not found.');
              // 「クーポン獲得/使用履歴」を削除
              transaction.delete(couponHistoryDocRef);
              return;
            }

            const now = Timestamp.fromMillis(DateTime.now().toMillis());
            if (couponHistoryData.dueDate < now) {
              // 有効期限超過

              console.log('Due date has been exceeded.');
              // 「クーポン獲得/使用履歴」を削除
              transaction.delete(couponHistoryDocRef);
              return;
            }

            let targetPoint = 0;
            if (exchangePoint !== 0) {
              targetPoint = -exchangePoint;
            }

            // 所持ポイントからクーポンの交換ポイントを減算
            transaction.update(pointDocRef, {
              point: FieldValue.increment(targetPoint),
              updatedAt: FieldValue.serverTimestamp(),
            });

            // ポイント履歴作成
            transaction.set(pointHistoryDocRef, {
              point: targetPoint,
              pointBeforeEarning: point,
              // クーポン獲得情報のリファレンス
              completedCouponRef: couponHistoryDocRef,
              updatedAt: FieldValue.serverTimestamp(),
              createdAt: FieldValue.serverTimestamp(),
            });

            // ポイント交換済みフラグ更新
            transaction.update(couponHistoryDocRef, {
              isPointUsed: true,
              updatedAt: FieldValue.serverTimestamp(),
            });

            // クーポン獲得制限人数残りをデクリメント
            transaction.update(couponTransactionDocRef, {
              exchangeLimitRemain: FieldValue.increment(-1),
              updatedAt: FieldValue.serverTimestamp(),
            });

          }
        );
      }
    )
  );

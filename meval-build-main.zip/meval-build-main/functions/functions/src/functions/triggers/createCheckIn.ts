import { db, region, triggerOnce } from '../commons/commonFunctions';
import { firestore } from 'firebase-admin';
import { setRanking } from '../commons/rankingFunctions';
import { EventContext } from 'firebase-functions';
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

/**
 * チェックイン時に起動するFunctionです。
 *
 * @remarks
 * 会員のランキングを算出します。
 * 親拠点に対するチェックインの場合、ランキングに影響しないため処理を行わずに終了します。
 */
module.exports.createCheckIn = region
  .firestore
  .document('checkIns/{checkInId}')
  .onCreate(triggerOnce('createCheckIn',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        const checkIn = snapshot.data();
        console.log(`checkIn=${JSON.stringify(checkIn)}`);

        const memberId = checkIn.memberRef.id;
        console.log(`memberId=${memberId}`);

        const isParent: boolean = snapshot.data().isParent;
        if (isParent) {
          // 親拠点へのチェックインはランキングに影響しないため終了
          console.log(`No ranking is calculated. checkInId=${checkIn.id}`);
          return;
        }

        await db.runTransaction(async (transaction) => {

          // ランキング設定
          await setRanking(transaction);

        });
      }
    )
  );

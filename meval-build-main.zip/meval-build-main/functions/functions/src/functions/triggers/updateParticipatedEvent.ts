import { db, region, triggerOnce } from '../commons/commonFunctions';
import { Change } from 'firebase-functions/lib/common/change';
import { getPointBeforeEarning, updatePoint } from '../commons/pointFunctions';
import { firestore } from 'firebase-admin';
import { EventContext } from 'firebase-functions';
import FieldValue = firestore.FieldValue;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const eventsRef = db.collection('events');
const eventParticipationHistoriesRef = db.collection('eventParticipationHistories');
const pointsRef = db.collection('points');

/**
 * 参加イベントの更新時に起動するFunctionです。
 *
 * @remarks
 * ポイントを付与し、ポイント履歴を作成します。既にポイント履歴が存在（ポイント履歴IDが存在）する場合、ポイント付与を行わず処理を終了します。
 * また、当該イベントが未完了の場合、当該イベントの交換対象種別が"ポイント"ではない場合については、ポイント履歴作成およびポイント付与を行わず処理を終了します。
 *
 * 当該イベントにおける、ポイント付与可能な制限人数の残りをデクリメントします。
 * 既にポイント付与可能な制限人数に到達している場合、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 * 獲得ポイントが0の場合も同様に、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 */
module.exports.updateParticipatedEvent = region
  .firestore
  .document('eventParticipationHistories/{memberId}/participatedEvents/{eventId}')
  .onUpdate(triggerOnce('updateParticipatedEvent',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (change: Change<QueryDocumentSnapshot>, _context: EventContext) => {

        const participatedEvent = change.after.data();
        console.log(`participatedEvent=${JSON.stringify(participatedEvent)}`);

        if (!participatedEvent.isComplete || participatedEvent.exchangeType !== 0) {
          // 参加イベントが未完了の場合、および交換対象種別が"ポイント"ではない場合は処理しない
          console.log('The process of awarding points for this event is not executed.');
          return;
        }

        // 付与するポイント
        let point = participatedEvent.point;
        console.log(`point=${point}`);

        // イベントID
        const eventId = participatedEvent.id;
        console.log(`eventId=${eventId}`);

        // 会員ID
        const memberId = participatedEvent.memberRef.id;
        console.log(`memberId=${memberId}`);

        const eventTransactionDocRef = eventsRef.doc(eventId)
          .collection('eventTransactions').doc('eventTransaction');
        const participatedEventDocRef = eventParticipationHistoriesRef.doc(memberId)
          .collection('participatedEvents').doc(eventId);

        // ポイント
        const pointDocRef = pointsRef.doc(memberId);
        // ポイント履歴ID（会員ID_称号ID）
        const pointHistoryId = `${memberId}_${eventId}`;
        const pointHistoryDocRef = pointDocRef.collection('pointHistories').doc(pointHistoryId);

        await db.runTransaction(async (transaction) => {

          // イベントトランザクション
          const eventTransactionDocSnap = await transaction.get(eventTransactionDocRef);
          const eventTransaction = eventTransactionDocSnap.data();
          if (!eventTransaction) {
            console.log('eventTransaction is not found.');
            return;
          }

          // 参加イベント
          const participatedEventDocSnap = await transaction.get(participatedEventDocRef);
          const participatedEvent = participatedEventDocSnap.data();
          if (!participatedEvent) {
            console.log('participatedEvent is not found.');
            return;
          }

          // 現在（更新前）のポイント数
          const pointBeforeEarning = await getPointBeforeEarning(transaction, memberId, pointHistoryId);
          if (pointBeforeEarning === -1) {
            // 既にポイント獲得履歴が存在するため終了
            return;
          }

          // ポイント付与制限人数残り
          const exchangeLimitRemain = eventTransaction.exchangeLimitRemain;
          console.log(`exchangeLimitRemain=${exchangeLimitRemain}`);

          // true:ポイント付与の処理を実行する
          const isIncrementPoint = point !== 0 && exchangeLimitRemain !== 0;

          // ポイント付与
          point = updatePoint(transaction, memberId, point, isIncrementPoint);

          // ポイント履歴作成
          transaction.set(pointHistoryDocRef, {
            point: point,
            pointBeforeEarning: pointBeforeEarning,
            // イベント達成情報のリファレンス
            completedEventRef: participatedEventDocRef,
            updatedAt: FieldValue.serverTimestamp(),
            createdAt: FieldValue.serverTimestamp(),
          });

          if (isIncrementPoint) {
            // ポイント付与可能人数をデクリメント
            // （ポイント付与を実行していない場合はデクリメントしない）
            transaction.update(eventTransactionDocRef, {
              exchangeLimitRemain: FieldValue.increment(-1),
              updatedAt: FieldValue.serverTimestamp(),
            });
          }

        });
      }
    )
  );

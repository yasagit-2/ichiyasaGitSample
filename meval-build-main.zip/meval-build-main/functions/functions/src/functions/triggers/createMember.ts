import { db, region, triggerOnce } from '../commons/commonFunctions';
import { firestore } from 'firebase-admin';
import { setRanking } from '../commons/rankingFunctions';
import { EventContext } from 'firebase-functions';
import FieldValue = firestore.FieldValue;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const pointsRef = db.collection('points');
const membersRef = db.collection('members');
const summariesRef = db.collection('summaries');

/**
 * 会員登録時に起動するFunctionです。
 *
 * @remarks
 * ポイント情報の初期状態を生成します。（ポイント初期値=0）
 * 会員総数および会員のランキングを算出します。
 * （フロントエンドからのポイント操作を禁止するため、Cloud Functionsにて初期状態を生成します。）
 */
module.exports.createMember = region
  .firestore
  .document('members/{memberId}')
  .onCreate(triggerOnce('createMember',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        console.log(`member=${JSON.stringify(snapshot.data())}`);

        const memberId = snapshot.id;
        console.log(`memberId=${memberId}`);

        const summaryDocRef = summariesRef.doc('mevalAppSummaries');

        await db.runTransaction(async (transaction) => {
          const pointDocSnapshot = await transaction.get(pointsRef.doc(memberId));
          const point = pointDocSnapshot.data();

          const summaryDocSnapshot = await transaction.get(summaryDocRef);
          const summary = summaryDocSnapshot.data();

          // 会員数
          // （membersコレクションのドキュメントはアプリが生成するため、このFunctionが起動したタイミングでは1名分追加された数値となる。）
          const memberDocs = await membersRef.listDocuments();
          const totalMember = memberDocs.length;
          console.log(`totalMember=${totalMember}`);

          // ランキング設定
          await setRanking(transaction);

          if (!summary) {
            // summaryドキュメントが存在しない場合は新規生成
            transaction.set(summaryDocRef, {
              totalMember: totalMember,
              updatedAt: FieldValue.serverTimestamp(),
              createdAt: FieldValue.serverTimestamp(),
            });
          } else {
            // 会員数更新
            transaction.update(summaryDocRef, {
              totalMember: totalMember,
              updatedAt: FieldValue.serverTimestamp(),
            });
          }

          if (!point) {
            // ポイント情報の初期状態を生成
            transaction.set(pointsRef.doc(memberId), {
              point: 0,
              updatedAt: FieldValue.serverTimestamp(),
              createdAt: FieldValue.serverTimestamp(),
            });
          }

        });

      }
    )
  );

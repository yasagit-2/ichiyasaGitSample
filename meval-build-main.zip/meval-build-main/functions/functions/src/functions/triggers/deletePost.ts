import * as admin from 'firebase-admin';
import { firestore } from 'firebase-admin';
import { db, region, triggerOnce } from '../commons/commonFunctions';
import { DateTime } from 'luxon';
import { EventContext } from 'firebase-functions';
import Timestamp = firestore.Timestamp;
import DocumentReference = firestore.DocumentReference;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const commentsRef = db.collection('comments');
const likesRef = db.collection('likes');
const postingAlertsRef = db.collection('postingAlerts');
const membersRef = db.collection('members');
const postsRef = db.collection('posts');

/**
 * 投稿削除時に起動するFunctionです。
 *
 * @remarks
 * 投稿に紐づく投稿画像、コメント、いいねおよび通報情報を削除します。
 * 最終投稿日時は、Unix epochにて初期化します。
 */
module.exports.deletePost = region
  .firestore
  .document('posts/{postId}')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  .onDelete(triggerOnce('deletePost', async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {
        try {
          // 投稿画像の削除
          const imagePath = snapshot.data().imagePath;
          if (imagePath) {
            console.log(`delete target imagePath=${imagePath}`);
            await admin.storage().bucket().file(imagePath).delete();
          }
        } catch (e) {
          // 投稿画像の削除に失敗したとしても、削除処理を継続する。
          console.log(JSON.stringify(e));
        }

        await db.runTransaction(async (transaction) => {

            // 削除対象のDocumentReference
            const deleteTargetDocRefs: Array<DocumentReference> = [];

            // コメント削除
            const commentsQuery = commentsRef.where('postRef', '==', snapshot.ref);
            const commentsQuerySnapshot = await commentsQuery.get();
            commentsQuerySnapshot.forEach(doc => {
              deleteTargetDocRefs.push(doc.ref);
            });

            // いいね削除
            const likesQuery = likesRef.where('postRef', '==', snapshot.ref);
            const likesQuerySnapshot = await likesQuery.get();
            likesQuerySnapshot.forEach(doc => {
              deleteTargetDocRefs.push(doc.ref);
            });

            // 通報削除
            const postingAlertsQuery = postingAlertsRef.where('postRef', '==', snapshot.ref);
            const postingAlertsQuerySnapshot = await postingAlertsQuery.get();
            postingAlertsQuerySnapshot.forEach(doc => {
                deleteTargetDocRefs.push(doc.ref);
              }
            );

            const memberId = snapshot.data().memberRef.id;
            console.log(`memberId=${memberId}`);

            // 最終投稿日時（Unix epochからの積算ミリ秒）
            let postedAt;

            // 直近の投稿（処理中の削除投稿は除く）を取得
            const postsQuery = await postsRef.orderBy('id').where('id', '!=', snapshot.id)
              .where('memberRef', '==', membersRef.doc(memberId))
              .orderBy('createdAt', 'desc')
              .limit(1);
            const postsQuerySnapshot = await transaction.get(postsQuery);

            if (postsQuerySnapshot.docs.length === 0) {
              // 他に投稿が存在しない場合はUnix epochを設定
              postedAt = 0;
            } else {
              // 他に既存の投稿が存在する場合は、最も新しい投稿の時刻を利用
              const latestPost = postsQuerySnapshot.docs[0].data();
              console.log(`latestPost=${JSON.stringify(latestPost)}`);
              const createdAt = latestPost.createdAt as Timestamp;
              postedAt = createdAt.toMillis();
            }

            const memberDocSnapshot = await transaction.get(membersRef.doc(memberId));
            const member = memberDocSnapshot.data();
            if (member) {
              const currentPostedAt = member.postedAt as Timestamp;

              if (currentPostedAt.toMillis() !== postedAt) {
                // 現在の最終投稿日時と異なる場合は最終投稿日時を更新
                transaction.update(membersRef.doc(memberId), {
                  postedAt: Timestamp.fromMillis(postedAt),
                  updatedAt: Timestamp.fromMillis(DateTime.now().toMillis())
                });

              }
            }

            // 削除対象のドキュメント群を削除
            deleteTargetDocRefs.forEach((doc) => {
              transaction.delete(doc);
            });

          }
        );
      },
    )
  );

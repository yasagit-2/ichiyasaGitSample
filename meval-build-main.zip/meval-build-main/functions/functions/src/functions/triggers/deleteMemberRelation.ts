import { firestore } from 'firebase-admin';
import { db, region, triggerOnce } from '../commons/commonFunctions';
import { setRanking } from '../commons/rankingFunctions';
import { EventContext } from 'firebase-functions';
import CollectionReference = firestore.CollectionReference;
import DocumentReference = firestore.DocumentReference;
import Transaction = firestore.Transaction;
import FieldValue = firestore.FieldValue;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const membersRef = db.collection('members');
const checkInsRef = db.collection('checkIns');
const privateProfilesRef = db.collection('privateProfiles');
const summariesRef = db.collection('summaries');
const reportsRef = db.collection('reports');
const likesRef = db.collection('likes');
const postingAlertsRef = db.collection('postingAlerts');
const commentsRef = db.collection('comments');
const postsRef = db.collection('posts');
const pointsRef = db.collection('points');
const completedBasesRef = db.collection('completedBases');
const completedTitlesRef = db.collection('completedTitles');
const answeredQuestionnairesRef = db.collection('answeredQuestionnaires');
const completedWalksRef = db.collection('completedWalks');
const eventParticipationHistoriesRef = db.collection('eventParticipationHistories');
const completedCouponsRef = db.collection('completedCoupons');
const withdrawalsRef = db.collection('withdrawals');

/**
 * 会員削除時に起動するFunctionです。
 *
 * @remarks
 * 会員に紐づく各種関連情報を削除し、ランキングおよび会員数を更新します。
 * 会員情報（members）については deleteMember にて削除済みのため、ここでは処理しません。
 *
 * 削除処理としては、deletePost（投稿削除時をトリガーに起動するFunction）と重複する処理（投稿に紐づくコメント削除等）がありますが、
 * Functionの独立性を考慮して当該会員に紐づく関連情報を削除します。
 */
module.exports.deleteMemberRelation = region
  .firestore
  .document('members/{memberId}')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  .onDelete(triggerOnce('deleteMemberRelation', async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        const member = snapshot.data();
        console.log(`member=${JSON.stringify(member)}`);

        const memberDocRef = membersRef.doc(member.id);

        await db.runTransaction(async (transaction) => {

            // 削除対象のDocumentReference
            const deleteTargetDocRefs: Array<DocumentReference> = [];

            // チェックイン
            (await getQueryDocumentSnapshot(checkInsRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // プライベートプロフィール（ドキュメントID = 会員ID）
            const privateProfileDocRef = privateProfilesRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(privateProfileDocRef);

            // ランキング（ドキュメントID = 会員ID）
            const rankingDocRef = summariesRef.doc('mevalAppSummaries').collection('rankings').doc(memberDocRef.id);
            deleteTargetDocRefs.push(rankingDocRef);

            // 行政報告
            (await getQueryDocumentSnapshot(reportsRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // いいね
            (await getQueryDocumentSnapshot(likesRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // 通報
            (await getQueryDocumentSnapshot(postingAlertsRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // コメント
            (await getQueryDocumentSnapshot(commentsRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // 投稿
            (await getQueryDocumentSnapshot(postsRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // ポイント（ドキュメントID = 会員ID）
            const pointDocRef = pointsRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(pointDocRef);

            // ポイント獲得履歴
            const pointHistoriesRef = pointDocRef.collection('pointHistories');
            (await pointHistoriesRef.listDocuments())
              .forEach((doc) => {
                deleteTargetDocRefs.push(doc);
              });

            // 拠点制覇情報（ドキュメントID = 会員ID）
            const completedBaseDocRef = completedBasesRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(completedBaseDocRef);

            // 拠点制覇情報（親拠点）
            const completedParentBasesRef = completedBaseDocRef.collection('completedParentBases');
            for (const queryDocSnap of (await getQueryDocumentSnapshot(completedParentBasesRef, transaction, memberDocRef))) {
              deleteTargetDocRefs.push(queryDocSnap.ref);

              // 拠点制覇情報（サブ拠点）
              const completedSubBasesRef = queryDocSnap.ref.collection('completedSubBases');
              (await getQueryDocumentSnapshot(completedSubBasesRef, transaction, memberDocRef))
                .forEach((completedSubBaseQueryDocSnap) => {
                  deleteTargetDocRefs.push(completedSubBaseQueryDocSnap.ref);
                });
            }

            // 称号獲得情報（ドキュメントID = 会員ID）
            const completedTitleDocRef = completedTitlesRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(completedTitleDocRef);

            // 称号獲得履歴
            const titleHistoriesRef = completedTitleDocRef.collection('titleHistories');
            (await getQueryDocumentSnapshot(titleHistoriesRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // アンケート回答情報（ドキュメントID = 会員ID）
            const answeredQuestionnaireDocRef = answeredQuestionnairesRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(answeredQuestionnaireDocRef);

            // アンケート回答履歴
            const questionnaireHistoriesRef = answeredQuestionnaireDocRef.collection('questionnaireHistories');
            (await getQueryDocumentSnapshot(questionnaireHistoriesRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // ウォーク達成情報（ドキュメントID = 会員ID）
            const completedWalkDocRef = completedWalksRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(completedWalkDocRef);

            // ウォーク達成履歴
            const walkHistoriesRef = completedWalkDocRef.collection('walkHistories');
            (await getQueryDocumentSnapshot(walkHistoriesRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // イベント参加履歴（ドキュメントID = 会員ID）
            const eventParticipationHistoryDocRef = eventParticipationHistoriesRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(eventParticipationHistoryDocRef);

            // 参加イベント
            const participatedEventsRef = eventParticipationHistoryDocRef.collection('participatedEvents');
            for (const queryDocSnap of (await getQueryDocumentSnapshot(participatedEventsRef, transaction,
              memberDocRef))) {
              deleteTargetDocRefs.push(queryDocSnap.ref);

              // 達成地点
              const completedSpotsRef = queryDocSnap.ref.collection('completedSpots');
              (await getQueryDocumentSnapshot(completedSpotsRef, transaction, memberDocRef))
                .forEach((completedSpotQueryDocSnap) => {
                  deleteTargetDocRefs.push(completedSpotQueryDocSnap.ref);
                });
            }

            // クーポン獲得情報
            const completedCouponDocRef = completedCouponsRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(completedCouponDocRef);

            // クーポン獲得/使用履歴
            const couponHistoriesRef = completedCouponDocRef.collection('couponHistories');
            (await getQueryDocumentSnapshot(couponHistoriesRef, transaction, memberDocRef))
              .forEach((queryDocSnap) => {
                deleteTargetDocRefs.push(queryDocSnap.ref);
              });

            // 退会申請
            const withdrawalDocRef = withdrawalsRef.doc(memberDocRef.id);
            deleteTargetDocRefs.push(withdrawalDocRef);

            const summaryDocRef = summariesRef.doc('mevalAppSummaries');
            const summaryDocSnapshot = await transaction.get(summaryDocRef);
            const summary = summaryDocSnapshot.data();

            // ランキング設定
            await setRanking(transaction);

            if (summary) {
              // 会員数
              const memberDocs = await membersRef.listDocuments();
              const totalMember = memberDocs.length;

              // 会員数更新
              transaction.update(summaryDocRef, {
                totalMember: totalMember,
                updatedAt: FieldValue.serverTimestamp(),
              });
            }

            // 削除対象のドキュメント群を削除
            deleteTargetDocRefs.forEach((doc) => {
              transaction.delete(doc);
            });

          }
        );
      },
    )
  );

/**
 * {@link collectionReference} において、{@link memberDocRef} のreference（フィールド名：memberRef）を持つ {@link QueryDocumentSnapshot} を返却します。
 *
 * @param collectionReference コレクションリファレンス
 * @param transaction トランザクション
 * @param memberDocRef 削除対象会員のリファレンス
 */
async function getQueryDocumentSnapshot(collectionReference: CollectionReference, transaction: Transaction,
                                        memberDocRef: DocumentReference): Promise<QueryDocumentSnapshot[]> {
  const query = collectionReference.where('memberRef', '==', memberDocRef);
  const querySnap = await transaction.get(query);
  return querySnap.docs;
}

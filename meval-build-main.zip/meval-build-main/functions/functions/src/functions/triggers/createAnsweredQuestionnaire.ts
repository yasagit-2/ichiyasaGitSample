import { db, region, triggerOnce } from '../commons/commonFunctions';
import { firestore } from 'firebase-admin';
import { getPointBeforeEarning, updatePoint } from '../commons/pointFunctions';
import { EventContext } from 'firebase-functions';
import FieldValue = firestore.FieldValue;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const adminQuestionnairesRef = db.collection('adminQuestionnaires');
const pointsRef = db.collection('points');
const answeredQuestionnairesRef = db.collection('answeredQuestionnaires');

/**
 * アンケート回答情報生成時に起動するFunctionです。
 *
 * @remarks
 * ポイントを付与し、ポイント履歴を作成します。既にポイント履歴が存在（ポイント履歴IDが存在）する場合、ポイント付与を行わず処理を終了します。
 * 当該アンケートにおける、ポイント付与可能な制限人数の残りをデクリメントします。
 * 既にポイント付与可能な制限人数に到達している場合、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 * 獲得ポイントが0の場合も同様に、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 *
 * 上記ポイント関連処理に加え、アンケート選択肢の回答数をカウントアップします。
 */
module.exports.createAnsweredQuestionnaire = region
  .firestore
  .document('answeredQuestionnaires/{memberId}/questionnaireHistories/{answeredQuestionnaireId}')
  .onCreate(triggerOnce('createAnsweredQuestionnaire',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        const answeredQuestionnaire = snapshot.data();
        console.log(`answeredQuestionnaire=${JSON.stringify(answeredQuestionnaire)}`);

        // 付与するポイント
        let point = snapshot.data().point;
        console.log(`point=${point}`);

        // アンケートのID
        const answeredQuestionnaireId = snapshot.id;
        console.log(`answeredQuestionnaireId=${answeredQuestionnaireId}`);
        // アンケート回答した選択肢のID
        const choiceId = answeredQuestionnaire.choiceId;
        console.log(`choiceId=${choiceId}`);

        const memberId = answeredQuestionnaire.memberRef.id;
        console.log(`memberId=${memberId}`);

        await db.runTransaction(async (transaction) => {

            const questionnaireTransactionDocRef = adminQuestionnairesRef.doc(answeredQuestionnaireId)
              .collection('questionnaireTransactions')
              .doc('questionnaireTransaction');

            const questionnaireTransactionDocSnapshot = await transaction.get(questionnaireTransactionDocRef);
            const questionnaireTransaction = questionnaireTransactionDocSnapshot.data();
            if (!questionnaireTransaction) {
              console.log('questionnaireTransaction is not found.');
              return;
            }

            const choiceDocRef = adminQuestionnairesRef.doc(answeredQuestionnaireId)
              .collection('choices').doc(choiceId);
            const choiceDocSnapshot = await transaction.get(choiceDocRef);
            if (!choiceDocSnapshot.exists) {
              console.log('choice is not found.');
              return;
            }

            // 当該会員のポイント取得
            const pointDocRef = pointsRef.doc(memberId);

            // ポイント履歴ID（会員ID_行政投稿（アンケート）ID）
            const pointHistoryId = `${memberId}_${answeredQuestionnaireId}`;
            const pointHistoryDocRef = pointDocRef.collection('pointHistories').doc(pointHistoryId);

            // 現在（更新前）のポイント数
            const pointBeforeEarning = await getPointBeforeEarning(transaction, memberId, pointHistoryId);
            if (pointBeforeEarning === -1) {
              // 既にポイント獲得履歴が存在するため終了
              return;
            }

            // ポイント付与制限人数残り
            const pointLimitRemain = questionnaireTransaction.pointLimitRemain;

            // true:ポイント付与の処理を実行する
            const isIncrementPoint = point !== 0 && pointLimitRemain !== 0;

            // ポイント付与
            point = updatePoint(transaction, memberId, point, isIncrementPoint);

            // ポイント履歴作成
            transaction.set(pointHistoryDocRef, {
              point: point,
              pointBeforeEarning: pointBeforeEarning,
              // アンケート回答情報のリファレンス
              answeredQuestionnaireRef: answeredQuestionnairesRef.doc(memberId)
                .collection('questionnaireHistories')
                .doc(answeredQuestionnaireId),
              updatedAt: FieldValue.serverTimestamp(),
              createdAt: FieldValue.serverTimestamp(),
            });

            if (isIncrementPoint) {
              // ポイント付与可能人数をデクリメント
              // （ポイント付与を実行していない場合はデクリメントしない）
              transaction.update(questionnaireTransactionDocRef, {
                pointLimitRemain: FieldValue.increment(-1),
                updatedAt: FieldValue.serverTimestamp(),
              });
            }

            // アンケート回答選択肢をカウントアップ
            transaction.update(choiceDocRef, {
              answer: FieldValue.increment(1),
              updatedAt: FieldValue.serverTimestamp(),
            });

          }
        );
      }
    )
  );

import * as admin from 'firebase-admin';
import { firestore } from 'firebase-admin';
import { region, triggerOnce } from '../commons/commonFunctions';
import { EventContext } from 'firebase-functions';
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

/**
 * 行政報告削除時に起動するFunctionです。
 *
 * @remarks
 * 行政報告の投稿画像を削除します。
 */
module.exports.deleteReport = region
  .firestore
  .document('reports/{reportId}')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  .onDelete(triggerOnce('deleteReport', async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        try {
          // 行政報告の投稿画像を削除
          const imagePath = snapshot.data().imagePath;
          if (imagePath) {
            console.log(`delete target imagePath=${imagePath}`);
            await admin.storage().bucket().file(imagePath).delete();
          }
        } catch (e) {
          console.log(JSON.stringify(e));
        }

      }
    )
  );

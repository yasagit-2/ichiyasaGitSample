import { db, region, triggerOnce } from '../commons/commonFunctions';
import { firestore } from 'firebase-admin';
import { getPointBeforeEarning, updatePoint } from '../commons/pointFunctions';
import { EventContext } from 'firebase-functions';
import FieldValue = firestore.FieldValue;
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;

const basesRef = db.collection('bases');
const pointsRef = db.collection('points');
const completedBasesRef = db.collection('completedBases');

/**
 * 拠点制覇情報生成時に起動するFunctionです。
 *
 * @remarks
 * ポイントを付与し、ポイント履歴を作成します。既にポイント履歴が存在（ポイント履歴IDが存在）する場合、ポイント付与を行わず処理を終了します。
 * 当該拠点における、ポイント付与可能な制限人数の残りをデクリメントします。
 * 既にポイント付与可能な制限人数に到達している場合、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 * 獲得ポイントが0の場合も同様に、ポイント付与を行わず0ポイント獲得としてポイント履歴を作成します。
 */
module.exports.createCompletedBase = region
  .firestore
  .document('completedBases/{memberId}/completedParentBases/{completedParentBaseId}')
  .onCreate(triggerOnce('createCompletedBase',
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      async (snapshot: QueryDocumentSnapshot, _context: EventContext) => {

        const completedParentBase = snapshot.data();
        console.log(`completedParentBase=${JSON.stringify(completedParentBase)}`);

        // 付与するポイント
        let point = snapshot.data().point;
        console.log(`point=${point}`);

        const completedParentBaseId = snapshot.id;
        console.log(`completedParentBaseId=${completedParentBaseId}`);

        const memberId = completedParentBase.memberRef.id;
        console.log(`memberId=${memberId}`);

        await db.runTransaction(async (transaction) => {

            const baseTransactionDocRef = basesRef.doc(completedParentBaseId)
              .collection('baseTransactions')
              .doc('baseTransaction');

            const baseTransactionDocSnapshot = await transaction.get(baseTransactionDocRef);
            const baseTransaction = baseTransactionDocSnapshot.data();
            if (!baseTransaction) {
              console.log('baseTransaction is not found.');
              return;
            }

            // 当該会員のポイント取得
            const pointDocRef = pointsRef.doc(memberId);

            // ポイント履歴ID（会員ID_親の拠点ID）
            const pointHistoryId = `${memberId}_${completedParentBaseId}`;
            const pointHistoryDocRef = pointDocRef.collection('pointHistories').doc(pointHistoryId);

            // 現在（更新前）のポイント数
            const pointBeforeEarning = await getPointBeforeEarning(transaction, memberId, pointHistoryId);
            if (pointBeforeEarning === -1) {
              // 既にポイント獲得履歴が存在するため終了
              return;
            }

            // ポイント付与制限人数残り
            const pointLimitRemain = baseTransaction.pointLimitRemain;

            // true:ポイント付与の処理を実行する
            const isIncrementPoint = point !== 0 && pointLimitRemain !== 0;

            // ポイント付与
            point = updatePoint(transaction, memberId, point, isIncrementPoint);

            // ポイント履歴作成
            transaction.set(pointHistoryDocRef, {
              point: point,
              pointBeforeEarning: pointBeforeEarning,
              // 拠点制覇情報のリファレンス
              completedParentBaseRef: completedBasesRef.doc(memberId).collection('completedParentBases')
                .doc(completedParentBaseId),
              updatedAt: FieldValue.serverTimestamp(),
              createdAt: FieldValue.serverTimestamp(),
            });

            if (isIncrementPoint) {
              // ポイント付与可能人数をデクリメント
              // （ポイント付与を実行していない場合はデクリメントしない）
              transaction.update(baseTransactionDocRef, {
                pointLimitRemain: FieldValue.increment(-1),
                updatedAt: FieldValue.serverTimestamp(),
              });
            }

          }
        );
      }
    )
  );

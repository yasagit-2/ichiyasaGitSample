import * as functions from 'firebase-functions'

export const signInWithApple = functions.region('asia-northeast1').https.onRequest((request, response) => {
  const redirect = `intent://callback?${new URLSearchParams(
    request.body
  ).toString()}#Intent;package=${
    'jp.co.mki.meval-mki-enviroment' // applicationId of app/build.gradle
  };scheme=signinwithapple;end` 

  response.redirect(307, redirect)
})
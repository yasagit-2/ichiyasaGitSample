<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\GovernmentUser;

class GovernmentUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        GovernmentUser::create([
            'name' => '又吉',
            'email' => 'matayoshi@abridge-co.jp',
            'password' => 'P@ssw0rd',
        ]);
    }
}

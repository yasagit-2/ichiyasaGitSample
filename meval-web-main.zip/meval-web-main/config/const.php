<?php

$upload_image_extensions = ['jpeg', 'jpg', 'png', 'tiff', 'heic'];

return [

    // common
    'default_paginate_number' => 10,
    'default_text_maxlength' => 50,
    'default_textarea_maxlength' => 300,
    'default_url_maxlength' => 2000,
    'default_email_maxlength' => 254,
    'default_password_minlength' => 6,
    'default_password_maxlength' => 16,
    'default_version_maxlength' => 20,
    // 大文字・小文字を含めた半角英数字記号を、6文字以上16文字以内
    'password_regex' => '/^((?=.*[a-z])(?=.*[A-Z]))([a-zA-Z0-9\-+=^$*.\[\]{}()?\"!@#%&\/\\\\,><\':;|_~`\-+=]){6,16}$/',
    'weeks' => [
        0 => '日',
        1 => '月',
        2 => '火',
        3 => '水',
        4 => '木',
        5 => '金',
        6 => '土',
    ],
    'upload_max_filesize' => 10240,
    'upload_image_extensions' => $upload_image_extensions,
    'accept_image_extensions' => array_map(function ($value) {
        return '.' . $value;
    }, $upload_image_extensions),

    // base
    'base_statuses' => [
        0 => '未公開',
        1 => '公開済み',
        9 => '非公開',
    ],

    // event
    'event_use_locations' => [
        1 => '利用する',
        0 => '利用しない',
    ],
    'event_exchange_types' => [
        0 => 'ポイント',
        1 => 'チケット',
    ],

    'login_type' => [
        'param' => [
            'admin' => '1',
            'gov'   => '2',
            'shop'  => '3',
        ],
        'str' => [
            '1'     => '運用',
            '2'     => '行政',
            '3'     => '加盟店',
        ],
    ],

    // maintenance
    'maintenance_use_maintenances' => [
        0 => '無効',
        1 => '有効',
    ],

    // firebase 同時処理
    'firebase' => [
        'batch_size' => 100,
    ],


];

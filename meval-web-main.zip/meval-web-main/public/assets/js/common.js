$(document).on('submit', '.form-store', function() {
    let msg = $('#id').val() ? '情報を更新してもよろしいですか？' : '情報を登録してもよろしいですか？';
    if (!confirm(msg)) {
        return false;
    }
});

$(document).on('submit', '.form-update', function() {
    if (!confirm('情報を更新してもよろしいですか？')) {
        return false;
    }
});

$(document).on('submit', '.form-destroy', function() {
    if (!confirm('削除してもよろしいですか？')) {
        return false;
    }
});

$(document).on('submit', '.form-logout', function() {
    if (!confirm('ログアウトしますか？')) {
        return false;
    }
});

$(document).on('submit', '.form-cancel', function() {
    if (!confirm('キャンセルしますか？')) {
        return false;
    }
});

$(document).on('submit', '.form-push', function () {
    if (!confirm('プッシュ通知してもよろしいですか？')) {
        return false;
    }
});

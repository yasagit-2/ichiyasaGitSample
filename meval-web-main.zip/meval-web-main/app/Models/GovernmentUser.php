<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\SoftDeletes;

class GovernmentUser extends Authenticatable
{
    use HasUuid;

    // PRIMARY KEY uuid 設定
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;

    // Soft delete 設定
    // use SoftDeletes;
    // protected $table = 'government_users';
    // protected $dates = ['deleted_at'];

    protected $fillable = [
        'name',
        'email',
        'password'
    ];

    protected $hidden = [
        'password'
    ];

    public function setPasswordAttribute($value)
    {
        if (! empty($value)) {
            $this->attributes['password'] = \Hash::make($value);
        }
    }
}

<?php

namespace App\Services\Firebase;

class SettingService
{
    private $db;
    private $collection;

    private $collection_name = 'settings';
    private $document_id = 'mevalAppSettings';

    private $fields = [
        'baseIconUrl' => 'string',
        'baseCheckedInIconUrl' => 'string',
        'subBaseIconUrl' => 'string',
        'merchantIconUrl' => 'string',
        'merchantTweetIconUrl' => 'string',
        'postIconUrl' => 'string',
        'adminAlertIconUrl' => 'string',
        'adminQuestionnaireIconUrl' => 'string',
        'checkInRadius' => 'float',
        'collectionRadius' => 'float',
        'targetStepPerWeek' => 'number',
        'stepAchievedPoint' => 'number',
        'postIntervalLimitHour' => 'number',
        'reportIntervalLimitHour' => 'number',
        'commentIntervalLimitMinute' => 'number',
        'notificationRetentionDay' => 'number',
        'eventRetentionDay' => 'number',
        'memberDeletionGraceDay' => 'number',
        'tweetExpirationMinutes' => 'number',
        'helpPageUrl' => 'string',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    private $images = [
        'baseIcon' => 'base',
        'baseCheckedInIcon' => 'baseCheckedIn',
        'subBaseIcon' => 'subBase',
        'merchantIcon' => 'merchant',
        'merchantTweetIcon' => 'merchantTweet',
        'postIcon' => 'post',
        'adminAlertIcon' => 'adminAlert',
        'adminQuestionnaireIcon' => 'adminQuestionnaire',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(): object
    {
    	return $this->collection->document($this->document_id);
    }

    public function store(array $setting): void
    {
        // image
        $dir = 'icons'; // for debug
        foreach ($this->images as $attribute_name => $file_name) {
            if (request()->file($attribute_name)) {
                $image = $this->storage->uploadImage($dir, $file_name, request()->file($attribute_name));
                $setting[$attribute_name . 'Url'] = $image['imageUrl'];
            }
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $setting);
        $response = $this->collection->document($this->document_id)->set($store_data);

    }

    public function update(array $setting, object $snapshot): void
    {
        // image
        $dir = 'icons';
        foreach ($this->images as $attribute_name => $file_name) {
            if (request()->file($attribute_name)) {
                $image = $this->storage->uploadImage($dir, $file_name, request()->file($attribute_name));
                $setting[$attribute_name . 'Url'] = $image['imageUrl'];
            }
        }

        $update_data = $this->firestore->makeUpdateData($this->fields, $setting, $snapshot);
        $response = $this->collection->document($this->document_id)->update($update_data);
    }

    // public function destroy(): void
    // {
    // 	$response = $this->collection->document($this->document_id)->delete();
    // }

}

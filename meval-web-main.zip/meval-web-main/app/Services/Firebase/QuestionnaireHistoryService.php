<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class QuestionnaireHistoryService
{
    private $db;
    private $collection;

    private $collection_name = 'questionnaireHistories';

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function find(string $id): object
    {
        $query = $this->db->collectionGroup('questionnaireHistories')->where('id', '==', $id);
        $documents = $query->documents();
        return $documents;
    }

}

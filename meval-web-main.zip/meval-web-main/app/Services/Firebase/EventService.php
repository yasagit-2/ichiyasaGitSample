<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class EventService
{
    private $db;
    private $collection;

    private $collection_name = 'events';

    private $fields = [
        'id' => 'string',
        'title' => 'string',
        'imageUrl' => 'string',
        'effectivePeriodBegin' => 'timestamp',
        'effectivePeriodEnd' => 'timestamp',
        'eventIconUrl' => 'string',
        'completeSpotIconUrl' => 'string',
        'completeSpotCount' => 'number',
        'isUseLocation' => 'boolean',
        'qrCodeRadius' => 'float',
        'point' => 'number',
        'exchangeLimit' => 'number',
        'exchangeType' => 'number',
        'eventSpotCount' => 'number',
        'position' => 'array',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $transaction_fields = [
        'exchangeLimitRemain' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $images = [
        'image' => 'image',
        'eventIcon' => 'event',
        'completeSpotIcon' => 'completeSpot',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $event): void
    {
        $event['id'] = (string) Str::uuid();
        $event['completeSpotCount'] = 1;
        $event['eventSpotCount'] = 1;
        $event['position'] = $this->firestore->getPosition($event['positionLatitude'], $event['positionLongitude']);
        if ($event['isUseLocation'] == 0) {
            $event['qrCodeRadius'] = 0;
        }
        if ($event['exchangeType'] == 1 ) {
            $event['point'] = 0;
        }

        // upload image
        $dir = $this->collection_name . '/' . $event['id'];
        $event['eventIconUrl'] = ''; // フィールドは必須なので空文字を設定
        $event['completeSpotIconUrl'] = '';  // フィールドは必須なので空文字を設定
        foreach ($this->images as $attribute_name => $file_name) {
            if (request()->file($attribute_name)) {
                $image = $this->storage->uploadImage($dir, $file_name, request()->file($attribute_name));
                $event[$attribute_name . 'Url'] = $image['imageUrl'];
            }
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $event);
        $this->collection->document($event['id'])->set($store_data);

        // イベントスポット
        $event_spot = app()->make(EventSpotService::class);
        $event_spot->setEventId($event['id']);
        $event_spot->store($event['eventSpots'][0]);

        // サブコレクション
        $transaction_store_data = $this->firestore->makeStoreData(
            $this->transaction_fields,
            ['exchangeLimitRemain' => $event['exchangeLimit']]
        );
        $this->collection->document($event['id'])
            ->collection('eventTransactions')->document('eventTransaction')->set($transaction_store_data);
    }

    public function update(array $event, object $snapshot): void
    {
        $event['position'] = $this->firestore->getPosition($event['positionLatitude'], $event['positionLongitude']);
        if ($event['isUseLocation'] == 0) {
            $event['qrCodeRadius'] = 0;
        }
        if ($event['exchangeType'] == 1 ) {
            $event['point'] = 0;
        }

        // delete image
        if (! empty($event['imageDelete'])) {
            $event['imageUrl'] = null; // フィールド自体削除する場合はnull
        }
        if (! empty($event['eventIconDelete'])) {
            $event['eventIconUrl'] = ''; // フィールドを残す場合は空文字
        }
        if (! empty($event['completeSpotIconDelete'])) {
            $event['completeSpotIconUrl'] = ''; // フィールドを残す場合は空文字
        }

        // upload image
        $dir = $this->collection_name . '/' . $snapshot['id'];
        foreach ($this->images as $attribute_name => $file_name) {
            if (request()->file($attribute_name)) {
                $image = $this->storage->uploadImage($dir, $file_name, request()->file($attribute_name));
                $event[$attribute_name . 'Url'] = $image['imageUrl'];
            }
        }

        $update_data = $this->firestore->makeUpdateData($this->fields, $event, $snapshot);
        $this->collection->document($snapshot['id'])->update($update_data);

        // サブコレクション
        // TODO 更新時にトランザクションも更新するか？
        // if (array_key_exists('exchangeLimit', $event)) {
        //     $transaction_update_data = $this->firestore->makeUpdateData(
        //         $this->transaction_fields,
        //         ['exchangeLimitRemain' => $event['exchangeLimit']]
        //     );
        //     $transaction_response = $this->collection->document($snapshot['id'])
        //         ->collection('eventTransactions')->document('eventTransaction')->update($transaction_update_data);
        // }
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // サブコレクションの削除
        $this->firestore->destroySubCollections($document, ['eventTransactions', 'eventSpots']);

        // image削除
        $dir = $this->collection_name . '/' . $id;
        $this->storage->deleteDir($dir);

        $document->delete();
    }

}

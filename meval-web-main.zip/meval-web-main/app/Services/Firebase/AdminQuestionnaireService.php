<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class AdminQuestionnaireService
{
    private $db;
    private $collection;

    private $collection_name = 'adminQuestionnaires';

    private $fields = [
        'id' => 'string',
        'message' => 'string',
        'position' => 'array',
        'dueDate' => 'timestamp',
        'imageUrl' => 'string',
        'imagePath' => 'string',
        'point' => 'number',
        'pointLimit' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $choice_fields = [
        'id' => 'string',
        'choice' => 'string',
        'displayOrder' => 'number',
        'answer' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $transaction_fields = [
        'pointLimitRemain' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $admin_questionnaire): void
    {
        $admin_questionnaire['id'] = (string) Str::uuid();
        $admin_questionnaire['position'] = $this->firestore->getPosition($admin_questionnaire['positionLatitude'], $admin_questionnaire['positionLongitude']);

        // upload image
        if (request()->file('image')) {
            $admin_questionnaire += $this->storage->uploadImage($this->collection_name, $admin_questionnaire['id'], request()->file('image'));
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $admin_questionnaire);
        $this->collection->document($admin_questionnaire['id'])->set($store_data);

        // アンケート選択肢
        for ($i = 0; $i < 5; $i++) {
            if ($admin_questionnaire['choices'][$i]['choice'] !== null) {
                $choice = [
                    'id' => (string) Str::uuid(),
                    'choice' => $admin_questionnaire['choices'][$i]['choice'],
                    'displayOrder' => $i,
                    'answer' => 0,
                ];
                $choice_store_data = $this->firestore->makeStoreData($this->choice_fields, $choice);
                $this->collection->document($admin_questionnaire['id'])
                    ->collection('choices')->document($choice['id'])->set($choice_store_data);
            }
        }

        // サブコレクション
        $transaction_store_data = $this->firestore->makeStoreData(
            $this->transaction_fields,
            ['pointLimitRemain' => $admin_questionnaire['pointLimit']]
        );
        $this->collection->document($admin_questionnaire['id'])
            ->collection('questionnaireTransactions')->document('questionnaireTransaction')->set($transaction_store_data);
    }

    public function update(array $admin_questionnaire, object $snapshot): void
    {
        $admin_questionnaire['position'] = $this->firestore->getPosition($admin_questionnaire['positionLatitude'], $admin_questionnaire['positionLongitude']);

        // delete image
        if (! empty($admin_questionnaire['imageDelete'])) {
            $admin_questionnaire['imageUrl'] = null;
            $admin_questionnaire['imagePath'] = null;
        }

        // upload image
        if (request()->file('image')) {
            $image = $this->storage->uploadImage($this->collection_name, $snapshot['id'], request()->file('image'));
            $admin_questionnaire['imageUrl'] = $image['imageUrl'];
            $admin_questionnaire['imagePath'] = $image['imagePath'];
        }

        $update_data = $this->firestore->makeUpdateData($this->fields, $admin_questionnaire, $snapshot);
        $this->collection->document($snapshot['id'])->update($update_data);

        // アンケート選択肢
        $batch = $this->db->batch();
        for ($i = 0; $i < 5; $i++) {
            $choice = $admin_questionnaire['choices'][$i];

            // 更新 or 削除
            if ($choice['id'] !== null) {
                $ref = $this->collection->document($admin_questionnaire['id'])
                    ->collection('choices')->document($choice['id']);

                // 更新
                if ($choice['choice'] !== null) {
                    $choice_update_data = $this->firestore->makeUpdateData($this->choice_fields, $choice);
                    $batch->update($ref, $choice_update_data);

                // 削除
                } else {
                    $batch->delete($ref);
                }

            // 登録
            } else {
                $choice['id'] = (string) Str::uuid();
                $choice['displayOrder'] = $i;
                $choice['answer'] = 0;
                $choice_store_data = $this->firestore->makeStoreData($this->choice_fields, $choice);
                $ref = $this->collection->document($admin_questionnaire['id'])
                    ->collection('choices')->document($choice['id']);
                $batch->set($ref, $choice_store_data);
            }
        }
        $batch->commit();

        // サブコレクション
        // TODO 更新時にトランザクションも更新するか？
        // if (array_key_exists('pointLimit', $admin_questionnaire)) {
        //     $transaction_update_data = $this->firestore->makeUpdateData(
        //         $this->transaction_fields,
        //         ['pointLimitRemain' => $admin_questionnaire['pointLimit']]
        //     );
        //     $transaction_response = $this->collection->document($snapshot['id'])
        //         ->collection('questionnaireTransactions')->document('questionnaireTransaction')->update($transaction_update_data);
        // }
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // サブコレクションの削除
        $this->firestore->destroySubCollections($document, ['questionnaireTransactions', 'choices']);

        // delete image
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        // コレクションの削除
        $document->delete();
    }

}

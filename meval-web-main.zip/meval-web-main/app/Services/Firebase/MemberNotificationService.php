<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class MemberNotificationService
{
    private $db;
    private $collection;

    private $collection_name = 'memberNotifications';

    private $fields = [
        'id' => 'string',
        'title' => 'string',
        'contentUrl' => 'string',
        'effectivePeriodBegin' => 'timestamp',
        'effectivePeriodEnd' => 'timestamp',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $member_notification): void
    {
        $member_notification['id'] = (string) Str::uuid();

        $store_data = $this->firestore->makeStoreData($this->fields, $member_notification);
        $response = $this->collection->document($member_notification['id'])->set($store_data);
    }

    public function update(array $member_notification, object $snapshot): void
    {
        $update_data = $this->firestore->makeUpdateData($this->fields, $member_notification, $snapshot);
        $response = $this->collection->document($snapshot['id'])->update($update_data);
    }

    public function destroy(string $id): void
    {
        $response = $this->collection->document($id)->delete();
    }

}

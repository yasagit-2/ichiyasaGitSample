<?php

namespace App\Services\Firebase;

class PostService
{
    private $db;
    private $collection;

    private $collection_name = 'posts';

    private $fields = [
        // WEBから更新対象のみ記載
        'visibleStatus' => 'number',
        'updatedAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function update(array $post, object $snapshot): void
    {
        $post_update_data = $this->firestore->makeUpdateData($this->fields, $post, $snapshot);
        $response = $this->collection->document($snapshot->id())->update($post_update_data);
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // image削除
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        $response = $document->delete();
    }

}

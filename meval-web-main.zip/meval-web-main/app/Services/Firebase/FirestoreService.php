<?php

namespace App\Services\Firebase;

use Carbon\Carbon;
use Google\Cloud\Core\GeoPoint;
use Sk\Geohash\Geohash;
use Google\Cloud\Firestore\FieldValue;
use Google\Cloud\Core\Timestamp;
class FirestoreService
{
    private $db;
    public function __construct() {
        $this->db = app('firebase.firestore')->database();
    }

    public function getDatabase()
    {
        return  $this->db;
    }

    public function makeStoreData(array $fields, array $values): array
    {
        $response = [];
        foreach ($values as $key => $val) {
            if (array_key_exists($key, $fields)) {
                // null=入力していないとして省略
                if ($val === null) {
                    continue;
                }
                $response[$key] = $this->cast($fields[$key], $key, $val);
            }
        }

        // コレクションに必要なデータ生成
        if (array_key_exists('updatedAt', $fields)) {
            $response['updatedAt'] = FieldValue::serverTimestamp();
        }
        if (array_key_exists('createdAt', $fields)) {
            $response['createdAt'] = FieldValue::serverTimestamp();
        }

        return $response;
    }

    public function makeUpdateData(array $fields, array $values, object $snapshot = null): array
    {
        $response = [];
        foreach ($values as $key => $val) {
            if (array_key_exists($key, $fields)) {

                // $snapshotではフィールドがあるが、$valuesではnullとなっているもの => フィールド削除
                if ($snapshot !== null && isset($snapshot[$key]) && $val === null) {
                    $response[] = [
                        'path' => $key,
                        'value' => FieldValue::deleteField(),
                    ];

                // $snapshotでフィールドがなく、$valuesでもnullとなっているもの => 更新しない=continue
                } else if ($val === null) {
                    continue;

                } else {
                    $response[] = [
                        'path' => $key,
                        'value' => $this->cast($fields[$key], $key, $val),
                    ];
                }
            }
        }

        // コレクションに必要なデータ生成
        if (array_key_exists('updatedAt', $fields)) {
            $response[] = [
                'path' => 'updatedAt',
                'value' => FieldValue::serverTimestamp(),
            ];
        }

        return $response;
    }

    public function getPosition(float $lat, float $lng): array
    {
        $g = new Geohash();
        $geohash = $g->encode($lat, $lng, 9);
        $geopoint = new GeoPoint($lat, $lng);
        return ['geohash' => $geohash, 'geopoint' => $geopoint];
    }

    public function toArrays(object $documents): array
    {
        $response = [];
        foreach ($documents as $document) {
            $temp = [];
            if ($document->exists()) {
                $temp['id'] = $document->id();
                foreach (array_keys($document->data()) as $key) {
                    $temp[$key] = $document->data()[$key];
                }
                $response[] = $temp;
            }
        }
        return $response;
    }

    public function toCollections(object $documents): object
    {
        return collect($this->toArrays($documents));
    }

    public function destroySubCollections(object $target, array $sub_collection_names) {
        foreach($sub_collection_names as $sub_collection_name) {
            //サブコレクションの削除
            $documents = $target->collection($sub_collection_name)->limit(config('const.firebase.batch_size'))->documents();
            while (!$documents->isEmpty()) {
                foreach ($documents as $document) {
                    $document->reference()->delete();
                }
                $documents = $target->collection($sub_collection_name)->limit(config('const.firebase.batch_size'))->documents();
            }
        }
    }

    private function cast(string $type, string $key, mixed $val): mixed
    {
        switch ($type) {
            case 'number':
                $response = (int) $val;
                break;
            case 'float':
            case 'double':
                $response = (float) $val;
                break;
            case 'timestamp':
                // 期間終了系は23:59:59とする
                switch ($key) {
                    case 'effectivePeriodEnd':
                    case 'publicationPeriodEnd':
                    case 'dueDate':
                        $timestamp = Carbon::parse($val)->endOfDay();
                        break;
                    default:
                        $timestamp = Carbon::parse($val);
                }
                $response = new Timestamp($timestamp);
                break;
            case 'boolean':
                $response = (bool) $val;
                break;
            case 'array': // TODO 型定義してからキャストではないので要検討
                array_walk($val, function (&$item) {
                    if (is_numeric($item)) {
                        $item = (int) $item;
                    }
                });
                $response = $val;
                break;
            default: // stringもここを通る想定
                $response = $val;
        }
        return $response;
    }

}

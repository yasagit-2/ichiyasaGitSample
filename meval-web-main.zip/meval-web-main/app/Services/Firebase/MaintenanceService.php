<?php

namespace App\Services\Firebase;

class MaintenanceService
{
    private $db;
    private $collection;

    private $collection_name = 'maintenances';
    private $document_id = 'maintenance';

    private $fields = [
        'version' => 'string',
        'appStoreUrl' => 'string',
        'playStoreUrl' => 'string',
        'isMaintenance' => 'boolean',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(): object
    {
    	return $this->collection->document($this->document_id);
    }

    public function store(array $maintenance): void
    {
        $store_data = $this->firestore->makeStoreData($this->fields, $maintenance);
        $response = $this->collection->document($this->document_id)->set($store_data);

    }

    public function update(array $maintenance, object $snapshot): void
    {
        $update_data = $this->firestore->makeUpdateData($this->fields, $maintenance, $snapshot);
        $response = $this->collection->document($this->document_id)->update($update_data);
    }

    // public function destroy(): void
    // {
    // 	$response = $this->collection->document($this->document_id)->delete();
    // }

}

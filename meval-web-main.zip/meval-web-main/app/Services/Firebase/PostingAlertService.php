<?php

namespace App\Services\Firebase;

class PostingAlertService
{
    private $db;
    private $collection;

    private $collection_name = 'postingAlerts';

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $query = $this->collection;

        if (array_key_exists('post_id', $conditions)) {
            $post = app()->make(PostService::class);
            $query = $query->where('postRef', '=', $post->get($conditions['post_id']));
        }

        $documents = $query->documents();

        return $documents;
    }

}

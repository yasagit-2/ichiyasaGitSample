<?php

namespace App\Services\Firebase;

use Kreait\Firebase\Contract\Messaging;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

use Illuminate\Support\Str;

class PushNotificationService
{
    private $db;
    private $collection;

    private $collection_name = 'pushNotifications';

    private $fields = [
        'id' => 'string',
        'title' => 'string',
        'body' => 'string',
        'topic' => 'string',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage, private Messaging $messaging)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
        $this->messaging = $messaging;
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $push_notification): void
    {
        $push_notification['id'] = (string) Str::uuid();

        $store_data = $this->firestore->makeStoreData($this->fields, $push_notification);
        $response = $this->collection->document($push_notification['id'])->set($store_data);
    }

    public function update(array $push_notification, object $snapshot): void
    {
        $update_data = $this->firestore->makeUpdateData($this->fields, $push_notification, $snapshot);
        $response = $this->collection->document($snapshot['id'])->update($update_data);
    }

    public function destroy(string $id): void
    {
        $response = $this->collection->document($id)->delete();
    }

    public function push(string $topic, string $title, string $body): void
    {
        try {
            // 通知メッセージ作成
            $message = CloudMessage::withTarget('topic', $topic)
                ->withNotification(Notification::create($title, $body));

            // 以下は追加の通知オプション
            // https://firebase-php.readthedocs.io/en/stable/cloud-messaging.html
            // Android固有
            // ->withAndroidConfig()
            // iOS固有
            // ->withApnsConfig()
            // Web固有
            // ->withWebPushConfig()
            // アイコン
            // ->withNotification()
            // 優先度
            // ->withHighestPossiblePriority()
            // ->withLowestPossiblePriority()

            // ログ出力
            logger()->info($message->jsonSerialize());

            // 通知を送信
            $this->messaging->send($message);
        } catch (\Exception $e) {
            logger()->error($e->getMessage());
        }
    }
}

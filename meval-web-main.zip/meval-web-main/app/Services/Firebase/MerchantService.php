<?php

namespace App\Services\Firebase;

class MerchantService
{
    private $db;
    private $collection;

    private $collection_name = 'merchants';

    private $fields = [
        'id' => 'string',
        'name' => 'string',
        'imageUrl' => 'string',
        'imagePath' => 'string',
        'position' => 'array',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $merchant): void
    {
        $merchant['position'] = $this->firestore->getPosition($merchant['positionLatitude'], $merchant['positionLongitude']);

        // upload image
        if (request()->file('image')) {
            $merchant += $this->storage->uploadImage($this->collection_name, $merchant['id'], request()->file('image'));
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $merchant);
        $this->collection->document($merchant['id'])->set($store_data);
    }

    public function update(array $merchant, object $snapshot): void
    {
        $merchant['position'] = $this->firestore->getPosition($merchant['positionLatitude'], $merchant['positionLongitude']);

        // delete image
        if (! empty($merchant['imageDelete'])) {
            $merchant['imageUrl'] = null;
            $merchant['imagePath'] = null;
        }

        // upload image
        if (request()->file('image')) {
            $image = $this->storage->uploadImage($this->collection_name, $snapshot['id'], request()->file('image'));
            $merchant['imageUrl'] = $image['imageUrl'];
            $merchant['imagePath'] = $image['imagePath'];
        }
        $merchant_update_data = $this->firestore->makeUpdateData($this->fields, $merchant, $snapshot);
        $this->collection->document($merchant['id'])->update($merchant_update_data);
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // サブコレクションの削除
        $sub_documents = $document->collection('coupons')->limit(config('const.firebase.batch_size'))->documents();
        while (! $sub_documents->isEmpty()) {
            foreach ($sub_documents as $sub_document) {
                // サブサブコレクションの削除
                $sub_document->reference()->collection('couponTransactions')->document('couponTransaction')->delete();
                $sub_document->reference()->delete();
            }
            $sub_documents = $document->collection('coupons')->limit(config('const.firebase.batch_size'))->documents();
        }

        // delete image
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        // 関連するコレクションからも削除
        $tweet_ref = app()->make(TweetService::class);
        $tweet_ref->destroy($id); // 1加盟店1つぶやき（merchent.id = tweet.id）

        // コレクションの削除
        $document->delete();
    }

}

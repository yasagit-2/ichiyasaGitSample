<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class TitleService
{
    private $db;
    private $collection;

    private $collection_name = 'titles';

    private $fields = [
        'id' => 'string',
        'name' => 'string',
        'point' => 'number',
        'pointLimit' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $transaction_fields = [
        'pointLimitRemain' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $title): void
    {
        $title['id'] = (string) Str::uuid();

        $store_data = $this->firestore->makeStoreData($this->fields, $title);
        $response = $this->collection->document($title['id'])->set($store_data);

        // サブコレクション
        $transaction_store_data = $this->firestore->makeStoreData(
            $this->transaction_fields,
            ['pointLimitRemain' => $title['pointLimit']]
        );
        $transaction_response = $this->collection->document($title['id'])
            ->collection('titleTransactions')->document('titleTransaction')->set($transaction_store_data);
    }

    public function update(array $title, object $snapshot): void
    {
        $title_update_data = $this->firestore->makeUpdateData($this->fields, $title, $snapshot);
        $response = $this->collection->document($title['id'])->update($title_update_data);

        // サブコレクション
        // TODO 更新時にトランザクションも更新するか？
        // if (array_key_exists('pointLimit', $title)) {
        //     $transaction_update_data = $this->firestore->makeUpdateData(
        //         $this->transaction_fields,
        //         ['pointLimitRemain' => $title['pointLimit']]
        //     );
        //     $transaction_response = $this->collection->document($snapshot['id'])
        //         ->collection('titleTransactions')->document('titleTransaction')->update($transaction_update_data);
        // }
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // サブコレクションの削除
        $this->firestore->destroySubCollections($document, ['titleTransactions']);

        // コレクションの削除
        $response = $document->delete();
    }

}

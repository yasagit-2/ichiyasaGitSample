<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class CouponService
{
    private $db;
    private $collection;

    private $parent_collection_name = 'merchants';
    private $collection_name = 'coupons';
    private $merchant_id;

    private $fields = [
        'id' => 'string',
        'merchantId' => 'string',
        'name' => 'string',
        'exchangePoint' => 'number',
        'exchangeLimit' => 'number',
        'dueDate' => 'timestamp',
        'publicationPeriodBegin' => 'timestamp',
        'publicationPeriodEnd' => 'timestamp',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $transaction_fields = [
        'exchangeLimitRemain' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->parent_collection_name);
    }

    public function setMerchantId(string $merchant_id): void
    {
        $this->merchant_id = $merchant_id;
        $this->collection = $this->collection
            ->document($this->merchant_id)->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $coupon): void
    {
        $coupon['id'] = (string) Str::uuid();
        $coupon['merchantId'] = $this->merchant_id;

        $store_data = $this->firestore->makeStoreData($this->fields, $coupon);
        $response = $this->collection->document($coupon['id'])->set($store_data);

        // サブコレクション
        $transaction_update_data = $this->firestore->makeStoreData(
            $this->transaction_fields,
            ['exchangeLimitRemain' => $coupon['exchangeLimit']]
        );
        $sub_response = $this->collection->document($coupon['id'])
            ->collection('couponTransactions')->document('couponTransaction')->set($transaction_update_data);
    }

    public function update(array $coupon, object $snapshot): void
    {
        $update_data = $this->firestore->makeUpdateData($this->fields, $coupon, $snapshot);
        $response = $this->collection->document($snapshot['id'])->update($update_data);

        // サブコレクション
        if (array_key_exists('exchangeLimit', $coupon)) {
            $transaction_update_data = $this->firestore->makeUpdateData(
                $this->transaction_fields,
                ['exchangeLimitRemain' => $coupon['exchangeLimit']]
            );
            $transaction_response = $this->collection->document($snapshot['id'])
                ->collection('couponTransactions')->document('couponTransaction')->update($transaction_update_data);
        }
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // サブコレクションの削除
        $this->firestore->destroySubCollections($document, ['couponTransactions']);

        $response = $document->delete();
    }

}

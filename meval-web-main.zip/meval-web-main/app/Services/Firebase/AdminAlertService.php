<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class AdminAlertService
{
    private $db;
    private $collection;

    private $collection_name = 'adminAlerts';

    private $fields = [
        'id' => 'string',
        'message' => 'string',
        'position' => 'array',
        'dueDate' => 'timestamp',
        'imageUrl' => 'string',
        'imagePath' => 'string',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $admin_alert): void
    {
        $admin_alert['id'] = (string) Str::uuid();
        $admin_alert['position'] = $this->firestore->getPosition($admin_alert['positionLatitude'], $admin_alert['positionLongitude']);

        // upload image
        if (request()->file('image')) {
            $admin_alert += $this->storage->uploadImage($this->collection_name, $admin_alert['id'], request()->file('image'));
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $admin_alert);
        $response = $this->collection->document($admin_alert['id'])->set($store_data);
    }

    public function update(array $admin_alert, object $snapshot): void
    {
        $admin_alert['position'] = $this->firestore->getPosition($admin_alert['positionLatitude'], $admin_alert['positionLongitude']);

        // delete image
        if (! empty($admin_alert['imageDelete'])) {
            $admin_alert['imageUrl'] = null;
            $admin_alert['imagePath'] = null;
        }

        // upload image
        if (request()->file('image')) {
            $admin_alert += $this->storage->uploadImage($this->collection_name, $snapshot->id(), request()->file('image'));
        }

        $admin_alert_update_data = $this->firestore->makeUpdateData($this->fields, $admin_alert, $snapshot);
        $this->collection->document($snapshot->id())->update($admin_alert_update_data);
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // delete image
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        // delete collection
        $document->delete();

    }

}

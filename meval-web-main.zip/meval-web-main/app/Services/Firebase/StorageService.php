<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class StorageService
{
    private $storage;
    public function __construct() {
        $this->storage = app('firebase.storage');
    }

    // public function getStorage()
    // {
    //     return $this->storage;
    // }

    public function getBucket(): object
    {
        return $this->storage->getBucket();
    }

    public function uploadImage(string $dir, string $name, object $image): array
    {
        $ext =  $image->getClientOriginalExtension();
        $path = $dir . '/' . Str::snake($name) . '.' . $ext; // settingsコレクションではスネークケースで保存されていたため統一
        $token = (string) Str::uuid();

        $bucket = $this->getBucket();

        $file = fopen($image->getPathName(), 'r');
        $object = $bucket->upload($file, [
            'name' => $path,
            'metadata' => [
                'metadata' => [
                    'firebaseStorageDownloadTokens' => $token,
                ],
            ],
        ]);

        // TODO 旧画像の削除

        return [
            'imageUrl' => 'https://firebasestorage.googleapis.com/v0/b/' . $bucket->name() .  '/o/' . urlencode($object->name()) . '?alt=media&token=' . $token,
            'imagePath' => $object->name(),
        ];
    }

    public function delete(string $path) : bool
    {
        $bucket = $this->getBucket();
        $object = $bucket->object($path);
        if ($object->exists()) {
            $object->delete();
        }

        return true;
    }

    public function deleteDir(string $dir) : bool
    {
        $bucket = $this->getBucket();
        $objects = $bucket->objects(['prefix' => $dir]);

        foreach ($objects as $object) {
            if (substr($object->name(), -1, 1) == '/') {
                // サブディレクトリがある場合再帰処理
                $this->deleteDir($object->name);
            } else {
                $object->delete();
            }
        }

        return true;
    }
}

<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class EventSpotService
{
    private $db;
    private $collection;

    private $parent_collection_name = 'events';
    private $collection_name = 'eventSpots';
    private $event_id;

    private $fields = [
        'id' => 'string',
        'name' => 'string',
        'imageUrl' => 'string',
        'imagePath' => 'string',
        'position' => 'array',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->parent_collection_name);
    }

    public function setEventId(string $event_id): void
    {
        $this->event_id = $event_id;
        $this->collection = $this->collection
            ->document($this->event_id)->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $event_spot): void
    {
        $event_spot['id'] = (string) Str::uuid();
        $event_spot['position'] = $this->firestore->getPosition($event_spot['positionLatitude'], $event_spot['positionLongitude']);

        // upload image
        $dir = $this->parent_collection_name . '/' . $this->event_id . '/' . $this->collection_name;
        if (request()->file('eventSpots.0.image')) { // イベントと同時登録の場合
            $image = $this->storage->uploadImage($dir, $event_spot['id'], request()->file('eventSpots.0.image'));
            $event_spot['imageUrl'] = $image['imageUrl'];
            $event_spot['imagePath'] = $image['imagePath'];

        } else if (request()->file('image')) { // イベントスポット単体登録の場合
            $image = $this->storage->uploadImage($dir, $event_spot['id'], request()->file('image'));
            $event_spot['imageUrl'] = $image['imageUrl'];
            $event_spot['imagePath'] = $image['imagePath'];
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $event_spot);
        $response = $this->collection->document($event_spot['id'])->set($store_data);
    }

    public function update(array $event_spot, object $snapshot): void
    {
        $event_spot['position'] = $this->firestore->getPosition($event_spot['positionLatitude'], $event_spot['positionLongitude']);

        // delete image
        if (! empty($event_spot['imageDelete'])) {
            $event_spot['imageUrl'] = null;
            $event_spot['imagePath'] = null;
        }

        // upload image
        $dir = $this->parent_collection_name . '/' . $this->event_id . '/' . $this->collection_name;
        if (request()->file('image')) {
            $image = $this->storage->uploadImage($dir, $snapshot['id'], request()->file('image'));
            $event_spot['imageUrl'] = $image['imageUrl'];
            $event_spot['imagePath'] = $image['imagePath'];
        }

        $update_data = $this->firestore->makeUpdateData($this->fields, $event_spot, $snapshot);
        $response = $this->collection->document($snapshot['id'])->update($update_data);
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // delete image
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        $response = $document->delete();
    }

}

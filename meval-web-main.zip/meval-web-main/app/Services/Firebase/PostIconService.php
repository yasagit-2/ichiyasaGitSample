<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class PostIconService
{
    private $db;
    private $collection;

    private $parent_collection_name = 'settings';
    private $collection_name = 'postIcons';
    private $parent_id = 'mevalAppSettings';

    private $fields = [
        'unitOfLikePostIconUrl' => 'string',
        'likeCount' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->parent_collection_name)
            ->document($this->parent_id)->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $documents = $this->collection->documents();
        return $documents;
    }

    public function store(array $post_icon): void
    {
        $post_icon['id'] = (string) Str::uuid();

        // image
        $this->uploadImage($post_icon);

        $store_data = $this->firestore->makeStoreData($this->fields, $post_icon);
        $response = $this->collection->document($post_icon['id'])->set($store_data);
    }

    public function update(array $post_icon, object $snapshot): void
    {
        // image
        $this->uploadImage($post_icon);

        $update_data = $this->firestore->makeUpdateData($this->fields, $post_icon, $snapshot);
        $response = $this->collection->document($snapshot->id())->update($update_data);
    }

    public function destroy(string $id): void
    {
        // image削除
        $dir = 'icons/' . $id;
        $this->storage->deleteDir($dir);

        $response = $this->collection->document($id)->delete();
    }

    private function uploadImage(array &$post_icon): array
    {
        $dir = 'icons';
        if (request()->file('unitOfLikePostIcon')) {
            $image = $this->storage->uploadImage($dir, 'post' . $post_icon['likeCount'], request()->file('unitOfLikePostIcon'));
            $post_icon['unitOfLikePostIconUrl'] = $image['imageUrl'];
        }
        return $post_icon;
    }
}

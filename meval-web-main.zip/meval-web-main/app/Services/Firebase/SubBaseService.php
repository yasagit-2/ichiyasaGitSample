<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class SubBaseService
{
    private $db;
    private $collection;

    private $collection_name = 'bases';

    private $fields = [
        'id' => 'string',
        'name' => 'string',
        'subBaseCount' => 'number',
        'parentRef' => 'reference',
        'position' => 'array',
        'publishStatus' => 'number',
        'point' => 'number',
        'pointLimit' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $query = $this->collection;

        if (array_key_exists('parent_id', $conditions)) {
            $base_ref = app()->make(BaseService::class);
            $query = $query->where('parentRef', '=', $base_ref->get($conditions['parent_id']));
        }

        $documents = $query->documents();

        return $documents;
    }

    public function store(array $sub_base): void
    {
        $sub_base['id'] = (string) Str::uuid();
        $sub_base['subBaseCount'] = 0;
        $sub_base['position'] = $this->firestore->getPosition($sub_base['positionLatitude'], $sub_base['positionLongitude']);
        $sub_base['point'] = 0;
        $sub_base['pointLimit'] = 0;

        // parentRef
        $base_ref = app()->make(BaseService::class);
        $parent_base = $base_ref->get(request()->parent_id);
        $sub_base['parentRef'] = $parent_base;
        $sub_base['publishStatus'] = $parent_base->snapshot()['publishStatus'];

        $store_data = $this->firestore->makeStoreData($this->fields, $sub_base);
        $response = $this->collection->document($sub_base['id'])->set($store_data);

        // 親拠点のsubBaseCount更新
        $base_ref->updateSubBaseCount(request()->parent_id);
    }

    public function update(array $sub_base, object $snapshot): void
    {
        if (! empty($sub_base['positionLatitude']) && ! empty($sub_base['positionLongitude'])) {
            $sub_base['position'] = $this->firestore->getPosition($sub_base['positionLatitude'], $sub_base['positionLongitude']);
        }

        $update_data = $this->firestore->makeUpdateData($this->fields, $sub_base, $snapshot);
        $response = $this->collection->document($snapshot->id())->update($update_data);
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);
        $snapshot = $document->snapshot();

        $response = $document->delete();

        // 親拠点のsubBaseCount更新
        $base = app()->make(BaseService::class);
        $base->updateSubBaseCount($snapshot['parentRef']->id());
    }

}

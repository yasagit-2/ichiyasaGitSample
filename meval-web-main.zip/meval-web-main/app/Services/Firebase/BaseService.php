<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;

class BaseService
{
    private $db;
    private $collection;

    private $collection_name = 'bases';

    private $fields = [
        'id' => 'string',
        'name' => 'string',
        'subBaseCount' => 'number',
        'imageUrl' => 'string',
        'imagePath' => 'string',
        'titleRef' => 'reference',
        'position' => 'array',
        'effectivePeriodBegin' => 'timestamp',
        'effectivePeriodEnd' => 'timestamp',
        'effectiveDaysOfWeek' => 'array',
        'effectiveTimeBegin' => 'string',
        'effectiveTimeEnd' => 'string',
        'publishStatus' => 'number',
        'point' => 'number',
        'pointLimit' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];
    private $transaction_fields = [
        'pointLimitRemain' => 'number',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function get(string $id): object
    {
        return $this->collection->document($id);
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $query = $this->collection;

        if (array_key_exists('title_id', $conditions)) {
            $title_ref = app()->make(TitleService::class);
            $query = $query->where('titleRef', '=', $title_ref->get($conditions['title_id']));

        } else {
            // DataTablesで並び替えをしているため、ここでは絞り込みのためorderByを実行
            $query = $query->orderBy('titleRef');
        }

        $documents = $query->documents();

        return $documents;
    }

    public function store(array $base): void
    {
        $base['id'] = (string) Str::uuid();
        $base['subBaseCount'] = 0;
        $base['position'] = $this->firestore->getPosition($base['positionLatitude'], $base['positionLongitude']);

        // titleRef
        $title_ref = app()->make(TitleService::class);
        $base['titleRef'] = $title_ref->get($base['titleRef']);

        // upload image
        if (request()->file('image')) {
            $base += $this->storage->uploadImage($this->collection_name, $base['id'], request()->file('image'));
        }

        $store_data = $this->firestore->makeStoreData($this->fields, $base);
        $this->collection->document($base['id'])->set($store_data);

        // transaction collection
        $transaction_update_data = $this->firestore->makeStoreData(
            $this->transaction_fields,
            ['pointLimitRemain' => $base['pointLimit']]
        );
        $this->collection->document($base['id'])
            ->collection('baseTransactions')->document('baseTransaction')->set($transaction_update_data);
    }

    public function update(array $base, object $snapshot): void
    {
        if (! empty($base['positionLatitude']) && ! empty($base['positionLongitude'])) {
            $base['position'] = $this->firestore->getPosition($base['positionLatitude'], $base['positionLongitude']);
        }
        if (array_key_exists('effectiveDaysOfWeek', $base)) {
            // ステータスに応じて更新可否を行うため、effectiveDaysOfWeek[]=7をhiddenとして設定している
            $effectiveDaysOfWeek = array_diff($base['effectiveDaysOfWeek'], [7]);
            $base['effectiveDaysOfWeek'] = $effectiveDaysOfWeek ? array_values($effectiveDaysOfWeek) : null;
        }

        // titleRef
        if (! empty($base['titleRef'])) {
            $title_ref = app()->make(TitleService::class);
            $base['titleRef'] = $title_ref->get($base['titleRef']);
        }
        unset($base['titleRef']);

        // delete image
        if (! empty($base['imageDelete'])) {
            $base['imageUrl'] = null;
            $base['imagePath'] = null;
        }

        // upload image
        if (request()->file('image')) {
            $image = $this->storage->uploadImage($this->collection_name, $snapshot->id(), request()->file('image'));
            $base['imageUrl'] = $image['imageUrl'];
            $base['imagePath'] = $image['imagePath'];
        }

        $base_update_data = $this->firestore->makeUpdateData($this->fields, $base, $snapshot);
        $this->collection->document($snapshot->id())->update($base_update_data);

        // transaction collection
        if (array_key_exists('pointLimit', $base)) {
            $transaction_update_data = $this->firestore->makeUpdateData(
                $this->transaction_fields,
                ['pointLimitRemain' => $base['pointLimit']]
            );
            $this->collection->document($snapshot->id())
                ->collection('baseTransactions')->document('baseTransaction')->update($transaction_update_data);
        }

        // ステータスを更新する場合、サブ拠点のステータスも更新する
        $sub_base_ref = app()->make(SubBaseService::class);
        $sub_bases = $sub_base_ref->find(['parent_id' => $snapshot->id()]);
        foreach ($sub_bases as $sub_base) {
            $sub_base_ref->update(['publishStatus' => $base['publishStatus']], $sub_base);
        }
    }

    public function destroy(string $id): void
    {
        $document = $this->get($id);

        // delete sub collections
        $this->firestore->destroySubCollections($document, ['baseTransactions']);

        // delete image
        $snapshot = $document->snapshot();
        if (@$snapshot['imagePath']) {
            $this->storage->delete($snapshot['imagePath']);
        }

        // delete sub base
        $sub_base_ref = app()->make(SubBaseService::class);
        $sub_bases = $sub_base_ref->find(['parent_id' => $id]);
        foreach ($sub_bases as $sub_base) {
            $sub_base_ref->destroy($sub_base['id']);
        }

        $document->delete();
    }

    public function updateSubBaseCount(string $id): void
    {
        $sub_base_ref = app()->make(SubBaseService::class);
        $sub_bases = $sub_base_ref->find(['parent_id' => $id]);

        $update_data = $this->firestore->makeUpdateData($this->fields, ['subBaseCount' => $sub_bases->size()]);
        $this->collection->document($id)->update($update_data);
    }

}

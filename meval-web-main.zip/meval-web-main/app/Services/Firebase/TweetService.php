<?php

namespace App\Services\Firebase;

use Illuminate\Support\Str;
use Carbon\Carbon;

class TweetService
{
    private $db;
    private $collection;

    private $collection_name = 'tweets';
    private $merchant_id;

    private $fields = [
        'id' => 'string',
        'message' => 'string',
        'merchantRef' => 'reference',
        'expiration' => 'timestamp',
        'updatedAt' => 'timestamp',
        'createdAt' => 'timestamp',
    ];

    public function __construct(private FirestoreService $firestore, private StorageService $storage)
    {
        $this->db = $firestore->getDatabase();
        $this->collection = $this->db->collection($this->collection_name);
    }

    public function setMerchantId(string $merchant_id): void
    {
        $this->merchant_id = $merchant_id;
    }

    public function get(string $id = null): object
    {
        $ref = $this->collection;

        if ($id === null) {
            $merchant = app()->make(MerchantService::class);
            $query = $ref->where('merchantRef', '=', $merchant->get($this->merchant_id))->limit(1);
            $documents = $query->documents();
            foreach ($documents as $document) {
                return $document;
            }

        } else {
            return $ref->document($id);
        }
    }

    public function find(array $conditions = [], array $order = []): object
    {
        $query = $this->collection;

        if (array_key_exists('merchant_id', $conditions)) {
            $merchant_ref = app()->make(MerchantService::class);
            $query = $query->where('merchantRef', '=', $merchant_ref->get($conditions['merchant_id']));
        }

        $documents = $query->documents();

        return $documents;
    }

    public function store(array $tweet): void
    {
        $tweet['id'] = $this->merchant_id;

        // merchantRef
        $merchant = app()->make(MerchantService::class);
        $tweet['merchantRef'] = $merchant->get($this->merchant_id);

        // expiration
        $setting = app()->make(SettingService::class);
        $setting_snapshot = $setting->get('mevalAppSettings')->snapshot();
        $tweet['expiration'] = Carbon::now()->addMinutes($setting_snapshot['tweetExpirationMinutes'] ?? 180)->format('Y-m-d H:i:s');

        $store_data = $this->firestore->makeStoreData($this->fields, $tweet);
        $response = $this->collection->document($tweet['id'])->set($store_data);
    }

    public function update(array $tweet, object $snapshot): void
    {
        $tweet['id'] = $this->merchant_id;

        // expiration
        $setting = app()->make(SettingService::class);
        $setting_snapshot = $setting->get('mevalAppSettings')->snapshot();
        $tweet['expiration'] = Carbon::now()->addMinutes($setting_snapshot['tweetExpirationMinutes'] ?? 180)->format('Y-m-d H:i:s');

        $tweet_update_data = $this->firestore->makeUpdateData($this->fields, $tweet, $snapshot);
        $response = $this->collection->document($tweet['id'])->update($tweet_update_data);
    }

    public function destroy(string $id): void
    {
        $response = $this->collection->document($id)->delete();
    }

}

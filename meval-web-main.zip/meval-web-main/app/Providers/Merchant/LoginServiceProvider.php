<?php

namespace App\Providers\Merchant;

use App\Http\Controllers\Merchant\LoginController;
use Illuminate\Contracts\Auth\StatefulGuard;
use Illuminate\Support\Facades\Auth;
use App\Actions\Merchant\AttemptToAuthenticate;
use Illuminate\Support\ServiceProvider;

class LoginServiceProvider extends ServiceProvider
{
    /**
    * Register services.
    *
    * @return void
    */
    public function register()
    {
        $this->app
            ->when([LoginController::class, AttemptToAuthenticate::class])
            ->needs(StatefulGuard::class)
            ->give(function () {
                return Auth::guard('merchant');
            });
    }

    /**
    * Bootstrap services.
    *
    * @return void
    */
    public function boot()
    {
        //
    }
}

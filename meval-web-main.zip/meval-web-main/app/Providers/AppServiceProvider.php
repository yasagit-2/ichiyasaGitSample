<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //======Repositories========
        //拠点リポジトリ
        $this->app->bind(
            \App\Repositories\BaseRepositoryInterface::class,
            \App\Repositories\BaseRepository::class,
        );

        //サブ拠点リポジトリ
        $this->app->bind(
            \App\Repositories\SubBaseRepositoryInterface::class,
            \App\Repositories\SubBaseRepository::class,
        );

        //Adminリポジトリ
        $this->app->bind(
            \App\Repositories\AdminRepositoryInterface::class,
            \App\Repositories\AdminRepository::class,
        );
        
        //Settingリポジトリ
        $this->app->bind(
            \App\Repositories\SettingRepositoryInterface::class,
            \App\Repositories\SettingRepository::class,
        );

        //投稿リポジトリ
        $this->app->bind(
            \App\Repositories\ReportRepositoryInterface::class,
            \App\Repositories\ReportRepository::class,
        );

        //投稿リポジトリ
        $this->app->bind(
            \App\Repositories\PostRepositoryInterface::class,
            \App\Repositories\PostRepository::class,
        );

        //コメントリポジトリ
        $this->app->bind(
            \App\Repositories\CommentRepositoryInterface::class,
            \App\Repositories\CommentRepository::class,
        );

        //行政投稿ポジトリ
        $this->app->bind(
            \App\Repositories\AdminPostRepositoryInterface::class,
            \App\Repositories\AdminPostRepository::class,
        );


        //======Services===========

        //拠点サービス
        $this->app->bind(
            \App\Services\BaseServiceInterface::class,
            function ($app) {
                return new \App\Services\BaseService(
                    $app->make(\App\Repositories\BaseRepositoryInterface::class),
                    $app->make(\App\Repositories\SubBaseRepositoryInterface::class)
                );
            },
        );

        //サブ拠点サービス
        $this->app->bind(
            \App\Services\SubBaseServiceInterface::class,
            function ($app) {
                return new \App\Services\SubBaseService(
                    $app->make(\App\Repositories\SubBaseRepositoryInterface::class)
                );
            },
        );

        //Adminサービス
        $this->app->bind(
            \App\Services\AdminServiceInterface::class,
            function ($app) {
                return new \App\Services\AdminService(
                    $app->make(\App\Repositories\AdminRepositoryInterface::class)
                );
            },
        );

        //Settingサービス
        $this->app->bind(
            \App\Services\SettingServiceInterface::class,
            function ($app) {
                return new \App\Services\SettingService(
                    $app->make(\App\Repositories\SettingRepositoryInterface::class)
                );
            },
        );

        //Reportサービス
        $this->app->bind(
            \App\Services\ReportServiceInterface::class,
            function ($app) {
                return new \App\Services\ReportService(
                    $app->make(\App\Repositories\ReportRepositoryInterface::class)
                );
            },
        );

        //Postサービス
        $this->app->bind(
            \App\Services\PostServiceInterface::class,
            function ($app) {
                return new \App\Services\PostService(
                    $app->make(\App\Repositories\PostRepositoryInterface::class)
                );
            },
        );

        //Commentサービス
        $this->app->bind(
            \App\Services\CommentServiceInterface::class,
            function ($app) {
                return new \App\Services\CommentService(
                    $app->make(\App\Repositories\CommentRepositoryInterface::class)
                );
            },
        );

        //AdminPostサービス
        $this->app->bind(
            \App\Services\AdminPostServiceInterface::class,
            function ($app) {
                return new \App\Services\AdminPostService(
                    $app->make(\App\Repositories\AdminPostRepositoryInterface::class)
                );
            },
        );
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();
    }
}

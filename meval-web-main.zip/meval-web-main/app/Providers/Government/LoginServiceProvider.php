<?php

namespace App\Providers\Government;

use App\Http\Controllers\Government\LoginController;
use Illuminate\Contracts\Auth\StatefulGuard;
use Illuminate\Support\Facades\Auth;
use App\Actions\Government\AttemptToAuthenticate;
use Illuminate\Support\ServiceProvider;

class LoginServiceProvider extends ServiceProvider
{
    /**
    * Register services.
    *
    * @return void
    */
    public function register()
    {
        $this->app
            ->when([LoginController::class, AttemptToAuthenticate::class])
            ->needs(StatefulGuard::class)
            ->give(function () {
                return Auth::guard('government');
            });
    }

    /**
    * Bootstrap services.
    *
    * @return void
    */
    public function boot()
    {
        //
    }
}

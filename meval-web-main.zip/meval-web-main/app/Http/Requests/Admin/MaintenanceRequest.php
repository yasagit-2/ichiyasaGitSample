<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class MaintenanceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'version' => [
                'required',
                'max:20',
                'regex:' . '/^([0-9]|[1-9][0-9]{1,})(\.([0-9]|[1-9][0-9]{1,}))*$/',
            ],
            'appStoreUrl' => [
                'required',
                'url',
                'max:' . config('const.default_url_maxlength'),
            ],
            'playStoreUrl' => [
                'required',
                'url',
                'max:' . config('const.default_url_maxlength'),
            ],
            'isMaintenance' => [
                'required',
                'boolean',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'version' => 'アプリケーションバージョン',
            'appStoreUrl' => 'Apple App StoreのURL',
            'playStoreUrl' => 'Google Play StoreのURL',
            'isMaintenance' => 'メンテナンスフラグ',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    public function messages()
    {
        return [
            'version.regex' => ':attributeは1.0.0の形式で入力してください。',
        ];
    }
}

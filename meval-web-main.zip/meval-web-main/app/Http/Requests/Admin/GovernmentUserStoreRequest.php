<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class GovernmentUserStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => [
                'required',
                'max:' . config('const.default_text_maxlength')
            ],
            'email' => [
                'required',
                // 'email:rfc,dns',
                'email:rfc',
                'max:' . config('const.default_email_maxlength'),
                Rule::unique('government_users', 'email')->ignore($this->government_user)->whereNull('deleted_at')
            ],
            'password' => [
                'required',
                'min:' . config('const.default_password_minlength'),
                'max:' . config('const.default_password_maxlength'),
                'regex:' . config('const.password_regex'),
                function ($attribute, $value, $fail) {
                    if ($this->request->get('email') == $value) {
                        return $fail('メールアドレスと一致しないようにしてください。');
                    }
                },
                'confirmed'
            ],
            'password_confirmation' => [
                'required',
            ],
        ];

        return $rules;
    }

    /**
    * バリデーションエラーのカスタム属性の取得
    *
    * @return array
    */
    public function attributes()
    {
        return [
            'name' => '行政ユーザー名称',
            'email' => 'メールアドレス',
            'password' => 'パスワード',
            'password_confirmation' => 'パスワード（確認用）'
        ];
    }

    /**
    * 定義済みバリデーションルールのエラーメッセージ取得
    *
    * @return array
    */
    public function messages()
    {
        return [
            'password.regex' => '大文字・小文字を含めた半角英数字記号を、6文字以上16文字以内で入力してください。'
        ];
    }
}

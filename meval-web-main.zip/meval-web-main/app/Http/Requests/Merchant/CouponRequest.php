<?php

namespace App\Http\Requests\Merchant;

use Illuminate\Foundation\Http\FormRequest;

class CouponRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'exchangePoint' => [
                'required',
                'integer',
                'min:0',
            ],
            'exchangeLimit' => [
                'required',
                'integer',
                'min:0',
            ],
            'dueDate' => [
                'required',
                'date_format:Y-m-d'
            ],
            'publicationPeriodBegin' => [
                'required',
                'date_format:Y-m-d'
            ],
            'publicationPeriodEnd' => [
                'required',
                'date_format:Y-m-d',
                function ($attribute, $value, $fail) {
                    if ($this->request->get('publicationPeriodBegin') > $value) {
                        return $fail(':attributeは掲載期間開始よりも後に指定してください。');
                    }
                },
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'name' => 'クーポン名称',
            'exchangePoint' => '交換ポイント',
            'exchangeLimit' => 'クーポン獲得制限人数',
            'dueDate' => 'クーポン有効期限',
            'publicationPeriodBegin' => '掲載期間開始',
            'publicationPeriodEnd' => '掲載期間終了',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

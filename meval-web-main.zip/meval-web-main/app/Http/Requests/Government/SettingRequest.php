<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class SettingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'baseIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'baseCheckedInIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'subBaseIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'merchantIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'merchantTweetIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'postIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'adminAlertIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'adminQuestionnaireIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'checkInRadius' => [
                'required',
                'numeric',
                'min:0',
                'regex:/\A\d{1,4}(\.\d{1})?\z/',
            ],
            'collectionRadius' => [
                'required',
                'numeric',
                'min:0',
                'regex:/\A\d{1,4}(\.\d{1})?\z/',
            ],
            'targetStepPerWeek' => [
                'required',
                'integer',
                'min:0',
            ],
            'stepAchievedPoint' => [
                'required',
                'integer',
                'min:0',
            ],
            'postIntervalLimitHour' => [
                'required',
                'integer',
                'min:0',
            ],
            'reportIntervalLimitHour' => [
                'required',
                'integer',
                'min:0',
            ],
            'commentIntervalLimitMinute' => [
                'required',
                'integer',
                'min:0',
            ],
            'notificationRetentionDay' => [
                'required',
                'integer',
                'min:0',
            ],
            'eventRetentionDay' => [
                'required',
                'integer',
                'min:0',
            ],
            'memberDeletionGraceDay' => [
                'required',
                'integer',
                'min:0',
            ],
            'tweetExpirationMinutes' => [
                'required',
                'integer',
                'min:0',
            ],
            'helpPageUrl' => [
                'required',
                'url',
                'max:' . config('const.default_url_maxlength'),
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'baseIcon' => '拠点アイコン',
            'baseCheckedInIcon' => 'チェックイン済み拠点アイコン',
            'subBaseIcon' => 'サブ拠点アイコン',
            'merchantIcon' => '加盟店アイコン',
            'merchantTweetIcon' => '加盟店つぶやきアイコン',
            'postIcon' => '投稿アイコン',
            'adminAlertIcon' => '行政投稿アラートアイコン',
            'adminQuestionnaireIcon' => '行政投稿アンケートアイコン',
            'checkInRadius' => 'チェックイン可能距離',
            'collectionRadius' => '拠点/投稿/加盟店収集半径',
            'targetStepPerWeek' => '週間規定歩数',
            'stepAchievedPoint' => '週間規定歩数達成ポイント',
            'postIntervalLimitHour' => '投稿間隔制限',
            'reportIntervalLimitHour' => '行政報告間隔制限',
            'commentIntervalLimitMinute' => 'コメント間隔制限',
            'notificationRetentionDay' => 'お知らせ保存日数',
            'eventRetentionDay' => 'イベント保存日数',
            'memberDeletionGraceDay' => '会員削除猶予日数',
            'tweetExpirationMinutes' => 'つぶやき表示期限',
            'helpPageUrl' => 'ヘルプページURL',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

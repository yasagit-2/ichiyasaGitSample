<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class MerchantStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'email' => [
                'required',
                // 'email:rfc,dns',
                'email:rfc',
                'max:' . config('const.default_email_maxlength'),
                Rule::unique('merchants', 'email')->ignore($this->merchant)->whereNull('deleted_at')
            ],
            'password' => [
                'required',
                'min:' . config('const.default_password_minlength'),
                'max:' . config('const.default_password_maxlength'),
                'regex:' . config('const.password_regex'),
                function ($attribute, $value, $fail) {
                    if ($this->request->get('email') == $value) {
                        return $fail('メールアドレスと一致しないようにしてください。');
                    }
                },
                'confirmed'
            ],
            'password_confirmation' => [
                'required',
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'positionLatitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'name' => '加盟店名称',
            'email' => 'メールアドレス',
            'password' => 'パスワード',
            'password_confirmation' => 'パスワード（確認用）',
            'image' => '加盟店画像',
            'positionLatitude' => '加盟店の緯度',
            'positionLongitude' => '加盟店の経度',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'positionLatitude.regex' => ':attributeは小数の形式で入力してください。',
    //         'positionLongitude.regex' => ':attributeは小数の形式で入力してください。',
    //     ];
    // }
}

<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class TitleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'point' => [
                'required',
                'integer',
                'min:0',
            ],
            'pointLimit' => [
                'required',
                'integer',
                'min:0',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'name' => '称号名称',
            'point' => '称号獲得ポイント',
            'pointLimit' => 'ポイント付与制限人数',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class PushNotificationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'topic' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'title' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'body' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'topic' => 'ターゲット',
            'title' => 'タイトル',
            'body' => '本文',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

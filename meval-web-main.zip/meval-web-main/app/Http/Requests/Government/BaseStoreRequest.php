<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class BaseStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'titleRef' => [
                'required',
            ],
            'name' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'publishStatus' => [
                'required',
                'in:' . implode(',', array_keys(config('const.base_statuses')))
            ],
            'positionLatitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'effectivePeriodBegin' => [
                'nullable',
                'date_format:Y-m-d',
            ],
            'effectivePeriodEnd' => [
                'nullable',
                'date_format:Y-m-d',
                'after:effectivePeriodBegin',
            ],
            'effectiveTimeBegin' => [
                'nullable',
                'date_format:H:i'
            ],
            'effectiveTimeEnd' => [
                'nullable',
                'date_format:H:i',
                function ($attribute, $value, $fail) {
                    if ($this->request->get('effectiveTimeBegin') > $value) {
                        return $fail(':attributeは有効時刻開始よりも後に指定してください。');
                    }
                },
            ],
            'effectiveDaysOfWeek' => [
                'nullable',
                'array',
            ],
            // 'effectiveDaysOfWeek.*' => [
            //     'in:' . implode(',', array_keys(config('const.weeks'))),
            // ],
            'point' => [
                'required',
                'integer',
                'min:0',
            ],
            'pointLimit' => [
                'required',
                'integer',
                'min:0',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'titleRef' => '称号',
            'name' => '拠点名称',
            'publishStatus' => '公開ステータス',
            'positionLatitude' => '拠点の緯度',
            'positionLongitude' => '拠点の経度',
            'image' => '拠点画像',
            'effectivePeriodBegin' => '有効期間開始',
            'effectivePeriodEnd' => '有効期間終了',
            'effectiveTimeBegin' => '有効時刻開始',
            'effectiveTimeEnd' => '有効時刻終了',
            'effectiveDaysOfWeek' => '有効曜日',
            'point' => '獲得ポイント',
            'pointLimit' => 'ポイント付与制限人数',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'positionLatitude.regex' => ':attributeは小数の形式で入力してください。',
    //         'positionLongitude.regex' => ':attributeは小数の形式で入力してください。',
    //     ];
    // }
}

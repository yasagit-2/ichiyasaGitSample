<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class AdminQuestionnaireStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'message' => [
                'required',
                'max:' . config('const.default_textarea_maxlength'),
            ],
            'positionLatitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'dueDate' => [
                'required',
                'date_format:Y-m-d'
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'point' => [
                'required',
                'integer',
                'min:0',
            ],
            'pointLimit' => [
                'required',
                'integer',
                'min:0',
            ],

            'choices.0.choice' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'choices.1.choice' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'choices.2.choice' => [
                'nullable',
                'max:' . config('const.default_text_maxlength'),
            ],
            'choices.3.choice' => [
                'nullable',
                'max:' . config('const.default_text_maxlength'),
            ],
            'choices.4.choice' => [
                'nullable',
                'max:' . config('const.default_text_maxlength'),
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'message' => '行政投稿（注意）メッセージ',
            'positionLatitude' => '行政投稿（注意）の緯度',
            'positionLongitude' => '行政投稿（注意）の経度',
            'dueDate' => '行政投稿（注意）期限',
            'image' => '行政投稿（注意）画像',
            'point' => 'アンケート獲得回答ポイント',
            'pointLimit' => 'ポイント付与制限人数',
            'choices.0.choice' => '選択肢の文言1',
            'choices.1.choice' => '選択肢の文言2',
            'choices.2.choice' => '選択肢の文言3',
            'choices.3.choice' => '選択肢の文言4',
            'choices.4.choice' => '選択肢の文言5',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'positionLatitude.regex' => ':attributeは小数の形式で入力してください。',
    //         'positionLongitude.regex' => ':attributeは小数の形式で入力してください。',
    //     ];
    // }
}

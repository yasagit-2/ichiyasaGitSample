<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class MemberNotificationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'title' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'contentUrl' => [
                'nullable',
                'url',
                'max:' . config('const.default_url_maxlength'),
            ],
            'effectivePeriodBegin' => [
                'required',
                'date_format:Y-m-d'
            ],
            'effectivePeriodEnd' => [
                'required',
                'date_format:Y-m-d',
                'after:effectivePeriodBegin'
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'title' => 'お知らせタイトル',
            'contentUrl' => 'コンテンツURL',
            'effectivePeriodBegin' => '有効期間開始',
            'effectivePeriodEnd' => '有効期間終了',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

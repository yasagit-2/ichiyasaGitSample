<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;
use App\Services\Firebase\BaseService;

class BaseUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // 更新前のデータを取得
        $id = request()->route()->parameter('basis');
        $base = app()->make(BaseService::class);
        $snapshot = $base->get($id)->snapshot();

        $rules = [
            'titleRef' => [
                'filled',
            ],
            'name' => [
                'filled',
                'max:' . config('const.default_text_maxlength'),
            ],
            'publishStatus' => [
                'required',
                'in:' . implode(',', array_keys(config('const.base_statuses'))),
                function ($attribute, $value, $fail) use ($snapshot) {
                    // 現在より前のステータスには戻すことは不可
                    if ($snapshot['publishStatus'] > 0) {
                        if ($snapshot['publishStatus'] > $value) {
                            return $fail(':attributeは前に戻すことはできません。');
                        }
                    }
                },
            ],
            'positionLatitude' => [
                'filled',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'filled',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'imageDelete' => [
                'nullable',
            ],
            'effectivePeriodBegin' => [
                'nullable',
                'date_format:Y-m-d'
            ],
            'effectivePeriodEnd' => [
                'nullable',
                'date_format:Y-m-d',
                function ($attribute, $value, $fail) {
                    if ($this->request->get('effectivePeriodBegin') > $value) {
                        return $fail(':attributeは有効期間開始よりも後に指定してください。');
                    }
                },
            ],
            'effectiveTimeBegin' => [
                'nullable',
                'date_format:H:i'
            ],
            'effectiveTimeEnd' => [
                'nullable',
                'date_format:H:i',
                'after:effectiveTimeBegin',
            ],
            'effectiveDaysOfWeek' => [
                'nullable',
                'array',
            ],
            // 'effectiveDaysOfWeek.*' => [
            //     'in:' . implode(',', array_keys(config('const.weeks'))),
            // ],
            'point' => [
                'filled',
                'integer',
                'min:0',
            ],
            'pointLimit' => [
                'filled',
                'integer',
                'min:0',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'titleRef' => '称号',
            'name' => '拠点名称',
            'publishStatus' => '公開ステータス',
            'positionLatitude' => '拠点の緯度',
            'positionLongitude' => '拠点の経度',
            'image' => '拠点画像',
            'effectivePeriodBegin' => '有効期間開始',
            'effectivePeriodEnd' => '有効期間終了',
            'effectiveTimeBegin' => '有効時刻開始',
            'effectiveTimeEnd' => '有効時刻終了',
            'effectiveDaysOfWeek' => '有効曜日',
            'point' => '獲得ポイント',
            'pointLimit' => 'ポイント付与制限人数',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'positionLatitude.regex' => ':attributeは小数の形式で入力してください。',
    //         'positionLongitude.regex' => ':attributeは小数の形式で入力してください。',
    //     ];
    // }
}

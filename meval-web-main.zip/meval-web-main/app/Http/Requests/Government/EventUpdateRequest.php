<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;
use App\Services\Firebase\EventSpotService;

class EventUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // イベントスポットのデータを取得
        $id = request()->route()->parameter('event');
        $event_spot = app()->make(EventSpotService::class);
        $event_spot->setEventId($id);
        $event_spot_size = $event_spot->find()->size();

        $rules = [
            'title' => [
                'required',
                'max:' . config('const.default_text_maxlength'),
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'imageDelete' => [
                'nullable'
            ],
            'effectivePeriodBegin' => [
                'required',
                'date_format:Y-m-d',
                'after_or_equal:today'
            ],
            'effectivePeriodEnd' => [
                'required',
                'date_format:Y-m-d',
                'after:effectivePeriodBegin',
            ],
            'eventIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'eventIconDelete' => [
                'nullable'
            ],
            'completeSpotIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'completeSpotIconDelete' => [
                'nullable'
            ],
            'completeSpotCount' => [
                'required',
                'integer',
                'min:1',
                function ($attribute, $value, $fail) use ($event_spot_size) {
                    if ($event_spot_size < $value) {
                        return $fail(':attributeはイベントスポット地点数以下で指定してください。');
                    }
                },
            ],
            'isUseLocation' => [
                'required',
                'boolean',
            ],
            'qrCodeRadius' => [
                'required_if:isUseLocation,1',
                'numeric',
                'min:0',
                'regex:/\A\d{1,4}(\.\d{1})?\z/',
            ],
            'exchangeType' => [
                'required',
                'in:' . implode(',', array_keys(config('const.event_exchange_types')))
            ],
            'point' => [
                'required_if:exchangeType,0',
                'integer',
                'min:0',
            ],
            'exchangeLimit' => [
                'required',
                'integer',
                'min:0',
            ],
            'positionLatitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'title' => 'イベントタイトル',
            'image' => 'イベント画像',
            'effectivePeriodBegin' => 'イベント開催期間開始',
            'effectivePeriodEnd' => 'イベント開催期間終了',
            'eventIcon' => 'イベントアイコン',
            'completeSpotIcon' => 'スタンプ獲得済アイコン',
            'completeSpotCount' => 'イベント達成地点数',
            'isUseLocation' => '位置情報の利用',
            'qrCodeRadius' => 'QRコード読み取り可能距離',
            'exchangeType' => '交換対象種別',
            'point' => 'イベント達成獲得ポイント',
            'exchangeLimit' => '交換制限人数',
            'positionLatitude' => 'イベントの緯度',
            'positionLongitude' => 'イベントの経度',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    public function messages()
    {
        return [
            'qrCodeRadius.regex' => ':attributeは整数部分4桁・小数部分1桁（省略可能）で指定してください。',
            'effectivePeriodBegin.after_or_equal' => ':attributeには、今日以降の日付を指定してください。',
        ];
    }
}

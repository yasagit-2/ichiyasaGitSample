<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;
use App\Services\Firebase\PostIconService;

class PostIconUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // 既存データの取得
        $id = request()->route()->parameter('post_icon');
        $post_icon_ref = app()->make(PostIconService::class);
        $post_icons = $post_icon_ref->find();
        $like_counts = [];
        foreach ($post_icons as $post_icon) {
            if ($post_icon->id() != $id) {
                $like_counts[] = $post_icon['likeCount'];
            }
        }

        $rules = [
            'unitOfLikePostIcon' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'likeCount' => [
                'required',
                'integer',
                'min:0',
                function ($attribute, $value, $fail) use ($like_counts) {
                    if (in_array($value, $like_counts)) {
                        return $fail(':attribute「' . $value . '」は既に設定されています。');
                    }
                },
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'unitOfLikePostIcon' => 'いいね数単位の投稿アイコンURL',
            'likeCount' => 'いいね数',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'pos_lat.regex' => ':attributeは〇〇の形式で入力してください。',
    //     ];
    // }
}

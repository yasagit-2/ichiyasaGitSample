<?php

namespace App\Http\Requests\Government;

use Illuminate\Foundation\Http\FormRequest;

class AdminAlertRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'message' => [
                'required',
                'max:' . config('const.default_textarea_maxlength'),
            ],
            'positionLatitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'positionLongitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'dueDate' => [
                'required',
                'date_format:Y-m-d'
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:' . implode(',', config('const.upload_image_extensions')),
                'max:' . config('const.upload_max_filesize'),
                // 'dimensions:max_width=640,max_height=640',
            ],
            'imageDelete' => [
                'nullable',
            ],
        ];

        return $rules;
    }

    /**
     * バリデーションエラーのカスタム属性の取得
     *
     * @return array
     */
    public function attributes()
    {
        $attributes = [
            'message' => '行政投稿（注意）メッセージ',
            'positionLatitude' => '行政投稿（注意）の緯度',
            'positionLongitude' => '行政投稿（注意）の経度',
            'dueDate' => '行政投稿（注意）期限',
            'image' => '行政投稿（注意）期限',
        ];
        return $attributes;
    }

    /**
     * 定義済みバリデーションルールのエラーメッセージ取得
     *
     * @return array
     */
    // public function messages()
    // {
    //     return [
    //         'positionLatitude.regex' => ':attributeは小数の形式で入力してください。',
    //         'positionLongitude.regex' => ':attributeは小数の形式で入力してください。',
    //     ];
    // }
}

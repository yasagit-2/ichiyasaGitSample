<?php

namespace App\Http\Controllers\Merchant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Merchant\CouponRequest;
use App\Services\Firebase\CouponService;

class CouponController extends Controller
{
    public function __construct(private CouponService $coupon)
    {
        $this->middleware(function ($request, $next) use ($coupon) { // コンストラクタでAuthが参照できないための対応
            $coupon->setMerchantId(\Auth::guard('merchant')->user()->id);
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $coupons = $this->coupon->find();
        return view('merchant.coupons.index', ['coupons' => $coupons]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('merchant.coupons.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Merchant\CouponRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CouponRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->coupon->store($validated);

        return redirect()
            ->route('merchant.coupons.index')
            ->with('alert.success', 'クーポン情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $coupon
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $coupon)
    {
        $snapshot = $this->coupon->get($coupon)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('merchant.coupons.edit', [
            'snapshot' => $snapshot,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Merchant\CouponRequest  $request
     * @param  string  $coupon
     * @return \Illuminate\Http\Response
     */
    public function update(CouponRequest $request, string $coupon)
    {
        $snapshot = $this->coupon->get($coupon)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->coupon->update($validated, $snapshot);

        return redirect()
            ->route('merchant.coupons.index')
            ->with('alert.success', 'クーポン情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $coupon
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $coupon)
    {
        $snapshot = $this->coupon->get($coupon)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->coupon->destroy($coupon);

        return redirect()
            ->route('merchant.coupons.index')
            ->with('alert.success', 'クーポン情報を削除しました。');
    }

}

<?php

namespace App\Http\Controllers\Merchant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Merchant\TweetRequest;
use App\Services\Firebase\TweetService;

class TweetController extends Controller
{
    private $merchant_id;

    public function __construct(private TweetService $tweet)
    {
        $this->middleware(function ($request, $next) use ($tweet) { // コンストラクタでAuthが参照できないための対応
            $this->merchant_id = \Auth::guard('merchant')->user()->id;
            $tweet->setMerchantId($this->merchant_id);
            return $next($request);
        });
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $snapshot = $this->tweet->get($this->merchant_id)->snapshot();
        return view('merchant.tweets.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Merchant\TweetRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function update(TweetRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $snapshot = $this->tweet->get($this->merchant_id)->snapshot();

        // 既に存在している場合は更新
        if ($snapshot->exists()) {
            $this->tweet->update($validated, $snapshot);

        // 存在しない場合は登録
        } else {
            $this->tweet->store($validated);
        }

        return redirect()
            ->route('merchant.tweets.edit')
            ->with('alert.success', 'つぶやき情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
    	$snapshot = $this->tweet->get($this->merchant_id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->tweet->destroy($this->merchant_id);

        return redirect()
            ->route('merchant.tweets.edit')
            ->with('alert.success', 'つぶやき情報を削除しました。');
    }

}

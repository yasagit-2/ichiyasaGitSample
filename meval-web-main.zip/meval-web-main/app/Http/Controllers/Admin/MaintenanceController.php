<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\MaintenanceRequest;
use App\Services\Firebase\MaintenanceService;

class MaintenanceController extends Controller
{
    public function __construct(private MaintenanceService $maintenance)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $snapshot = $this->maintenance->get()->snapshot();
        return view('admin.maintenances.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Admin\MaintenanceRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function update(MaintenanceRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $snapshot = $this->maintenance->get()->snapshot();

        // 既に存在している場合は更新
        if ($snapshot->exists()) {
            $this->maintenance->update($validated, $snapshot);

        // 存在しない場合は登録
        } else {
            $this->maintenance->store($validated);
        }

        return redirect()
            ->route('admin.maintenances.edit')
            ->with('alert.success', '運用情報を保存しました。');
    }

}

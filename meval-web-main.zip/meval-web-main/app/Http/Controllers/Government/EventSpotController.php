<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\EventSpotRequest;
use App\Services\Firebase\EventSpotService;
use App\Services\Firebase\EventService;
use Carbon\Carbon;

class EventSpotController extends Controller
{
    private $event_id;

    public function __construct(private EventSpotService $event_spot)
    {
        $this->event_id = request()->route()->parameter('event');
        $event_spot->setEventId($this->event_id);
    }

    /**
     * Display a listing of the resource
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $event_spots = $this->event_spot->find();

        $event_ref = app()->make(EventService::class);
        $event_snapshot = $event_ref->get($this->event_id)->snapshot();

        return view('government.event_spots.index', [
            'event_snapshot' => $event_snapshot,
            'event_spots' => $event_spots,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if ($this->isDateValid()) {
            logger()->error('Document can not create');
            abort(403);
        }

        return view('government.event_spots.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\EventSpotRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EventSpotRequest $request)
    {
        if ($this->isDateValid()) {
            logger()->error('Document can not store');
            abort(403);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->event_spot->store($validated);

        return redirect()
            ->route('government.event_spots.index', ['event' => $this->event_id])
            ->with('alert.success', 'イベントスポット情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $event
     * @param  string  $event_spot
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $event, string $event_spot)
    {
        if ($this->isDateValid()) {
            logger()->error('Document can not edit');
            abort(403);
        }

        $snapshot = $this->event_spot->get($event_spot)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.event_spots.edit', [
            'snapshot' => $snapshot,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\EventSpotRequest  $request
     * @param  string  $event
     * @param  string  $event_spot
     * @return \Illuminate\Http\Response
     */
    public function update(EventSpotRequest $request, string $event, string $event_spot)
    {
        $snapshot = $this->event_spot->get($event_spot)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not update');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->event_spot->update($validated, $snapshot);

        return redirect()
            ->route('government.event_spots.index', ['event' => $this->event_id])
            ->with('alert.success', 'イベントスポット情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $event
     * @param  string  $event_spot
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $event, string $event_spot)
    {
        if ($this->isDateValid()) {
            logger()->error('Document can not destroy');
            abort(403);
        }

        if ($this->event_spot->find()->size() <= 1) {
            logger()->error('Document can not destroy');
            abort(403);
        }

        $snapshot = $this->event_spot->get($event_spot)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->event_spot->destroy($event_spot);

        return redirect()
            ->route('government.event_spots.index', ['event' => $this->event_id])
            ->with('alert.success', 'イベントスポット情報を削除しました。');
    }

    private function isDateValid(): bool
    {
        $event_ref = app()->make(EventService::class);
        $event_snapshot = $event_ref->get($this->event_id)->snapshot();
        $effectivePeriodBegin = parseFromGoogleTimestamp($event_snapshot['effectivePeriodBegin']);
        if ($effectivePeriodBegin->lte(Carbon::now())) {
            return true;
        }
        return false;
    }
}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Merchant;
use App\Http\Requests\Government\MerchantStoreRequest;
use App\Http\Requests\Government\MerchantUpdateRequest;
use App\Services\Firebase\MerchantService;

class MerchantController extends Controller
{

    public function __construct(private MerchantService $merchant)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $merchants = $this->merchant->find();

        foreach ($merchants as $merchant) {
            $rdb_merchant = Merchant::find($merchant->id());
            if ($rdb_merchant !== null) {
                $rdb_merchants[$merchant->id()] = ['email' => $rdb_merchant['email']];
            }
        }

        return view('government.merchants.index', [
            'merchants' => $merchants,
            'rdb_merchants' => $rdb_merchants,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.merchants.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\MerchantStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MerchantStoreRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        \DB::beginTransaction();
        try {
            // ログイン用データ保存
            $merchant = Merchant::create($validated);

            // Firebaseへ保存
            $validated['id'] = $merchant->id;
            $this->merchant->store($validated);

            \DB::commit();
        } catch (\Exception $e) {
            logger()->error($e->getMessage());
            \DB::rollback();
            return back()
                ->with('alert.error', '加盟店情報の登録に失敗しました。')
                ->withInput();
        }

        return redirect()
            ->route('government.merchants.index')
            ->with('alert.success', '加盟店情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Merchant $merchant)
    {
        $snapshot = $this->merchant->get($merchant->id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.merchants.edit', [
            'merchant' => $merchant,
            'snapshot' => $snapshot,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\MerchantUpdateRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Merchant $merchant, MerchantUpdateRequest $request)
    {
        $snapshot = $this->merchant->get($merchant->id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        \DB::beginTransaction();
        try {
            // ログイン用データ保存
            $merchant->fill($validated)->save();

            // Firebaseへ保存
            $validated['id'] = $merchant->id;
            $this->merchant->update($validated, $snapshot);

            \DB::commit();
        } catch (\Exception $e) {
            logger()->error($e->getMessage());
            \DB::rollback();
            return back()
                ->with('alert.error', '加盟店情報の編集に失敗しました。')
                ->withInput();
        }

        return redirect()
            ->route('government.merchants.index')
            ->with('alert.success', '加盟店情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Merchant $merchant)
    {
        $snapshot = $this->merchant->get($merchant->id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        \DB::beginTransaction();
        try {
            // ログイン用データ削除
            $merchant->delete();

            // Firebaseから削除
            $this->merchant->destroy($merchant->id);

            \DB::commit();
        } catch (\Exception $e) {
            logger()->error($e->getMessage());
            \DB::rollback();
            return back()
                ->with('alert.error', '加盟店情報の削除に失敗しました。')
                ->withInput();
        }

        return redirect()
            ->route('government.merchants.index')
            ->with('alert.success', '加盟店情報を削除しました。');
    }

}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\AdminQuestionnaireStoreRequest;
use App\Http\Requests\Government\AdminQuestionnaireUpdateRequest;
use App\Services\Firebase\AdminQuestionnaireService;

class AdminQuestionnaireController extends Controller
{

    public function __construct(private AdminQuestionnaireService $admin_questionnaire)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $admin_questionnaires = $this->admin_questionnaire->find();
        return view('government.admin_questionnaires.index', ['admin_questionnaires' => $admin_questionnaires]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.admin_questionnaires.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\AdminQuestionnaireStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AdminQuestionnaireStoreRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->admin_questionnaire->store($validated);

        return redirect()
            ->route('government.admin_questionnaires.index')
            ->with('alert.success', '行政投稿（アンケート）情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $document = $this->admin_questionnaire->get($id);
        $snapshot = $document->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        // 利用しやすい形に加工
        $choices = $document->collection('choices')->documents();
        foreach ($choices as $choice) {
            $new_choices[$choice['displayOrder']] = [
                'id' => $choice['id'],
                'choice' => $choice['choice'],
            ];
        }

        return view('government.admin_questionnaires.edit', [
            'snapshot' => $snapshot,
            'choices' => $new_choices,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\AdminQuestionnaireUpdateRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AdminQuestionnaireUpdateRequest $request, string $id)
    {
        $snapshot = $this->admin_questionnaire->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->admin_questionnaire->update($validated, $snapshot);

        return redirect()
            ->route('government.admin_questionnaires.index')
            ->with('alert.success', '行政投稿（アンケート）情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->admin_questionnaire->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->admin_questionnaire->destroy($id);

        return redirect()
            ->route('government.admin_questionnaires.index')
            ->with('alert.success', '行政投稿（アンケート）情報を削除しました。');
    }

}

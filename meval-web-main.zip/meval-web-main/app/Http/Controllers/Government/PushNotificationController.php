<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\PushNotificationRequest;
use App\Services\Firebase\PushNotificationService;
use App\Services\Firebase\MessagingService;

class PushNotificationController extends Controller
{
    public function __construct(private PushNotificationService $push_notification)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $push_notifications = $this->push_notification->find();
        return view('government.push_notifications.index', ['push_notifications' => $push_notifications]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.push_notifications.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\PushNotificationRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PushNotificationRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->push_notification->store($validated);

        // Firebase Push通知(FCM)
        //$this->_push($validated);

        return redirect()
            ->route('government.push_notifications.index')
            ->with('alert.success', 'プッシュ通知を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->push_notification->get($id)->snapshot();
        if (!$snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.push_notifications.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\PushNotificationRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PushNotificationRequest $request, string $id)
    {
        $snapshot = $this->push_notification->get($id)->snapshot();
        if (!$snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->push_notification->update($validated, $snapshot);

        return redirect()
            ->route('government.push_notifications.index')
            ->with('alert.success', 'プッシュ通知を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->push_notification->get($id)->snapshot();
        if (!$snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->push_notification->destroy($id);

        return redirect()
            ->route('government.push_notifications.index')
            ->with('alert.success', 'プッシュ通知を削除しました。');
    }

    /**
     * プッシュ通知を実行
     *
     * @param  \App\Http\Requests\Government\PushNotificationRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function push(Request $request, string $id)
    {
        $snapshot = $this->push_notification->get($id)->snapshot();
        if (!$snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        // 通知ターゲットのトピックを指定(all=全配信)
        $topic = $snapshot['topic'];
        // 通知タイトル
        $title = $snapshot['title'];
        // 通知本文
        $body = $snapshot['body'];

        // Firebase Push通知(FCM)
        $this->push_notification->push($topic, $title, $body);

        return redirect()
            ->route('government.push_notifications.index')
            ->with('alert.success', 'プッシュ通知を送信しました。');
    }
}

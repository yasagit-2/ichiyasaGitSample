<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\AdminAlertRequest;
use App\Services\Firebase\AdminAlertService;

class AdminAlertController extends Controller
{

    public function __construct(private AdminAlertService $admin_alert)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $admin_alerts = $this->admin_alert->find();
        return view('government.admin_alerts.index', ['admin_alerts' => $admin_alerts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.admin_alerts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\AdminAlertRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AdminAlertRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->admin_alert->store($validated);

        return redirect()
            ->route('government.admin_alerts.index')
            ->with('alert.success', '行政投稿（注意）情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->admin_alert->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.admin_alerts.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\AdminAlertRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AdminAlertRequest $request, string $id)
    {
        $snapshot = $this->admin_alert->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->admin_alert->update($validated, $snapshot);

        return redirect()
            ->route('government.admin_alerts.index')
            ->with('alert.success', '行政投稿（注意）情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->admin_alert->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->admin_alert->destroy($id);

        return redirect()
            ->route('government.admin_alerts.index')
            ->with('alert.success', '行政投稿（注意）情報を削除しました。');
    }

}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\MemberNotificationRequest;
use App\Services\Firebase\MemberNotificationService;

class MemberNotificationController extends Controller
{

    public function __construct(private MemberNotificationService $member_notification)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $member_notifications = $this->member_notification->find();
        return view('government.member_notifications.index', ['member_notifications' => $member_notifications]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.member_notifications.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\MemberNotificationRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MemberNotificationRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->member_notification->store($validated);

        return redirect()
            ->route('government.member_notifications.index')
            ->with('alert.success', 'お知らせ情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->member_notification->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.member_notifications.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\MemberNotificationRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(MemberNotificationRequest $request, string $id)
    {
        $snapshot = $this->member_notification->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->member_notification->update($validated, $snapshot);

        return redirect()
            ->route('government.member_notifications.index')
            ->with('alert.success', 'お知らせ情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->member_notification->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->member_notification->destroy($id);

        return redirect()
            ->route('government.member_notifications.index')
            ->with('alert.success', 'お知らせ情報を削除しました。');
    }

}

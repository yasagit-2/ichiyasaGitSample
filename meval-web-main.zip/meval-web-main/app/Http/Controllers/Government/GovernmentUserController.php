<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GovernmentUser;
use App\Http\Requests\Government\GovernmentUserStoreRequest;
use App\Http\Requests\Government\GovernmentUserUpdateRequest;

class GovernmentUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $government_users = GovernmentUser::orderBy('updated_at', 'DESC')->get();
        // if ($request->filled('name')) {
        //     $government_users->where('name', 'like', '%' . $request->name . '%');
        // }
        // if ($request->filled('email')) {
        //     $government_users->where('email', 'like', '%' . $request->email . '%');
        // }
        // $government_users = $government_users->paginate(config('const.default_paginate_number'));

        return response()->view('government.government_users.index', ['government_users' => $government_users]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return response()->view('government.government_users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\GovernmentUserStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GovernmentUserStoreRequest $request)
    {
        $validated = $request->validated();
        \Log::info($validated);

        GovernmentUser::create($validated);

        return redirect()
            ->route('government.government_users.index')
            ->with('alert.success', '行政ユーザーを登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(GovernmentUser $government_user)
    {
        return response()->view('government.government_users.edit', ['government_user' => $government_user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param  \App\Http\Requests\Government\GovernmentUserUpdateRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function update(GovernmentUser $government_user, GovernmentUserUpdateRequest $request)
    {
        $validated = $request->validated();
        \Log::info($validated);

        $government_user->fill($validated)->save();

        return redirect()
            ->route('government.government_users.index')
            ->with('alert.success', '行政ユーザーを更新しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(GovernmentUser $government_user)
    {
        $government_user->delete();
        return back()->with('alert.success', '行政ユーザーを削除しました。');
    }
}

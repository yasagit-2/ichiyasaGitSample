<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\MemberRequest;
use App\Services\Firebase\MemberService;

class MemberController extends Controller
{

    public function __construct(private MemberService $member)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $members = $this->member->find();

        $auth = app('firebase.auth');
        foreach ($members as $member) {
            $auth_members[$member->id()] = $auth->getUser($member->id());
        }

        return view('government.members.index', [
            'members' => $members,
            'auth_members' => $auth_members,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\MemberRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(MemberRequest $request, string $id)
    {
        $snapshot = $this->member->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $auth = app('firebase.auth');
        $auth->updateUser($id, ['disabled' => (bool) $validated['disabled']]);

        return redirect()
            ->route('government.members.index')
            ->with('alert.success', '会員情報を編集しました。');
    }
}

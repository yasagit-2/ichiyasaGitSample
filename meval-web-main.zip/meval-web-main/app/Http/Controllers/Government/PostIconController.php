<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\PostIconStoreRequest;
use App\Http\Requests\Government\PostIconUpdateRequest;
use App\Services\Firebase\PostIconService;

class PostIconController extends Controller
{

    public function __construct(private PostIconService $post_icon)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $post_icons = $this->post_icon->find();
        return view('government.post_icons.index', ['post_icons' => $post_icons]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.post_icons.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\PostIconStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PostIconStoreRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->post_icon->store($validated);

        return redirect()
            ->route('government.post_icons.index')
            ->with('alert.success', '投稿アイコン情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->post_icon->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.post_icons.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\PostIconUpdateRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PostIconUpdateRequest $request, string $id)
    {
        $snapshot = $this->post_icon->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->post_icon->update($validated, $snapshot);

        return redirect()
            ->route('government.post_icons.index')
            ->with('alert.success', '投稿アイコン情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->post_icon->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->post_icon->destroy($id);

        return redirect()
            ->route('government.post_icons.index')
            ->with('alert.success', '投稿アイコン情報を削除しました。');
    }

}

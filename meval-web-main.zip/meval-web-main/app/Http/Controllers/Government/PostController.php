<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\PostRequest;
use App\Services\Firebase\PostService;
use App\Services\Firebase\PostingAlertService;

class PostController extends Controller
{

    public function __construct(private PostService $post)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $posts = $this->post->find();

        // 会員投稿に対する通報数カウント
        $posting_alert = app()->make(PostingAlertService::class);
        foreach ($posts as $post) {
            $posting_alerts[$post->id()] = $posting_alert->find(['post_id' => $post->id()])->size();
        }

        return view('government.posts.index', [
            'posts' => $posts,
            'posting_alerts' => $posting_alerts ?? [],
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\PostRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PostRequest $request, string $id)
    {
        $snapshot = $this->post->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->post->update($validated, $snapshot);

        return redirect()
            ->route('government.posts.index')
            ->with('alert.success', '会員投稿情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->post->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->post->destroy($id);

        return redirect()
            ->route('government.posts.index')
            ->with('alert.success', '会員投稿情報を削除しました。');
    }

}

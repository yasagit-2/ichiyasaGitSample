<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\BaseStoreRequest;
use App\Http\Requests\Government\BaseUpdateRequest;
use App\Services\Firebase\BaseService;
use App\Services\Firebase\TitleService;

class BaseController extends Controller
{

    public function __construct(private BaseService $base)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $bases = $this->base->find();
        return view('government.bases.index', ['bases' => $bases]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $title = app()->make(TitleService::class);
        $titles = $title->find();
        return view('government.bases.create', ['titles' => $titles]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\BaseStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BaseStoreRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->base->store($validated);

        return redirect()
            ->route('government.bases.index')
            ->with('alert.success', '拠点情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $title = app()->make(TitleService::class);
        $titles = $title->find();

        return view('government.bases.edit', [
            'snapshot' => $snapshot,
            'titles' => $titles,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\BaseUpdateRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BaseUpdateRequest $request, string $id)
    {
        $snapshot = $this->base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->base->update($validated, $snapshot);

        return redirect()
            ->route('government.bases.index')
            ->with('alert.success', '拠点情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->base->destroy($id);

        return redirect()
            ->route('government.bases.index')
            ->with('alert.success', '拠点情報を削除しました。');
    }

}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\SettingRequest;
use App\Services\Firebase\SettingService;

class SettingController extends Controller
{
    public function __construct(private SettingService $setting)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $snapshot = $this->setting->get()->snapshot();
        return view('government.settings.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\SettingRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function update(SettingRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $snapshot = $this->setting->get()->snapshot();

        // 既に存在している場合は更新
        if ($snapshot->exists()) {
            $this->setting->update($validated, $snapshot);

        // 存在しない場合は登録
        } else {
            $this->setting->store($validated);
        }

        return redirect()
            ->route('government.settings.edit')
            ->with('alert.success', '設定情報を保存しました。');
    }

}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\SubBaseRequest;
use App\Services\Firebase\SubBaseService;
use App\Services\Firebase\BaseService;

class SubBaseController extends Controller
{

    public function __construct(private SubBaseService $sub_base)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, string $parent_id)
    {
        $base_ref = app()->make(BaseService::class);
        $base = $base_ref->get($parent_id)->snapshot();

        $sub_bases = $this->sub_base->find(['parent_id' => $parent_id]);
        return view('government.bases.sub.index', ['base' => $base, 'sub_bases' => $sub_bases]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request, string $parent_id)
    {
        $base_ref = app()->make(BaseService::class);
        $base = $base_ref->get($parent_id)->snapshot();
        if ($base['publishStatus'] > 0) {
            logger()->error('Document can not create');
            abort(403);
        }

        return view('government.bases.sub.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\SubBaseRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SubBaseRequest $request, string $parent_id)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->sub_base->store($validated);

        return redirect()
            ->route('government.bases.sub.index', $parent_id)
            ->with('alert.success', 'サブ拠点情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->sub_base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }
        if ($snapshot['publishStatus'] > 0) {
            logger()->error('Document can not edit');
            abort(403);
        }

        return view('government.bases.sub.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\SubBaseRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SubBaseRequest $request, string $id)
    {;
        $snapshot = $this->sub_base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }
        if ($snapshot['publishStatus'] > 0) {
            logger()->error('Document can not update');
            abort(403);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->sub_base->update($validated, $snapshot);

        return redirect()
            ->route('government.bases.sub.index', $snapshot['parentRef']->id())
            ->with('alert.success', 'サブ拠点情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->sub_base->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }
        if ($snapshot['publishStatus'] > 0) {
            logger()->error('Document can not destroy');
            abort(403);
        }

        $this->sub_base->destroy($id);

        return redirect()
            ->route('government.bases.sub.index', $snapshot['parentRef']->id())
            ->with('alert.success', 'サブ拠点情報を削除しました。');
    }

}

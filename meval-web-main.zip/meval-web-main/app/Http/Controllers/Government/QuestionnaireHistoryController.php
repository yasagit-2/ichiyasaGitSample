<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Firebase\QuestionnaireHistoryService;
use App\Services\Firebase\AdminQuestionnaireService;

class QuestionnaireHistoryController extends Controller
{

	public function __construct(private AdminQuestionnaireService $admin_questionnaire, private QuestionnaireHistoryService $questionnaire_history)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, string $id)
    {
        $document = $this->admin_questionnaire->get($id);
        $snapshot = $document->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $choices = $document->collection('choices')->documents();
        foreach ($choices as $choice) {
            $new_choices[$choice['id']] = [
                'id' => $choice['id'],
                'choice' => $choice['choice'],
                'displayOrder'=> $choice['displayOrder'],
                'count' => 0,
           ];
        }

        $questionnaire_histories = $this->questionnaire_history->find($id);
        foreach($questionnaire_histories as $questionnaire_history){
            $new_choices[$questionnaire_history['choiceId']]['count']++;
        }

        // ソートキーを指定
        $displayOrders = array_column($new_choices, 'displayOrder');
        // displayOrderの昇順（SORT_ASC）に並び替える.
        array_multisort($displayOrders, SORT_ASC, $new_choices);

        return view('government.admin_questionnaires.questionnaire_histories.index', ['new_choices' => $new_choices ?? []]);
    }

}

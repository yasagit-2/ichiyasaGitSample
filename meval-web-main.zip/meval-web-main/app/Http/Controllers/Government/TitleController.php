<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\TitleRequest;
use App\Services\Firebase\TitleService;
use App\Services\Firebase\BaseService;

class TitleController extends Controller
{

    public function __construct(private TitleService $title)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $titles = $this->title->find();

        $base_ref = app()->make(BaseService::class);
        foreach ($titles as $title) {
            $count_bases[$title->id()] = $base_ref->find(['title_id' => $title->id()])->size();
        }

        return view('government.titles.index', [
            'titles' => $titles,
            'count_bases' => $count_bases,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.titles.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\TitleRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TitleRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->title->store($validated);

        return redirect()
            ->route('government.titles.index')
            ->with('alert.success', '称号情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->title->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        return view('government.titles.edit', ['snapshot' => $snapshot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\TitleRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TitleRequest $request, string $id)
    {
        $snapshot = $this->title->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $validated['id'] = $id;
        $this->title->update($validated, $snapshot);

        return redirect()
            ->route('government.titles.index')
            ->with('alert.success', '称号情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->title->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $base_ref = app()->make(BaseService::class);
        $base_count = $base_ref->find(['title_id' => $snapshot->id()])->size();

        // 紐づく拠点がある場合削除不可
        if ($base_count > 0) {
            logger()->error('Document can not delete');
            abort(403);
        }

        $this->title->destroy($id);

        return redirect()
            ->route('government.titles.index')
            ->with('alert.success', '称号情報を削除しました。');
    }

}

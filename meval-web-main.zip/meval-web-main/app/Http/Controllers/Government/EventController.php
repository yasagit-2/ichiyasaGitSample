<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Government\EventStoreRequest;
use App\Http\Requests\Government\EventUpdateRequest;
use App\Services\Firebase\EventService;
use Carbon\Carbon;

class EventController extends Controller
{

    public function __construct(private EventService $event)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $events = $this->event->find();
        return view('government.events.index', ['events' => $events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('government.events.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Government\EventStoreRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EventStoreRequest $request)
    {
        $validated = $request->validated();
        logger()->info($validated);

        $this->event->store($validated);

        return redirect()
            ->route('government.events.index')
            ->with('alert.success', 'イベント情報を登録しました。');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, string $id)
    {
        $snapshot = $this->event->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $effectivePeriodBegin = parseFromGoogleTimestamp($snapshot['effectivePeriodBegin']);
        if ($effectivePeriodBegin->lte(Carbon::now())) {
            logger()->error('Document can not edit');
            abort(403);
        }

        return view('government.events.edit', [
            'snapshot' => $snapshot,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Government\EventUpdateRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EventUpdateRequest $request, string $id)
    {
        $snapshot = $this->event->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $effectivePeriodBegin = parseFromGoogleTimestamp($snapshot['effectivePeriodBegin']);
        if ($effectivePeriodBegin->lte(Carbon::now())) {
            logger()->error('Document can not update');
            abort(403);
        }

        $validated = $request->validated();
        logger()->info($validated);

        $this->event->update($validated, $snapshot);

        return redirect()
            ->route('government.events.index')
            ->with('alert.success', 'イベント情報を編集しました。');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, string $id)
    {
        $snapshot = $this->event->get($id)->snapshot();
        if (! $snapshot->exists()) {
            logger()->error('Document not exists');
            abort(404);
        }

        $this->event->destroy($id);

        return redirect()
            ->route('government.events.index')
            ->with('alert.success', 'イベント情報を削除しました。');
    }

}

<?php

namespace App\Http\Controllers\Government;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Firebase\ReportService;

class ReportController extends Controller
{

    public function __construct(private ReportService $report)
    {
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $reports = $this->report->find();

        return view('government.reports.index', [
            'reports' => $reports,
        ]);
    }

}

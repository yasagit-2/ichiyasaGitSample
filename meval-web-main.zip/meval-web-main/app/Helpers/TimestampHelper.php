<?php

use Carbon\Carbon;

if (! function_exists('parseFromGoogleTimestamp')) {
    function parseFromGoogleTimestamp(object $timestamp = null): object
    {
        if ($timestamp === null) {
            return Carbon::now();
        }

        return Carbon::parse($timestamp)
            ->setTimezone(config('app.timestamp'));
    }
}

if (! function_exists('formatFromGoogleTimestamp')) {
    function formatFromGoogleTimestamp(object $timestamp = null, string $format = 'Y-m-d'): string
    {
        if ($timestamp === null) {
            return '';
        }
        return Carbon::parse($timestamp)
            ->setTimezone(config('app.timestamp'))
            ->format($format);
    }
}
